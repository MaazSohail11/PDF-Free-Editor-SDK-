import { e3 as k0 } from "./PDFEditor-Bi8pUA0E.js";
const In = {
  utf16le: "utf-16le",
  ucs2: "utf-16le",
  utf16be: "utf-16be"
};
class Ae {
  constructor(e) {
    this.buffer = e, this.view = new DataView(e.buffer, e.byteOffset, e.byteLength), this.pos = 0, this.length = this.buffer.length;
  }
  readString(e, t = "ascii") {
    t = In[t] || t;
    let r = this.readBuffer(e);
    try {
      return new TextDecoder(t).decode(r);
    } catch {
      return r;
    }
  }
  readBuffer(e) {
    return this.buffer.slice(this.pos, this.pos += e);
  }
  readUInt24BE() {
    return (this.readUInt16BE() << 8) + this.readUInt8();
  }
  readUInt24LE() {
    return this.readUInt16LE() + (this.readUInt8() << 16);
  }
  readInt24BE() {
    return (this.readInt16BE() << 8) + this.readUInt8();
  }
  readInt24LE() {
    return this.readUInt16LE() + (this.readInt8() << 16);
  }
}
Ae.TYPES = {
  UInt8: 1,
  UInt16: 2,
  UInt24: 3,
  UInt32: 4,
  Int8: 1,
  Int16: 2,
  Int24: 3,
  Int32: 4,
  Float: 4,
  Double: 8
};
for (let i of Object.getOwnPropertyNames(DataView.prototype))
  if (i.slice(0, 3) === "get") {
    let e = i.slice(3).replace("Ui", "UI");
    e === "Float32" ? e = "Float" : e === "Float64" && (e = "Double");
    let t = Ae.TYPES[e];
    Ae.prototype["read" + e + (t === 1 ? "" : "BE")] = function() {
      const r = this.view[i](this.pos, !1);
      return this.pos += t, r;
    }, t !== 1 && (Ae.prototype["read" + e + "LE"] = function() {
      const r = this.view[i](this.pos, !0);
      return this.pos += t, r;
    });
  }
const kn = new TextEncoder(), gs = new Uint8Array(new Uint16Array([4660]).buffer)[0] == 18;
class kt {
  constructor(e) {
    this.buffer = e, this.view = new DataView(this.buffer.buffer, this.buffer.byteOffset, this.buffer.byteLength), this.pos = 0;
  }
  writeBuffer(e) {
    this.buffer.set(e, this.pos), this.pos += e.length;
  }
  writeString(e, t = "ascii") {
    let r;
    switch (t) {
      case "utf16le":
      case "utf16-le":
      case "ucs2":
        r = vs(e, gs);
        break;
      case "utf16be":
      case "utf16-be":
        r = vs(e, !gs);
        break;
      case "utf8":
        r = kn.encode(e);
        break;
      case "ascii":
        r = En(e);
        break;
      default:
        throw new Error(`Unsupported encoding: ${t}`);
    }
    this.writeBuffer(r);
  }
  writeUInt24BE(e) {
    this.buffer[this.pos++] = e >>> 16 & 255, this.buffer[this.pos++] = e >>> 8 & 255, this.buffer[this.pos++] = e & 255;
  }
  writeUInt24LE(e) {
    this.buffer[this.pos++] = e & 255, this.buffer[this.pos++] = e >>> 8 & 255, this.buffer[this.pos++] = e >>> 16 & 255;
  }
  writeInt24BE(e) {
    e >= 0 ? this.writeUInt24BE(e) : this.writeUInt24BE(e + 16777215 + 1);
  }
  writeInt24LE(e) {
    e >= 0 ? this.writeUInt24LE(e) : this.writeUInt24LE(e + 16777215 + 1);
  }
  fill(e, t) {
    if (t < this.buffer.length)
      this.buffer.fill(e, this.pos, this.pos + t), this.pos += t;
    else {
      const r = new Uint8Array(t);
      r.fill(e), this.writeBuffer(r);
    }
  }
}
function vs(i, e) {
  let t = new Uint16Array(i.length);
  for (let r = 0; r < i.length; r++) {
    let s = i.charCodeAt(r);
    e && (s = s >> 8 | (s & 255) << 8), t[r] = s;
  }
  return new Uint8Array(t.buffer);
}
function En(i) {
  let e = new Uint8Array(i.length);
  for (let t = 0; t < i.length; t++)
    e[t] = i.charCodeAt(t);
  return e;
}
for (let i of Object.getOwnPropertyNames(DataView.prototype))
  if (i.slice(0, 3) === "set") {
    let e = i.slice(3).replace("Ui", "UI");
    e === "Float32" ? e = "Float" : e === "Float64" && (e = "Double");
    let t = Ae.TYPES[e];
    kt.prototype["write" + e + (t === 1 ? "" : "BE")] = function(r) {
      this.view[i](this.pos, r, !1), this.pos += t;
    }, t !== 1 && (kt.prototype["write" + e + "LE"] = function(r) {
      this.view[i](this.pos, r, !0), this.pos += t;
    });
  }
class s0 {
  fromBuffer(e) {
    let t = new Ae(e);
    return this.decode(t);
  }
  toBuffer(e) {
    let t = this.size(e), r = new Uint8Array(t), s = new kt(r);
    return this.encode(s, e), r;
  }
}
class ce extends s0 {
  constructor(e, t = "BE") {
    super(), this.type = e, this.endian = t, this.fn = this.type, this.type[this.type.length - 1] !== "8" && (this.fn += this.endian);
  }
  size() {
    return Ae.TYPES[this.type];
  }
  decode(e) {
    return e[`read${this.fn}`]();
  }
  encode(e, t) {
    return e[`write${this.fn}`](t);
  }
}
const D = new ce("UInt8"), Pn = new ce("UInt16", "BE"), l = Pn;
new ce("UInt16", "LE");
const Tn = new ce("UInt24", "BE"), h0 = Tn;
new ce("UInt24", "LE");
const On = new ce("UInt32", "BE"), v = On;
new ce("UInt32", "LE");
const we = new ce("Int8"), Fn = new ce("Int16", "BE"), E = Fn;
new ce("Int16", "LE");
new ce("Int24", "BE");
new ce("Int24", "LE");
const Dn = new ce("Int32", "BE"), C0 = Dn;
new ce("Int32", "LE");
new ce("Float", "BE");
new ce("Float", "LE");
new ce("Double", "BE");
new ce("Double", "LE");
class E0 extends ce {
  constructor(e, t, r = e >> 1) {
    super(`Int${e}`, t), this._point = 1 << r;
  }
  decode(e) {
    return super.decode(e) / this._point;
  }
  encode(e, t) {
    return super.encode(e, t * this._point | 0);
  }
}
const Bn = new E0(16, "BE"), Ln = Bn;
new E0(16, "LE");
const Mn = new E0(32, "BE"), ve = Mn;
new E0(32, "LE");
function Ze(i, e, t) {
  let r;
  if (typeof i == "number" ? r = i : typeof i == "function" ? r = i.call(t, t) : t && typeof i == "string" ? r = t[i] : e && i instanceof ce && (r = i.decode(e)), isNaN(r))
    throw new Error("Not a fixed size");
  return r;
}
class zr {
  constructor(e = {}) {
    this.enumerable = !0, this.configurable = !0;
    for (let t in e) {
      const r = e[t];
      this[t] = r;
    }
  }
}
class b extends s0 {
  constructor(e, t, r = "count") {
    super(), this.type = e, this.length = t, this.lengthType = r;
  }
  decode(e, t) {
    let r;
    const { pos: s } = e, n = [];
    let a = t;
    if (this.length != null && (r = Ze(this.length, e, t)), this.length instanceof ce && (Object.defineProperties(n, {
      parent: { value: t },
      _startOffset: { value: s },
      _currentOffset: { value: 0, writable: !0 },
      _length: { value: r }
    }), a = n), r == null || this.lengthType === "bytes") {
      const o = r != null ? e.pos + r : t?._length ? t._startOffset + t._length : e.length;
      for (; e.pos < o; )
        n.push(this.type.decode(e, a));
    } else
      for (let o = 0, u = r; o < u; o++)
        n.push(this.type.decode(e, a));
    return n;
  }
  size(e, t, r = !0) {
    if (!e)
      return this.type.size(null, t) * Ze(this.length, null, t);
    let s = 0;
    this.length instanceof ce && (s += this.length.size(), t = { parent: t, pointerSize: 0 });
    for (let n of e)
      s += this.type.size(n, t);
    return t && r && this.length instanceof ce && (s += t.pointerSize), s;
  }
  encode(e, t, r) {
    let s = r;
    this.length instanceof ce && (s = {
      pointers: [],
      startOffset: e.pos,
      parent: r
    }, s.pointerOffset = e.pos + this.size(t, s, !1), this.length.encode(e, t.length));
    for (let n of t)
      this.type.encode(e, n, s);
    if (this.length instanceof ce) {
      let n = 0;
      for (; n < s.pointers.length; ) {
        const a = s.pointers[n++];
        a.type.encode(e, a.val, a.parent);
      }
    }
  }
}
class he extends b {
  decode(e, t) {
    const { pos: r } = e, s = Ze(this.length, e, t);
    this.length instanceof ce && (t = {
      parent: t,
      _startOffset: r,
      _currentOffset: 0,
      _length: s
    });
    const n = new lr(this.type, s, e, t);
    return e.pos += s * this.type.size(null, t), n;
  }
  size(e, t) {
    return e instanceof lr && (e = e.toArray()), super.size(e, t);
  }
  encode(e, t, r) {
    return t instanceof lr && (t = t.toArray()), super.encode(e, t, r);
  }
}
class lr {
  constructor(e, t, r, s) {
    this.type = e, this.length = t, this.stream = r, this.ctx = s, this.base = this.stream.pos, this.items = [];
  }
  get(e) {
    if (!(e < 0 || e >= this.length)) {
      if (this.items[e] == null) {
        const { pos: t } = this.stream;
        this.stream.pos = this.base + this.type.size(null, this.ctx) * e, this.items[e] = this.type.decode(this.stream, this.ctx), this.stream.pos = t;
      }
      return this.items[e];
    }
  }
  toArray() {
    const e = [];
    for (let t = 0, r = this.length; t < r; t++)
      e.push(this.get(t));
    return e;
  }
}
class ze extends s0 {
  constructor(e, t = []) {
    super(), this.type = e, this.flags = t;
  }
  decode(e) {
    const t = this.type.decode(e), r = {};
    for (let s = 0; s < this.flags.length; s++) {
      const n = this.flags[s];
      n != null && (r[n] = !!(t & 1 << s));
    }
    return r;
  }
  size() {
    return this.type.size();
  }
  encode(e, t) {
    let r = 0;
    for (let s = 0; s < this.flags.length; s++) {
      const n = this.flags[s];
      n != null && t[n] && (r |= 1 << s);
    }
    return this.type.encode(e, r);
  }
}
class Ye extends s0 {
  constructor(e) {
    super(), this.length = e;
  }
  decode(e, t) {
    const r = Ze(this.length, e, t);
    return e.readBuffer(r);
  }
  size(e, t) {
    if (!e)
      return Ze(this.length, null, t);
    let r = e.length;
    return this.length instanceof ce && (r += this.length.size()), r;
  }
  encode(e, t, r) {
    return this.length instanceof ce && this.length.encode(e, t.length), e.writeBuffer(t);
  }
}
class Et extends s0 {
  constructor(e, t = !0) {
    super(), this.type = e, this.condition = t;
  }
  decode(e, t) {
    let { condition: r } = this;
    if (typeof r == "function" && (r = r.call(t, t)), r)
      return this.type.decode(e, t);
  }
  size(e, t) {
    let { condition: r } = this;
    return typeof r == "function" && (r = r.call(t, t)), r ? this.type.size(e, t) : 0;
  }
  encode(e, t, r) {
    let { condition: s } = this;
    if (typeof s == "function" && (s = s.call(r, r)), s)
      return this.type.encode(e, t, r);
  }
}
class be extends s0 {
  constructor(e, t = 1) {
    super(), this.type = e, this.count = t;
  }
  decode(e, t) {
    e.pos += this.size(null, t);
  }
  size(e, t) {
    const r = Ze(this.count, null, t);
    return this.type.size() * r;
  }
  encode(e, t, r) {
    return e.fill(0, this.size(t, r));
  }
}
class de extends s0 {
  constructor(e, t = "ascii") {
    super(), this.length = e, this.encoding = t;
  }
  decode(e, t) {
    let r, s, { encoding: n } = this;
    typeof n == "function" && (n = n.call(t, t) || "ascii");
    let a = or(n);
    if (this.length != null)
      r = Ze(this.length, e, t);
    else {
      let u;
      for ({ buffer: u, length: r, pos: s } = e; s < r - a + 1 && (u[s] !== 0 || a === 2 && u[s + 1] !== 0); )
        s += a;
      r = s - e.pos;
    }
    const o = e.readString(r, n);
    return this.length == null && e.pos < e.length && (e.pos += a), o;
  }
  size(e, t) {
    if (e == null)
      return Ze(this.length, null, t);
    let { encoding: r } = this;
    typeof r == "function" && (r = r.call(t?.val, t?.val) || "ascii"), r === "utf16be" && (r = "utf16le");
    let s = xs(e, r);
    return this.length instanceof ce && (s += this.length.size()), this.length == null && (s += or(r)), s;
  }
  encode(e, t, r) {
    let { encoding: s } = this;
    if (typeof s == "function" && (s = s.call(r?.val, r?.val) || "ascii"), this.length instanceof ce && this.length.encode(e, xs(t, s)), e.writeString(t, s), this.length == null)
      return or(s) == 2 ? e.writeUInt16LE(0) : e.writeUInt8(0);
  }
}
function or(i) {
  switch (i) {
    case "ascii":
    case "utf8":
      return 1;
    case "utf16le":
    case "utf16-le":
    case "utf-16be":
    case "utf-16le":
    case "utf16be":
    case "utf16-be":
    case "ucs2":
      return 2;
    default:
      return 1;
  }
}
function xs(i, e) {
  switch (e) {
    case "ascii":
      return i.length;
    case "utf8":
      let t = 0;
      for (let r = 0; r < i.length; r++) {
        let s = i.charCodeAt(r);
        if (s >= 55296 && s <= 56319 && r < i.length - 1) {
          let n = i.charCodeAt(++r);
          (n & 64512) === 56320 ? s = ((s & 1023) << 10) + (n & 1023) + 65536 : r--;
        }
        (s & 4294967168) === 0 ? t++ : (s & 4294965248) === 0 ? t += 2 : (s & 4294901760) === 0 ? t += 3 : (s & 4292870144) === 0 && (t += 4);
      }
      return t;
    case "utf16le":
    case "utf16-le":
    case "utf16be":
    case "utf16-be":
    case "ucs2":
      return i.length * 2;
    default:
      throw new Error("Unknown encoding " + e);
  }
}
class x extends s0 {
  constructor(e = {}) {
    super(), this.fields = e;
  }
  decode(e, t, r = 0) {
    const s = this._setup(e, t, r);
    return this._parseFields(e, s, this.fields), this.process != null && this.process.call(s, e), s;
  }
  _setup(e, t, r) {
    const s = {};
    return Object.defineProperties(s, {
      parent: { value: t },
      _startOffset: { value: e.pos },
      _currentOffset: { value: 0, writable: !0 },
      _length: { value: r }
    }), s;
  }
  _parseFields(e, t, r) {
    for (let n in r) {
      var s;
      const a = r[n];
      typeof a == "function" ? s = a.call(t, t) : s = a.decode(e, t), s !== void 0 && (s instanceof zr ? Object.defineProperty(t, n, s) : t[n] = s), t._currentOffset = e.pos - t._startOffset;
    }
  }
  size(e, t, r = !0) {
    e == null && (e = {});
    const s = {
      parent: t,
      val: e,
      pointerSize: 0
    };
    this.preEncode != null && this.preEncode.call(e);
    let n = 0;
    for (let a in this.fields) {
      const o = this.fields[a];
      o.size != null && (n += o.size(e[a], s));
    }
    return r && (n += s.pointerSize), n;
  }
  encode(e, t, r) {
    let s;
    this.preEncode != null && this.preEncode.call(t, e);
    const n = {
      pointers: [],
      startOffset: e.pos,
      parent: r,
      val: t,
      pointerSize: 0
    };
    n.pointerOffset = e.pos + this.size(t, n, !1);
    for (let o in this.fields)
      s = this.fields[o], s.encode != null && s.encode(e, t[o], n);
    let a = 0;
    for (; a < n.pointers.length; ) {
      const o = n.pointers[a++];
      o.type.encode(e, o.val, o.parent);
    }
  }
}
const Rn = (i, e) => e.reduce((t, r) => t && t[r], i);
class te extends x {
  constructor(e, t = {}) {
    super(), this.type = e, this.versions = t, typeof e == "string" && (this.versionPath = e.split("."));
  }
  decode(e, t, r = 0) {
    const s = this._setup(e, t, r);
    typeof this.type == "string" ? s.version = Rn(t, this.versionPath) : s.version = this.type.decode(e), this.versions.header && this._parseFields(e, s, this.versions.header);
    const n = this.versions[s.version];
    if (n == null)
      throw new Error(`Unknown version ${s.version}`);
    return n instanceof te ? n.decode(e, t) : (this._parseFields(e, s, n), this.process != null && this.process.call(s, e), s);
  }
  size(e, t, r = !0) {
    let s, n;
    if (!e)
      throw new Error("Not a fixed size");
    this.preEncode != null && this.preEncode.call(e);
    const a = {
      parent: t,
      val: e,
      pointerSize: 0
    };
    let o = 0;
    if (typeof this.type != "string" && (o += this.type.size(e.version, a)), this.versions.header)
      for (s in this.versions.header)
        n = this.versions.header[s], n.size != null && (o += n.size(e[s], a));
    const u = this.versions[e.version];
    if (u == null)
      throw new Error(`Unknown version ${e.version}`);
    for (s in u)
      n = u[s], n.size != null && (o += n.size(e[s], a));
    return r && (o += a.pointerSize), o;
  }
  encode(e, t, r) {
    let s, n;
    this.preEncode != null && this.preEncode.call(t, e);
    const a = {
      pointers: [],
      startOffset: e.pos,
      parent: r,
      val: t,
      pointerSize: 0
    };
    if (a.pointerOffset = e.pos + this.size(t, a, !1), typeof this.type != "string" && this.type.encode(e, t.version), this.versions.header)
      for (s in this.versions.header)
        n = this.versions.header[s], n.encode != null && n.encode(e, t[s], a);
    const o = this.versions[t.version];
    for (s in o)
      n = o[s], n.encode != null && n.encode(e, t[s], a);
    let u = 0;
    for (; u < a.pointers.length; ) {
      const c = a.pointers[u++];
      c.type.encode(e, c.val, c.parent);
    }
  }
}
class g extends s0 {
  constructor(e, t, r = {}) {
    if (super(), this.offsetType = e, this.type = t, this.options = r, this.type === "void" && (this.type = null), this.options.type == null && (this.options.type = "local"), this.options.allowNull == null && (this.options.allowNull = !0), this.options.nullValue == null && (this.options.nullValue = 0), this.options.lazy == null && (this.options.lazy = !1), this.options.relativeTo) {
      if (typeof this.options.relativeTo != "function")
        throw new Error("relativeTo option must be a function");
      this.relativeToGetter = r.relativeTo;
    }
  }
  decode(e, t) {
    const r = this.offsetType.decode(e, t);
    if (r === this.options.nullValue && this.options.allowNull)
      return null;
    let s;
    switch (this.options.type) {
      case "local":
        s = t._startOffset;
        break;
      case "immediate":
        s = e.pos - this.offsetType.size();
        break;
      case "parent":
        s = t.parent._startOffset;
        break;
      default:
        for (var n = t; n.parent; )
          n = n.parent;
        s = n._startOffset || 0;
    }
    this.options.relativeTo && (s += this.relativeToGetter(t));
    const a = r + s;
    if (this.type != null) {
      let o = null;
      const u = () => {
        if (o != null)
          return o;
        const { pos: c } = e;
        return e.pos = a, o = this.type.decode(e, t), e.pos = c, o;
      };
      return this.options.lazy ? new zr({
        get: u
      }) : u();
    } else
      return a;
  }
  size(e, t) {
    const r = t;
    switch (this.options.type) {
      case "local":
      case "immediate":
        break;
      case "parent":
        t = t.parent;
        break;
      default:
        for (; t.parent; )
          t = t.parent;
    }
    let { type: s } = this;
    if (s == null) {
      if (!(e instanceof Or))
        throw new Error("Must be a VoidPointer");
      ({ type: s } = e), e = e.value;
    }
    if (e && t) {
      let n = s.size(e, r);
      t.pointerSize += n;
    }
    return this.offsetType.size();
  }
  encode(e, t, r) {
    let s;
    const n = r;
    if (t == null) {
      this.offsetType.encode(e, this.options.nullValue);
      return;
    }
    switch (this.options.type) {
      case "local":
        s = r.startOffset;
        break;
      case "immediate":
        s = e.pos + this.offsetType.size(t, n);
        break;
      case "parent":
        r = r.parent, s = r.startOffset;
        break;
      default:
        for (s = 0; r.parent; )
          r = r.parent;
    }
    this.options.relativeTo && (s += this.relativeToGetter(n.val)), this.offsetType.encode(e, r.pointerOffset - s);
    let { type: a } = this;
    if (a == null) {
      if (!(t instanceof Or))
        throw new Error("Must be a VoidPointer");
      ({ type: a } = t), t = t.value;
    }
    return r.pointers.push({
      type: a,
      val: t,
      parent: n
    }), r.pointerOffset += a.size(t, n);
  }
}
class Or {
  constructor(e, t) {
    this.type = e, this.value = t;
  }
}
function De(i, e, t) {
  return e in i ? Object.defineProperty(i, e, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : i[e] = t, i;
}
function Ie(i, e, t, r) {
  var s = arguments.length, n = s < 3 ? e : r === null ? r = Object.getOwnPropertyDescriptor(e, t) : r, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function") n = Reflect.decorate(i, e, t, r);
  else for (var o = i.length - 1; o >= 0; o--) (a = i[o]) && (n = (s < 3 ? a(n) : s > 3 ? a(e, t, n) : a(e, t)) || n);
  return s > 3 && n && Object.defineProperty(e, t, n), n;
}
var ur, ms;
function Nn() {
  return ms || (ms = 1, ur = function i(e, t) {
    if (e === t) return !0;
    if (e && t && typeof e == "object" && typeof t == "object") {
      if (e.constructor !== t.constructor) return !1;
      var r, s, n;
      if (Array.isArray(e)) {
        if (r = e.length, r != t.length) return !1;
        for (s = r; s-- !== 0; )
          if (!i(e[s], t[s])) return !1;
        return !0;
      }
      if (e.constructor === RegExp) return e.source === t.source && e.flags === t.flags;
      if (e.valueOf !== Object.prototype.valueOf) return e.valueOf() === t.valueOf();
      if (e.toString !== Object.prototype.toString) return e.toString() === t.toString();
      if (n = Object.keys(e), r = n.length, r !== Object.keys(t).length) return !1;
      for (s = r; s-- !== 0; )
        if (!Object.prototype.hasOwnProperty.call(t, n[s])) return !1;
      for (s = r; s-- !== 0; ) {
        var a = n[s];
        if (!i(e[a], t[a])) return !1;
      }
      return !0;
    }
    return e !== e && t !== t;
  }), ur;
}
var Un = Nn();
const ws = /* @__PURE__ */ k0(Un);
var $0 = {}, ys;
function Da() {
  if (ys) return $0;
  ys = 1, $0.byteLength = o, $0.toByteArray = c, $0.fromByteArray = p;
  for (var i = [], e = [], t = typeof Uint8Array < "u" ? Uint8Array : Array, r = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", s = 0, n = r.length; s < n; ++s)
    i[s] = r[s], e[r.charCodeAt(s)] = s;
  e[45] = 62, e[95] = 63;
  function a(m) {
    var C = m.length;
    if (C % 4 > 0)
      throw new Error("Invalid string. Length must be a multiple of 4");
    var O = m.indexOf("=");
    O === -1 && (O = C);
    var G = O === C ? 0 : 4 - O % 4;
    return [O, G];
  }
  function o(m) {
    var C = a(m), O = C[0], G = C[1];
    return (O + G) * 3 / 4 - G;
  }
  function u(m, C, O) {
    return (C + O) * 3 / 4 - O;
  }
  function c(m) {
    var C, O = a(m), G = O[0], L = O[1], T = new t(u(m, G, L)), w = 0, I = L > 0 ? G - 4 : G, h;
    for (h = 0; h < I; h += 4)
      C = e[m.charCodeAt(h)] << 18 | e[m.charCodeAt(h + 1)] << 12 | e[m.charCodeAt(h + 2)] << 6 | e[m.charCodeAt(h + 3)], T[w++] = C >> 16 & 255, T[w++] = C >> 8 & 255, T[w++] = C & 255;
    return L === 2 && (C = e[m.charCodeAt(h)] << 2 | e[m.charCodeAt(h + 1)] >> 4, T[w++] = C & 255), L === 1 && (C = e[m.charCodeAt(h)] << 10 | e[m.charCodeAt(h + 1)] << 4 | e[m.charCodeAt(h + 2)] >> 2, T[w++] = C >> 8 & 255, T[w++] = C & 255), T;
  }
  function d(m) {
    return i[m >> 18 & 63] + i[m >> 12 & 63] + i[m >> 6 & 63] + i[m & 63];
  }
  function f(m, C, O) {
    for (var G, L = [], T = C; T < O; T += 3)
      G = (m[T] << 16 & 16711680) + (m[T + 1] << 8 & 65280) + (m[T + 2] & 255), L.push(d(G));
    return L.join("");
  }
  function p(m) {
    for (var C, O = m.length, G = O % 3, L = [], T = 16383, w = 0, I = O - G; w < I; w += T)
      L.push(f(m, w, w + T > I ? I : w + T));
    return G === 1 ? (C = m[O - 1], L.push(
      i[C >> 2] + i[C << 4 & 63] + "=="
    )) : G === 2 && (C = (m[O - 2] << 8) + m[O - 1], L.push(
      i[C >> 10] + i[C >> 4 & 63] + i[C << 2 & 63] + "="
    )), L.join("");
  }
  return $0;
}
var Gn = Da();
const Vn = /* @__PURE__ */ k0(Gn);
var cr, Cs;
function Ba() {
  if (Cs) return cr;
  Cs = 1;
  var i = 0, e = -3;
  function t() {
    this.table = new Uint16Array(16), this.trans = new Uint16Array(288);
  }
  function r(y, M) {
    this.source = y, this.sourceIndex = 0, this.tag = 0, this.bitcount = 0, this.dest = M, this.destLen = 0, this.ltree = new t(), this.dtree = new t();
  }
  var s = new t(), n = new t(), a = new Uint8Array(30), o = new Uint16Array(30), u = new Uint8Array(30), c = new Uint16Array(30), d = new Uint8Array([
    16,
    17,
    18,
    0,
    8,
    7,
    9,
    6,
    10,
    5,
    11,
    4,
    12,
    3,
    13,
    2,
    14,
    1,
    15
  ]), f = new t(), p = new Uint8Array(320);
  function m(y, M, S, N) {
    var R, H;
    for (R = 0; R < S; ++R) y[R] = 0;
    for (R = 0; R < 30 - S; ++R) y[R + S] = R / S | 0;
    for (H = N, R = 0; R < 30; ++R)
      M[R] = H, H += 1 << y[R];
  }
  function C(y, M) {
    var S;
    for (S = 0; S < 7; ++S) y.table[S] = 0;
    for (y.table[7] = 24, y.table[8] = 152, y.table[9] = 112, S = 0; S < 24; ++S) y.trans[S] = 256 + S;
    for (S = 0; S < 144; ++S) y.trans[24 + S] = S;
    for (S = 0; S < 8; ++S) y.trans[168 + S] = 280 + S;
    for (S = 0; S < 112; ++S) y.trans[176 + S] = 144 + S;
    for (S = 0; S < 5; ++S) M.table[S] = 0;
    for (M.table[5] = 32, S = 0; S < 32; ++S) M.trans[S] = S;
  }
  var O = new Uint16Array(16);
  function G(y, M, S, N) {
    var R, H;
    for (R = 0; R < 16; ++R) y.table[R] = 0;
    for (R = 0; R < N; ++R) y.table[M[S + R]]++;
    for (y.table[0] = 0, H = 0, R = 0; R < 16; ++R)
      O[R] = H, H += y.table[R];
    for (R = 0; R < N; ++R)
      M[S + R] && (y.trans[O[M[S + R]]++] = R);
  }
  function L(y) {
    y.bitcount-- || (y.tag = y.source[y.sourceIndex++], y.bitcount = 7);
    var M = y.tag & 1;
    return y.tag >>>= 1, M;
  }
  function T(y, M, S) {
    if (!M)
      return S;
    for (; y.bitcount < 24; )
      y.tag |= y.source[y.sourceIndex++] << y.bitcount, y.bitcount += 8;
    var N = y.tag & 65535 >>> 16 - M;
    return y.tag >>>= M, y.bitcount -= M, N + S;
  }
  function w(y, M) {
    for (; y.bitcount < 24; )
      y.tag |= y.source[y.sourceIndex++] << y.bitcount, y.bitcount += 8;
    var S = 0, N = 0, R = 0, H = y.tag;
    do
      N = 2 * N + (H & 1), H >>>= 1, ++R, S += M.table[R], N -= M.table[R];
    while (N >= 0);
    return y.tag = H, y.bitcount -= R, M.trans[S + N];
  }
  function I(y, M, S) {
    var N, R, H, ue, re, le;
    for (N = T(y, 5, 257), R = T(y, 5, 1), H = T(y, 4, 4), ue = 0; ue < 19; ++ue) p[ue] = 0;
    for (ue = 0; ue < H; ++ue) {
      var K = T(y, 3, 0);
      p[d[ue]] = K;
    }
    for (G(f, p, 0, 19), re = 0; re < N + R; ) {
      var Q = w(y, f);
      switch (Q) {
        case 16:
          var J = p[re - 1];
          for (le = T(y, 2, 3); le; --le)
            p[re++] = J;
          break;
        case 17:
          for (le = T(y, 3, 3); le; --le)
            p[re++] = 0;
          break;
        case 18:
          for (le = T(y, 7, 11); le; --le)
            p[re++] = 0;
          break;
        default:
          p[re++] = Q;
          break;
      }
    }
    G(M, p, 0, N), G(S, p, N, R);
  }
  function h(y, M, S) {
    for (; ; ) {
      var N = w(y, M);
      if (N === 256)
        return i;
      if (N < 256)
        y.dest[y.destLen++] = N;
      else {
        var R, H, ue, re;
        for (N -= 257, R = T(y, a[N], o[N]), H = w(y, S), ue = y.destLen - T(y, u[H], c[H]), re = ue; re < ue + R; ++re)
          y.dest[y.destLen++] = y.dest[re];
      }
    }
  }
  function W(y) {
    for (var M, S, N; y.bitcount > 8; )
      y.sourceIndex--, y.bitcount -= 8;
    if (M = y.source[y.sourceIndex + 1], M = 256 * M + y.source[y.sourceIndex], S = y.source[y.sourceIndex + 3], S = 256 * S + y.source[y.sourceIndex + 2], M !== (~S & 65535))
      return e;
    for (y.sourceIndex += 4, N = M; N; --N)
      y.dest[y.destLen++] = y.source[y.sourceIndex++];
    return y.bitcount = 0, i;
  }
  function V(y, M) {
    var S = new r(y, M), N, R, H;
    do {
      switch (N = L(S), R = T(S, 2, 0), R) {
        case 0:
          H = W(S);
          break;
        case 1:
          H = h(S, s, n);
          break;
        case 2:
          I(S, S.ltree, S.dtree), H = h(S, S.ltree, S.dtree);
          break;
        default:
          H = e;
      }
      if (H !== i)
        throw new Error("Data error");
    } while (!N);
    return S.destLen < S.dest.length ? typeof S.dest.slice == "function" ? S.dest.slice(0, S.destLen) : S.dest.subarray(0, S.destLen) : S.dest;
  }
  return C(s, n), m(a, o, 4, 3), m(u, c, 2, 1), a[28] = 0, o[28] = 258, cr = V, cr;
}
var fr, Ss;
function zn() {
  if (Ss) return fr;
  Ss = 1;
  const i = new Uint8Array(new Uint32Array([305419896]).buffer)[0] === 18, e = (s, n, a) => {
    let o = s[n];
    s[n] = s[a], s[a] = o;
  }, t = (s) => {
    const n = s.length;
    for (let a = 0; a < n; a += 4)
      e(s, a, a + 3), e(s, a + 1, a + 2);
  };
  return fr = {
    swap32LE: (s) => {
      i && t(s);
    }
  }, fr;
}
var dr, As;
function qn() {
  if (As) return dr;
  As = 1;
  const i = Ba(), { swap32LE: e } = zn(), t = 11, r = 5, s = t - r, n = 65536 >> t, o = (1 << s) - 1, u = 2, d = (1 << r) - 1, f = 65536 >> r, p = 1024 >> r, G = f + p + 32, L = 1 << u;
  class T {
    constructor(I) {
      const h = typeof I.readUInt32BE == "function" && typeof I.slice == "function";
      if (h || I instanceof Uint8Array) {
        let W;
        if (h)
          this.highStart = I.readUInt32LE(0), this.errorValue = I.readUInt32LE(4), W = I.readUInt32LE(8), I = I.slice(12);
        else {
          const V = new DataView(I.buffer);
          this.highStart = V.getUint32(0, !0), this.errorValue = V.getUint32(4, !0), W = V.getUint32(8, !0), I = I.subarray(12);
        }
        I = i(I, new Uint8Array(W)), I = i(I, new Uint8Array(W)), e(I), this.data = new Uint32Array(I.buffer);
      } else
        ({ data: this.data, highStart: this.highStart, errorValue: this.errorValue } = I);
    }
    get(I) {
      let h;
      return I < 0 || I > 1114111 ? this.errorValue : I < 55296 || I > 56319 && I <= 65535 ? (h = (this.data[I >> r] << u) + (I & d), this.data[h]) : I <= 65535 ? (h = (this.data[f + (I - 55296 >> r)] << u) + (I & d), this.data[h]) : I < this.highStart ? (h = this.data[G - n + (I >> t)], h = this.data[h + (I >> r & o)], h = (h << u) + (I & d), this.data[h]) : this.data[this.data.length - L];
    }
  }
  return dr = T, dr;
}
var Wn = qn();
const Gt = /* @__PURE__ */ k0(Wn);
function P0(i) {
  return i && i.__esModule ? i.default : i;
}
var x0 = {};
x0 = JSON.parse('{"categories":["Cc","Zs","Po","Sc","Ps","Pe","Sm","Pd","Nd","Lu","Sk","Pc","Ll","So","Lo","Pi","Cf","No","Pf","Lt","Lm","Mn","Me","Mc","Nl","Zl","Zp","Cs","Co"],"combiningClasses":["Not_Reordered","Above","Above_Right","Below","Attached_Above_Right","Attached_Below","Overlay","Iota_Subscript","Double_Below","Double_Above","Below_Right","Above_Left","CCC10","CCC11","CCC12","CCC13","CCC14","CCC15","CCC16","CCC17","CCC18","CCC19","CCC20","CCC21","CCC22","CCC23","CCC24","CCC25","CCC30","CCC31","CCC32","CCC27","CCC28","CCC29","CCC33","CCC34","CCC35","CCC36","Nukta","Virama","CCC84","CCC91","CCC103","CCC107","CCC118","CCC122","CCC129","CCC130","CCC132","Attached_Above","Below_Left","Left","Kana_Voicing","CCC26","Right"],"scripts":["Common","Latin","Bopomofo","Inherited","Greek","Coptic","Cyrillic","Armenian","Hebrew","Arabic","Syriac","Thaana","Nko","Samaritan","Mandaic","Devanagari","Bengali","Gurmukhi","Gujarati","Oriya","Tamil","Telugu","Kannada","Malayalam","Sinhala","Thai","Lao","Tibetan","Myanmar","Georgian","Hangul","Ethiopic","Cherokee","Canadian_Aboriginal","Ogham","Runic","Tagalog","Hanunoo","Buhid","Tagbanwa","Khmer","Mongolian","Limbu","Tai_Le","New_Tai_Lue","Buginese","Tai_Tham","Balinese","Sundanese","Batak","Lepcha","Ol_Chiki","Braille","Glagolitic","Tifinagh","Han","Hiragana","Katakana","Yi","Lisu","Vai","Bamum","Syloti_Nagri","Phags_Pa","Saurashtra","Kayah_Li","Rejang","Javanese","Cham","Tai_Viet","Meetei_Mayek","null","Linear_B","Lycian","Carian","Old_Italic","Gothic","Old_Permic","Ugaritic","Old_Persian","Deseret","Shavian","Osmanya","Osage","Elbasan","Caucasian_Albanian","Linear_A","Cypriot","Imperial_Aramaic","Palmyrene","Nabataean","Hatran","Phoenician","Lydian","Meroitic_Hieroglyphs","Meroitic_Cursive","Kharoshthi","Old_South_Arabian","Old_North_Arabian","Manichaean","Avestan","Inscriptional_Parthian","Inscriptional_Pahlavi","Psalter_Pahlavi","Old_Turkic","Old_Hungarian","Hanifi_Rohingya","Old_Sogdian","Sogdian","Elymaic","Brahmi","Kaithi","Sora_Sompeng","Chakma","Mahajani","Sharada","Khojki","Multani","Khudawadi","Grantha","Newa","Tirhuta","Siddham","Modi","Takri","Ahom","Dogra","Warang_Citi","Nandinagari","Zanabazar_Square","Soyombo","Pau_Cin_Hau","Bhaiksuki","Marchen","Masaram_Gondi","Gunjala_Gondi","Makasar","Cuneiform","Egyptian_Hieroglyphs","Anatolian_Hieroglyphs","Mro","Bassa_Vah","Pahawh_Hmong","Medefaidrin","Miao","Tangut","Nushu","Duployan","SignWriting","Nyiakeng_Puachue_Hmong","Wancho","Mende_Kikakui","Adlam"],"eaw":["N","Na","A","W","H","F"]}');
const qr = new Gt(Vn.toByteArray("AAARAAAAAADwfAEAZXl5ONRt+/5bPVFZimRfKoTQJNm37CGE7Iw0j3UsTWKsoyI7kwyyTiEUzSD7NiEzhWYijH0wMVkHE4Mx49fzfo+3nuP4/fdZjvv+XNd5n/d9nef1WZvmKhTxiZndzDQBSEYQqxqKwnsKvGQucFh+6t6cJ792ePQBZv5S9yXSwkyjf/P4T7mTNnIAv1dOVhMlR9lflbUL9JeJguqsjvG9NTj/wLb566VAURnLo2vvRi89S3gW/33ihh2eXpDn40BIW7REl/7coRKIhAFlAiOtbLDTt6mMb4GzMF1gNnvX/sBxtbsAIjfztCNcQjcNDtLThRvuXu5M5g/CBjaLBE4lJm4qy/oZD97+IJryApcXfgWYlkvWbhfXgujOJKVu8B+ozqTLbxyJ5kNiR75CxDqfBM9eOlDMmGeoZ0iQbbS5VUplIwI+ZNXEKQVJxlwqjhOY7w3XwPesbLK5JZE+Tt4X8q8km0dzInsPPzbscrjBMVjF5mOHSeRdJVgKUjLTHiHqXSPkep8N/zFk8167KLp75f6RndkvzdfB6Uz3MmqvRArzdCbs1/iRZjYPLLF3U8Qs+H+Rb8iK51a6NIV2V9+07uJsTGFWpPz8J++7iRu2B6eAKlK/kujrLthwaD/7a6J5w90TusnH1JMAc+gNrql4aspOUG/RrsxUKmPzhHgP4Bleru+6Vfc/MBjgXVx7who94nPn7MPFrnwQP7g0k0Dq0h2GSKO6fTZ8nLodN1SiOUj/5EL/Xo1DBvRm0wmrh3x6phcJ20/9CuMr5h8WPqXMSasLoLHoufTmE7mzYrs6B0dY7KjuCogKqsvxnxAwXWvd9Puc9PnE8DOHT2INHxRlIyVHrqZahtfV2E/A2PDdtA3ewlRHMtFIBKO/T4IozWTQZ+mb+gdKuk/ZHrqloucKdsOSJmlWTSntWjcxVMjUmroXLM10I6TwDLnBq4LP69TxgVeyGsd8yHvhF8ydPlrNRSNs9EP7WmeuSE7Lu10JbOuQcJw/63sDp68wB9iwP5AO+mBpV0R5VDDeyQUFCel1G+4KHBgEVFS0YK+m2sXLWLuGTlkVAd97WwKKdacjWElRCuDRauf33l/yVcDF6sVPKeTes99FC1NpNWcpieGSV/IbO8PCTy5pbUR1U8lxzf4T+y6fZMxOz3LshkQLeeDSd0WmUrQgajmbktrxsb2AZ0ACw2Vgni+gV/m+KvCRWLg08Clx7uhql+v9XySGcjjOHlsp8vBw/e8HS7dtiqF6T/XcSXuaMW66GF1g4q9YyBadHqy3Y5jin1c7yZos6BBr6dsomSHxiUHanYtcYQwnMMZhRhOnaYJeyJzaRuukyCUh48+e/BUvk/aEfDp8ag+jD64BHxNnQ5v/E7WRk7eLjGV13I3oqy45YNONi/1op1oDr7rPjkhPsTXgUpQtGDPlIs55KhQaic9kSGs/UrZ2QKQOflB8MTEQxRF9pullToWO7Eplan6mcMRFnUu2441yxi23x+KqKlr7RWWsi9ZXMWlr8vfP3llk1m2PRj0yudccxBuoa7VfIgRmnFPGX6Pm1WIfMm/Rm4n/xTn8IGqA0GWuqgu48pEUO0U9nN+ZdIvFpPb7VDPphIfRZxznlHeVFebkd9l+raXy9BpTMcIUIvBfgHEb6ndGo8VUkxpief14KjzFOcaANfgvFpvyY8lE8lE4raHizLpluPzMks1hx/e1Hok5yV0p7qQH7GaYeMzzZTFvRpv6k6iaJ4yNqzBvN8J7B430h2wFm1IBPcqbou33G7/NWPgopl4Mllla6e24L3TOTVNkza2zv3QKuDWTeDpClCEYgTQ+5vEBSQZs/rMF50+sm4jofTgWLqgX1x3TkrDEVaRqfY/xZizFZ3Y8/DFEFD31VSfBQ5raEB6nHnZh6ddehtclQJ8fBrldyIh99LNnV32HzKEej04hk6SYjdauCa4aYW0ru/QxvQRGzLKOAQszf3ixJypTW3WWL6BLSF2EMCMIw7OUvWBC6A/gDc2D1jvBapMCc7ztx6jYczwTKsRLL6dMNXb83HS8kdD0pTMMj161zbVHkU0mhSHo9SlBDDXdN6hDvRGizmohtIyR3ot8tF5iUG4GLNcXeGvBudSFrHu+bVZb9jirNVG+rQPI51A7Hu8/b0UeaIaZ4UgDO68PkYx3PE2HWpKapJ764Kxt5TFYpywMy4DLQqVRy11I7SOLhxUFmqiEK52NaijWArIfCg6qG8q5eSiwRCJb1R7GDJG74TrYgx/lVq7w9++Kh929xSJEaoSse5fUOQg9nMAnIZv+7fwVRcNv3gOHI46Vb5jYUC66PYHO6lS+TOmvEQjuYmx4RkffYGxqZIp/DPWNHAixbRBc+XKE3JEOgs4jIwu/dSAwhydruOGF39co91aTs85JJ3Z/LpXoF43hUwJsb/M1Chzdn8HX8vLXnqWUKvRhNLpfAF4PTFqva1sBQG0J+59HyYfmQ3oa4/sxZdapVLlo/fooxSXi/dOEQWIWq8E0FkttEyTFXR2aNMPINMIzZwCNEheYTVltsdaLkMyKoEUluPNAYCM2IG3br0DLy0fVNWKHtbSKbBjfiw7Lu06gQFalC7RC9BwRMSpLYDUo9pDtDfzwUiPJKLJ2LGcSphWBadOI/iJjNqUHV7ucG8yC6+iNM9QYElqBR7ECFXrcTgWQ3eG/tCWacT9bxIkfmxPmi3vOd36KxihAJA73vWNJ+Y9oapXNscVSVqS5g15xOWND/WuUCcA9YAAg6WFbjHamrblZ5c0L6Zx1X58ZittGcfDKU697QRSqW/g+RofNRyvrWMrBn44cPvkRe2HdTu/Cq01C5/riWPHZyXPKHuSDDdW8c1XPgd6ogvLh20qEIu8c19sqr4ufyHrwh37ZN5MkvY1dsGmEz9pUBTxWrvvhNyODyX2Q1k/fbX/T/vbHNcBrmjgDtvBdtZrVtiIg5iXQuzO/DEMvRX8Mi1zymSlt92BGILeKItjoShJXE/H7xwnf0Iewb8BFieJ9MflEBCQYEDm8eZniiEPfGoaYiiEdhQxHQNr2AuRdmbL9mcl18Kumh+HEZLp6z+j35ML9zTbUwahUZCyQQOgQrGfdfQtaR/OYJ/9dYXb2TWZFMijfCA8Nov4sa5FFDUe1T68h4q08WDE7JbbDiej4utRMR9ontevxlXv6LuJTXt1YEv8bDzEt683PuSsIN0afvu0rcBu9AbXZbkOG3K3AhtqQ28N23lXm7S3Yn6KXmAhBhz+GeorJJ4XxO/b3vZk2LXp42+QvsVxGSNVpfSctIFMTR1bD9t70i6sfNF3WKz/uKDEDCpzzztwhL45lsw89H2IpWN10sXHRlhDse9KCdpP5qNNpU84cTY+aiqswqR8XZ9ea0KbVRwRuOGQU3csAtV2fSbnq47U6es6rKlWLWhg3s/B9C9g+oTyp6RtIldR51OOkP5/6nSy6itUVPcMNOp4M/hDdKOz3uK6srbdxOrc2cJgr1Sg02oBxxSky6V7JaG+ziNwlfqnjnvh2/uq1lKfbp+qpwq/D/5OI5gkFl5CejKGxfc2YVJfGqc4E0x5e9PHK2ukbHNI7/RZV6LNe65apbTGjoCaQls0txPPbmQbCQn+/upCoXRZy9yzorWJvZ0KWcbXlBxU/d5I4ERUTxMuVWhSMmF677LNN7NnLwsmKawXkCgbrpcluOl0WChR1qhtSrxGXHu251dEItYhYX3snvn1gS2uXuzdTxCJjZtjsip0iT2sDC0qMS7Bk9su2NyXjFK5/f5ZoWwofg3DtTyjaFqspnOOTSh8xK/CKUFS57guVEkw9xoQuRCwwEO9Lu9z2vYxSa9NFV8DvSxv2C4WYLYF8Nrc4DzWkzNsk81JJOlZ/LYJrGCoj4MmZpnf3AXmzxT4rtl9jsqljEyedz468SGKdBiQzyz/qWKEhFg45ZczlZZ3KGL3l6sn+3TTa3zMVMhPa1obGp/z+fvY0QXTrJTf1XAT3EtQdUfYYlmWZyvPZ/6rWwU7UOQei7pVE0osgN94Iy+T1+omE6z4Rh2O20FjgBeK2y1mcoFiMDOJvuZPn5Moy9fmFH3wyfKvn4+TwfLvt/lHTTVnvrtoUWRBiQXhiNM8nE6ZoWeux/Z0b2unRcdUzdDpmL7CAgd1ToRXwgmHTZOgiGtVT+xr1QH9ObebRTT4NzL+XSpLuuWp62GqQvJVTPoZOeJCb6gIwd9XHMftQ+Kc08IKKdKQANSJ1a2gve3JdRhO0+tNiYzWAZfd7isoeBu67W7xuK8WX7nhJURld98Inb0t/dWOSau/kDvV4DJo/cImw9AO2Gvq0F2n0M7yIZKL8amMbjYld+qFls7hq8Acvq97K2PrCaomuUiesu7qNanGupEl6J/iem8lyr/NMnsTr6o41PO0yhQh3hPFN0wJP7S830je9iTBLzUNgYH+gUZpROo3rN2qgCI+6GewpX8w8CH+ro6QrWiStqmcMzVa3vEel+3/dDxMp0rDv1Q6wTMS3K64zTT6RWzK1y643im25Ja7X2ePCV2mTswd/4jshZPo4bLnerqIosq/hy2bKUAmVn9n4oun1+a0DIZ56UhVwmZHdUNpLa8gmPvxS1eNvCF1T0wo1wKPdCJi0qOrWz7oYRTzgTtkzEzZn308XSLwUog4OWGKJzCn/3FfF9iA32dZHSv30pRCM3KBY9WZoRhtdK/ChHk6DEQBsfV6tN2o1Cn0mLtPBfnkS+qy1L2xfFe9TQPtDE1Be44RTl82E9hPT2rS2+93LFbzhQQO3C/hD2jRFH3BWWbasAfuMhRJFcTri73eE835y016s22DjoFJ862WvLj69fu2TgSF3RHia9D5DSitlQAXYCnbdqjPkR287Lh6dCHDapos+eFDvcZPP2edPmTFxznJE/EBLoQQ0Qmn9EkZOyJmHxMbvKYb8o21ZHmv5YLqgsEPk9gWZwYQY9wLqGXuax/8QlV5qDaPbq9pLPT1yp+zOWKmraEy1OUJI7zdEcEmvBpbdwLrDCgEb2xX8S/nxZgjK4bRi+pbOmbh8bEeoPvU/L9ndx9kntlDALbdAvp0O8ZC3zSUnFg4cePsw7jxewWvL7HRSBLUn6J7vTH9uld5N76JFPgBCdXGF221oEJk++XfRwXplLSyrVO7HFWBEs99nTazKveW3HpbD4dH/YmdAl+lwbSt8BQWyTG7jAsACI7bPPUU9hI9XUHWqQOuezHzUjnx5Qqs6T1qNHfTTHleDtmqK7flA9a0gz2nycIpz1FHBuWxKNtUeTdqP29Fb3tv+tl5JyBqXoR+vCsdzZwZUhf6Lu8bvkB9yQP4x7GGegB0ym0Lpl03Q7e+C0cDsm9GSDepCDji7nUslLyYyluPfvLyKaDSX4xpR+nVYQjQQn5F8KbY1gbIVLiK1J3mW90zTyR1bqApX2BlWh7KG8LAY9/S9nWC0XXh9pZZo6xuir12T43rkaGfQssbQyIslA7uJnSHOV22NhlNtUo0czxPAsXhh8tIQYaTM4l/yAlZlydTcXhlG22Gs/n3BxKBd/3ZjYwg3NaUurVXhNB+afVnFfNr9TbC9ksNdvwpNfeHanyJ8M6GrIVfLlYAPv0ILe4dn0Z+BJSbJkN7eZY/c6+6ttDYcIDeUKIDXqUSE42Xdh5nRbuaObozjht0HJ5H1e+em+NJi/+8kQlyjCbJpPckwThZeIF9/u7lrVIKNeJLCN/TpPAeXxvd31/CUDWHK9MuP1V1TJgngzi4V0qzS3SW3Qy5UiGHqg02wQa5tsEl9s/X9nNMosgLlUgZSfCBj1DiypLfhr9/r0nR0XY2tmhDOcUS4E7cqa4EJBhzqvpbZa35Q5Iz5EqmhYiOGDAYk606Tv74+KGfPjKVuP15rIzgW0I7/niOu9el/sn2bRye0gV+GrePDRDMHjwO1lEdeXH8N+UTO3IoN18kpI3tPxz+fY+n2MGMSGFHAx/83tKeJOl+2i+f1O9v6FfEDBbqrw+lpM8Anav7zHNr7hE78nXUtPNodMbCnITWA7Ma/IHlZ50F9hWge/wzOvSbtqFVFtkS8Of2nssjZwbSFdU+VO8z6tCEc9UA9ACxT5zIUeSrkBB/v1krOpm7bVMrGxEKfI6LcnpB4D8bvn2hDKGqKrJaVAJuDaBEY3F7eXyqnFWlOoFV/8ZLspZiZd7orXLhd4mhHQgbuKbHjJWUzrnm0Dxw/LJLzXCkh7slMxKo8uxZIWZfdKHlfI7uj3LP6ARAuWdF7ZmZ7daOKqKGbz5LxOggTgS39oEioYmrqkCeUDvbxkBYKeHhcLmMN8dMF01ZMb32IpL/cH8R7VHQSI5I0YfL14g9d7P/6cjB1JXXxbozEDbsrPdmL8ph7QW10jio+v7YsqHKQ6xrBbOVtxU0/nFfzUGZwIBLwyUvg49ii+54nv9FyECBpURnQK4Ox6N7lw5fsjdd5l/2SwBcAHMJoyjO1Pifye2dagaOwCVMqdJWAo77pvBe0zdJcTWu5fdzPNfV2p1pc7/JKQ8zhKkwsOELUDhXygPJ5oR8Vpk2lsCen3D3QOQp2zdrSZHjVBstDF/wWO98rrkQ6/7zt/Drip7OHIug1lomNdmRaHRrjmqeodn22sesQQPgzimPOMqC60a5+i/UYh51uZm+ijWkkaI2xjrBO2558DZNZMiuDQlaVAvBy2wLn/bR3FrNzfnO/9oDztYqxZrr7JMIhqmrochbqmQnKowxW29bpqTaJu7kW1VotC72QkYX8OoDDdMDwV1kJRk3mufgJBzf+iwFRJ7XWQwO5ujVglgFgHtycWiMLx5N+6XU+TulLabWjOzoao03fniUW0xvIJNPbk7CQlFZd/RCOPvgQbLjh5ITE8NVJeKt3HGr6JTnFdIzcVOlEtwqbIIX0IM7saC+4N5047MTJ9+Wn11EhyEPIlwsHE5utCeXRjQzlrR+R1Cf/qDzcNbqLXdk3J7gQ39VUrrEkS/VMWjjg+t2oYrqB0tUZClcUF6+LBC3EQ7KnGIwm/qjZX4GKPtjTX1zQKV6nPAb2t/Rza5IqKRf8i2DFEhV/YSifX0YwsiF6TQnp48Gr65TFq0zUe6LGjiY7fq0LSGKL1VnC6ESI2yxvt3XqBx53B3gSlGFeJcPbUbonW1E9E9m4NfuwPh+t5QjRxX34lvBPVxwQd7aeTd+r9dw5CiP1pt8wMZoMdni7GapYdo6KPgeQKcmlFfq4UYhvV0IBgeiR3RnTMBaqDqpZrTRyLdsp4l0IXZTdErfH0sN3dqBG5vRIx3VgCYcHmmkqJ8Hyu3s9K9uBD1d8cZUEx3qYcF5vsqeRpF1GOg8emeWM2OmBlWPdZ6qAXwm3nENFyh+kvXk132PfWAlN0kb7yh4fz2T7VWUY/hEXX5DvxGABC03XRpyOG8t/u3Gh5tZdpsSV9AWaxJN7zwhVglgII1gV28tUViyqn4UMdIh5t+Ea2zo7PO48oba0TwQbiSZOH4YhD578kPF3reuaP7LujPMsjHmaDuId9XEaZBCJhbXJbRg5VCk3KJpryH/+8S3wdhR47pdFcmpZG2p0Bpjp/VbvalgIZMllYX5L31aMPdt1J7r/7wbixt0Mnz2ZvNGTARHPVD+2O1D8SGpWXlVnP2ekgon55YiinADDynyaXtZDXueVqbuTi8z8cHHK325pgqM+mWZwzHeEreMvhZopAScXM14SJHpGwZyRljMlDvcMm9FZ/1e9+r/puOnpXOtc9Iu2fmgBfEP9cGW1Fzb1rGlfJ08pACtq1ZW18bf2cevebzVeHbaA50G9qoUp39JWdPHbYkPCRXjt4gzlq3Cxge28Mky8MoS/+On72kc+ZI2xBtgJytpAQHQ1zrEddMIVyR5urX6yBNu8v5lKC8eLdGKTJtbgIZ3ZyTzSfWmx9f+cvcJe8yM39K/djkp2aUTE/9m2Lj5jg7b8vdRAer7DO3SyLNHs1CAm5x5iAdh2yGJYivArZbCBNY88Tw+w+C1Tbt7wK3zl2rzTHo/D8/gb3c3mYrnEIEipYqPUcdWjnTsSw471O3EUN7Gtg4NOAs9PJrxm03VuZKa5xwXAYCjt7Gs01Km6T2DhOYUMoFcCSu7Hk1p3yP1eG+M3v3Q5luAze6WwBnZIYO0TCucPWK+UJ36KoJ8Y+vpavhLO8g5ed704IjlQdfemrMu//EvPYXTQSGIPPfiagJS9nMqP5IvkxN9pvuJz7h8carPXTKMq8jnTeL0STan6dnLTAqwIswcIwWDR2KwbGddAVN8SYWRB7kfBfBRkSXzvHlIF8D6jo64kUzYk5o/n8oLjKqat0rdXvQ86MkwQGMnnlcasqPPT2+mVtUGb32KuH6cyZQenrRG11TArcAl27+nvOMBDe++EKHf4YdyGf7mznzOz33cFFGEcv329p4qG2hoaQ8ULiMyVz6ENcxhoqGnFIdupcn7GICQWuw3yO3W8S33mzCcMYJ8ywc7U7rmaQf/W5K63Gr4bVTpXOyOp4tbaPyIaatBNpXqlmQUTSZXjxPr19+73PSaT+QnI35YsWn6WpfJjRtK8vlJZoTSgjaRU39AGCkWOZtifJrnefCrqwTKDFmuWUCukEsYcRrMzCoit28wYpP7kSVjMD8WJYQiNc2blMjuqYegmf6SsfC1jqz8XzghMlOX+gn/MKZmgljszrmehEa4V98VreJDxYvHr3j7IeJB9/sBZV41BWT/AZAjuC5XorlIPnZgBAniBEhanp0/0+qZmEWDpu8ige1hUPIyTo6T6gDEcFhWSoduNh8YSu65KgMOGBw7VlNYzNIgwHtq9KP2yyTVysqX5v12sf7D+vQUdR2dRDvCV40rIInXSLWT/yrC6ExOQxBJwIDbeZcl3z1yR5Rj3l8IGpxspapnvBL+fwupA3b6fkFceID9wgiM1ILB0cHVdvo/R4xg8yqKXT8efl0GnGX1/27FUYeUW2L/GNRGGWVGp3i91oaJkb4rybENHre9a2P5viz/yqk8ngWUUS+Kv+fu+9BLFnfLiLXOFcIeBJLhnayCiuDRSqcx0Qu68gVsGYc6EHD500Fkt+gpDj6gvr884n8wZ5o6q7xtL5wA0beXQnffWYkZrs2NGIRgQbsc5NB302SVx+R4ROvmgZaR8wBcji128BMfJ9kcvJ4DC+bQ57kRmv5yxgU4ngZfn0/JNZ8JBwxjTqS+s9kjJFG1unGUGLwMiIuXUD9EFhNIJuyCEAmVZSIGKH4G6v1gRR1LyzQKH2ZqiI1DnHMoDEZspbDjTeaFIAbSvjSq3A+n46y9hhVM8wIpnARSXyzmOD96d9UXvFroSPgGw1dq2vdEqDq9fJN1EbL2WulNmHkFDvxSO9ZT/RX/Bw2gA/BrF90XrJACereVfbV/YXaKfp77Nmx5NjEIUlxojsy7iN7nBHSZigfsbFyVOX1ZTeCCxvqnRSExP4lk5ZeYlRu9caaa743TWNdchRIhEWwadsBIe245C8clpaZ4zrPsk+OwXzxWCvRRumyNSLW5KWaSJyJU95cwheK76gr7228spZ3hmTtLyrfM2QRFqZFMR8/Q6yWfVgwTdfX2Ry4w3+eAO/5VT5nFb5NlzXPvBEAWrNZ6Q3jbH0RF4vcbp+fDngf/ywpoyNQtjrfvcq93AVb1RDWRghvyqgI2BkMr1rwYi8gizZ0G9GmPpMeqPerAQ0dJbzx+KAFM4IBq6iSLpZHUroeyfd9o5o+4fR2EtsZBoJORQEA4SW0CmeXSnblx2e9QkCHIodyqV6+g5ETEpZsLqnd/Na60EKPX/tQpPEcO+COIBPcQdszDzSiHGyQFPly/7KciUh1u+mFfxTCHGv9nn2WqndGgeGjQ/kr02qmTBX7Hc1qiEvgiSz1Tz/sy7Es29wvn6FrDGPP7asXlhOaiHxOctPvTptFA1kHFUk8bME7SsTSnGbFbUrssxrq70LhoSh5OwvQna+w84XdXhZb2sloJ4ZsCg3j+PrjJL08/JBi5zGd6ud/ZxhmcGKLOXPcNunQq5ESW92iJvfsuRrNYtawWwSmNhPYoFj2QqWNF0ffLpGt/ad24RJ8vkb5sXkpyKXmvFG5Vcdzf/44k3PBL/ojJ52+kWGzOArnyp5f969oV3J2c4Li27Nkova9VwRNVKqN0V+gV+mTHitgkXV30aWd3A1RSildEleiNPA+5cp+3+T7X+xfHiRZXQ1s4FA9TxIcnveQs9JSZ5r5qNmgqlW4zMtZ6rYNvgmyVcywKtu8ZxnSbS5vXlBV+NXdIfi3+xzrnJ0TkFL+Un8v1PWOC2PPFCjVPq7qTH7mOpzOYj/b4h0ceT+eHgr97Jqhb1ziVfeANzfN8bFUhPKBi7hJBCukQnB0aGjFTYLJPXL26lQ2b80xrOD5cFWgA8hz3St0e69kwNnD3+nX3gy12FjrjO+ddRvvvfyV3SWbXcxqNHfmsb9u1TV+wHTb9B07/L2sB8WUHJ9eeNomDyysEWZ0deqEhH/oWI2oiEh526gvAK1Nx2kIhNvkYR+tPYHEa9j+nd1VBpQP1uzSjIDO+fDDB7uy029rRjDC5Sk6aKczyz1D5uA9Lu+Rrrapl8JXNL3VRllNQH2K1ZFxOpX8LprttfqQ56MbPM0IttUheXWD/mROOeFqGUbL+kUOVlXLTFX/525g4faLEFO4qWWdmOXMNvVjpIVTWt650HfQjX9oT3Dg5Au6+v1/Ci78La6ZOngYCFPT1AUwxQuZ0yt5xKdNXLaDTISMTeCj16XTryhM36K2mfGRIgot71voWs8tTpL/f1rvcwv3LSDf+/G8THCT7NpfHWcW+lsF/ol8q9Bi6MezNTqp0rpp/kJRiVfNrX/w27cRRTu8RIIqtUblBMkxy4jwAVqCjUJkiPBj2cAoVloG8B2/N5deLdMhDb7xs5nhd3dubJhuj8WbaFRyu1L678DHhhA+rMimNo4C1kGpp0tD/qnCfCFHejpf0LJX43OTr578PY0tnIIrlWyNYyuR/ie6j2xNb1OV6u0dOX/1Dtcd7+ya9W+rY2LmnyQMtk8SMLTon8RAdwOaN2tNg5zVnDKlmVeOxPV2vhHIo9QEPV7jc3f+zVDquiNg1OaHX3cZXJDRY5MJpo+VanAcmqp4oasYLG+wrXUL5vJU0kqk2hGEskhP+Jjigrz1l6QnEwp6n8PMVeJp70Ii6ppeaK9GhF6fJE00ceLyxv08tKiPat4QdxZFgSbQknnEiCLD8Qc1rjazVKM3r3gXnnMeONgdz/yFV1q+haaN+wnF3Fn4uYCI9XsKOuVwDD0LsCO/f0gj5cmxCFcr7sclIcefWjvore+3aSU474cyqDVxH7w1RX3CHsaqsMRX17ZLgjsDXws3kLm2XJdM3Ku383UXqaHqsywzPhx7NFir0Fqjym/w6cxD2U9ypa3dx7Z12w/fi3Jps8sqJ8f8Ah8aZAvkHXvIRyrsxK7rrFaNNdNvjI8+3Emri195DCNa858anj2Qdny6Czshkn4N2+1m+k5S8sunX3Ja7I+JutRzg1mc2e9Yc0Zv9PZn1SwhxIdU9sXwZRTd/J5FoUm0e+PYREeHg3oc2YYzGf2xfJxXExt4pT3RfDRHvMXLUmoXOy63xv5pLuhOEax0dRgSywZ/GH+YBXFgCeTU0hZ8SPEFsn8punp1Kurd1KgXxUZ+la3R5+4ePGR4ZF5UQtOa83+Vj8zh80dfzbhxWCeoJnQ4dkZJM4drzknZOOKx2n3WrvJnzFIS8p0xeic+M3ZRVXIp10tV2DyYKwRxLzulPwzHcLlYTxl4PF7v8l106Azr+6wBFejbq/3P72C/0j78cepY9990/d4eAurn2lqdGKLU8FffnMw7cY7pVeXJRMU73Oxwi2g2vh/+4gX8dvbjfojn/eLVhhYl8GthwCQ50KcZq4z2JeW5eeOnJWFQEnVxDoG459TaC4zXybECEoJ0V5q1tXrQbDMtUxeTV6Pdt1/zJuc7TJoV/9YZFWxUtCf6Ou3Vd/vR/vG0138hJQrHkNeoep5dLe+6umcSquKvMaFpm3EZHDBOvCi0XYyIFHMgX7Cqp3JVXlxJFwQfHSaIUEbI2u1lBVUdlNw4Qa9UsLPEK94Qiln3pyKxQVCeNlx8yd7EegVNQBkFLabKvnietYVB4IPZ1fSor82arbgYec8aSdFMaIluYTYuNx32SxfrjKUdPGq+UNp5YpydoEG3xVLixtmHO9zXxKAnHnPuH2fPGrjx0GcuCDEU+yXUtXh6nfUL+cykws1gJ5vkfYFaFBr9PdCXvVf35OJQxzUMmWjv0W6uGJK11uAGDqSpOwCf6rouSIjPVgw57cJCOQ4b9tkI/Y5WNon9Swe72aZryKo8d+HyHBEdWJKrkary0LIGczA4Irq353Wc0Zga3om7UQiAGCvIl8GGyaqz5zH+1gMP5phWUCpKtttWIyicz09vXg76GxkmiGSMQ06Z9X8BUwqOtauDbPIf4rpK/yYoeAHxJ9soXS9VDe1Aw+awOOxaN8foLrif0TXBvQ55dtRtulRq9emFDBxlQcqKCaD8NeTSE7FOHvcjf/+oKbbtRqz9gbofoc2EzQ3pL6W5JdfJzAWmOk8oeoECe90lVMruwl/ltM015P/zIPazqvdvFmLNVHMIZrwiQ2tIKtGh6PDVH+85ew3caqVt2BsDv5rOcu3G9srQWd7NmgtzCRUXLYknYRSwtH9oUtkqyN3CfP20xQ1faXQl4MEmjQehWR6GmGnkdpYNQYeIG408yAX7uCZmYUic9juOfb+Re28+OVOB+scYK4DaPcBe+5wmji9gymtkMpKo4UKqCz7yxzuN8VIlx9yNozpRJpNaWHtaZVEqP45n2JemTlYBSmNIK1FuSYAUQ1yBLnKxevrjayd+h2i8PjdB3YY6b0nr3JuOXGpPMyh4V2dslpR3DFEvgpsBLqhqLDOWP4yEvIL6f21PpA7/8B")), Hn = Math.log2 || ((i) => Math.log(i) / Math.LN2), Vt = (i) => Hn(i) + 1 | 0, $n = Vt((/* @__PURE__ */ P0(x0)).categories.length - 1), La = Vt((/* @__PURE__ */ P0(x0)).combiningClasses.length - 1), Wr = Vt((/* @__PURE__ */ P0(x0)).scripts.length - 1), Hr = Vt((/* @__PURE__ */ P0(x0)).eaw.length - 1), $r = 10, Xn = La + Wr + Hr + $r, jn = Wr + Hr + $r, Yn = Hr + $r, Zn = (1 << $n) - 1, Kn = (1 << La) - 1, Jn = (1 << Wr) - 1;
function zt(i) {
  const e = qr.get(i);
  return (/* @__PURE__ */ P0(x0)).categories[e >> Xn & Zn];
}
function Qn(i) {
  const e = qr.get(i);
  return (/* @__PURE__ */ P0(x0)).combiningClasses[e >> jn & Kn];
}
function Ma(i) {
  const e = qr.get(i);
  return (/* @__PURE__ */ P0(x0)).scripts[e >> Yn & Jn];
}
function Is(i) {
  return zt(i) === "Nd";
}
function Ra(i) {
  const e = zt(i);
  return e === "Mn" || e === "Me" || e === "Mc";
}
var hr, ks;
function _n() {
  if (ks) return hr;
  ks = 1;
  var i = 1, e = 0;
  class t {
    constructor(s) {
      this.stateTable = s.stateTable, this.accepting = s.accepting, this.tags = s.tags;
    }
    /**
     * Returns an iterable object that yields pattern matches over the input sequence.
     * Matches are of the form [startIndex, endIndex, tags].
     */
    match(s) {
      var n = this;
      return {
        *[Symbol.iterator]() {
          for (var a = i, o = null, u = null, c = null, d = 0; d < s.length; d++) {
            var f = s[d];
            c = a, a = n.stateTable[a][f], a === e && (o != null && u != null && u >= o && (yield [o, u, n.tags[c]]), a = n.stateTable[i][f], o = null), a !== e && o == null && (o = d), n.accepting[a] && (u = d), a === e && (a = i);
          }
          o != null && u != null && u >= o && (yield [o, u, n.tags[a]]);
        }
      };
    }
    /**
     * For each match over the input sequence, action functions matching
     * the tag definitions in the input pattern are called with the startIndex,
     * endIndex, and sub-match sequence.
     */
    apply(s, n) {
      for (var [a, o, u] of this.match(s))
        for (var c of u)
          typeof n[c] == "function" && n[c](a, o, s.slice(a, o + 1));
    }
  }
  return hr = t, hr;
}
var ei = _n();
const Na = /* @__PURE__ */ k0(ei);
var pr = { exports: {} }, Es;
function ti() {
  return Es || (Es = 1, (function(i) {
    var e = (function() {
      function t(p, m) {
        return m != null && p instanceof m;
      }
      var r;
      try {
        r = Map;
      } catch {
        r = function() {
        };
      }
      var s;
      try {
        s = Set;
      } catch {
        s = function() {
        };
      }
      var n;
      try {
        n = Promise;
      } catch {
        n = function() {
        };
      }
      function a(p, m, C, O, G) {
        typeof m == "object" && (C = m.depth, O = m.prototype, G = m.includeNonEnumerable, m = m.circular);
        var L = [], T = [], w = typeof Buffer < "u";
        typeof m > "u" && (m = !0), typeof C > "u" && (C = 1 / 0);
        function I(h, W) {
          if (h === null)
            return null;
          if (W === 0)
            return h;
          var V, y;
          if (typeof h != "object")
            return h;
          if (t(h, r))
            V = new r();
          else if (t(h, s))
            V = new s();
          else if (t(h, n))
            V = new n(function(K, Q) {
              h.then(function(J) {
                K(I(J, W - 1));
              }, function(J) {
                Q(I(J, W - 1));
              });
            });
          else if (a.__isArray(h))
            V = [];
          else if (a.__isRegExp(h))
            V = new RegExp(h.source, f(h)), h.lastIndex && (V.lastIndex = h.lastIndex);
          else if (a.__isDate(h))
            V = new Date(h.getTime());
          else {
            if (w && Buffer.isBuffer(h))
              return Buffer.allocUnsafe ? V = Buffer.allocUnsafe(h.length) : V = new Buffer(h.length), h.copy(V), V;
            t(h, Error) ? V = Object.create(h) : typeof O > "u" ? (y = Object.getPrototypeOf(h), V = Object.create(y)) : (V = Object.create(O), y = O);
          }
          if (m) {
            var M = L.indexOf(h);
            if (M != -1)
              return T[M];
            L.push(h), T.push(V);
          }
          t(h, r) && h.forEach(function(K, Q) {
            var J = I(Q, W - 1), _ = I(K, W - 1);
            V.set(J, _);
          }), t(h, s) && h.forEach(function(K) {
            var Q = I(K, W - 1);
            V.add(Q);
          });
          for (var S in h) {
            var N;
            y && (N = Object.getOwnPropertyDescriptor(y, S)), !(N && N.set == null) && (V[S] = I(h[S], W - 1));
          }
          if (Object.getOwnPropertySymbols)
            for (var R = Object.getOwnPropertySymbols(h), S = 0; S < R.length; S++) {
              var H = R[S], ue = Object.getOwnPropertyDescriptor(h, H);
              ue && !ue.enumerable && !G || (V[H] = I(h[H], W - 1), ue.enumerable || Object.defineProperty(V, H, {
                enumerable: !1
              }));
            }
          if (G)
            for (var re = Object.getOwnPropertyNames(h), S = 0; S < re.length; S++) {
              var le = re[S], ue = Object.getOwnPropertyDescriptor(h, le);
              ue && ue.enumerable || (V[le] = I(h[le], W - 1), Object.defineProperty(V, le, {
                enumerable: !1
              }));
            }
          return V;
        }
        return I(p, C);
      }
      a.clonePrototype = function(m) {
        if (m === null)
          return null;
        var C = function() {
        };
        return C.prototype = m, new C();
      };
      function o(p) {
        return Object.prototype.toString.call(p);
      }
      a.__objToStr = o;
      function u(p) {
        return typeof p == "object" && o(p) === "[object Date]";
      }
      a.__isDate = u;
      function c(p) {
        return typeof p == "object" && o(p) === "[object Array]";
      }
      a.__isArray = c;
      function d(p) {
        return typeof p == "object" && o(p) === "[object RegExp]";
      }
      a.__isRegExp = d;
      function f(p) {
        var m = "";
        return p.global && (m += "g"), p.ignoreCase && (m += "i"), p.multiline && (m += "m"), m;
      }
      return a.__getRegExpFlags = f, a;
    })();
    i.exports && (i.exports = e);
  })(pr)), pr.exports;
}
var ri = ti();
const br = /* @__PURE__ */ k0(ri);
var si = Ba();
const ai = /* @__PURE__ */ k0(si);
var X0 = {}, pt = {}, Ps;
function Ts() {
  if (Ps) return pt;
  Ps = 1;
  function i(t) {
    this.buffer = t, this.pos = 0;
  }
  i.prototype.read = function(t, r, s) {
    this.pos + s > this.buffer.length && (s = this.buffer.length - this.pos);
    for (var n = 0; n < s; n++)
      t[r + n] = this.buffer[this.pos + n];
    return this.pos += s, s;
  }, pt.BrotliInput = i;
  function e(t) {
    this.buffer = t, this.pos = 0;
  }
  return e.prototype.write = function(t, r) {
    if (this.pos + r > this.buffer.length)
      throw new Error("Output buffer is not large enough");
    return this.buffer.set(t.subarray(0, r), this.pos), this.pos += r, r;
  }, pt.BrotliOutput = e, pt;
}
var gr, Os;
function ni() {
  if (Os) return gr;
  Os = 1;
  var i = 4096, e = 2 * i + 32, t = 2 * i - 1, r = new Uint32Array([
    0,
    1,
    3,
    7,
    15,
    31,
    63,
    127,
    255,
    511,
    1023,
    2047,
    4095,
    8191,
    16383,
    32767,
    65535,
    131071,
    262143,
    524287,
    1048575,
    2097151,
    4194303,
    8388607,
    16777215
  ]);
  function s(n) {
    this.buf_ = new Uint8Array(e), this.input_ = n, this.reset();
  }
  return s.READ_SIZE = i, s.IBUF_MASK = t, s.prototype.reset = function() {
    this.buf_ptr_ = 0, this.val_ = 0, this.pos_ = 0, this.bit_pos_ = 0, this.bit_end_pos_ = 0, this.eos_ = 0, this.readMoreInput();
    for (var n = 0; n < 4; n++)
      this.val_ |= this.buf_[this.pos_] << 8 * n, ++this.pos_;
    return this.bit_end_pos_ > 0;
  }, s.prototype.readMoreInput = function() {
    if (!(this.bit_end_pos_ > 256))
      if (this.eos_) {
        if (this.bit_pos_ > this.bit_end_pos_)
          throw new Error("Unexpected end of input " + this.bit_pos_ + " " + this.bit_end_pos_);
      } else {
        var n = this.buf_ptr_, a = this.input_.read(this.buf_, n, i);
        if (a < 0)
          throw new Error("Unexpected end of input");
        if (a < i) {
          this.eos_ = 1;
          for (var o = 0; o < 32; o++)
            this.buf_[n + a + o] = 0;
        }
        if (n === 0) {
          for (var o = 0; o < 32; o++)
            this.buf_[(i << 1) + o] = this.buf_[o];
          this.buf_ptr_ = i;
        } else
          this.buf_ptr_ = 0;
        this.bit_end_pos_ += a << 3;
      }
  }, s.prototype.fillBitWindow = function() {
    for (; this.bit_pos_ >= 8; )
      this.val_ >>>= 8, this.val_ |= this.buf_[this.pos_ & t] << 24, ++this.pos_, this.bit_pos_ = this.bit_pos_ - 8 >>> 0, this.bit_end_pos_ = this.bit_end_pos_ - 8 >>> 0;
  }, s.prototype.readBits = function(n) {
    32 - this.bit_pos_ < n && this.fillBitWindow();
    var a = this.val_ >>> this.bit_pos_ & r[n];
    return this.bit_pos_ += n, a;
  }, gr = s, gr;
}
var o0 = {}, vr = {}, xr, Fs;
function ii() {
  return Fs || (Fs = 1, xr = "W5/fcQLn5gKf2XUbAiQ1XULX+TZz6ADToDsgqk6qVfeC0e4m6OO2wcQ1J76ZBVRV1fRkEsdu//62zQsFEZWSTCnMhcsQKlS2qOhuVYYMGCkV0fXWEoMFbESXrKEZ9wdUEsyw9g4bJlEt1Y6oVMxMRTEVbCIwZzJzboK5j8m4YH02qgXYhv1V+PM435sLVxyHJihaJREEhZGqL03txGFQLm76caGO/ovxKvzCby/3vMTtX/459f0igi7WutnKiMQ6wODSoRh/8Lx1V3Q99MvKtwB6bHdERYRY0hStJoMjNeTsNX7bn+Y7e4EQ3bf8xBc7L0BsyfFPK43dGSXpL6clYC/I328h54/VYrQ5i0648FgbGtl837svJ35L3Mot/+nPlNpWgKx1gGXQYqX6n+bbZ7wuyCHKcUok12Xjqub7NXZGzqBx0SD+uziNf87t7ve42jxSKQoW3nyxVrWIGlFShhCKxjpZZ5MeGna0+lBkk+kaN8F9qFBAFgEogyMBdcX/T1W/WnMOi/7ycWUQloEBKGeC48MkiwqJkJO+12eQiOFHMmck6q/IjWW3RZlany23TBm+cNr/84/oi5GGmGBZWrZ6j+zykVozz5fT/QH/Da6WTbZYYPynVNO7kxzuNN2kxKKWche5WveitPKAecB8YcAHz/+zXLjcLzkdDSktNIDwZE9J9X+tto43oJy65wApM3mDzYtCwX9lM+N5VR3kXYo0Z3t0TtXfgBFg7gU8oN0Dgl7fZlUbhNll+0uuohRVKjrEd8egrSndy5/Tgd2gqjA4CAVuC7ESUmL3DZoGnfhQV8uwnpi8EGvAVVsowNRxPudck7+oqAUDkwZopWqFnW1riss0t1z6iCISVKreYGNvQcXv+1L9+jbP8cd/dPUiqBso2q+7ZyFBvENCkkVr44iyPbtOoOoCecWsiuqMSML5lv+vN5MzUr+Dnh73G7Q1YnRYJVYXHRJaNAOByiaK6CusgFdBPE40r0rvqXV7tksKO2DrHYXBTv8P5ysqxEx8VDXUDDqkPH6NNOV/a2WH8zlkXRELSa8P+heNyJBBP7PgsG1EtWtNef6/i+lcayzQwQCsduidpbKfhWUDgAEmyhGu/zVTacI6RS0zTABrOYueemnVa19u9fT23N/Ta6RvTpof5DWygqreCqrDAgM4LID1+1T/taU6yTFVLqXOv+/MuQOFnaF8vLMKD7tKWDoBdALgxF33zQccCcdHx8fKIVdW69O7qHtXpeGr9jbbpFA+qRMWr5hp0s67FPc7HAiLV0g0/peZlW7hJPYEhZyhpSwahnf93/tZgfqZWXFdmdXBzqxGHLrQKxoAY6fRoBhgCRPmmGueYZ5JexTVDKUIXzkG/fqp/0U3hAgQdJ9zumutK6nqWbaqvm1pgu03IYR+G+8s0jDBBz8cApZFSBeuWasyqo2OMDKAZCozS+GWSvL/HsE9rHxooe17U3s/lTE+VZAk4j3dp6uIGaC0JMiqR5CUsabPyM0dOYDR7Ea7ip4USZlya38YfPtvrX/tBlhHilj55nZ1nfN24AOAi9BVtz/Mbn8AEDJCqJgsVUa6nQnSxv2Fs7l/NlCzpfYEjmPrNyib/+t0ei2eEMjvNhLkHCZlci4WhBe7ePZTmzYqlY9+1pxtS4GB+5lM1BHT9tS270EWUDYFq1I0yY/fNiAk4bk9yBgmef/f2k6AlYQZHsNFnW8wBQxCd68iWv7/35bXfz3JZmfGligWAKRjIs3IpzxQ27vAglHSiOzCYzJ9L9A1CdiyFvyR66ucA4jKifu5ehwER26yV7HjKqn5Mfozo7Coxxt8LWWPT47BeMxX8p0Pjb7hZn+6bw7z3Lw+7653j5sI8CLu5kThpMlj1m4c2ch3jGcP1FsT13vuK3qjecKTZk2kHcOZY40UX+qdaxstZqsqQqgXz+QGF99ZJLqr3VYu4aecl1Ab5GmqS8k/GV5b95zxQ5d4EfXUJ6kTS/CXF/aiqKDOT1T7Jz5z0PwDUcwr9clLN1OJGCiKfqvah+h3XzrBOiLOW8wvn8gW6qE8vPxi+Efv+UH55T7PQFVMh6cZ1pZQlzJpKZ7P7uWvwPGJ6DTlR6wbyj3Iv2HyefnRo/dv7dNx+qaa0N38iBsR++Uil7Wd4afwDNsrzDAK4fXZwvEY/jdKuIKXlfrQd2C39dW7ntnRbIp9OtGy9pPBn/V2ASoi/2UJZfS+xuGLH8bnLuPlzdTNS6zdyk8Dt/h6sfOW5myxh1f+zf3zZ3MX/mO9cQPp5pOx967ZA6/pqHvclNfnUFF+rq+Vd7alKr6KWPcIDhpn6v2K6NlUu6LrKo8b/pYpU/Gazfvtwhn7tEOUuXht5rUJdSf6sLjYf0VTYDgwJ81yaqKTUYej/tbHckSRb/HZicwGJqh1mAHB/IuNs9dc9yuvF3D5Xocm3elWFdq5oEy70dYFit79yaLiNjPj5UUcVmZUVhQEhW5V2Z6Cm4HVH/R8qlamRYwBileuh07CbEce3TXa2JmXWBf+ozt319psboobeZhVnwhMZzOeQJzhpTDbP71Tv8HuZxxUI/+ma3XW6DFDDs4+qmpERwHGBd2edxwUKlODRdUWZ/g0GOezrbzOZauFMai4QU6GVHV6aPNBiBndHSsV4IzpvUiiYyg6OyyrL4Dj5q/Lw3N5kAwftEVl9rNd7Jk5PDij2hTH6wIXnsyXkKePxbmHYgC8A6an5Fob/KH5GtC0l4eFso+VpxedtJHdHpNm+Bvy4C79yVOkrZsLrQ3OHCeB0Ra+kBIRldUGlDCEmq2RwXnfyh6Dz+alk6eftI2n6sastRrGwbwszBeDRS/Fa/KwRJkCzTsLr/JCs5hOPE/MPLYdZ1F1fv7D+VmysX6NpOC8aU9F4Qs6HvDyUy9PvFGDKZ/P5101TYHFl8pjj6wm/qyS75etZhhfg0UEL4OYmHk6m6dO192AzoIyPSV9QedDA4Ml23rRbqxMPMxf7FJnDc5FTElVS/PyqgePzmwVZ26NWhRDQ+oaT7ly7ell4s3DypS1s0g+tOr7XHrrkZj9+x/mJBttrLx98lFIaRZzHz4aC7r52/JQ4VjHahY2/YVXZn/QC2ztQb/sY3uRlyc5vQS8nLPGT/n27495i8HPA152z7Fh5aFpyn1GPJKHuPL8Iw94DuW3KjkURAWZXn4EQy89xiKEHN1mk/tkM4gYDBxwNoYvRfE6LFqsxWJtPrDGbsnLMap3Ka3MUoytW0cvieozOmdERmhcqzG+3HmZv2yZeiIeQTKGdRT4HHNxekm1tY+/n06rGmFleqLscSERzctTKM6G9P0Pc1RmVvrascIxaO1CQCiYPE15bD7c3xSeW7gXxYjgxcrUlcbIvO0r+Yplhx0kTt3qafDOmFyMjgGxXu73rddMHpV1wMubyAGcf/v5dLr5P72Ta9lBF+fzMJrMycwv+9vnU3ANIl1cH9tfW7af8u0/HG0vV47jNFXzFTtaha1xvze/s8KMtCYucXc1nzfd/MQydUXn/b72RBt5wO/3jRcMH9BdhC/yctKBIveRYPrNpDWqBsO8VMmP+WvRaOcA4zRMR1PvSoO92rS7pYEv+fZfEfTMzEdM+6X5tLlyxExhqLRkms5EuLovLfx66de5fL2/yX02H52FPVwahrPqmN/E0oVXnsCKhbi/yRxX83nRbUKWhzYceXOntfuXn51NszJ6MO73pQf5Pl4in3ec4JU8hF7ppV34+mm9r1LY0ee/i1O1wpd8+zfLztE0cqBxggiBi5Bu95v9l3r9r/U5hweLn+TbfxowrWDqdJauKd8+q/dH8sbPkc9ttuyO94f7/XK/nHX46MPFLEb5qQlNPvhJ50/59t9ft3LXu7uVaWaO2bDrDCnRSzZyWvFKxO1+vT8MwwunR3bX0CkfPjqb4K9O19tn5X50PvmYpEwHtiW9WtzuV/s76B1zvLLNkViNd8ySxIl/3orfqP90TyTGaf7/rx8jQzeHJXdmh/N6YDvbvmTBwCdxfEQ1NcL6wNMdSIXNq7b1EUzRy1/Axsyk5p22GMG1b+GxFgbHErZh92wuvco0AuOLXct9hvw2nw/LqIcDRRmJmmZzcgUa7JpM/WV/S9IUfbF56TL2orzqwebdRD8nIYNJ41D/hz37Fo11p2Y21wzPcn713qVGhqtevStYfGH4n69OEJtPvbbLYWvscDqc3Hgnu166+tAyLnxrX0Y5zoYjV++1sI7t5kMr02KT/+uwtkc+rZLOf/qn/s3nYCf13Dg8/sB2diJgjGqjQ+TLhxbzyue2Ob7X6/9lUwW7a+lbznHzOYy8LKW1C/uRPbQY3KW/0gO9LXunHLvPL97afba9bFtc9hmz7GAttjVYlCvQAiOwAk/gC5+hkLEs6tr3AZKxLJtOEwk2dLxTYWsIB/j/ToWtIWzo906FrSG8iaqqqqqqiIiIiAgzMzMzNz+AyK+01/zi8n8S+Y1MjoRaQ80WU/G8MBlO+53VPXANrWm4wzGUVZUjjBJZVdhpcfkjsmcWaO+UEldXi1e+zq+HOsCpknYshuh8pOLISJun7TN0EIGW2xTnlOImeecnoGW4raxe2G1T3HEvfYUYMhG+gAFOAwh5nK8mZhwJMmN7r224QVsNFvZ87Z0qatvknklyPDK3Hy45PgVKXji52Wen4d4PlFVVYGnNap+fSpFbK90rYnhUc6n91Q3AY9E0tJOFrcfZtm/491XbcG/jsViUPPX76qmeuiz+qY1Hk7/1VPM405zWVuoheLUimpWYdVzCmUdKHebMdzgrYrb8mL2eeLSnRWHdonfZa8RsOU9F37w+591l5FLYHiOqWeHtE/lWrBHcRKp3uhtr8yXm8LU/5ms+NM6ZKsqu90cFZ4o58+k4rdrtB97NADFbwmEG7lXqvirhOTOqU14xuUF2myIjURcPHrPOQ4lmM3PeMg7bUuk0nnZi67bXsU6H8lhqIo8TaOrEafCO1ARK9PjC0QOoq2BxmMdgYB9G/lIb9++fqNJ2s7BHGFyBNmZAR8J3KCo012ikaSP8BCrf6VI0X5xdnbhHIO+B5rbOyB54zXkzfObyJ4ecwxfqBJMLFc7m59rNcw7hoHnFZ0b00zee+gTqvjm61Pb4xn0kcDX4jvHM0rBXZypG3DCKnD/Waa/ZtHmtFPgO5eETx+k7RrVg3aSwm2YoNXnCs3XPQDhNn+Fia6IlOOuIG6VJH7TP6ava26ehKHQa2T4N0tcZ9dPCGo3ZdnNltsHQbeYt5vPnJezV/cAeNypdml1vCHI8M81nSRP5Qi2+mI8v/sxiZru9187nRtp3f/42NemcONa+4eVC3PCZzc88aZh851CqSsshe70uPxeN/dmYwlwb3trwMrN1Gq8jbnApcVDx/yDPeYs5/7r62tsQ6lLg+DiFXTEhzR9dHqv0iT4tgj825W+H3XiRUNUZT2kR9Ri0+lp+UM3iQtS8uOE23Ly4KYtvqH13jghUntJRAewuzNLDXp8RxdcaA3cMY6TO2IeSFRXezeWIjCqyhsUdMYuCgYTZSKpBype1zRfq8FshvfBPc6BAQWl7/QxIDp3VGo1J3vn42OEs3qznws+YLRXbymyB19a9XBx6n/owcyxlEYyFWCi+kG9F+EyD/4yn80+agaZ9P7ay2Dny99aK2o91FkfEOY8hBwyfi5uwx2y5SaHmG+oq/zl1FX/8irOf8Y3vAcX/6uLP6A6nvMO24edSGPjQc827Rw2atX+z2bKq0CmW9mOtYnr5/AfDa1ZfPaXnKtlWborup7QYx+Or2uWb+N3N//2+yDcXMqIJdf55xl7/vsj4WoPPlxLxtVrkJ4w/tTe3mLdATOOYwxcq52w5Wxz5MbPdVs5O8/lhfE7dPj0bIiPQ3QV0iqm4m3YX8hRfc6jQ3fWepevMqUDJd86Z4vwM40CWHnn+WphsGHfieF02D3tmZvpWD+kBpNCFcLnZhcmmrhpGzzbdA+sQ1ar18OJD87IOKOFoRNznaHPNHUfUNhvY1iU+uhvEvpKHaUn3qK3exVVyX4joipp3um7FmYJWmA+WbIDshRpbVRx5/nqstCgy87FGbfVB8yDGCqS+2qCsnRwnSAN6zgzxfdB2nBT/vZ4/6uxb6oH8b4VBRxiIB93wLa47hG3w2SL/2Z27yOXJFwZpSJaBYyvajA7vRRYNKqljXKpt/CFD/tSMr18DKKbwB0xggBePatl1nki0yvqW5zchlyZmJ0OTxJ3D+fsYJs/mxYN5+Le5oagtcl+YsVvy8kSjI2YGvGjvmpkRS9W2dtXqWnVuxUhURm1lKtou/hdEq19VBp9OjGvHEQSmrpuf2R24mXGheil8KeiANY8fW1VERUfBImb64j12caBZmRViZHbeVMjCrPDg9A90IXrtnsYCuZtRQ0PyrKDjBNOsPfKsg1pA02gHlVr0OXiFhtp6nJqXVzcbfM0KnzC3ggOENPE9VBdmHKN6LYaijb4wXxJn5A0FSDF5j+h1ooZx885Jt3ZKzO5n7Z5WfNEOtyyPqQEnn7WLv5Fis3PdgMshjF1FRydbNyeBbyKI1oN1TRVrVK7kgsb/zjX4NDPIRMctVeaxVB38Vh1x5KbeJbU138AM5KzmZu3uny0ErygxiJF7GVXUrPzFxrlx1uFdAaZFDN9cvIb74qD9tzBMo7L7WIEYK+sla1DVMHpF0F7b3+Y6S+zjvLeDMCpapmJo1weBWuxKF3rOocih1gun4BoJh1kWnV/Jmiq6uOhK3VfKxEHEkafjLgK3oujaPzY6SXg8phhL4TNR1xvJd1Wa0aYFfPUMLrNBDCh4AuGRTbtKMc6Z1Udj8evY/ZpCuMAUefdo69DZUngoqE1P9A3PJfOf7WixCEj+Y6t7fYeHbbxUAoFV3M89cCKfma3fc1+jKRe7MFWEbQqEfyzO2x/wrO2VYH7iYdQ9BkPyI8/3kXBpLaCpU7eC0Yv/am/tEDu7HZpqg0EvHo0nf/R/gRzUWy33/HXMJQeu1GylKmOkXzlCfGFruAcPPhaGqZOtu19zsJ1SO2Jz4Ztth5cBX6mRQwWmDwryG9FUMlZzNckMdK+IoMJv1rOWnBamS2w2KHiaPMPLC15hCZm4KTpoZyj4E2TqC/P6r7/EhnDMhKicZZ1ZwxuC7DPzDGs53q8gXaI9kFTK+2LTq7bhwsTbrMV8Rsfua5lMS0FwbTitUVnVa1yTb5IX51mmYnUcP9wPr8Ji1tiYJeJV9GZTrQhF7vvdU2OTU42ogJ9FDwhmycI2LIg++03C6scYhUyUuMV5tkw6kGUoL+mjNC38+wMdWNljn6tGPpRES7veqrSn5TRuv+dh6JVL/iDHU1db4c9WK3++OrH3PqziF916UMUKn8G67nN60GfWiHrXYhUG3yVWmyYak59NHj8t1smG4UDiWz2rPHNrKnN4Zo1LBbr2/eF9YZ0n0blx2nG4X+EKFxvS3W28JESD+FWk61VCD3z/URGHiJl++7TdBwkCj6tGOH3qDb0QqcOF9Kzpj0HUb/KyFW3Yhj2VMKJqGZleFBH7vqvf7WqLC3XMuHV8q8a4sTFuxUtkD/6JIBvKaVjv96ndgruKZ1k/BHzqf2K9fLk7HGXANyLDd1vxkK/i055pnzl+zw6zLnwXlVYVtfmacJgEpRP1hbGgrYPVN6v2lG+idQNGmwcKXu/8xEj/P6qe/sB2WmwNp6pp8jaISMkwdleFXYK55NHWLTTbutSUqjBfDGWo/Yg918qQ+8BRZSAHZbfuNZz2O0sov1Ue4CWlVg3rFhM3Kljj9ksGd/NUhk4nH+a5UN2+1i8+NM3vRNp7uQ6sqexSCukEVlVZriHNqFi5rLm9TMWa4qm3idJqppQACol2l4VSuvWLfta4JcXy3bROPNbXOgdOhG47LC0CwW/dMlSx4Jf17aEU3yA1x9p+Yc0jupXgcMuYNku64iYOkGToVDuJvlbEKlJqsmiHbvNrIVZEH+yFdF8DbleZ6iNiWwMqvtMp/mSpwx5KxRrT9p3MAPTHGtMbfvdFhyj9vhaKcn3At8Lc16Ai+vBcSp1ztXi7rCJZx/ql7TXcclq6Q76UeKWDy9boS0WHIjUuWhPG8LBmW5y2rhuTpM5vsLt+HOLh1Yf0DqXa9tsfC+kaKt2htA0ai/L2i7RKoNjEwztkmRU0GfgW1TxUvPFhg0V7DdfWJk5gfrccpYv+MA9M0dkGTLECeYwUixRzjRFdmjG7zdZIl3XKB9YliNKI31lfa7i2JG5C8Ss+rHe0D7Z696/V3DEAOWHnQ9yNahMUl5kENWS6pHKKp2D1BaSrrHdE1w2qNxIztpXgUIrF0bm15YML4b6V1k+GpNysTahKMVrrS85lTVo9OGJ96I47eAy5rYWpRf/mIzeoYU1DKaQCTUVwrhHeyNoDqHel+lLxr9WKzhSYw7vrR6+V5q0pfi2k3L1zqkubY6rrd9ZLvSuWNf0uqnkY+FpTvFzSW9Fp0b9l8JA7THV9eCi/PY/SCZIUYx3BU2alj7Cm3VV6eYpios4b6WuNOJdYXUK3zTqj5CVG2FqYM4Z7CuIU0qO05XR0d71FHM0YhZmJmTRfLlXEumN82BGtzdX0S19t1e+bUieK8zRmqpa4Qc5TSjifmaQsY2ETLjhI36gMR1+7qpjdXXHiceUekfBaucHShAOiFXmv3sNmGQyU5iVgnoocuonQXEPTFwslHtS8R+A47StI9wj0iSrtbi5rMysczFiImsQ+bdFClnFjjpXXwMy6O7qfjOr8Fb0a7ODItisjnn3EQO16+ypd1cwyaAW5Yzxz5QknfMO7643fXW/I9y3U2xH27Oapqr56Z/tEzglj6IbT6HEHjopiXqeRbe5mQQvxtcbDOVverN0ZgMdzqRYRjaXtMRd56Q4cZSmdPvZJdSrhJ1D9zNXPqAEqPIavPdfubt5oke2kmv0dztIszSv2VYuoyf1UuopbsYb+uX9h6WpwjpgtZ6fNNawNJ4q8O3CFoSbioAaOSZMx2GYaPYB+rEb6qjQiNRFQ76TvwNFVKD+BhH9VhcKGsXzmMI7BptU/CNWolM7YzROvpFAntsiWJp6eR2d3GarcYShVYSUqhmYOWj5E96NK2WvmYNTeY7Zs4RUEdv9h9QT4EseKt6LzLrqEOs3hxAY1MaNWpSa6zZx8F3YOVeCYMS88W+CYHDuWe4yoc6YK+djDuEOrBR5lvh0r+Q9uM88lrjx9x9AtgpQVNE8r+3O6Gvw59D+kBF/UMXyhliYUtPjmvXGY6Dk3x+kEOW+GtdMVC4EZTqoS/jmR0P0LS75DOc/w2vnri97M4SdbZ8qeU7gg8DVbERkU5geaMQO3mYrSYyAngeUQqrN0C0/vsFmcgWNXNeidsTAj7/4MncJR0caaBUpbLK1yBCBNRjEv6KvuVSdpPnEMJdsRRtqJ+U8tN1gXA4ePHc6ZT0eviI73UOJF0fEZ8YaneAQqQdGphNvwM4nIqPnXxV0xA0fnCT+oAhJuyw/q8jO0y8CjSteZExwBpIN6SvNp6A5G/abi6egeND/1GTguhuNjaUbbnSbGd4L8937Ezm34Eyi6n1maeOBxh3PI0jzJDf5mh/BsLD7F2GOKvlA/5gtvxI3/eV4sLfKW5Wy+oio+es/u6T8UU+nsofy57Icb/JlZHPFtCgd/x+bwt3ZT+xXTtTtTrGAb4QehC6X9G+8YT+ozcLxDsdCjsuOqwPFnrdLYaFc92Ui0m4fr39lYmlCaqTit7G6O/3kWDkgtXjNH4BiEm/+jegQnihOtfffn33WxsFjhfMd48HT+f6o6X65j7XR8WLSHMFkxbvOYsrRsF1bowDuSQ18Mkxk4qz2zoGPL5fu9h2Hqmt1asl3Q3Yu3szOc+spiCmX4AETBM3pLoTYSp3sVxahyhL8eC4mPN9k2x3o0xkiixIzM3CZFzf5oR4mecQ5+ax2wCah3/crmnHoqR0+KMaOPxRif1oEFRFOO/kTPPmtww+NfMXxEK6gn6iU32U6fFruIz8Q4WgljtnaCVTBgWx7diUdshC9ZEa5yKpRBBeW12r/iNc/+EgNqmhswNB8SBoihHXeDF7rrWDLcmt3V8GYYN7pXRy4DZjj4DJuUBL5iC3DQAaoo4vkftqVTYRGLS3mHZ7gdmdTTqbgNN/PTdTCOTgXolc88MhXAEUMdX0iy1JMuk5wLsgeu0QUYlz2S4skTWwJz6pOm/8ihrmgGfFgri+ZWUK2gAPHgbWa8jaocdSuM4FJYoKicYX/ZSENkg9Q1ZzJfwScfVnR2DegOGwCvmogaWJCLQepv9WNlU6QgsmOwICquU28Mlk3d9W5E81lU/5Ez0LcX6lwKMWDNluNKfBDUy/phJgBcMnfkh9iRxrdOzgs08JdPB85Lwo+GUSb4t3nC+0byqMZtO2fQJ4U2zGIr49t/28qmmGv2RanDD7a3FEcdtutkW8twwwlUSpb8QalodddbBfNHKDQ828BdE7OBgFdiKYohLawFYqpybQoxATZrheLhdI7+0Zlu9Q1myRcd15r9UIm8K2LGJxqTegntqNVMKnf1a8zQiyUR1rxoqjiFxeHxqFcYUTHfDu7rhbWng6qOxOsI+5A1p9mRyEPdVkTlE24vY54W7bWc6jMgZvNXdfC9/9q7408KDsbdL7Utz7QFSDetz2picArzrdpL8OaCHC9V26RroemtDZ5yNM/KGkWMyTmfnInEvwtSD23UcFcjhaE3VKzkoaEMKGBft4XbIO6forTY1lmGQwVmKicBCiArDzE+1oIxE08fWeviIOD5TznqH+OoHadvoOP20drMPe5Irg3XBQziW2XDuHYzjqQQ4wySssjXUs5H+t3FWYMHppUnBHMx/nYIT5d7OmjDbgD9F6na3m4l7KdkeSO3kTEPXafiWinogag7b52taiZhL1TSvBFmEZafFq2H8khQaZXuitCewT5FBgVtPK0j4xUHPfUz3Q28eac1Z139DAP23dgki94EC8vbDPTQC97HPPSWjUNG5tWKMsaxAEMKC0665Xvo1Ntd07wCLNf8Q56mrEPVpCxlIMVlQlWRxM3oAfpgIc+8KC3rEXUog5g06vt7zgXY8grH7hhwVSaeuvC06YYRAwpbyk/Unzj9hLEZNs2oxPQB9yc+GnL6zTgq7rI++KDJwX2SP8Sd6YzTuw5lV/kU6eQxRD12omfQAW6caTR4LikYkBB1CMOrvgRr/VY75+NSB40Cni6bADAtaK+vyxVWpf9NeKJxN2KYQ8Q2xPB3K1s7fuhvWbr2XpgW044VD6DRs0qXoqKf1NFsaGvKJc47leUV3pppP/5VTKFhaGuol4Esfjf5zyCyUHmHthChcYh4hYLQF+AFWsuq4t0wJyWgdwQVOZiV0efRHPoK5+E1vjz9wTJmVkITC9oEstAsyZSgE/dbicwKr89YUxKZI+owD205Tm5lnnmDRuP/JnzxX3gMtlrcX0UesZdxyQqYQuEW4R51vmQ5xOZteUd8SJruMlTUzhtVw/Nq7eUBcqN2/HVotgfngif60yKEtoUx3WYOZlVJuJOh8u59fzSDPFYtQgqDUAGyGhQOAvKroXMcOYY0qjnStJR/G3aP+Jt1sLVlGV8POwr/6OGsqetnyF3TmTqZjENfnXh51oxe9qVUw2M78EzAJ+IM8lZ1MBPQ9ZWSVc4J3mWSrLKrMHReA5qdGoz0ODRsaA+vwxXA2cAM4qlfzBJA6581m4hzxItQw5dxrrBL3Y6kCbUcFxo1S8jyV44q//+7ASNNudZ6xeaNOSIUffqMn4A9lIjFctYn2gpEPAb3f7p3iIBN8H14FUGQ9ct2hPsL+cEsTgUrR47uJVN4n4wt/wgfwwHuOnLd4yobkofy8JvxSQTA7rMpDIc608SlZFJfZYcmbT0tAHpPE8MrtQ42siTUNWxqvWZOmvu9f0JPoQmg+6l7sZWwyfi6PXkxJnwBraUG0MYG4zYHQz3igy/XsFkx5tNQxw43qvI9dU3f0DdhOUlHKjmi1VAr2Kiy0HZwD8VeEbhh0OiDdMYspolQsYdSwjCcjeowIXNZVUPmL2wwIkYhmXKhGozdCJ4lRKbsf4NBh/XnQoS92NJEWOVOFs2YhN8c5QZFeK0pRdAG40hqvLbmoSA8xQmzOOEc7wLcme9JOsjPCEgpCwUs9E2DohMHRhUeyGIN6TFvrbny8nDuilsDpzrH5mS76APoIEJmItS67sQJ+nfwddzmjPxcBEBBCw0kWDwd0EZCkNeOD7NNQhtBm7KHL9mRxj6U1yWU2puzlIDtpYxdH4ZPeXBJkTGAJfUr/oTCz/iypY6uXaR2V1doPxJYlrw2ghH0D5gbrhFcIxzYwi4a/4hqVdf2DdxBp6vGYDjavxMAAoy+1+3aiO6S3W/QAKNVXagDtvsNtx7Ks+HKgo6U21B+QSZgIogV5Bt+BnXisdVfy9VyXV+2P5fMuvdpAjM1o/K9Z+XnE4EOCrue+kcdYHqAQ0/Y/OmNlQ6OI33jH/uD1RalPaHpJAm2av0/xtpqdXVKNDrc9F2izo23Wu7firgbURFDNX9eGGeYBhiypyXZft2j3hTvzE6PMWKsod//rEILDkzBXfi7xh0eFkfb3/1zzPK/PI5Nk3FbZyTl4mq5BfBoVoqiPHO4Q4QKZAlrQ3MdNfi3oxIjvsM3kAFv3fdufurqYR3PSwX/mpGy/GFI/B2MNPiNdOppWVbs/gjF3YH+QA9jMhlAbhvasAHstB0IJew09iAkmXHl1/TEj+jvHOpOGrPRQXbPADM+Ig2/OEcUcpgPTItMtW4DdqgfYVI/+4hAFWYjUGpOP/UwNuB7+BbKOcALbjobdgzeBQfjgNSp2GOpxzGLj70Vvq5cw2AoYENwKLUtJUX8sGRox4dVa/TN4xKwaKcl9XawQR/uNus700Hf17pyNnezrUgaY9e4MADhEDBpsJT6y1gDJs1q6wlwGhuUzGR7C8kgpjPyHWwsvrf3yn1zJEIRa5eSxoLAZOCR9xbuztxFRJW9ZmMYfCFJ0evm9F2fVnuje92Rc4Pl6A8bluN8MZyyJGZ0+sNSb//DvAFxC2BqlEsFwccWeAl6CyBcQV1bx4mQMBP1Jxqk1EUADNLeieS2dUFbQ/c/kvwItbZ7tx0st16viqd53WsRmPTKv2AD8CUnhtPWg5aUegNpsYgasaw2+EVooeNKmrW3MFtj76bYHJm5K9gpAXZXsE5U8DM8XmVOSJ1F1WnLy6nQup+jx52bAb+rCq6y9WXl2B2oZDhfDkW7H3oYfT/4xx5VncBuxMXP2lNfhUVQjSSzSRbuZFE4vFawlzveXxaYKVs8LpvAb8IRYF3ZHiRnm0ADeNPWocwxSzNseG7NrSEVZoHdKWqaGEBz1N8Pt7kFbqh3LYmAbm9i1IChIpLpM5AS6mr6OAPHMwwznVy61YpBYX8xZDN/a+lt7n+x5j4bNOVteZ8lj3hpAHSx1VR8vZHec4AHO9XFCdjZ9eRkSV65ljMmZVzaej2qFn/qt1lvWzNZEfHxK3qOJrHL6crr0CRzMox5f2e8ALBB4UGFZKA3tN6F6IXd32GTJXGQ7DTi9j/dNcLF9jCbDcWGKxoKTYblIwbLDReL00LRcDPMcQuXLMh5YzgtfjkFK1DP1iDzzYYVZz5M/kWYRlRpig1htVRjVCknm+h1M5LiEDXOyHREhvzCGpFZjHS0RsK27o2avgdilrJkalWqPW3D9gmwV37HKmfM3F8YZj2ar+vHFvf3B8CRoH4kDHIK9mrAg+owiEwNjjd9V+FsQKYR8czJrUkf7Qoi2YaW6EVDZp5zYlqiYtuXOTHk4fAcZ7qBbdLDiJq0WNV1l2+Hntk1mMWvxrYmc8kIx8G3rW36J6Ra4lLrTOCgiOihmow+YnzUT19jbV2B3RWqSHyxkhmgsBqMYWvOcUom1jDQ436+fcbu3xf2bbeqU/ca+C4DOKE+e3qvmeMqW3AxejfzBRFVcwVYPq4L0APSWWoJu+5UYX4qg5U6YTioqQGPG9XrnuZ/BkxuYpe6Li87+18EskyQW/uA+uk2rpHpr6hut2TlVbKgWkFpx+AZffweiw2+VittkEyf/ifinS/0ItRL2Jq3tQOcxPaWO2xrG68GdFoUpZgFXaP2wYVtRc6xYCfI1CaBqyWpg4bx8OHBQwsV4XWMibZZ0LYjWEy2IxQ1mZrf1/UNbYCJplWu3nZ4WpodIGVA05d+RWSS+ET9tH3RfGGmNI1cIY7evZZq7o+a0bjjygpmR3mVfalkT/SZGT27Q8QGalwGlDOS9VHCyFAIL0a1Q7JiW3saz9gqY8lqKynFrPCzxkU4SIfLc9VfCI5edgRhDXs0edO992nhTKHriREP1NJC6SROMgQ0xO5kNNZOhMOIT99AUElbxqeZF8A3xrfDJsWtDnUenAHdYWSwAbYjFqQZ+D5gi3hNK8CSxU9i6f6ClL9IGlj1OPMQAsr84YG6ijsJpCaGWj75c3yOZKBB9mNpQNPUKkK0D6wgLH8MGoyRxTX6Y05Q4AnYNXMZwXM4eij/9WpsM/9CoRnFQXGR6MEaY+FXvXEO3RO0JaStk6OXuHVATHJE+1W+TU3bSZ2ksMtqjO0zfSJCdBv7y2d8DMx6TfVme3q0ZpTKMMu4YL/t7ciTNtdDkwPogh3Cnjx7qk08SHwf+dksZ7M2vCOlfsF0hQ6J4ehPCaHTNrM/zBSOqD83dBEBCW/F/LEmeh0nOHd7oVl3/Qo/9GUDkkbj7yz+9cvvu+dDAtx8NzCDTP4iKdZvk9MWiizvtILLepysflSvTLFBZ37RLwiriqyRxYv/zrgFd/9XVHh/OmzBvDX4mitMR/lUavs2Vx6cR94lzAkplm3IRNy4TFfu47tuYs9EQPIPVta4P64tV+sZ7n3ued3cgEx2YK+QL5+xms6osk8qQbTyuKVGdaX9FQqk6qfDnT5ykxk0VK7KZ62b6DNDUfQlqGHxSMKv1P0XN5BqMeKG1P4Wp5QfZDUCEldppoX0U6ss2jIko2XpURKCIhfaOqLPfShdtS37ZrT+jFRSH2xYVV1rmT/MBtRQhxiO4MQ3iAGlaZi+9PWBEIXOVnu9jN1f921lWLZky9bqbM3J2MAAI9jmuAx3gyoEUa6P2ivs0EeNv/OR+AX6q5SW6l5HaoFuS6jr6yg9limu+P0KYKzfMXWcQSfTXzpOzKEKpwI3YGXZpSSy2LTlMgfmFA3CF6R5c9xWEtRuCg2ZPUQ2Nb6dRFTNd4TfGHrnEWSKHPuRyiJSDAZ+KX0VxmSHjGPbQTLVpqixia2uyhQ394gBMt7C3ZAmxn/DJS+l1fBsAo2Eir/C0jG9csd4+/tp12pPc/BVJGaK9mfvr7M/CeztrmCO5qY06Edi4xAGtiEhnWAbzLy2VEyazE1J5nPmgU4RpW4Sa0TnOT6w5lgt3/tMpROigHHmexBGAMY0mdcDbDxWIz41NgdD6oxgHsJRgr5RnT6wZAkTOcStU4NMOQNemSO7gxGahdEsC+NRVGxMUhQmmM0llWRbbmFGHzEqLM4Iw0H7577Kyo+Zf+2cUFIOw93gEY171vQaM0HLwpjpdRR6Jz7V0ckE7XzYJ0TmY9znLdzkva0vNrAGGT5SUZ5uaHDkcGvI0ySpwkasEgZPMseYcu85w8HPdSNi+4T6A83iAwDbxgeFcB1ZM2iGXzFcEOUlYVrEckaOyodfvaYSQ7GuB4ISE0nYJc15X/1ciDTPbPCgYJK55VkEor4LvzL9S2WDy4xj+6FOqVyTAC2ZNowheeeSI5hA/02l8UYkv4nk9iaVn+kCVEUstgk5Hyq+gJm6R9vG3rhuM904he/hFmNQaUIATB1y3vw+OmxP4X5Yi6A5I5jJufHCjF9+AGNwnEllZjUco6XhsO5T5+R3yxz5yLVOnAn0zuS+6zdj0nTJbEZCbXJdtpfYZfCeCOqJHoE2vPPFS6eRLjIJlG69X93nfR0mxSFXzp1Zc0lt/VafDaImhUMtbnqWVb9M4nGNQLN68BHP7AR8Il9dkcxzmBv8PCZlw9guY0lurbBsmNYlwJZsA/B15/HfkbjbwPddaVecls/elmDHNW2r4crAx43feNkfRwsaNq/yyJ0d/p5hZ6AZajz7DBfUok0ZU62gCzz7x8eVfJTKA8IWn45vINLSM1q+HF9CV9qF3zP6Ml21kPPL3CXzkuYUlnSqT+Ij4tI/od5KwIs+tDajDs64owN7tOAd6eucGz+KfO26iNcBFpbWA5732bBNWO4kHNpr9D955L61bvHCF/mwSrz6eQaDjfDEANqGMkFc+NGxpKZzCD2sj/JrHd+zlPQ8Iz7Q+2JVIiVCuCKoK/hlAEHzvk/Piq3mRL1rT/fEh9hoT5GJmeYswg1otiKydizJ/fS2SeKHVu6Z3JEHjiW8NaTQgP5xdBli8nC57XiN9hrquBu99hn9zqwo92+PM2JXtpeVZS0PdqR5mDyDreMMtEws+CpwaRyyzoYtfcvt9PJIW0fJVNNi/FFyRsea7peLvJrL+5b4GOXJ8tAr+ATk9f8KmiIsRhqRy0vFzwRV3Z5dZ3QqIU8JQ/uQpkJbjMUMFj2F9sCFeaBjI4+fL/oN3+LQgjI4zuAfQ+3IPIPFQBccf0clJpsfpnBxD84atwtupkGqKvrH7cGNl/QcWcSi6wcVDML6ljOgYbo+2BOAWNNjlUBPiyitUAwbnhFvLbnqw42kR3Yp2kv2dMeDdcGOX5kT4S6M44KHEB/SpCfl7xgsUvs+JNY9G3O2X/6FEt9FyAn57lrbiu+tl83sCymSvq9eZbe9mchL7MTf/Ta78e80zSf0hYY5eUU7+ff14jv7Xy8qjzfzzzvaJnrIdvFb5BLWKcWGy5/w7+vV2cvIfwHqdTB+RuJK5oj9mbt0Hy94AmjMjjwYNZlNS6uiyxNnwNyt3gdreLb64p/3+08nXkb92LTkkRgFOwk1oGEVllcOj5lv1hfAZywDows0944U8vUFw+A/nuVq/UCygsrmWIBnHyU01d0XJPwriEOvx/ISK6Pk4y2w0gmojZs7lU8TtakBAdne4v/aNxmMpK4VcGMp7si0yqsiolXRuOi1Z1P7SqD3Zmp0CWcyK4Ubmp2SXiXuI5nGLCieFHKHNRIlcY3Pys2dwMTYCaqlyWSITwr2oGXvyU3h1Pf8eQ3w1bnD7ilocVjYDkcXR3Oo1BXgMLTUjNw2xMVwjtp99NhSVc5aIWrDQT5DHPKtCtheBP4zHcw4dz2eRdTMamhlHhtfgqJJHI7NGDUw1XL8vsSeSHyKqDtqoAmrQqsYwvwi7HW3ojWyhIa5oz5xJTaq14NAzFLjVLR12rRNUQ6xohDnrWFb5bG9yf8aCD8d5phoackcNJp+Dw3Due3RM+5Rid7EuIgsnwgpX0rUWh/nqPtByMhMZZ69NpgvRTKZ62ViZ+Q7Dp5r4K0d7EfJuiy06KuIYauRh5Ecrhdt2QpTS1k1AscEHvapNbU3HL1F2TFyR33Wxb5MvH5iZsrn3SDcsxlnnshO8PLwmdGN+paWnQuORtZGX37uhFT64SeuPsx8UOokY6ON85WdQ1dki5zErsJGazcBOddWJEKqNPiJpsMD1GrVLrVY+AOdPWQneTyyP1hRX/lMM4ZogGGOhYuAdr7F/DOiAoc++cn5vlf0zkMUJ40Z1rlgv9BelPqVOpxKeOpzKdF8maK+1Vv23MO9k/8+qpLoxrIGH2EDQlnGmH8CD31G8QqlyQIcpmR5bwmSVw9/Ns6IHgulCRehvZ/+VrM60Cu/r3AontFfrljew74skYe2uyn7JKQtFQBQRJ9ryGic/zQOsbS4scUBctA8cPToQ3x6ZBQu6DPu5m1bnCtP8TllLYA0UTQNVqza5nfew3Mopy1GPUwG5jsl0OVXniPmAcmLqO5HG8Hv3nSLecE9oOjPDXcsTxoCBxYyzBdj4wmnyEV4kvFDunipS8SSkvdaMnTBN9brHUR8xdmmEAp/Pdqk9uextp1t+JrtXwpN/MG2w/qhRMpSNxQ1uhg/kKO30eQ/FyHUDkWHT8V6gGRU4DhDMxZu7xXij9Ui6jlpWmQCqJg3FkOTq3WKneCRYZxBXMNAVLQgHXSCGSqNdjebY94oyIpVjMYehAiFx/tqzBXFHZaL5PeeD74rW5OysFoUXY8sebUZleFTUa/+zBKVTFDopTReXNuZq47QjkWnxjirCommO4L/GrFtVV21EpMyw8wyThL5Y59d88xtlx1g1ttSICDwnof6lt/6zliPzgVUL8jWBjC0o2D6Kg+jNuThkAlaDJsq/AG2aKA//A76avw2KNqtv223P+Wq3StRDDNKFFgtsFukYt1GFDWooFVXitaNhb3RCyJi4cMeNjROiPEDb4k+G3+hD8tsg+5hhmSc/8t2JTSwYoCzAI75doq8QTHe+E/Tw0RQSUDlU+6uBeNN3h6jJGX/mH8oj0i3caCNsjvTnoh73BtyZpsflHLq6AfwJNCDX4S98h4+pCOhGKDhV3rtkKHMa3EG4J9y8zFWI4UsfNzC/Rl5midNn7gwoN9j23HGCQQ+OAZpTTPMdiVow740gIyuEtd0qVxMyNXhHcnuXRKdw5wDUSL358ktjMXmAkvIB73BLa1vfF9BAUZInPYJiwxqFWQQBVk7gQH4ojfUQ/KEjn+A/WR6EEe4CtbpoLe1mzHkajgTIoE0SLDHVauKhrq12zrAXBGbPPWKCt4DGedq3JyGRbmPFW32bE7T20+73BatV/qQhhBWfWBFHfhYWXjALts38FemnoT+9bn1jDBMcUMmYgSc0e7GQjv2MUBwLU8ionCpgV+Qrhg7iUIfUY6JFxR0Y+ZTCPM+rVuq0GNLyJXX6nrUTt8HzFBRY1E/FIm2EeVA9NcXrj7S6YYIChVQCWr/m2fYUjC4j0XLkzZ8GCSLfmkW3PB/xq+nlXsKVBOj7vTvqKCOMq7Ztqr3cQ+N8gBnPaAps+oGwWOkbuxnRYj/x/WjiDclVrs22xMK4qArE1Ztk1456kiJriw6abkNeRHogaPRBgbgF9Z8i/tbzWELN4CvbqtrqV9TtGSnmPS2F9kqOIBaazHYaJ9bi3AoDBvlZasMluxt0BDXfhp02Jn411aVt6S4TUB8ZgFDkI6TP6gwPY85w+oUQSsjIeXVminrwIdK2ZAawb8Se6XOJbOaliQxHSrnAeONDLuCnFejIbp4YDtBcQCwMsYiRZfHefuEJqJcwKTTJ8sx5hjHmJI1sPFHOr6W9AhZ2NAod38mnLQk1gOz2LCAohoQbgMbUK9RMEA3LkiF7Sr9tLZp6lkciIGhE2V546w3Mam53VtVkGbB9w0Yk2XiRnCmbpxmHr2k4eSC0RuNbjNsUfDIfc8DZvRvgUDe1IlKdZTzcT4ZGEb53dp8VtsoZlyXzLHOdAbsp1LPTVaHvLA0GYDFMbAW/WUBfUAdHwqLFAV+3uHvYWrCfhUOR2i89qvCBoOb48usAGdcF2M4aKn79k/43WzBZ+xR1L0uZfia70XP9soQReeuhZiUnXFDG1T8/OXNmssTSnYO+3kVLAgeiY719uDwL9FQycgLPessNihMZbAKG7qwPZyG11G1+ZA3jAX2yddpYfmaKBlmfcK/V0mwIRUDC0nJSOPUl2KB8h13F4dlVZiRhdGY5farwN+f9hEb1cRi41ZcGDn6Xe9MMSTOY81ULJyXIHSWFIQHstVYLiJEiUjktlHiGjntN5/btB8Fu+vp28zl2fZXN+dJDyN6EXhS+0yzqpl/LSJNEUVxmu7BsNdjAY0jVsAhkNuuY0E1G48ej25mSt+00yPbQ4SRCVkIwb6ISvYtmJRPz9Zt5dk76blf+lJwAPH5KDF+vHAmACLoCdG2Adii6dOHnNJnTmZtoOGO8Q1jy1veMw6gbLFToQmfJa7nT7Al89mRbRkZZQxJTKgK5Kc9INzmTJFp0tpAPzNmyL/F08bX3nhCumM/cR/2RPn9emZ3VljokttZD1zVWXlUIqEU7SLk5I0lFRU0AcENXBYazNaVzsVHA/sD3o9hm42wbHIRb/BBQTKzAi8s3+bMtpOOZgLdQzCYPfX3UUxKd1WYVkGH7lh/RBBgMZZwXzU9+GYxdBqlGs0LP+DZ5g2BWNh6FAcR944B+K/JTWI3t9YyVyRhlP4CCoUk/mmF7+r2pilVBjxXBHFaBfBtr9hbVn2zDuI0kEOG3kBx8CGdPOjX1ph1POOZJUO1JEGG0jzUy2tK4X0CgVNYhmkqqQysRNtKuPdCJqK3WW57kaV17vXgiyPrl4KEEWgiGF1euI4QkSFHFf0TDroQiLNKJiLbdhH0YBhriRNCHPxSqJmNNoketaioohqMglh6wLtEGWSM1EZbQg72h0UJAIPVFCAJOThpQGGdKfFovcwEeiBuZHN2Ob4uVM7+gwZLz1D9E7ta4RmMZ24OBBAg7Eh6dLXGofZ4U2TFOCQMKjwhVckjrydRS+YaqCw1kYt6UexuzbNEDyYLTZnrY1PzsHZJT4U+awO2xlqTSYu6n/U29O2wPXgGOEKDMSq+zTUtyc8+6iLp0ivav4FKx+xxVy4FxhIF/pucVDqpsVe2jFOfdZhTzLz2QjtzvsTCvDPU7bzDH2eXVKUV9TZ+qFtaSSxnYgYdXKwVreIgvWhT9eGDB2OvnWyPLfIIIfNnfIxU8nW7MbcH05nhlsYtaW9EZRsxWcKdEqInq1DiZPKCz7iGmAU9/ccnnQud2pNgIGFYOTAWjhIrd63aPDgfj8/sdlD4l+UTlcxTI9jbaMqqN0gQxSHs60IAcW3cH4p3V1aSciTKB29L1tz2eUQhRiTgTvmqc+sGtBNh4ky0mQJGsdycBREP+fAaSs1EREDVo5gvgi5+aCN7NECw30owbCc1mSpjiahyNVwJd1jiGgzSwfTpzf2c5XJvG/g1n0fH88KHNnf+u7ZiRMlXueSIsloJBUtW9ezvsx9grfsX/FNxnbxU1Lvg0hLxixypHKGFAaPu0xCD8oDTeFSyfRT6s8109GMUZL8m2xXp8X2dpPCWWdX84iga4BrTlOfqox4shqEgh/Ht4qRst52cA1xOIUuOxgfUivp6v5f8IVyaryEdpVk72ERAwdT4aoY1usBgmP+0m06Q216H/nubtNYxHaOIYjcach3A8Ez/zc0KcShhel0HCYjFsA0FjYqyJ5ZUH1aZw3+zWC0hLpM6GDfcAdn9fq2orPmZbW6XXrf+Krc9RtvII5jeD3dFoT1KwZJwxfUMvc5KLfn8rROW23Jw89sJ2a5dpB3qWDUBWF2iX8OCuKprHosJ2mflBR+Wqs86VvgI/XMnsqb97+VlKdPVysczPj8Jhzf+WCvGBHijAqYlavbF60soMWlHbvKT+ScvhprgeTln51xX0sF+Eadc/l2s2a5BgkVbHYyz0E85p0LstqH+gEGiR84nBRRFIn8hLSZrGwqjZ3E29cuGi+5Z5bp7EM8MWFa9ssS/vy4VrDfECSv7DSU84DaP0sXI3Ap4lWznQ65nQoTKRWU30gd7Nn8ZowUvGIx4aqyXGwmA/PB4qN8msJUODezUHEl0VP9uo+cZ8vPFodSIB4C7lQYjEFj8yu49C2KIV3qxMFYTevG8KqAr0TPlkbzHHnTpDpvpzziAiNFh8xiT7C/TiyH0EguUw4vxAgpnE27WIypV+uFN2zW7xniF/n75trs9IJ5amB1zXXZ1LFkJ6GbS/dFokzl4cc2mamVwhL4XU0Av5gDWAl+aEWhAP7t2VIwU+EpvfOPDcLASX7H7lZpXA2XQfbSlD4qU18NffNPoAKMNSccBfO9YVVgmlW4RydBqfHAV7+hrZ84WJGho6bNT0YMhxxLdOx/dwGj0oyak9aAkNJ8lRJzUuA8sR+fPyiyTgUHio5+Pp+YaKlHrhR41jY5NESPS3x+zTMe0S2HnLOKCOQPpdxKyviBvdHrCDRqO+l96HhhNBLXWv4yEMuEUYo8kXnYJM8oIgVM4XJ+xXOev4YbWeqsvgq0lmw4/PiYr9sYLt+W5EAuYSFnJEan8CwJwbtASBfLBBpJZiRPor/aCJBZsM+MhvS7ZepyHvU8m5WSmaZnxuLts8ojl6KkS8oSAHkq5GWlCB/NgJ5W3rO2Cj1MK7ahxsCrbTT3a0V/QQH+sErxV4XUWDHx0kkFy25bPmBMBQ6BU3HoHhhYcJB9JhP6NXUWKxnE0raXHB6U9KHpWdQCQI72qevp5fMzcm+AvC85rsynVQhruDA9fp9COe7N56cg1UKGSas89vrN+WlGLYTwi5W+0xYdKEGtGCeNJwXKDU0XqU5uQYnWsMwTENLGtbQMvoGjIFIEMzCRal4rnBAg7D/CSn8MsCvS+FDJJAzoiioJEhZJgAp9n2+1Yznr7H+6eT4YkJ9Mpj60ImcW4i4iHDLn9RydB8dx3QYm3rsX6n4VRrZDsYK6DCGwkwd5n3/INFEpk16fYpP6JtMQpqEMzcOfQGAHXBTEGzuLJ03GYQL9bmV2/7ExDlRf+Uvf1sM2frRtCWmal12pMgtonvSCtR4n1CLUZRdTHDHP1Otwqd+rcdlavnKjUB/OYXQHUJzpNyFoKpQK+2OgrEKpGyIgIBgn2y9QHnTJihZOpEvOKIoHAMGAXHmj21Lym39Mbiow4IF+77xNuewziNVBxr6KD5e+9HzZSBIlUa/AmsDFJFXeyrQakR3FwowTGcADJHcEfhGkXYNGSYo4dh4bxwLM+28xjiqkdn0/3R4UEkvcBrBfn/SzBc1XhKM2VPlJgKSorjDac96V2UnQYXl1/yZPT4DVelgO+soMjexXwYO58VLl5xInQUZI8jc3H2CPnCNb9X05nOxIy4MlecasTqGK6s2az4RjpF2cQP2G28R+7wDPsZDZC/kWtjdoHC7SpdPmqQrUAhMwKVuxCmYTiD9q/O7GHtZvPSN0CAUQN/rymXZNniYLlJDE70bsk6Xxsh4kDOdxe7A2wo7P9F5YvqqRDI6brf79yPCSp4I0jVoO4YnLYtX5nzspR5WB4AKOYtR1ujXbOQpPyYDvfRE3FN5zw0i7reehdi7yV0YDRKRllGCGRk5Yz+Uv1fYl2ZwrnGsqsjgAVo0xEUba8ohjaNMJNwTwZA/wBDWFSCpg1eUH8MYL2zdioxRTqgGQrDZxQyNzyBJPXZF0+oxITJAbj7oNC5JwgDMUJaM5GqlGCWc//KCIrI+aclEe4IA0uzv7cuj6GCdaJONpi13O544vbtIHBF+A+JeDFUQNy61Gki3rtyQ4aUywn6ru314/dkGiP8Iwjo0J/2Txs49ZkwEl4mx+iYUUO55I6pJzU4P+7RRs+DXZkyKUYZqVWrPF4I94m4Wx1tXeE74o9GuX977yvJ/jkdak8+AmoHVjI15V+WwBdARFV2IPirJgVMdsg1Pez2VNHqa7EHWdTkl3XTcyjG9BiueWFvQfXI8aWSkuuRmqi/HUuzqyvLJfNfs0txMqldYYflWB1BS31WkuPJGGwXUCpjiQSktkuBMWwHjSkQxeehqw1Kgz0Trzm7QbtgxiEPDVmWCNCAeCfROTphd1ZNOhzLy6XfJyG6Xgd5MCAZw4xie0Sj5AnY1/akDgNS9YFl3Y06vd6FAsg2gVQJtzG7LVq1OH2frbXNHWH/NY89NNZ4QUSJqL2yEcGADbT38X0bGdukqYlSoliKOcsSTuqhcaemUeYLLoI8+MZor2RxXTRThF1LrHfqf/5LcLAjdl4EERgUysYS2geE+yFdasU91UgUDsc2cSQ1ZoT9+uLOwdgAmifwQqF028INc2IQEDfTmUw3eZxvz7Ud1z3xc1PQfeCvfKsB9jOhRj7rFyb9XcDWLcYj0bByosychMezMLVkFiYcdBBQtvI6K0KRuOZQH2kBsYHJaXTkup8F0eIhO1/GcIwWKpr2mouB7g5TUDJNvORXPXa/mU8bh27TAZYBe2sKx4NSv5OjnHIWD2RuysCzBlUfeNXhDd2jxnHoUlheJ3jBApzURy0fwm2FwwsSU0caQGl0Kv8hopRQE211NnvtLRsmCNrhhpEDoNiZEzD2QdJWKbRRWnaFedXHAELSN0t0bfsCsMf0ktfBoXBoNA+nZN9+pSlmuzspFevmsqqcMllzzvkyXrzoA+Ryo1ePXpdGOoJvhyru+EBRsmOp7MXZ0vNUMUqHLUoKglg1p73sWeZmPc+KAw0pE2zIsFFE5H4192KwDvDxdxEYoDBDNZjbg2bmADTeUKK57IPD4fTYF4c6EnXx/teYMORBDtIhPJneiZny7Nv/zG+YmekIKCoxr6kauE2bZtBLufetNG0BtBY7f+/ImUypMBvdWu/Q7vTMRzw5aQGZWuc1V0HEsItFYMIBnoKGZ0xcarba/TYZq50kCaflFysYjA4EDKHqGdpYWdKYmm+a7TADmW35yfnOYpZYrkpVEtiqF0EujI00aeplNs2k+qyFZNeE3CDPL9P6b4PQ/kataHkVpLSEVGK7EX6rAa7IVNrvZtFvOA6okKvBgMtFDAGZOx88MeBcJ8AR3AgUUeIznAN6tjCUipGDZONm1FjWJp4A3QIzSaIOmZ7DvF/ysYYbM/fFDOV0jntAjRdapxJxL0eThpEhKOjCDDq2ks+3GrwxqIFKLe1WdOzII8XIOPGnwy6LKXVfpSDOTEfaRsGujhpS4hBIsMOqHbl16PJxc4EkaVu9wpEYlF/84NSv5Zum4drMfp9yXbzzAOJqqS4YkI4cBrFrC7bMPiCfgI3nNZAqkk3QOZqR+yyqx+nDQKBBBZ7QKrfGMCL+XpqFaBJU0wpkBdAhbR4hJsmT5aynlvkouoxm/NjD5oe6BzVIO9uktM+/5dEC5P7vZvarmuO/lKXz4sBabVPIATuKTrwbJP8XUkdM6uEctHKXICUJGjaZIWRbZp8czquQYfY6ynBUCfIU+gG6wqSIBmYIm9pZpXdaL121V7q0VjDjmQnXvMe7ysoEZnZL15B0SpxS1jjd83uNIOKZwu5MPzg2NhOx3xMOPYwEn2CUzbSrwAs5OAtrz3GAaUkJOU74XwjaYUmGJdZBS1NJVkGYrToINLKDjxcuIlyfVsKQSG/G4DyiO2SlQvJ0d0Ot1uOG5IFSAkq+PRVMgVMDvOIJMdqjeCFKUGRWBW9wigYvcbU7CQL/7meF2KZAaWl+4y9uhowAX7elogAvItAAxo2+SFxGRsHGEW9BnhlTuWigYxRcnVUBRQHV41LV+Fr5CJYV7sHfeywswx4XMtUx6EkBhR+q8AXXUA8uPJ73Pb49i9KG9fOljvXeyFj9ixgbo6CcbAJ7WHWqKHy/h+YjBwp6VcN7M89FGzQ04qbrQtgrOFybg3gQRTYG5xn73ArkfQWjCJROwy3J38Dx/D7jOa6BBNsitEw1wGq780EEioOeD+ZGp2J66ADiVGMayiHYucMk8nTK2zzT9CnEraAk95kQjy4k0GRElLL5YAKLQErJ5rp1eay9O4Fb6yJGm9U4FaMwPGxtKD6odIIHKoWnhKo1U8KIpFC+MVn59ZXmc7ZTBZfsg6FQ8W10YfTr4u0nYrpHZbZ1jXiLmooF0cOm0+mPnJBXQtepc7n0BqOipNCqI6yyloTeRShNKH04FIo0gcMk0H/xThyN4pPAWjDDkEp3lNNPRNVfpMI44CWRlRgViP64eK0JSRp0WUvCWYumlW/c58Vcz/yMwVcW5oYb9+26TEhwvbxiNg48hl1VI1UXTU//Eta+BMKnGUivctfL5wINDD0giQL1ipt6U7C9cd4+lgqY2lMUZ02Uv6Prs+ZEZer7ZfWBXVghlfOOrClwsoOFKzWEfz6RZu1eCs+K8fLvkts5+BX0gyrFYve0C3qHrn5U/Oh6D/CihmWIrY7HUZRhJaxde+tldu6adYJ+LeXupQw0XExC36RETdNFxcq9glMu4cNQSX9cqR/GQYp+IxUkIcNGWVU7ZtGa6P3XAyodRt0XeS3Tp01AnCh0ZbUh4VrSZeV9RWfSoWyxnY3hzcZ30G/InDq4wxRrEejreBxnhIQbkxenxkaxl+k7eLUQkUR6vKJ2iDFNGX3WmVA1yaOH+mvhBd+sE6vacQzFobwY5BqEAFmejwW5ne7HtVNolOUgJc8CsUxmc/LBi8N5mu9VsIA5HyErnS6zeCz7VLI9+n/hbT6hTokMXTVyXJRKSG2hd2labXTbtmK4fNH3IZBPreSA4FMeVouVN3zG5x9CiGpLw/3pceo4qGqp+rVp+z+7yQ98oEf+nyH4F3+J9IheDBa94Wi63zJbLBCIZm7P0asHGpIJt3PzE3m0S4YIWyXBCVXGikj8MudDPB/6Nm2v4IxJ5gU0ii0guy5SUHqGUYzTP0jIJU5E82RHUXtX4lDdrihBLdP1YaG1AGUC12rQKuIaGvCpMjZC9bWSCYnjDlvpWbkdXMTNeBHLKiuoozMGIvkczmP0aRJSJ8PYnLCVNhKHXBNckH79e8Z8Kc2wUej4sQZoH8qDRGkg86maW/ZQWGNnLcXmq3FlXM6ssR/3P6E/bHMvm6HLrv1yRixit25JsH3/IOr2UV4BWJhxXW5BJ6Xdr07n9kF3ZNAk6/Xpc5MSFmYJ2R7bdL8Kk7q1OU9Elg/tCxJ8giT27wSTySF0GOxg4PbYJdi/Nyia9Nn89CGDulfJemm1aiEr/eleGSN+5MRrVJ4K6lgyTTIW3i9cQ0dAi6FHt0YMbH3wDSAtGLSAccezzxHitt1QdhW36CQgPcA8vIIBh3/JNjf/Obmc2yzpk8edSlS4lVdwgW5vzbYEyFoF4GCBBby1keVNueHAH+evi+H7oOVfS3XuPQSNTXOONAbzJeSb5stwdQHl1ZjrGoE49I8+A9j3t+ahhQj74FCSWpZrj7wRSFJJnnwi1T9HL5qrCFW/JZq6P62XkMWTb+u4lGpKfmmwiJWx178GOG7KbrZGqyWwmuyKWPkNswkZ1q8uptUlviIi+AXh2bOOTOLsrtNkfqbQJeh24reebkINLkjut5r4d9GR/r8CBa9SU0UQhsnZp5cP+RqWCixRm7i4YRFbtZ4EAkhtNa6jHb6gPYQv7MKqkPLRmX3dFsK8XsRLVZ6IEVrCbmNDc8o5mqsogjAQfoC9Bc7R6gfw03m+lQpv6kTfhxscDIX6s0w+fBxtkhjXAXr10UouWCx3C/p/FYwJRS/AXRKkjOb5CLmK4XRe0+xeDDwVkJPZau52bzLEDHCqV0f44pPgKOkYKgTZJ33fmk3Tu8SdxJ02SHM8Fem5SMsWqRyi2F1ynfRJszcFKykdWlNqgDA/L9lKYBmc7Zu/q9ii1FPF47VJkqhirUob53zoiJtVVRVwMR34gV9iqcBaHbRu9kkvqk3yMpfRFG49pKKjIiq7h/VpRwPGTHoY4cg05X5028iHsLvUW/uz+kjPyIEhhcKUwCkJAwbR9pIEGOn8z6svAO8i89sJ3dL5qDWFYbS+HGPRMxYwJItFQN86YESeJQhn2urGiLRffQeLptDl8dAgb+Tp47UQPxWOw17OeChLN1WnzlkPL1T5O+O3Menpn4C3IY5LEepHpnPeZHbvuWfeVtPlkH4LZjPbBrkJT3NoRJzBt86CO0Xq59oQ+8dsm0ymRcmQyn8w71mhmcuEI5byuF+C88VPYly2sEzjlzAQ3vdn/1+Hzguw6qFNNbqenhZGbdiG6RwZaTG7jTA2X9RdXjDN9yj1uQpyO4Lx8KRAcZcbZMafp4wPOd5MdXoFY52V1A8M9hi3sso93+uprE0qYNMjkE22CvK4HuUxqN7oIz5pWuETq1lQAjqlSlqdD2Rnr/ggp/TVkQYjn9lMfYelk2sH5HPdopYo7MHwlV1or9Bxf+QCyLzm92vzG2wjiIjC/ZHEJzeroJl6bdFPTpZho5MV2U86fLQqxNlGIMqCGy+9WYhJ8ob1r0+Whxde9L2PdysETv97O+xVw+VNN1TZSQN5I6l9m5Ip6pLIqLm4a1B1ffH6gHyqT9p82NOjntRWGIofO3bJz5GhkvSWbsXueTAMaJDou99kGLqDlhwBZNEQ4mKPuDvVwSK4WmLluHyhA97pZiVe8g+JxmnJF8IkV/tCs4Jq/HgOoAEGR9tCDsDbDmi3OviUQpG5D8XmKcSAUaFLRXb2lmJTNYdhtYyfjBYZQmN5qT5CNuaD3BVnlkCk7bsMW3AtXkNMMTuW4HjUERSJnVQ0vsBGa1wo3Qh7115XGeTF3NTz8w0440AgU7c3bSXO/KMINaIWXd0oLpoq/0/QJxCQSJ9XnYy1W7TYLBJpHsVWD1ahsA7FjNvRd6mxCiHsm8g6Z0pnzqIpF1dHUtP2ITU5Z1hZHbu+L3BEEStBbL9XYvGfEakv1bmf+bOZGnoiuHEdlBnaChxYKNzB23b8sw8YyT7Ajxfk49eJIAvdbVkdFCe2J0gMefhQ0bIZxhx3fzMIysQNiN8PgOUKxOMur10LduigREDRMZyP4oGWrP1GFY4t6groASsZ421os48wAdnrbovNhLt7ScNULkwZ5AIZJTrbaKYTLjA1oJ3sIuN/aYocm/9uoQHEIlacF1s/TM1fLcPTL38O9fOsjMEIwoPKfvt7opuI9G2Hf/PR4aCLDQ7wNmIdEuXJ/QNL72k5q4NejAldPfe3UVVqzkys8YZ/jYOGOp6c+YzRCrCuq0M11y7TiN6qk7YXRMn/gukxrEimbMQjr3jwRM6dKVZ4RUfWQr8noPXLJq6yh5R3EH1IVOHESst/LItbG2D2vRsZRkAObzvQAAD3mb3/G4NzopI0FAiHfbpq0X72adg6SRj+8OHMShtFxxLZlf/nLgRLbClwl5WmaYSs+yEjkq48tY7Z2bE0N91mJwt+ua0NlRJIDh0HikF4UvSVorFj2YVu9YeS5tfvlVjPSoNu/Zu6dEUfBOT555hahBdN3Sa5Xuj2Rvau1lQNIaC944y0RWj9UiNDskAK1WoL+EfXcC6IbBXFRyVfX/WKXxPAwUyIAGW8ggZ08hcijKTt1YKnUO6QPvcrmDVAb0FCLIXn5id4fD/Jx4tw/gbXs7WF9b2RgXtPhLBG9vF5FEkdHAKrQHZAJC/HWvk7nvzzDzIXZlfFTJoC3JpGgLPBY7SQTjGlUvG577yNutZ1hTfs9/1nkSXK9zzKLRZ3VODeKUovJe0WCq1zVMYxCJMenmNzPIU2S8TA4E7wWmbNkxq9rI2dd6v0VpcAPVMxnDsvWTWFayyqvKZO7Z08a62i/oH2/jxf8rpmfO64in3FLiL1GX8IGtVE9M23yGsIqJbxDTy+LtaMWDaPqkymb5VrQdzOvqldeU0SUi6IirG8UZ3jcpRbwHa1C0Dww9G/SFX3gPvTJQE+kyz+g1BeMILKKO+olcHzctOWgzxYHnOD7dpCRtuZEXACjgqesZMasoPgnuDC4nUviAAxDc5pngjoAITIkvhKwg5d608pdrZcA+qn5TMT6Uo/QzBaOxBCLTJX3Mgk85rMfsnWx86oLxf7p2PX5ONqieTa/qM3tPw4ZXvlAp83NSD8F7+ZgctK1TpoYwtiU2h02HCGioH5tkVCqNVTMH5p00sRy2JU1qyDBP2CII/Dg4WDsIl+zgeX7589srx6YORRQMBfKbodbB743Tl4WLKOEnwWUVBsm94SOlCracU72MSyj068wdpYjyz1FwC2bjQnxnB6Mp/pZ+yyZXtguEaYB+kqhjQ6UUmwSFazOb+rhYjLaoiM+aN9/8KKn0zaCTFpN9eKwWy7/u4EHzO46TdFSNjMfn2iPSJwDPCFHc0I1+vjdAZw5ZjqR/uzi9Zn20oAa5JnLEk/EA3VRWE7J/XrupfFJPtCUuqHPpnlL7ISJtRpSVcB8qsZCm2QEkWoROtCKKxUh3yEcMbWYJwk6DlEBG0bZP6eg06FL3v6RPb7odGuwm7FN8fG4woqtB8e7M5klPpo97GoObNwt+ludTAmxyC5hmcFx+dIvEZKI6igFKHqLH01iY1o7903VzG9QGetyVx5RNmBYUU+zIuSva/yIcECUi4pRmE3VkF2avqulQEUY4yZ/wmNboBzPmAPey3+dSYtBZUjeWWT0pPwCz4Vozxp9xeClIU60qvEFMQCaPvPaA70WlOP9f/ey39macvpGCVa+zfa8gO44wbxpJUlC8GN/pRMTQtzY8Z8/hiNrU+Zq64ZfFGIkdj7m7abcK1EBtws1X4J/hnqvasPvvDSDYWN+QcQVGMqXalkDtTad5rYY0TIR1Eqox3czwPMjKPvF5sFv17Thujr1IZ1Ytl4VX1J0vjXKmLY4lmXipRAro0qVGEcXxEVMMEl54jQMd4J7RjgomU0j1ptjyxY+cLiSyXPfiEcIS2lWDK3ISAy6UZ3Hb5vnPncA94411jcy75ay6B6DSTzK6UTCZR9uDANtPBrvIDgjsfarMiwoax2OlLxaSoYn4iRgkpEGqEkwox5tyI8aKkLlfZ12lO11TxsqRMY89j5JaO55XfPJPDL1LGSnC88Re9Ai+Nu5bZjtwRrvFITUFHPR4ZmxGslQMecgbZO7nHk32qHxYkdvWpup07ojcMCaVrpFAyFZJJbNvBpZfdf39Hdo2kPtT7v0/f8R/B5Nz4f1t9/3zNM/7n6SUHfcWk5dfQFJvcJMgPolGCpOFb/WC0FGWU2asuQyT+rm88ZKZ78Cei/CAh939CH0JYbpZIPtxc2ufXqjS3pHH9lnWK4iJ7OjR/EESpCo2R3MYKyE7rHfhTvWho4cL1QdN4jFTyR6syMwFm124TVDDRXMNveI1Dp/ntwdz8k8kxw7iFSx6+Yx6O+1LzMVrN0BBzziZi9kneZSzgollBnVwBh6oSOPHXrglrOj+QmR/AESrhDpKrWT+8/AiMDxS/5wwRNuGQPLlJ9ovomhJWn8sMLVItQ8N/7IXvtD8kdOoHaw+vBSbFImQsv/OCAIui99E+YSIOMlMvBXkAt+NAZK8wB9Jf8CPtB+TOUOR+z71d/AFXpPBT6+A5FLjxMjLIEoJzrQfquvxEIi+WoUzGR1IzQFNvbYOnxb2PyQ0kGdyXKzW2axQL8lNAXPk6NEjqrRD1oZtKLlFoofrXw0dCNWASHzy+7PSzOUJ3XtaPZsxLDjr+o41fKuKWNmjiZtfkOzItvlV2MDGSheGF0ma04qE3TUEfqJMrXFm7DpK+27DSvCUVf7rbNoljPhha5W7KBqVq0ShUSTbRmuqPtQreVWH4JET5yMhuqMoSd4r/N8sDmeQiQQvi1tcZv7Moc7dT5X5AtCD6kNEGZOzVcNYlpX4AbTsLgSYYliiPyVoniuYYySxsBy5cgb3pD+EK0Gpb0wJg031dPgaL8JZt6sIvzNPEHfVPOjXmaXj4bd4voXzpZ5GApMhILgMbCEWZ2zwgdeQgjNHLbPIt+KqxRwWPLTN6HwZ0Ouijj4UF+Sg0Au8XuIKW0WxlexdrFrDcZJ8Shauat3X0XmHygqgL1nAu2hrJFb4wZXkcS+i36KMyU1yFvYv23bQUJi/3yQpqr/naUOoiEWOxckyq/gq43dFou1DVDaYMZK9tho7+IXXokBCs5GRfOcBK7g3A+jXQ39K4YA8PBRW4m5+yR0ZAxWJncjRVbITvIAPHYRt1EJ3YLiUbqIvoKHtzHKtUy1ddRUQ0AUO41vonZDUOW+mrszw+SW/6Q/IUgNpcXFjkM7F4CSSQ2ExZg85otsMs7kqsQD4OxYeBNDcSpifjMoLb7GEbGWTwasVObmB/bfPcUlq0wYhXCYEDWRW02TP5bBrYsKTGWjnWDDJ1F7zWai0zW/2XsCuvBQjPFcTYaQX3tSXRSm8hsAoDdjArK/OFp6vcWYOE7lizP0Yc+8p16i7/NiXIiiQTp7c7Xus925VEtlKAjUdFhyaiLT7VxDagprMFwix4wZ05u0qj7cDWFd0W9OYHIu3JbJKMXRJ1aYNovugg+QqRN7fNHSi26VSgBpn+JfMuPo3aeqPWik/wI5Rz3BWarPQX4i5+dM0npwVOsX+KsOhC7vDg+OJsz4Q5zlnIeflUWL6QYMbf9WDfLmosLF4Qev3mJiOuHjoor/dMeBpA9iKDkMjYBNbRo414HCxjsHrB4EXNbHzNMDHCLuNBG6Sf+J4MZ/ElVsDSLxjIiGsTPhw8BPjxbfQtskj+dyNMKOOcUYIRBEIqbazz3lmjlRQhplxq673VklMMY6597vu+d89ec/zq7Mi4gQvh87ehYbpOuZEXj5g/Q7S7BFDAAB9DzG35SC853xtWVcnZQoH54jeOqYLR9NDuwxsVthTV7V99n/B7HSbAytbEyVTz/5NhJ8gGIjG0E5j3griULUd5Rg7tQR+90hJgNQKQH2btbSfPcaTOfIexc1db1BxUOhM1vWCpLaYuKr3FdNTt/T3PWCpEUWDKEtzYrjpzlL/wri3MITKsFvtF8QVV/NhVo97aKIBgdliNc10dWdXVDpVtsNn+2UIolrgqdWA4EY8so0YvB4a+aLzMXiMAuOHQrXY0tr+CL10JbvZzgjJJuB1cRkdT7DUqTvnswVUp5kkUSFVtIIFYK05+tQxT6992HHNWVhWxUsD1PkceIrlXuUVRogwmfdhyrf6zzaL8+c0L7GXMZOteAhAVQVwdJh+7nrX7x4LaIIfz2F2v7Dg/uDfz2Fa+4gFm2zHAor8UqimJG3VTJtZEoFXhnDYXvxMJFc6ku2bhbCxzij2z5UNuK0jmp1mnvkVNUfR+SEmj1Lr94Lym75PO7Fs0MIr3GdsWXRXSfgLTVY0FLqba97u1In8NAcY7IC6TjWLigwKEIm43NxTdaVTv9mcKkzuzBkKd8x/xt1p/9BbP7Wyb4bpo1K1gnOpbLvKz58pWl3B55RJ/Z5mRDLPtNQg14jdOEs9+h/V5UVpwrAI8kGbX8KPVPDIMfIqKDjJD9UyDOPhjZ3vFAyecwyq4akUE9mDOtJEK1hpDyi6Ae87sWAClXGTiwPwN7PXWwjxaR79ArHRIPeYKTunVW24sPr/3HPz2IwH8oKH4OlWEmt4BLM6W5g4kMcYbLwj2usodD1088stZA7VOsUSpEVl4w7NMb1EUHMRxAxLF0CIV+0L3iZb+ekB1vSDSFjAZ3hfLJf7gFaXrOKn+mhR+rWw/eTXIcAgl4HvFuBg1LOmOAwJH3eoVEjjwheKA4icbrQCmvAtpQ0mXG0agYp5mj4Rb6mdQ+RV4QBPbxMqh9C7o8nP0Wko2ocnCHeRGhN1XVyT2b9ACsL+6ylUy+yC3QEnaKRIJK91YtaoSrcWZMMwxuM0E9J68Z+YyjA0g8p1PfHAAIROy6Sa04VXOuT6A351FOWhKfTGsFJ3RTJGWYPoLk5FVK4OaYR9hkJvezwF9vQN1126r6isMGXWTqFW+3HL3I/jurlIdDWIVvYY+s6yq7lrFSPAGRdnU7PVwY/SvWbZGpXzy3BQ2LmAJlrONUsZs4oGkly0V267xbD5KMY8woNNsmWG1VVgLCra8aQBBcI4DP2BlNwxhiCtHlaz6OWFoCW0vMR3ErrG7JyMjTSCnvRcsEHgmPnwA6iNpJ2DrFb4gLlhKJyZGaWkA97H6FFdwEcLT6DRQQL++fOkVC4cYGW1TG/3iK5dShRSuiBulmihqgjR45Vi03o2RbQbP3sxt90VxQ6vzdlGfkXmmKmjOi080JSHkLntjvsBJnv7gKscOaTOkEaRQqAnCA4HWtB4XnMtOhpRmH2FH8tTXrIjAGNWEmudQLCkcVlGTQ965Kh0H6ixXbgImQP6b42B49sO5C8pc7iRlgyvSYvcnH9FgQ3azLbQG2cUW96SDojTQStxkOJyOuDGTHAnnWkz29aEwN9FT8EJ4yhXOg+jLTrCPKeEoJ9a7lDXOjEr8AgX4BmnMQ668oW0zYPyQiVMPxKRHtpfnEEyaKhdzNVThlxxDQNdrHeZiUFb6NoY2KwvSb7BnRcpJy+/g/zAYx3fYSN5QEaVD2Y1VsNWxB0BSO12MRsRY8JLfAezRMz5lURuLUnG1ToKk6Q30FughqWN6gBNcFxP/nY/iv+iaUQOa+2Nuym46wtI/DvSfzSp1jEi4SdYBE7YhTiVV5cX9gwboVDMVgZp5YBQlHOQvaDNfcCoCJuYhf5kz5kwiIKPjzgpcRJHPbOhJajeoeRL53cuMahhV8Z7IRr6M4hW0JzT7mzaMUzQpm866zwM7Cs07fJYXuWvjAMkbe5O6V4bu71sOG6JQ4oL8zIeXHheFVavzxmlIyBkgc9IZlEDplMPr8xlcyss4pVUdwK1e7CK2kTsSdq7g5SHRAl3pYUB9Ko4fsh4qleOyJv1z3KFSTSvwEcRO/Ew8ozEDYZSqpfoVW9uhJfYrNAXR0Z3VmeoAD+rVWtwP/13sE/3ICX3HhDG3CMc476dEEC0K3umSAD4j+ZQLVdFOsWL2C1TH5+4KiSWH+lMibo+B55hR3Gq40G1n25sGcN0mEcoU2wN9FCVyQLBhYOu9aHVLWjEKx2JIUZi5ySoHUAI9b8hGzaLMxCZDMLhv8MkcpTqEwz9KFDpCpqQhVmsGQN8m24wyB82FAKNmjgfKRsXRmsSESovAwXjBIoMKSG51p6Um8b3i7GISs7kjTq/PZoioCfJzfKdJTN0Q45kQEQuh9H88M3yEs3DbtRTKALraM0YC8laiMiOOe6ADmTcCiREeAWZelBaEXRaSuj2lx0xHaRYqF65O0Lo5OCFU18A8cMDE4MLYm9w2QSr9NgQAIcRxZsNpA7UJR0e71JL+VU+ISWFk5I97lra8uGg7GlQYhGd4Gc6rxsLFRiIeGO4abP4S4ekQ1fiqDCy87GZHd52fn5aaDGuvOmIofrzpVwMvtbreZ/855OaXTRcNiNE0wzGZSxbjg26v8ko8L537v/XCCWP2MFaArJpvnkep0pA+O86MWjRAZPQRfznZiSIaTppy6m3p6HrNSsY7fDtz7Cl4V/DJAjQDoyiL2uwf1UHVd2AIrzBUSlJaTj4k6NL97a/GqhWKU9RUmjnYKpm2r+JYUcrkCuZKvcYvrg8pDoUKQywY9GDWg03DUFSirlUXBS5SWn/KAntnf0IdHGL/7mwXqDG+LZYjbEdQmqUqq4y54TNmWUP7IgcAw5816YBzwiNIJiE9M4lPCzeI/FGBeYy3p6IAmH4AjXXmvQ4Iy0Y82NTobcAggT2Cdqz6Mx4TdGoq9fn2etrWKUNFyatAHydQTVUQ2S5OWVUlugcNvoUrlA8cJJz9MqOa/W3iVno4zDHfE7zhoY5f5lRTVZDhrQbR8LS4eRLz8iPMyBL6o4PiLlp89FjdokQLaSBmKHUwWp0na5fE3v9zny2YcDXG/jfI9sctulHRbdkI5a4GOPJx4oAJQzVZ/yYAado8KNZUdEFs9ZPiBsausotXMNebEgr0dyopuqfScFJ3ODNPHgclACPdccwv0YJGQdsN2lhoV4HVGBxcEUeUX/alr4nqpcc1CCR3vR7g40zteQg/JvWmFlUE4mAiTpHlYGrB7w+U2KdSwQz2QJKBe/5eiixWipmfP15AFWrK8Sh1GBBYLgzki1wTMhGQmagXqJ2+FuqJ8f0XzXCVJFHQdMAw8xco11HhM347alrAu+wmX3pDFABOvkC+WPX0Uhg1Z5MVHKNROxaR84YV3s12UcM+70cJ460SzEaKLyh472vOMD3XnaK7zxZcXlWqenEvcjmgGNR2OKbI1s8U+iwiW+HotHalp3e1MGDy6BMVIvajnAzkFHbeVsgjmJUkrP9OAwnEHYXVBqYx3q7LvXjoVR0mY8h+ZaOnh053pdsGkmbqhyryN01eVHySr+CkDYkSMeZ1xjPNVM+gVLTDKu2VGsMUJqWO4TwPDP0VOg2/8ITbAUaMGb4LjL7L+Pi11lEVMXTYIlAZ/QHmTENjyx3kDkBdfcvvQt6tKk6jYFM4EG5UXDTaF5+1ZjRz6W7MdJPC+wTkbDUim4p5QQH3b9kGk2Bkilyeur8Bc20wm5uJSBO95GfYDI1EZipoRaH7uVveneqz43tlTZGRQ4a7CNmMHgXyOQQOL6WQkgMUTQDT8vh21aSdz7ERiZT1jK9F+v6wgFvuEmGngSvIUR2CJkc5tx1QygfZnAruONobB1idCLB1FCfO7N1ZdRocT8/Wye+EnDiO9pzqIpnLDl4bkaRKW+ekBVwHn46Shw1X0tclt/0ROijuUB4kIInrVJU4buWf4YITJtjOJ6iKdr1u+flgQeFH70GxKjhdgt/MrwfB4K/sXczQ+9zYcrD4dhY6qZhZ010rrxggWA8JaZyg2pYij8ieYEg1aZJkZK9O1Re7sB0iouf60rK0Gd+AYlp7soqCBCDGwfKeUQhCBn0E0o0GS6PdmjLi0TtCYZeqazqwN+yNINIA8Lk3iPDnWUiIPLGNcHmZDxfeK0iAdxm/T7LnN+gemRL61hHIc0NCAZaiYJR+OHnLWSe8sLrK905B5eEJHNlWq4RmEXIaFTmo49f8w61+NwfEUyuJAwVqZCLFcyHBKAcIVj3sNzfEOXzVKIndxHw+AR93owhbCxUZf6Gs8cz6/1VdrFEPrv330+9s6BtMVPJ3zl/Uf9rUi0Z/opexfdL3ykF76e999GPfVv8fJv/Y/+/5hEMon1tqNFyVRevV9y9/uIvsG3dbB8GRRrgaEXfhx+2xeOFt+cEn3RZanNxdEe2+B6MHpNbrRE53PlDifPvFcp4kO78ILR0T4xyW/WGPyBsqGdoA7zJJCu1TKbGfhnqgnRbxbB2B3UZoeQ2bz2sTVnUwokTcTU21RxN1PYPS3Sar7T0eRIsyCNowr9amwoMU/od9s2APtiKNL6ENOlyKADstAEWKA+sdKDhrJ6BOhRJmZ+QJbAaZ3/5Fq0/lumCgEzGEbu3yi0Y4I4EgVAjqxh4HbuQn0GrRhOWyAfsglQJAVL1y/6yezS2k8RE2MstJLh92NOB3GCYgFXznF4d25qiP4ZCyI4RYGesut6FXK6GwPpKK8WHEkhYui0AyEmr5Ml3uBFtPFdnioI8RiCooa7Z1G1WuyIi3nSNglutc+xY8BkeW3JJXPK6jd2VIMpaSxpVtFq+R+ySK9J6WG5Qvt+C+QH1hyYUOVK7857nFmyDBYgZ/o+AnibzNVqyYCJQvyDXDTK+iXdkA71bY7TL3bvuLxLBQ8kbTvTEY9aqkQ3+MiLWbEgjLzOH+lXgco1ERgzd80rDCymlpaRQbOYnKG/ODoFl46lzT0cjM5FYVvv0qLUbD5lyJtMUaC1pFlTkNONx6lliaX9o0i/1vws5bNKn5OuENQEKmLlcP4o2ZmJjD4zzd3Fk32uQ4uRWkPSUqb4LBe3EXHdORNB2BWsws5daRnMfNVX7isPSb1hMQdAJi1/qmDMfRUlCU74pmnzjbXfL8PVG8NsW6IQM2Ne23iCPIpryJjYbVnm5hCvKpMa7HLViNiNc+xTfDIaKm3jctViD8A1M9YPJNk003VVr4Zo2MuGW8vil8SLaGpPXqG7I4DLdtl8a4Rbx1Lt4w5Huqaa1XzZBtj208EJVGcmKYEuaeN27zT9EE6a09JerXdEbpaNgNqYJdhP1NdqiPKsbDRUi86XvvNC7rME5mrSQtrzAZVndtSjCMqd8BmaeGR4l4YFULGRBeXIV9Y4yxLFdyoUNpiy2IhePSWzBofYPP0eIa2q5JP4j9G8at/AqoSsLAUuRXtvgsqX/zYwsE+of6oSDbUOo4RMJw+DOUTJq+hnqwKim9Yy/napyZNTc2rCq6V9jHtJbxGPDwlzWj/Sk3zF/BHOlT/fSjSq7FqlPI1q6J+ru8Aku008SFINXZfOfnZNOvGPMtEmn2gLPt+H4QLA+/SYe4j398auzhKIp2Pok3mPC5q1IN1HgR+mnEfc4NeeHYwd2/kpszR3cBn7ni9NbIqhtSWFW8xbUJuUPVOeeXu3j0IGZmFNiwaNZ6rH4/zQ2ODz6tFxRLsUYZu1bfd1uIvfQDt4YD/efKYv8VF8bHGDgK22w2Wqwpi43vNCOXFJZCGMqWiPbL8mil6tsmOTXAWCyMCw73e2rADZj2IK6rqksM3EXF2cbLb4vjB14wa/yXK5vwU+05MzERJ5nXsXsW21o7M+gO0js2OyKciP5uF2iXyb2DiptwQeHeqygkrNsqVCSlldxBMpwHi1vfc8RKpP/4L3Lmpq6DZcvhDDfxTCE3splacTcOtXdK2g303dIWBVe2wD/Gvja1cClFQ67gw0t1ZUttsUgQ1Veky8oOpS6ksYEc4bqseCbZy766SvL3FodmnahlWJRgVCNjPxhL/fk2wyvlKhITH/VQCipOI0dNcRa5B1M5HmOBjTLeZQJy237e2mobwmDyJNHePhdDmiknvLKaDbShL+Is1XTCJuLQd2wmdJL7+mKvs294whXQD+vtd88KKk0DXP8B1Xu9J+xo69VOuFgexgTrcvI6SyltuLix9OPuE6/iRJYoBMEXxU4shQMf4Fjqwf1PtnJ/wWSZd29rhZjRmTGgiGTAUQqRz+nCdjeMfYhsBD5Lv60KILWEvNEHfmsDs2L0A252351eUoYxAysVaCJVLdH9QFWAmqJDCODUcdoo12+gd6bW2boY0pBVHWL6LQDK5bYWh1V8vFvi0cRpfwv7cJiMX3AZNJuTddHehTIdU0YQ/sQ1dLoF2xQPcCuHKiuCWOY30DHe1OwcClLAhqAKyqlnIbH/8u9ScJpcS4kgp6HKDUdiOgRaRGSiUCRBjzI5gSksMZKqy7Sd51aeg0tgJ+x0TH9YH2Mgsap9N7ENZdEB0bey2DMTrBA1hn56SErNHf3tKtqyL9b6yXEP97/rc+jgD2N1LNUH6RM9AzP3kSipr06RkKOolR7HO768jjWiH1X92jA7dkg7gcNcjqsZCgfqWw0tPXdLg20cF6vnQypg7gLtkazrHAodyYfENPQZsdfnjMZiNu4nJO97D1/sQE+3vNFzrSDOKw+keLECYf7RJwVHeP/j79833oZ0egonYB2FlFE5qj02B/LVOMJQlsB8uNg3Leg4qtZwntsOSNidR0abbZmAK4sCzvt8Yiuz2yrNCJoH5O8XvX/vLeR/BBYTWj0sOPYM/jyxRd5+/JziKAABaPcw/34UA3aj/gLZxZgRCWN6m4m3demanNgsx0P237/Q+Ew5VYnJPkyCY0cIVHoFn2Ay/e7U4P19APbPFXEHX94N6KhEMPG7iwB3+I+O1jd5n6VSgHegxgaSawO6iQCYFgDsPSMsNOcUj4q3sF6KzGaH/0u5PQoAj/8zq6Uc9MoNrGqhYeb2jQo0WlGlXjxtanZLS24/OIN5Gx/2g684BPDQpwlqnkFcxpmP/osnOXrFuu4PqifouQH0eF5qCkvITQbJw/Zvy5mAHWC9oU+cTiYhJmSfKsCyt1cGVxisKu+NymEQIAyaCgud/V09qT3nk/9s/SWsYtha7yNpzBIMM40rCSGaJ9u6lEkl00vXBiEt7p9P5IBCiavynEOv7FgLqPdeqxRiCwuFVMolSIUBcoyfUC2e2FJSAUgYdVGFf0b0Kn2EZlK97yyxrT2MVgvtRikfdaAW8RwEEfN+B7/eK8bBdp7URpbqn1xcrC6d2UjdsKbzCjBFqkKkoZt7Mrhg6YagE7spkqj0jOrWM+UGQ0MUlG2evP1uE1p2xSv4dMK0dna6ENcNUF+xkaJ7B764NdxLCpuvhblltVRAf7vK5qPttJ/9RYFUUSGcLdibnz6mf7WkPO3MkUUhR2mAOuGv8IWw5XG1ZvoVMnjSAZe6T7WYA99GENxoHkMiKxHlCuK5Gd0INrISImHQrQmv6F4mqU/TTQ8nHMDzCRivKySQ8dqkpQgnUMnwIkaAuc6/FGq1hw3b2Sba398BhUwUZSAIO8XZvnuLdY2n6hOXws+gq9BHUKcKFA6kz6FDnpxLPICa3qGhnc97bo1FT/XJk48LrkHJ2CAtBv0RtN97N21plfpXHvZ8gMJb7Zc4cfI6MbPwsW7AilCSXMFIEUEmir8XLEklA0ztYbGpTTGqttp5hpFTTIqUyaAIqvMT9A/x+Ji5ejA4Bhxb/cl1pUdOD6epd3yilIdO6j297xInoiBPuEDW2/UfslDyhGkQs7Wy253bVnlT+SWg89zYIK/9KXFl5fe+jow2rd5FXv8zDPrmfMXiUPt9QBO/iK4QGbX5j/7Rx1c1vzsY8ONbP3lVIaPrhL4+1QrECTN3nyKavGG0gBBtHvTKhGoBHgMXHStFowN+HKrPriYu+OZ05Frn8okQrPaaxoKP1ULCS/cmKFN3gcH7HQlVjraCeQmtjg1pSQxeuqXiSKgLpxc/1OiZsU4+n4lz4hpahGyWBURLi4642n1gn9qz9bIsaCeEPJ0uJmenMWp2tJmIwLQ6VSgDYErOeBCfSj9P4G/vI7oIF+l/n5fp956QgxGvur77ynawAu3G9MdFbJbu49NZnWnnFcQHjxRuhUYvg1U/e84N4JTecciDAKb/KYIFXzloyuE1eYXf54MmhjTq7B/yBToDzzpx3tJCTo3HCmVPYfmtBRe3mPYEE/6RlTIxbf4fSOcaKFGk4gbaUWe44hVk9SZzhW80yfW5QWBHxmtUzvMhfVQli4gZTktIOZd9mjJ5hsbmzttaHQB29Am3dZkmx3g/qvYocyhZ2PXAWsNQiIaf+Q8W/MWPIK7/TjvCx5q2XRp4lVWydMc2wIQkhadDB0xsnw/kSEyGjLKjI4coVIwtubTF3E7MJ6LS6UOsJKj82XVAVPJJcepfewbzE91ivXZvOvYfsmMevwtPpfMzGmC7WJlyW2j0jh7AF1JLmwEJSKYwIvu6DHc3YnyLH9ZdIBnQ+nOVDRiP+REpqv++typYHIvoJyICGA40d8bR7HR2k7do6UQTHF4oriYeIQbxKe4Th6+/l1BjUtS9hqORh3MbgvYrStXTfSwaBOmAVQZzpYNqsAmQyjY56MUqty3c/xH6GuhNvNaG9vGbG6cPtBM8UA3e8r51D0AR9kozKuGGSMgLz3nAHxDNnc7GTwpLj7/6HeWp1iksDeTjwCLpxejuMtpMnGJgsiku1sOACwQ9ukzESiDRN77YNESxR5LphOlcASXA5uIts1LnBIcn1J7BLWs49DMALSnuz95gdOrTZr0u1SeYHinno/pE58xYoXbVO/S+FEMMs5qyWkMnp8Q3ClyTlZP52Y9nq7b8fITPuVXUk9ohG5EFHw4gAEcjFxfKb3xuAsEjx2z1wxNbSZMcgS9GKyW3R6KwJONgtA64LTyxWm8Bvudp0M1FdJPEGopM4Fvg7G/hsptkhCfHFegv4ENwxPeXmYhxwZy7js+BeM27t9ODBMynVCLJ7RWcBMteZJtvjOYHb5lOnCLYWNEMKC59BA7covu1cANa2PXL05iGdufOzkgFqqHBOrgQVUmLEc+Mkz4Rq8O6WkNr7atNkH4M8d+SD1t/tSzt3oFql+neVs+AwEI5JaBJaxARtY2Z4mKoUqxds4UpZ0sv3zIbNoo0J4fihldQTX3XNcuNcZmcrB5LTWMdzeRuAtBk3cZHYQF6gTi3PNuDJ0nmR+4LPLoHvxQIxRgJ9iNNXqf2SYJhcvCtJiVWo85TsyFOuq7EyBPJrAdhEgE0cTq16FQXhYPJFqSfiVn0IQnPOy0LbU4BeG94QjdYNB0CiQ3QaxQqD2ebSMiNjaVaw8WaM4Z5WnzcVDsr4eGweSLa2DE3BWViaxhZFIcSTjgxNCAfelg+hznVOYoe5VqTYs1g7WtfTm3e4/WduC6p+qqAM8H4ZyrJCGpewThTDPe6H7CzX/zQ8Tm+r65HeZn+MsmxUciEWPlAVaK/VBaQBWfoG/aRL/jSZIQfep/89GjasWmbaWzeEZ2R1FOjvyJT37O9B8046SRSKVEnXWlBqbkb5XCS3qFeuE9xb9+frEknxWB5h1D/hruz2iVDEAS7+qkEz5Ot5agHJc7WCdY94Ws61sURcX5nG8UELGBAHZ3i+3VulAyT0nKNNz4K2LBHBWJcTBX1wzf+//u/j/9+//v87+9/l9Lbh/L/uyNYiTsWV2LwsjaA6MxTuzFMqmxW8Jw/+IppdX8t/Clgi1rI1SN0UC/r6tX/4lUc2VV1OQReSeCsjUpKZchw4XUcjHfw6ryCV3R8s6VXm67vp4n+lcPV9gJwmbKQEsmrJi9c2vkwrm8HFbVYNTaRGq8D91t9n5+U+aD/hNtN3HjC/nC/vUoGFSCkXP+NlRcmLUqLbiUBl4LYf1U/CCvwtd3ryCH8gUmGITAxiH1O5rnGTz7y1LuFjmnFGQ1UWuM7HwfXtWl2fPFKklYwNUpF2IL/TmaRETjQiM5SJacI+3Gv5MBU8lP5Io6gWkawpyzNEVGqOdx4YlO1dCvjbWFZWbCmeiFKPSlMKtKcMFLs/KQxtgAHi7NZNCQ32bBAW2mbHflVZ8wXKi1JKVHkW20bnYnl3dKWJeWJOiX3oKPBD6Zbi0ZvSIuWktUHB8qDR8DMMh1ZfkBL9FS9x5r0hBGLJ8pUCJv3NYH+Ae8p40mZWd5m5fhobFjQeQvqTT4VKWIYfRL0tfaXKiVl75hHReuTJEcqVlug+eOIIc4bdIydtn2K0iNZPsYWQvQio2qbO3OqAlPHDDOB7DfjGEfVF51FqqNacd6QmgFKJpMfLp5DHTv4wXlONKVXF9zTJpDV4m1sYZqJPhotcsliZM8yksKkCkzpiXt+EcRQvSQqmBS9WdWkxMTJXPSw94jqI3varCjQxTazjlMH8jTS8ilaW8014/vwA/LNa+YiFoyyx3s/KswP3O8QW1jtq45yTM/DX9a8M4voTVaO2ebvw1EooDw/yg6Y1faY+WwrdVs5Yt0hQ5EwRfYXSFxray1YvSM+kYmlpLG2/9mm1MfmbKHXr44Ih8nVKb1M537ZANUkCtdsPZ80JVKVKabVHCadaLXg+IV8i5GSwpZti0h6diTaKs9sdpUKEpd7jDUpYmHtiX33SKiO3tuydkaxA7pEc9XIQEOfWJlszj5YpL5bKeQyT7aZSBOamvSHl8xsWvgo26IP/bqk+0EJUz+gkkcvlUlyPp2kdKFtt7y5aCdks9ZJJcFp5ZWeaWKgtnXMN3ORwGLBE0PtkEIek5FY2aVssUZHtsWIvnljMVJtuVIjpZup/5VL1yPOHWWHkOMc6YySWMckczD5jUj2mlLVquFaMU8leGVaqeXis+aRRL8zm4WuBk6cyWfGMxgtr8useQEx7k/PvRoZyd9nde1GUCV84gMX8Ogu/BWezYPSR27llzQnA97oo0pYyxobYUJfsj+ysTm9zJ+S4pk0TGo9VTG0KjqYhTmALfoDZVKla2b5yhv241PxFaLJs3i05K0AAIdcGxCJZmT3ZdT7CliR7q+kur7WdQjygYtOWRL9B8E4s4LI8KpAj7bE0dg7DLOaX+MGeAi0hMMSSWZEz+RudXbZCsGYS0QqiXjH9XQbd8sCB+nIVTq7/T/FDS+zWY9q7Z2fdq1tdLb6v3hKKVDAw5gjj6o9r1wHFROdHc18MJp4SJ2Ucvu+iQ9EgkekW8VCM+psM6y+/2SBy8tNN4a3L1MzP+OLsyvESo5gS7IQOnIqMmviJBVc6zbVG1n8eXiA3j46kmvvtJlewwNDrxk4SbJOtP/TV/lIVK9ueShNbbMHfwnLTLLhbZuO79ec5XvfgRwLFK+w1r5ZWW15rVFZrE+wKqNRv5KqsLNfpGgnoUU6Y71NxEmN7MyqwqAQqoIULOw/LbuUB2+uE75gJt+kq1qY4LoxV+qR/zalupea3D5+WMeaRIn0sAI6DDWDh158fqUb4YhAxhREbUN0qyyJYkBU4V2KARXDT65gW3gRsiv7xSPYEKLwzgriWcWgPr0sbZnv7m1XHNFW6xPdGNZUdxFiUYlmXNjDVWuu7LCkX/nVkrXaJhiYktBISC2xgBXQnNEP+cptWl1eG62a7CPXrnrkTQ5BQASbEqUZWMDiZUisKyHDeLFOaJILUo5f6iDt4ZO8MlqaKLto0AmTHVVbkGuyPa1R/ywZsWRoRDoRdNMMHwYTsklMVnlAd2S0282bgMI8fiJpDh69OSL6K3qbo20KfpNMurnYGQSr/stFqZ7hYsxKlLnKAKhsmB8AIpEQ4bd/NrTLTXefsE6ChRmKWjXKVgpGoPs8GAicgKVw4K0qgDgy1A6hFq1WRat3fHF+FkU+b6H4NWpOU3KXTxrIb2qSHAb+qhm8hiSROi/9ofapjxhyKxxntPpge6KL5Z4+WBMYkAcE6+0Hd3Yh2zBsK2MV3iW0Y6cvOCroXlRb2MMJtdWx+3dkFzGh2Pe3DZ9QpSqpaR/rE1ImOrHqYYyccpiLC22amJIjRWVAherTfpQLmo6/K2pna85GrDuQPlH1Tsar8isAJbXLafSwOof4gg9RkAGm/oYpBQQiPUoyDk2BCQ1k+KILq48ErFo4WSRhHLq/y7mgw3+L85PpP6xWr6cgp9sOjYjKagOrxF148uhuaWtjet953fh1IQiEzgC+d2IgBCcUZqgTAICm2bR8oCjDLBsmg+ThyhfD+zBalsKBY1Ce54Y/t9cwfbLu9SFwEgphfopNA3yNxgyDafUM3mYTovZNgPGdd4ZFFOj1vtfFW3u7N+iHEN1HkeesDMXKPyoCDCGVMo4GCCD6PBhQ3dRZIHy0Y/3MaE5zU9mTCrwwnZojtE+qNpMSkJSpmGe0EzLyFelMJqhfFQ7a50uXxZ8pCc2wxtAKWgHoeamR2O7R+bq7IbPYItO0esdRgoTaY38hZLJ5y02oIVwoPokGIzxAMDuanQ1vn2WDQ00Rh6o5QOaCRu99fwDbQcN0XAuqkFpxT/cfz3slGRVokrNU0iqiMAJFEbKScZdmSkTUznC0U+MfwFOGdLgsewRyPKwBZYSmy6U325iUhBQNxbAC3FLKDV9VSOuQpOOukJ/GAmu/tyEbX9DgEp6dv1zoU0IqzpG6gssSjIYRVPGgU1QAQYRgIT8gEV0EXr1sqeh2I6rXjtmoCYyEDCe/PkFEi/Q48FuT29p557iN+LCwk5CK/CZ2WdAdfQZh2Z9QGrzPLSNRj5igUWzl9Vi0rCqH8G1Kp4QMLkuwMCAypdviDXyOIk0AHTM8HBYKh3b0/F+DxoNj4ZdoZfCpQVdnZarqoMaHWnMLNVcyevytGsrXQEoIbubqWYNo7NRHzdc0zvT21fWVirj7g36iy6pxogfvgHp1xH1Turbz8QyyHnXeBJicpYUctbzApwzZ1HT+FPEXMAgUZetgeGMwt4G+DHiDT2Lu+PT21fjJCAfV16a/Wu1PqOkUHSTKYhWW6PhhHUlNtWzFnA7MbY+r64vkwdpfNB2JfWgWXAvkzd42K4lN9x7Wrg4kIKgXCb4mcW595MCPJ/cTfPAMQMFWwnqwde4w8HZYJFpQwcSMhjVz4B8p6ncSCN1X4klxoIH4BN2J6taBMj6lHkAOs8JJAmXq5xsQtrPIPIIp/HG6i21xMGcFgqDXSRF0xQg14d2uy6HgKE13LSvQe52oShF5Jx1R6avyL4thhXQZHfC94oZzuPUBKFYf1VvDaxIrtV6dNGSx7DO0i1p6CzBkuAmEqyWceQY7F9+U0ObYDzoa1iKao/cOD/v6Q9gHrrr1uCeOk8fST9MG23Ul0KmM3r+Wn6Hi6WAcL7gEeaykicvgjzkjSwFsAXIR81Zx4QJ6oosVyJkCcT+4xAldCcihqvTf94HHUPXYp3REIaR4dhpQF6+FK1H0i9i7Pvh8owu3lO4PT1iuqu+DkL2Bj9+kdfGAg2TXw03iNHyobxofLE2ibjsYDPgeEQlRMR7afXbSGQcnPjI2D+sdtmuQ771dbASUsDndU7t58jrrNGRzISvwioAlHs5FA+cBE5Ccznkd8NMV6BR6ksnKLPZnMUawRDU1MZ/ib3xCdkTblHKu4blNiylH5n213yM0zubEie0o4JhzcfAy3H5qh2l17uLooBNLaO+gzonTH2uF8PQu9EyH+pjGsACTMy4cHzsPdymUSXYJOMP3yTkXqvO/lpvt0cX5ekDEu9PUfBeZODkFuAjXCaGdi6ew4qxJ8PmFfwmPpkgQjQlWqomFY6UkjmcnAtJG75EVR+NpzGpP1Ef5qUUbfowrC3zcSLX3BxgWEgEx/v9cP8H8u1Mvt9/rMDYf6sjwU1xSOPBgzFEeJLMRVFtKo5QHsUYT8ZRLCah27599EuqoC9PYjYO6aoAMHB8X1OHwEAYouHfHB3nyb2B+SnZxM/vw/bCtORjLMSy5aZoEpvgdGvlJfNPFUu/p7Z4VVK1hiI0/UTuB3ZPq4ohEbm7Mntgc1evEtknaosgZSwnDC2BdMmibpeg48X8Ixl+/8+xXdbshQXUPPvx8jT3fkELivHSmqbhblfNFShWAyQnJ3WBU6SMYSIpTDmHjdLVAdlADdz9gCplZw6mTiHqDwIsxbm9ErGusiVpg2w8Q3khKV/R9Oj8PFeF43hmW/nSd99nZzhyjCX3QOZkkB6BsH4H866WGyv9E0hVAzPYah2tkRfQZMmP2rinfOeQalge0ovhduBjJs9a1GBwReerceify49ctOh5/65ATYuMsAkVltmvTLBk4oHpdl6i+p8DoNj4Fb2vhdFYer2JSEilEwPd5n5zNoGBXEjreg/wh2NFnNRaIUHSOXa4eJRwygZoX6vnWnqVdCRT1ARxeFrNBJ+tsdooMwqnYhE7zIxnD8pZH+P0Nu1wWxCPTADfNWmqx626IBJJq6NeapcGeOmbtXvl0TeWG0Y7OGGV4+EHTtNBIT5Wd0Bujl7inXgZgfXTM5efD3qDTJ54O9v3Bkv+tdIRlq1kXcVD0BEMirmFxglNPt5pedb1AnxuCYMChUykwsTIWqT23XDpvTiKEru1cTcEMeniB+HQDehxPXNmkotFdwUPnilB/u4Nx5Xc6l8J9jH1EgKZUUt8t8cyoZleDBEt8oibDmJRAoMKJ5Oe9CSWS5ZMEJvacsGVdXDWjp/Ype5x0p9PXB2PAwt2LRD3d+ftNgpuyvxlP8pB84oB1i73vAVpwyrmXW72hfW6Dzn9Jkj4++0VQ4d0KSx1AsDA4OtXXDo63/w+GD+zC7w5SJaxsmnlYRQ4dgdjA7tTl2KNLnpJ+mvkoDxtt1a4oPaX3EVqj96o9sRKBQqU7ZOiupeAIyLMD+Y3YwHx30XWHB5CQiw7q3mj1EDlP2eBsZbz79ayUMbyHQ7s8gu4Lgip1LiGJj7NQj905/+rgUYKAA5qdrlHKIknWmqfuR+PB8RdBkDg/NgnlT89G72h2NvySnj7UyBwD+mi/IWs1xWbxuVwUIVXun5cMqBtFbrccI+DILjsVQg6eeq0itiRfedn89CvyFtpkxaauEvSANuZmB1p8FGPbU94J9medwsZ9HkUYjmI7OH5HuxendLbxTaYrPuIfE2ffXFKhoNBUp33HsFAXmCV/Vxpq5AYgFoRr5Ay93ZLRlgaIPjhZjXZZChT+aE5iWAXMX0oSFQEtwjiuhQQItTQX5IYrKfKB+queTNplR1Hoflo5/I6aPPmACwQCE2jTOYo5Dz1cs7Sod0KTG/3kEDGk3kUaUCON19xSJCab3kNpWZhSWkO8l+SpW70Wn3g0ciOIJO5JXma6dbos6jyisuxXwUUhj2+1uGhcvuliKtWwsUTw4gi1c/diEEpZHoKoxTBeMDmhPhKTx7TXWRakV8imJR355DcIHkR9IREHxohP4TbyR5LtFU24umRPRmEYHbpe1LghyxPx7YgUHjNbbQFRQhh4KeU1EabXx8FS3JAxp2rwRDoeWkJgWRUSKw6gGP5U2PuO9V4ZuiKXGGzFQuRuf+tkSSsbBtRJKhCi3ENuLlXhPbjTKD4djXVnfXFds6Zb+1XiUrRfyayGxJq1+SYBEfbKlgjiSmk0orgTqzSS+DZ5rTqsJbttiNtp+KMqGE2AHGFw6jQqM5vD6vMptmXV9OAjq49Uf/Lx9Opam+Hn5O9p8qoBBAQixzQZ4eNVkO9sPzJAMyR1y4/RCQQ1s0pV5KAU5sKLw3tkcFbI/JqrjCsK4Mw+W8aod4lioYuawUiCyVWBE/qPaFi5bnkgpfu/ae47174rI1fqQoTbW0HrU6FAejq7ByM0V4zkZTg02/YJK2N7hUQRCeZ4BIgSEqgD8XsjzG6LIsSbuHoIdz/LhFzbNn1clci1NHWJ0/6/O8HJMdIpEZbqi1RrrFfoo/rI/7ufm2MPG5lUI0IYJ4MAiHRTSOFJ2oTverFHYXThkYFIoyFx6rMYFgaOKM4xNWdlOnIcKb/suptptgTOTdVIf4YgdaAjJnIAm4qNNHNQqqAzvi53GkyRCEoseUBrHohZsjUbkR8gfKtc/+Oa72lwxJ8Mq6HDfDATbfbJhzeIuFQJSiw1uZprHlzUf90WgqG76zO0eCB1WdPv1IT6sNxxh91GEL2YpgC97ikFHyoaH92ndwduqZ6IYjkg20DX33MWdoZk7QkcKUCgisIYslOaaLyvIIqRKWQj16jE1DlQWJJaPopWTJjXfixEjRJJo8g4++wuQjbq+WVYjsqCuNIQW3YjnxKe2M5ZKEqq+cX7ZVgnkbsU3RWIyXA1rxv4kGersYJjD//auldXGmcEbcfTeF16Y1708FB1HIfmWv6dSFi6oD4E+RIjCsEZ+kY7dKnwReJJw3xCjKvi3kGN42rvyhUlIz0Bp+fNSV5xwFiuBzG296e5s/oHoFtUyUplmPulIPl+e1CQIQVtjlzLzzzbV+D/OVQtYzo5ixtMi5BmHuG4N/uKfJk5UIREp7+12oZlKtPBomXSzAY0KgtbPzzZoHQxujnREUgBU+O/jKKhgxVhRPtbqyHiUaRwRpHv7pgRPyUrnE7fYkVblGmfTY28tFCvlILC04Tz3ivkNWVazA+OsYrxvRM/hiNn8Fc4bQBeUZABGx5S/xFf9Lbbmk298X7iFg2yeimvsQqqJ+hYbt6uq+Zf9jC+Jcwiccd61NKQtFvGWrgJiHB5lwi6fR8KzYS7EaEHf/ka9EC7H8D+WEa3TEACHBkNSj/cXxFeq4RllC+fUFm2xtstYLL2nos1DfzsC9vqDDdRVcPA3Ho95aEQHvExVThXPqym65llkKlfRXbPTRiDepdylHjmV9YTWAEjlD9DdQnCem7Aj/ml58On366392214B5zrmQz/9ySG2mFqEwjq5sFl5tYJPw5hNz8lyZPUTsr5E0F2C9VMPnZckWP7+mbwp/BiN7f4kf7vtGnZF2JGvjK/sDX1RtcFY5oPQnE4lIAYV49U3C9SP0LCY/9i/WIFK9ORjzM9kG/KGrAuwFmgdEpdLaiqQNpCTGZVuAO65afkY1h33hrqyLjZy92JK3/twdj9pafFcwfXONmPQWldPlMe7jlP24Js0v9m8bIJ9TgS2IuRvE9ZVRaCwSJYOtAfL5H/YS4FfzKWKbek+GFulheyKtDNlBtrdmr+KU+ibHTdalzFUmMfxw3f36x+3cQbJLItSilW9cuvZEMjKw987jykZRlsH/UI+HlKfo2tLwemBEeBFtmxF2xmItA/dAIfQ+rXnm88dqvXa+GapOYVt/2waFimXFx3TC2MUiOi5/Ml+3rj/YU6Ihx2hXgiDXFsUeQkRAD6wF3SCPi2flk7XwKAA4zboqynuELD312EJ88lmDEVOMa1W/K/a8tGylZRMrMoILyoMQzzbDJHNZrhH77L9qSC42HVmKiZ5S0016UTp83gOhCwz9XItK9fgXfK3F5d7nZCBUekoLxrutQaPHa16Rjsa0gTrzyjqTnmcIcrxg6X6dkKiucudc0DD5W4pJPf0vuDW8r5/uw24YfMuxFRpD2ovT2mFX79xH6Jf+MVdv2TYqR6/955QgVPe3JCD/WjAYcLA9tpXgFiEjge2J5ljeI/iUzg91KQuHkII4mmHZxC3XQORLAC6G7uFn5LOmlnXkjFdoO976moNTxElS8HdxWoPAkjjocDR136m2l+f5t6xaaNgdodOvTu0rievnhNAB79WNrVs6EsPgkgfahF9gSFzzAd+rJSraw5Mllit7vUP5YxA843lUpu6/5jAR0RvH4rRXkSg3nE+O5GFyfe+L0s5r3k05FyghSFnKo4TTgs07qj4nTLqOYj6qaW9knJTDkF5OFMYbmCP+8H16Ty482OjvERV6OFyw043L9w3hoJi408sR+SGo1WviXUu8d7qS+ehKjpKwxeCthsm2LBFSFeetx0x4AaKPxtp3CxdWqCsLrB1s/j5TAhc1jNZsXWl6tjo/WDoewxzg8T8NnhZ1niUwL/nhfygLanCnRwaFGDyLw+sfZhyZ1UtYTp8TYB6dE7R3VsKKH95CUxJ8u8N+9u2/9HUNKHW3x3w5GQrfOPafk2w5qZq8MaHT0ebeY3wIsp3rN9lrpIsW9c1ws3VNV+JwNz0Lo9+V7zZr6GD56We6gWVIvtmam5GPPkVAbr74r6SwhuL+TRXtW/0pgyX16VNl4/EAD50TnUPuwrW6OcUO2VlWXS0inq872kk7GUlW6o/ozFKq+Sip6LcTtSDfDrPTcCHhx75H8BeRon+KG2wRwzfDgWhALmiWOMO6h3pm1UCZEPEjScyk7tdLx6WrdA2N1QTPENvNnhCQjW6kl057/qv7IwRryHrZBCwVSbLLnFRiHdTwk8mlYixFt1slEcPD7FVht13HyqVeyD55HOXrh2ElAxJyinGeoFzwKA91zfrdLvDxJSjzmImfvTisreI25EDcVfGsmxLVbfU8PGe/7NmWWKjXcdTJ11jAlVIY/Bv/mcxg/Q10vCHwKG1GW/XbJq5nxDhyLqiorn7Wd7VEVL8UgVzpHMjQ+Z8DUgSukiVwWAKkeTlVVeZ7t1DGnCgJVIdBPZAEK5f8CDyDNo7tK4/5DBjdD5MPV86TaEhGsLVFPQSI68KlBYy84FievdU9gWh6XZrugvtCZmi9vfd6db6V7FmoEcRHnG36VZH8N4aZaldq9zZawt1uBFgxYYx+Gs/qW1jwANeFy+LCoymyM6zgG7j8bGzUyLhvrbJkTYAEdICEb4kMKusKT9V3eIwMLsjdUdgijMc+7iKrr+TxrVWG0U+W95SGrxnxGrE4eaJFfgvAjUM4SAy8UaRwE9j6ZQH5qYAWGtXByvDiLSDfOD0yFA3UCMKSyQ30fyy1mIRg4ZcgZHLNHWl+c9SeijOvbOJxoQy7lTN2r3Y8p6ovxvUY74aOYbuVezryqXA6U+fcp6wSV9X5/OZKP18tB56Ua0gMyxJI7XyNT7IrqN8GsB9rL/kP5KMrjXxgqKLDa+V5OCH6a5hmOWemMUsea9vQl9t5Oce76PrTyTv50ExOqngE3PHPfSL//AItPdB7kGnyTRhVUUFNdJJ2z7RtktZwgmQzhBG/G7QsjZmJfCE7k75EmdIKH7xlnmDrNM/XbTT6FzldcH/rcRGxlPrv4qDScqE7JSmQABJWqRT/TUcJSwoQM+1jvDigvrjjH8oeK2in1S+/yO1j8xAws/T5u0VnIvAPqaE1atNuN0cuRliLcH2j0nTL4JpcR7w9Qya0JoaHgsOiALLCCzRkl1UUESz+ze/gIXHGtDwgYrK6pCFKJ1webSDog4zTlPkgXZqxlQDiYMjhDpwTtBW2WxthWbov9dt2X9XFLFmcF+eEc1UaQ74gqZiZsdj63pH1qcv3Vy8JYciogIVKsJ8Yy3J9w/GhjWVSQAmrS0BPOWK+RKV+0lWqXgYMnIFwpcZVD7zPSp547i9HlflB8gVnSTGmmq1ClO081OW/UH11pEQMfkEdDFzjLC1Cdo/BdL3s7cXb8J++Hzz1rhOUVZFIPehRiZ8VYu6+7Er7j5PSZu9g/GBdmNzJmyCD9wiswj9BZw+T3iBrg81re36ihMLjoVLoWc+62a1U/7qVX5CpvTVF7rocSAKwv4cBVqZm7lLDS/qoXs4fMs/VQi6BtVbNA3uSzKpQfjH1o3x4LrvkOn40zhm6hjduDglzJUwA0POabgdXIndp9fzhOo23Pe+Rk9GSLX0d71Poqry8NQDTzNlsa+JTNG9+UrEf+ngxCjGEsDCc0bz+udVRyHQI1jmEO3S+IOQycEq7XwB6z3wfMfa73m8PVRp+iOgtZfeSBl01xn03vMaQJkyj7vnhGCklsCWVRUl4y+5oNUzQ63B2dbjDF3vikd/3RUMifPYnX5Glfuk2FsV/7RqjI9yKTbE8wJY+74p7qXO8+dIYgjtLD/N8TJtRh04N9tXJA4H59IkMmLElgvr0Q5OCeVfdAt+5hkh4pQgfRMHpL74XatLQpPiOyHRs/OdmHtBf8nOZcxVKzdGclIN16lE7kJ+pVMjspOI+5+TqLRO6m0ZpNXJoZRv9MPDRcAfJUtNZHyig/s2wwReakFgPPJwCQmu1I30/tcBbji+Na53i1W1N+BqoY7Zxo+U/M9XyJ4Ok2SSkBtoOrwuhAY3a03Eu6l8wFdIG1cN+e8hopTkiKF093KuH/BcB39rMiGDLn6XVhGKEaaT/vqb/lufuAdpGExevF1+J9itkFhCfymWr9vGb3BTK4j598zRH7+e+MU9maruZqb0pkGxRDRE1CD4Z8LV4vhgPidk5w2Bq816g3nHw1//j3JStz7NR9HIWELO8TMn3QrP/zZp//+Dv9p429/ogv+GATR+n/UdF+ns9xNkXZQJXY4t9jMkJNUFygAtzndXwjss+yWH9HAnLQQfhAskdZS2l01HLWv7L7us5uTH409pqitvfSOQg/c+Zt7k879P3K9+WV68n7+3cZfuRd/dDPP/03rn+d+/nBvWfgDlt8+LzjqJ/vx3CnNOwiXhho778C96iD+1TBvRZYeP+EH81LE0vVwOOrmCLB3iKzI1x+vJEsrPH4uF0UB4TJ4X3uDfOCo3PYpYe0MF4bouh0DQ/l43fxUF7Y+dpWuvTSffB0yO2UQUETI/LwCZE3BvnevJ7c9zUlY3H58xzke6DNFDQG8n0WtDN4LAYN4nogKav1ezOfK/z+t6tsCTp+dhx4ymjWuCJk1dEUifDP+HyS4iP/Vg9B2jTo9L4NbiBuDS4nuuHW6H+JDQn2JtqRKGkEQPEYE7uzazXIkcxIAqUq1esasZBETlEZY7y7Jo+RoV/IsjY9eIMkUvr42Hc0xqtsavZvhz1OLwSxMOTuqzlhb0WbdOwBH9EYiyBjatz40bUxTHbiWxqJ0uma19qhPruvcWJlbiSSH48OLDDpaHPszvyct41ZfTu10+vjox6kOqK6v0K/gEPphEvMl/vwSv+A4Hhm36JSP9IXTyCZDm4kKsqD5ay8b1Sad/vaiyO5N/sDfEV6Z4q95E+yfjxpqBoBETW2C7xl4pIO2bDODDFurUPwE7EWC2Uplq+AHmBHvir2PSgkR12/Ry65O0aZtQPeXi9mTlF/Wj5GQ+vFkYyhXsLTjrBSP9hwk4GPqDP5rBn5/l8b0mLRAvRSzXHc293bs3s8EsdE3m2exxidWVB4joHR+S+dz5/W+v00K3TqN14CDBth8eWcsTbiwXPsygHdGid0PEdy6HHm2v/IUuV5RVapYmzGsX90mpnIdNGcOOq64Dbc5GUbYpD9M7S+6cLY//QmjxFLP5cuTFRm3vA5rkFZroFnO3bjHF35uU3s8mvL7Tp9nyTc4mymTJ5sLIp7umSnGkO23faehtz3mmTS7fbVx5rP7x3HXIjRNeq/A3xCs9JNB08c9S9BF2O3bOur0ItslFxXgRPdaapBIi4dRpKGxVz7ir69t/bc9qTxjvtOyGOfiLGDhR4fYywHv1WdOplxIV87TpLBy3Wc0QP0P9s4G7FBNOdITS/tep3o3h1TEa5XDDii7fWtqRzUEReP2fbxz7bHWWJdbIOxOUJZtItNZpTFRfj6vm9sYjRxQVO+WTdiOhdPeTJ+8YirPvoeL88l5iLYOHd3b/Imkq+1ZN1El3UikhftuteEYxf1Wujof8Pr4ICTu5ezZyZ4tHQMxlzUHLYO2VMOoNMGL/20S5i2o2obfk+8qqdR7xzbRDbgU0lnuIgz4LelQ5XS7xbLuSQtNS95v3ZUOdaUx/Qd8qxCt6xf2E62yb/HukLO6RyorV8KgYl5YNc75y+KvefrxY+lc/64y9kvWP0a0bDz/rojq+RWjO06WeruWqNFU7r3HPIcLWRql8ICZsz2Ls/qOm/CLn6++X+Qf7mGspYCrZod/lpl6Rw4xN/yuq8gqV4B6aHk1hVE1SfILxWu5gvXqbfARYQpspcxKp1F/c8XOPzkZvmoSw+vEqBLdrq1fr3wAPv5NnM9i8F+jdAuxkP5Z71c6uhK3enlnGymr7UsWZKC12qgUiG8XXGQ9mxnqz4GSIlybF9eXmbqj2sHX+a1jf0gRoONHRdRSrIq03Ty89eQ1GbV/Bk+du4+V15zls+vvERvZ4E7ZbnxWTVjDjb4o/k8jlw44pTIrUGxxuJvBeO+heuhOjpFsO6lVJ/aXnJDa/bM0Ql1cLbXE/Pbv3EZ3vj3iVrB5irjupZTzlnv677NrI9UNYNqbPgp/HZXS+lJmk87wec+7YOxTDo2aw2l3NfDr34VNlvqWJBknuK7oSlZ6/T10zuOoPZOeoIk81N+sL843WJ2Q4Z0fZ3scsqC/JV2fuhWi1jGURSKZV637lf53Xnnx16/vKEXY89aVJ0fv91jGdfG+G4+sniwHes4hS+udOr4RfhFhG/F5gUG35QaU+McuLmclb5ZWmR+sG5V6nf+PxYzlrnFGxpZaK8eqqVo0NfmAWoGfXDiT/FnUbWvzGDOTr8aktOZWg4BYvz5YH12ZbfCcGtNk+dDAZNGWvHov+PIOnY9Prjg8h/wLRrT69suaMVZ5bNuK00lSVpnqSX1NON/81FoP92rYndionwgOiA8WMf4vc8l15KqEEG4yAm2+WAN5Brfu1sq9suWYqgoajgOYt/JCk1gC8wPkK+XKCtRX6TAtgvrnuBgNRmn6I8lVDipOVB9kX6Oxkp4ZKyd1M6Gj8/v2U7k+YQBL95Kb9PQENucJb0JlW3b5tObN7m/Z1j1ev388d7o15zgXsI9CikAGAViR6lkJv7nb4Ak40M2G8TJ447kN+pvfHiOFjSUSP6PM+QfbAywKJCBaxSVxpizHseZUyUBhq59vFwrkyGoRiHbo0apweEZeSLuNiQ+HAekOnarFg00dZNXaPeoHPTRR0FmEyqYExOVaaaO8c0uFUh7U4e/UxdBmthlBDgg257Q33j1hA7HTxSeTTSuVnPZbgW1nodwmG16aKBDKxEetv7D9OjO0JhrbJTnoe+kcGoDJazFSO8/fUN9Jy/g4XK5PUkw2dgPDGpJqBfhe7GA+cjzfE/EGsMM+FV9nj9IAhrSfT/J3QE5TEIYyk5UjsI6ZZcCPr6A8FZUF4g9nnpVmjX90MLSQysIPD0nFzqwCcSJmIb5mYv2Cmk+C1MDFkZQyCBq4c/Yai9LJ6xYkGS/x2s5/frIW2vmG2Wrv0APpCdgCA9snFvfpe8uc0OwdRs4G9973PGEBnQB5qKrCQ6m6X/H7NInZ7y/1674/ZXOVp7OeuCRk8JFS516VHrnH1HkIUIlTIljjHaQtEtkJtosYul77cVwjk3gW1Ajaa6zWeyHGLlpk3VHE2VFzT2yI/EvlGUSz2H9zYE1s4nsKMtMqNyKNtL/59CpFJki5Fou6VXGm8vWATEPwrUVOLvoA8jLuwOzVBCgHB2Cr5V6OwEWtJEKokJkfc87h+sNHTvMb0KVTp5284QTPupoWvQVUwUeogZR3kBMESYo0mfukewRVPKh5+rzLQb7HKjFFIgWhj1w3yN/qCNoPI8XFiUgBNT1hCHBsAz8L7Oyt8wQWUFj92ONn/APyJFg8hzueqoJdNj57ROrFbffuS/XxrSXLTRgj5uxZjpgQYceeMc2wJrahReSKpm3QjHfqExTLAB2ipVumE8pqcZv8LYXQiPHHsgb5BMW8zM5pvQit+mQx8XGaVDcfVbLyMTlY8xcfmm/RSAT/H09UQol5gIz7rESDmnrQ4bURIB4iRXMDQwxgex1GgtDxKp2HayIkR+E/aDmCttNm2C6lytWdfOVzD6X2SpDWjQDlMRvAp1symWv4my1bPCD+E1EmGnMGWhNwmycJnDV2WrQNxO45ukEb08AAffizYKVULp15I4vbNK5DzWwCSUADfmKhfGSUqii1L2UsE8rB7mLuHuUJZOx4+WiizHBJ/hwboaBzhpNOVvgFTf5cJsHef7L1HCI9dOUUbb+YxUJWn6dYOLz+THi91kzY5dtO5c+grX7v0jEbsuoOGnoIreDIg/sFMyG+TyCLIcAWd1IZ1UNFxE8Uie13ucm40U2fcxC0u3WLvLOxwu+F7MWUsHsdtFQZ7W+nlfCASiAKyh8rnP3EyDByvtJb6Kax6/HkLzT9SyEyTMVM1zPtM0MJY14DmsWh4MgD15Ea9Hd00AdkTZ0EiG5NAGuIBzQJJ0JR0na+OB7lQA6UKxMfihIQ7GCCnVz694QvykWXTxpS2soDu+smru1UdIxSvAszBFD1c8c6ZOobA8bJiJIvuycgIXBQIXWwhyTgZDQxJTRXgEwRNAawGSXO0a1DKjdihLVNp/taE/xYhsgwe+VpKEEB4LlraQyE84gEihxCnbfoyOuJIEXy2FIYw+JjRusybKlU2g/vhTSGTydvCvXhYBdtAXtS2v7LkHtmXh/8fly1do8FI/D0f8UbzVb5h+KRhMGSAmR2mhi0YG/uj7wgxcfzCrMvdjitUIpXDX8ae2JcF/36qUWIMwN6JsjaRGNj+jEteGDcFyTUb8X/NHSucKMJp7pduxtD6KuxVlyxxwaeiC1FbGBESO84lbyrAugYxdl+2N8/6AgWpo/IeoAOcsG35IA/b3AuSyoa55L7llBLlaWlEWvuCFd8f8NfcTUgzJv6CbB+6ohWwodlk9nGWFpBAOaz5uEW5xBvmjnHFeDsb0mXwayj3mdYq5gxxNf3H3/tnCgHwjSrpSgVxLmiTtuszdRUFIsn6LiMPjL808vL1uQhDbM7aA43mISXReqjSskynIRcHCJ9qeFopJfx9tqyUoGbSwJex/0aDE3plBPGtNBYgWbdLom3+Q/bjdizR2/AS/c/dH/d3G7pyl1qDXgtOFtEqidwLqxPYtrNEveasWq3vPUUtqTeu8gpov4bdOQRI2kneFvRNMrShyVeEupK1PoLDPMSfWMIJcs267mGB8X9CehQCF0gIyhpP10mbyM7lwW1e6TGvHBV1sg/UyTghHPGRqMyaebC6pbB1WKNCQtlai1GGvmq9zUKaUzLaXsXEBYtHxmFbEZ2kJhR164LhWW2Tlp1dhsGE7ZgIWRBOx3Zcu2DxgH+G83WTPceKG0TgQKKiiNNOlWgvqNEbnrk6fVD+AqRam2OguZb0YWSTX88N+i/ELSxbaUUpPx4vJUzYg/WonSeA8xUK6u7DPHgpqWpEe6D4cXg5uK9FIYVba47V/nb+wyOtk+zG8RrS4EA0ouwa04iByRLSvoJA2FzaobbZtXnq8GdbfqEp5I2dpfpj59TCVif6+E75p665faiX8gS213RqBxTZqfHP46nF6NSenOneuT+vgbLUbdTH2/t0REFXZJOEB6DHvx6N6g9956CYrY/AYcm9gELJXYkrSi+0F0geKDZgOCIYkLU/+GOW5aGj8mvLFgtFH5+XC8hvAE3CvHRfl4ofM/Qwk4x2A+R+nyc9gNu/9Tem7XW4XRnyRymf52z09cTOdr+PG6+P/Vb4QiXlwauc5WB1z3o+IJjlbxI8MyWtSzT+k4sKVbhF3xa+vDts3NxXa87iiu+xRH9cAprnOL2h6vV54iQRXuOAj1s8nLFK8gZ70ThIQcWdF19/2xaJmT0efrkNDkWbpAQPdo92Z8+Hn/aLjbOzB9AI/k12fPs9HhUNDJ1u6ax2VxD3R6PywN7BrLJ26z6s3QoMp76qzzwetrDABKSGkfW5PwS1GvYNUbK6uRqxfyVGNyFB0E+OugMM8kKwmJmupuRWO8XkXXXQECyRVw9UyIrtCtcc4oNqXqr7AURBmKn6Khz3eBN96LwIJrAGP9mr/59uTOSx631suyT+QujDd4beUFpZ0kJEEnjlP+X/Kr2kCKhnENTg4BsMTOmMqlj2WMFLRUlVG0fzdCBgUta9odrJfpVdFomTi6ak0tFjXTcdqqvWBAzjY6hVrH9sbt3Z9gn+AVDpTcQImefbB4edirjzrsNievve4ZT4EUZWV3TxEsIW+9MT/RJoKfZZYSRGfC1CwPG/9rdMOM8qR/LUYvw5f/emUSoD7YSFuOoqchdUg2UePd1eCtFSKgxLSZ764oy4lvRCIH6bowPxZWwxNFctksLeil47pfevcBipkkBIc4ngZG+kxGZ71a72KQ7VaZ6MZOZkQJZXM6kb/Ac0/XkJx8dvyfJcWbI3zONEaEPIW8GbkYjsZcwy+eMoKrYjDmvEEixHzkCSCRPRzhOfJZuLdcbx19EL23MA8rnjTZZ787FGMnkqnpuzB5/90w1gtUSRaWcb0eta8198VEeZMUSfIhyuc4/nywFQ9uqn7jdqXh+5wwv+RK9XouNPbYdoEelNGo34KyySwigsrfCe0v/PlWPvQvQg8R0KgHO18mTVThhQrlbEQ0Kp/JxPdjHyR7E1QPw/ut0r+HDDG7BwZFm9IqEUZRpv2WpzlMkOemeLcAt5CsrzskLGaVOAxyySzZV/D2EY7ydNZMf8e8VhHcKGHAWNszf1EOq8fNstijMY4JXyATwTdncFFqcNDfDo+mWFvxJJpc4sEZtjXyBdoFcxbUmniCoKq5jydUHNjYJxMqN1KzYV62MugcELVhS3Bnd+TLLOh7dws/zSXWzxEb4Nj4aFun5x4kDWLK5TUF/yCXB/cZYvI9kPgVsG2jShtXkxfgT+xzjJofXqPEnIXIQ1lnIdmVzBOM90EXvJUW6a0nZ/7XjJGl8ToO3H/fdxnxmTNKBZxnkpXLVgLXCZywGT3YyS75w/PAH5I/jMuRspej8xZObU9kREbRA+kqjmKRFaKGWAmFQspC+QLbKPf0RaK3OXvBSWqo46p70ws/eZpu6jCtZUgQy6r4tHMPUdAgWGGUYNbuv/1a6K+MVFsd3T183+T8capSo6m0+Sh57fEeG/95dykGJBQMj09DSW2bY0mUonDy9a8trLnnL5B5LW3Nl8rJZNysO8Zb+80zXxqUGFpud3Qzwb7bf+8mq6x0TAnJU9pDQR9YQmZhlna2xuxJt0aCO/f1SU8gblOrbIyMsxTlVUW69VJPzYU2HlRXcqE2lLLxnObZuz2tT9CivfTAUYfmzJlt/lOPgsR6VN64/xQd4Jlk/RV7UKVv2Gx/AWsmTAuCWKhdwC+4HmKEKYZh2Xis4KsUR1BeObs1c13wqFRnocdmuheaTV30gvVXZcouzHKK5zwrN52jXJEuX6dGx3BCpV/++4f3hyaW/cQJLFKqasjsMuO3B3WlMq2gyYfdK1e7L2pO/tRye2mwzwZPfdUMrl5wdLqdd2Kv/wVtnpyWYhd49L6rsOV+8HXPrWH2Kup89l2tz6bf80iYSd+V4LROSOHeamvexR524q4r43rTmtFzQvArpvWfLYFZrbFspBsXNUqqenjxNNsFXatZvlIhk7teUPfK+YL32F8McTnjv0BZNppb+vshoCrtLXjIWq3EJXpVXIlG6ZNL0dh6qEm2WMwDjD3LfOfkGh1/czYc/0qhiD2ozNnH4882MVVt3JbVFkbwowNCO3KL5IoYW5wlVeGCViOuv1svZx7FbzxKzA4zGqBlRRaRWCobXaVq4yYCWbZf8eiJwt3OY+MFiSJengcFP2t0JMfzOiJ7cECvpx7neg1Rc5x+7myPJOXt2FohVRyXtD+/rDoTOyGYInJelZMjolecVHUhUNqvdZWg2J2t0jPmiLFeRD/8fOT4o+NGILb+TufCo9ceBBm3JLVn+MO2675n7qiEX/6W+188cYg3Zn5NSTjgOKfWFSAANa6raCxSoVU851oJLY11WIoYK0du0ec5E4tCnAPoKh71riTsjVIp3gKvBbEYQiNYrmH22oLQWA2AdwMnID6PX9b58dR2QKo4qag1D1Z+L/FwEKTR7osOZPWECPJIHQqPUsM5i/CH5YupVPfFA5pHUBcsesh8eO5YhyWnaVRPZn/BmdXVumZWPxMP5e28zm2uqHgFoT9CymHYNNrzrrjlXZM06HnzDxYNlI5b/QosxLmmrqDFqmogQdqk0WLkUceoAvQxHgkIyvWU69BPFr24VB6+lx75Rna6dGtrmOxDnvBojvi1/4dHjVeg8owofPe1cOnxU1ioh016s/Vudv9mhV9f35At+Sh28h1bpp8xhr09+vf47Elx3Ms6hyp6QvB3t0vnLbOhwo660cp7K0vvepabK7YJfxEWWfrC2YzJfYOjygPwfwd/1amTqa0hZ5ueebhWYVMubRTwIjj+0Oq0ohU3zfRfuL8gt59XsHdwKtxTQQ4Y2qz6gisxnm2UdlmpEkgOsZz7iEk6QOt8BuPwr+NR01LTqXmJo1C76o1N274twJvl+I069TiLpenK/miRxhyY8jvYV6W1WuSwhH9q7kuwnJMtm7IWcqs7HsnyHSqWXLSpYtZGaR1V3t0gauninFPZGtWskF65rtti48UV9uV9KM8kfDYs0pgB00S+TlzTXV6P8mxq15b9En8sz3jWSszcifZa/NuufPNnNTb031pptt0+sRSH/7UG8pzbsgtt3OG3ut7B9JzDMt2mTZuyRNIV8D54TuTrpNcHtgmMlYJeiY9XS83NYJicjRjtJSf9BZLsQv629QdDsKQhTK5CnXhpk7vMNkHzPhm0ExW/VCGApHfPyBagtZQTQmPHx7g5IXXsrQDPzIVhv2LB6Ih138iSDww1JNHrDvzUxvp73MsQBVhW8EbrReaVUcLB1R3PUXyaYG4HpJUcLVxMgDxcPkVRQpL7VTAGabDzbKcvg12t5P8TSGQkrj/gOrpnbiDHwluA73xbXts/L7u468cRWSWRtgTwlQnA47EKg0OiZDgFxAKQQUcsbGomITgeXUAAyKe03eA7Mp4gnyKQmm0LXJtEk6ddksMJCuxDmmHzmVhO+XaN2A54MIh3niw5CF7PwiXFZrnA8wOdeHLvvhdoqIDG9PDI7UnWWHq526T8y6ixJPhkuVKZnoUruOpUgOOp3iIKBjk+yi1vHo5cItHXb1PIKzGaZlRS0g5d3MV2pD8FQdGYLZ73aae/eEIUePMc4NFz8pIUfLCrrF4jVWH5gQneN3S8vANBmUXrEcKGn6hIUN95y1vpsvLwbGpzV9L0ZKTan6TDXM05236uLJcIEMKVAxKNT0K8WljuwNny3BNQRfzovA85beI9zr1AGNYnYCVkR1aGngWURUrgqR+gRrQhxW81l3CHevjvGEPzPMTxdsIfB9dfGRbZU0cg/1mcubtECX4tvaedmNAvTxCJtc2QaoUalGfENCGK7IS/O8CRpdOVca8EWCRwv2sSWE8CJPW5PCugjCXPd3h6U60cPD+bdhtXZuYB6stcoveE7Sm5MM2yvfUHXFSW7KzLmi7/EeEWL0wqcOH9MOSKjhCHHmw+JGLcYE/7SBZQCRggox0ZZTAxrlzNNXYXL5fNIjkdT4YMqVUz6p8YDt049v4OXGdg3qTrtLBUXOZf7ahPlZAY/O+7Sp0bvGSHdyQ8B1LOsplqMb9Se8VAE7gIdSZvxbRSrfl+Lk5Qaqi5QJceqjitdErcHXg/3MryljPSIAMaaloFm1cVwBJ8DNmkDqoGROSHFetrgjQ5CahuKkdH5pRPigMrgTtlFI8ufJPJSUlGgTjbBSvpRc0zypiUn6U5KZqcRoyrtzhmJ7/caeZkmVRwJQeLOG8LY6vP5ChpKhc8Js0El+n6FXqbx9ItdtLtYP92kKfaTLtCi8StLZdENJa9Ex1nOoz1kQ7qxoiZFKRyLf4O4CHRT0T/0W9F8epNKVoeyxUXhy3sQMMsJjQJEyMOjmOhMFgOmmlscV4eFi1CldU92yjwleirEKPW3bPAuEhRZV7JsKV3Lr5cETAiFuX5Nw5UlF7d2HZ96Bh0sgFIL5KGaKSoVYVlvdKpZJVP5+NZ7xDEkQhmDgsDKciazJCXJ6ZN2B3FY2f6VZyGl/t4aunGIAk/BHaS+i+SpdRfnB/OktOvyjinWNfM9Ksr6WwtCa1hCmeRI6icpFM4o8quCLsikU0tMoZI/9EqXRMpKGaWzofl4nQuVQm17d5fU5qXCQeCDqVaL9XJ9qJ08n3G3EFZS28SHEb3cdRBdtO0YcTzil3QknNKEe/smQ1fTb0XbpyNB5xAeuIlf+5KWlEY0DqJbsnzJlQxJPOVyHiKMx5Xu9FcEv1Fbg6Fhm4t+Jyy5JC1W3YO8dYLsO0PXPbxodBgttTbH3rt9Cp1lJIk2r3O1Zqu94eRbnIz2f50lWolYzuKsj4PMok4abHLO8NAC884hiXx5Fy5pWKO0bWL7uEGXaJCtznhP67SlQ4xjWIfgq6EpZ28QMtuZK7JC0RGbl9nA4XtFLug/NLMoH1pGt9IonAJqcEDLyH6TDROcbsmGPaGIxMo41IUAnQVPMPGByp4mOmh9ZQMkBAcksUK55LsZj7E5z5XuZoyWCKu6nHmDq22xI/9Z8YdxJy4kWpD16jLVrpwGLWfyOD0Wd+cBzFBxVaGv7S5k9qwh/5t/LQEXsRqI3Q9Rm3QIoaZW9GlsDaKOUyykyWuhNOprSEi0s1G4rgoiX1V743EELti+pJu5og6X0g6oTynUqlhH9k6ezyRi05NGZHz0nvp3HOJr7ebrAUFrDjbkFBObEvdQWkkUbL0pEvMU46X58vF9j9F3j6kpyetNUBItrEubW9ZvMPM4qNqLlsSBJqOH3XbNwv/cXDXNxN8iFLzUhteisYY+RlHYOuP29/Cb+L+xv+35Rv7xudnZ6ohK4cMPfCG8KI7dNmjNk/H4e84pOxn/sZHK9psfvj8ncA8qJz7O8xqbxESDivGJOZzF7o5PJLQ7g34qAWoyuA+x3btU98LT6ZyGyceIXjrqob2CAVql4VOTQPUQYvHV/g4zAuCZGvYQBtf0wmd5lilrvuEn1BXLny01B4h4SMDlYsnNpm9d7m9h578ufpef9Z4WplqWQvqo52fyUA7J24eZD5av6SyGIV9kpmHNqyvdfzcpEMw97BvknV2fq+MFHun9BT3Lsf8pbzvisWiIQvYkng+8Vxk1V+dli1u56kY50LRjaPdotvT5BwqtwyF+emo/z9J3yVUVGfKrxQtJMOAQWoQii/4dp9wgybSa5mkucmRLtEQZ/pz0tL/NVcgWAd95nEQ3Tg6tNbuyn3Iepz65L3huMUUBntllWuu4DbtOFSMSbpILV4fy6wlM0SOvi6CpLh81c1LreIvKd61uEWBcDw1lUBUW1I0Z+m/PaRlX+PQ/oxg0Ye6KUiIiTF4ADNk59Ydpt5/rkxmq9tV5Kcp/eQLUVVmBzQNVuytQCP6Ezd0G8eLxWyHpmZWJ3bAzkWTtg4lZlw42SQezEmiUPaJUuR/qklVA/87S4ArFCpALdY3QRdUw3G3XbWUp6aq9z0zUizcPa7351p9JXOZyfdZBFnqt90VzQndXB/mwf8LC9STj5kenVpNuqOQQP3mIRJj7eV21FxG8VAxKrEn3c+XfmZ800EPb9/5lIlijscUbB6da0RQaMook0zug1G0tKi/JBC4rw7/D3m4ARzAkzMcVrDcT2SyFtUdWAsFlsPDFqV3N+EjyXaoEePwroaZCiLqEzb8MW+PNE9TmTC01EzWli51PzZvUqkmyuROU+V6ik+Le/9qT6nwzUzf9tP68tYei0YaDGx6kAd7jn1cKqOCuYbiELH9zYqcc4MnRJjkeGiqaGwLImhyeKs+xKJMBlOJ05ow9gGCKZ1VpnMKoSCTbMS+X+23y042zOb5MtcY/6oBeAo1Vy89OTyhpavFP78jXCcFH0t7Gx24hMEOm2gsEfGabVpQgvFqbQKMsknFRRmuPHcZu0Su/WMFphZvB2r/EGbG72rpGGho3h+Msz0uGzJ7hNK2uqQiE1qmn0zgacKYYZBCqsxV+sjbpoVdSilW/b94n2xNb648VmNIoizqEWhBnsen+d0kbCPmRItfWqSBeOd9Wne3c6bcd6uvXOJ6WdiSsuXq0ndhqrQ4QoWUjCjYtZ0EAhnSOP1m44xkf0O7jXghrzSJWxP4a/t72jU29Vu2rvu4n7HfHkkmQOMGSS+NPeLGO5I73mC2B7+lMiBQQZRM9/9liLIfowupUFAbPBbR+lxDM6M8Ptgh1paJq5Rvs7yEuLQv/7d1oU2woFSb3FMPWQOKMuCuJ7pDDjpIclus5TeEoMBy2YdVB4fxmesaCeMNsEgTHKS5WDSGyNUOoEpcC2OFWtIRf0w27ck34/DjxRTVIcc9+kqZE6iMSiVDsiKdP/Xz5XfEhm/sBhO50p1rvJDlkyyxuJ9SPgs7YeUJBjXdeAkE+P9OQJm6SZnn1svcduI78dYmbkE2mtziPrcjVisXG78spLvbZaSFx/Rks9zP4LKn0Cdz/3JsetkT06A8f/yCgMO6Mb1Hme0JJ7b2wZz1qleqTuKBGokhPVUZ0dVu+tnQYNEY1fmkZSz6+EGZ5EzL7657mreZGR3jUfaEk458PDniBzsSmBKhDRzfXameryJv9/D5m6HIqZ0R+ouCE54Dzp4IJuuD1e4Dc5i+PpSORJfG23uVgqixAMDvchMR0nZdH5brclYwRoJRWv/rlxGRI5ffD5NPGmIDt7vDE1434pYdVZIFh89Bs94HGGJbTwrN8T6lh1HZFTOB4lWzWj6EVqxSMvC0/ljWBQ3F2kc/mO2b6tWonT2JEqEwFts8rz2h+oWNds9ceR2cb7zZvJTDppHaEhK5avWqsseWa2Dt5BBhabdWSktS80oMQrL4TvAM9b5HMmyDnO+OkkbMXfUJG7eXqTIG6lqSOEbqVR+qYdP7uWb57WEJqzyh411GAVsDinPs7KvUeXItlcMdOUWzXBH6zscymV1LLVCtc8IePojzXHF9m5b5zGwBRdzcyUJkiu938ApmAayRdJrX1PmVguWUvt2ThQ62czItTyWJMW2An/hdDfMK7SiFQlGIdAbltHz3ycoh7j9V7GxNWBpbtcSdqm4XxRwTawc3cbZ+xfSv9qQfEkDKfZTwCkqWGI/ur250ItXlMlh6vUNWEYIg9A3GzbgmbqvTN8js2YMo87CU5y6nZ4dbJLDQJj9fc7yM7tZzJDZFtqOcU8+mZjYlq4VmifI23iHb1ZoT9E+kT2dolnP1AfiOkt7PQCSykBiXy5mv637IegWSKj9IKrYZf4Lu9+I7ub+mkRdlvYzehh/jaJ9n7HUH5b2IbgeNdkY7wx1yVzxS7pbvky6+nmVUtRllEFfweUQ0/nG017WoUYSxs+j2B4FV/F62EtHlMWZXYrjGHpthnNb1x66LKZ0Qe92INWHdfR/vqp02wMS8r1G4dJqHok8KmQ7947G13a4YXbsGgHcBvRuVu1eAi4/A5+ZixmdSXM73LupB/LH7O9yxLTVXJTyBbI1S49TIROrfVCOb/czZ9pM4JsZx8kUz8dQGv7gUWKxXvTH7QM/3J2OuXXgciUhqY+cgtaOliQQVOYthBLV3xpESZT3rmfEYNZxmpBbb24CRao86prn+i9TNOh8VxRJGXJfXHATJHs1T5txgc/opYrY8XjlGQQbRcoxIBcnVsMjmU1ymmIUL4dviJXndMAJ0Yet+c7O52/p98ytlmAsGBaTAmMhimAnvp1TWNGM9BpuitGj+t810CU2UhorrjPKGtThVC8WaXw04WFnT5fTjqmPyrQ0tN3CkLsctVy2xr0ZWgiWVZ1OrlFjjxJYsOiZv2cAoOvE+7sY0I/TwWcZqMoyIKNOftwP7w++Rfg67ljfovKYa50if3fzE/8aPYVey/Nq35+nH2sLPh/fP5TsylSKGOZ4k69d2PnH43+kq++sRXHQqGArWdwhx+hpwQC6JgT2uxehYU4Zbw7oNb6/HLikPyJROGK2ouyr+vzseESp9G50T4AyFrSqOQ0rroCYP4sMDFBrHn342EyZTMlSyk47rHSq89Y9/nI3zG5lX16Z5lxphguLOcZUndL8wNcrkyjH82jqg8Bo8OYkynrxZvbFno5lUS3OPr8Ko3mX9NoRPdYOKKjD07bvgFgpZ/RF+YzkWvJ/Hs/tUbfeGzGWLxNAjfDzHHMVSDwB5SabQLsIZHiBp43FjGkaienYoDd18hu2BGwOK7U3o70K/WY/kuuKdmdrykIBUdG2mvE91L1JtTbh20mOLbk1vCAamu7utlXeGU2ooVikbU/actcgmsC1FKk2qmj3GWeIWbj4tGIxE7BLcBWUvvcnd/lYxsMV4F917fWeFB/XbINN3qGvIyTpCalz1lVewdIGqeAS/gB8Mi+sA+BqDiX3VGD2eUunTRbSY+AuDy4E3Qx3hAhwnSXX+B0zuj3eQ1miS8Vux2z/l6/BkWtjKGU72aJkOCWhGcSf3+kFkkB15vGOsQrSdFr6qTj0gBYiOlnBO41170gOWHSUoBVRU2JjwppYdhIFDfu7tIRHccSNM5KZOFDPz0TGMAjzzEpeLwTWp+kn201kU6NjbiMQJx83+LX1e1tZ10kuChJZ/XBUQ1dwaBHjTDJDqOympEk8X2M3VtVw21JksChA8w1tTefO3RJ1FMbqZ01bHHkudDB/OhLfe7P5GOHaI28ZXKTMuqo0hLWQ4HabBsGG7NbP1RiXtETz074er6w/OerJWEqjmkq2y51q1BVI+JUudnVa3ogBpzdhFE7fC7kybrAt2Z6RqDjATAUEYeYK45WMupBKQRtQlU+uNsjnzj6ZmGrezA+ASrWxQ6LMkHRXqXwNq7ftv28dUx/ZSJciDXP2SWJsWaN0FjPX9Yko6LobZ7aYW/IdUktI9apTLyHS8DyWPyuoZyxN1TK/vtfxk3HwWh6JczZC8Ftn0bIJay2g+n5wd7lm9rEsKO+svqVmi+c1j88hSCxbzrg4+HEP0Nt1/B6YW1XVm09T1CpAKjc9n18hjqsaFGdfyva1ZG0Xu3ip6N6JGpyTSqY5h4BOlpLPaOnyw45PdXTN+DtAKg7DLrLFTnWusoSBHk3s0d7YouJHq85/R09Tfc37ENXZF48eAYLnq9GLioNcwDZrC6FW6godB8JnqYUPvn0pWLfQz0lM0Yy8Mybgn84Ds3Q9bDP10bLyOV+qzxa4Rd9Dhu7cju8mMaONXK3UqmBQ9qIg7etIwEqM/kECk/Dzja4Bs1xR+Q/tCbc8IKrSGsTdJJ0vge7IG20W687uVmK6icWQ6cD3lwFzgNMGtFvO5qyJeKflGLAAcQZOrkxVwy3cWvqlGpvjmf9Qe6Ap20MPbV92DPV0OhFM4kz8Yr0ffC2zLWSQ1kqY6QdQrttR3kh1YLtQd1kCEv5hVoPIRWl5ERcUTttBIrWp6Xs5Ehh5OUUwI5aEBvuiDmUoENmnVw1FohCrbRp1A1E+XSlWVOTi7ADW+5Ohb9z1vK4qx5R5lPdGCPBJZ00mC+Ssp8VUbgpGAvXWMuWQQRbCqI6Rr2jtxZxtfP7W/8onz+yz0Gs76LaT5HX9ecyiZCB/ZR/gFtMxPsDwohoeCRtiuLxE1GM1vUEUgBv86+eehL58/P56QFGQ/MqOe/vC76L63jzmeax4exd/OKTUvkXg+fOJUHych9xt/9goJMrapSgvXrj8+8vk/N80f22Sewj6cyGqt1B6mztoeklVHHraouhvHJaG/OuBz6DHKMpFmQULU1bRWlyYE0RPXYYkUycIemN7TLtgNCJX6BqdyxDKkegO7nJK5xQ7OVYDZTMf9bVHidtk6DQX9Et+V9M7esgbsYBdEeUpsB0Xvw2kd9+rI7V+m47u+O/tq7mw7262HU1WlS9uFzsV6JxIHNmUCy0QS9e077JGRFbG65z3/dOKB/Zk+yDdKpUmdXjn/aS3N5nv4fK7bMHHmPlHd4E2+iTbV5rpzScRnxk6KARuDTJ8Q1LpK2mP8gj1EbuJ9RIyY+EWK4hCiIDBAS1Tm2IEXAFfgKPgdL9O6mAa06wjCcUAL6EsxPQWO9VNegBPm/0GgkZbDxCynxujX/92vmGcjZRMAY45puak2sFLCLSwXpEsyy5fnF0jGJBhm+fNSHKKUUfy+276A7/feLOFxxUuHRNJI2Osenxyvf8DAGObT60pfTTlhEg9u/KKkhJqm5U1/+BEcSkpFDA5XeCqxwXmPac1jcuZ3JWQ+p0NdWzb/5v1ZvF8GtMTFFEdQjpLO0bwPb0BHNWnip3liDXI2fXf05jjvfJ0NpjLCUgfTh9CMFYVFKEd4Z/OG/2C+N435mnK+9t1gvCiVcaaH7rK4+PjCvpVNiz+t2QyqH1O8x3JKZVl6Q+Lp/XK8wMjVMslOq9FdSw5FtUs/CptXH9PW+wbWHgrV17R5jTVOtGtKFu3nb80T+E0tv9QkzW3J2dbaw/8ddAKZ0pxIaEqLjlPrji3VgJ3GvdFvlqD8075woxh4fVt0JZE0KVFsAvqhe0dqN9b35jtSpnYMXkU+vZq+IAHad3IHc2s/LYrnD1anfG46IFiMIr9oNbZDWvwthqYNqOigaKd/XlLU4XHfk/PXIjPsLy/9/kAtQ+/wKH+hI/IROWj5FPvTZAT9f7j4ZXQyG4M0TujMAFXYkKvEHv1xhySekgXGGqNxWeWKlf8dDAlLuB1cb/qOD+rk7cmwt+1yKpk9cudqBanTi6zTbXRtV8qylNtjyOVKy1HTz0GW9rjt6sSjAZcT5R+KdtyYb0zyqG9pSLuCw5WBwAn7fjBjKLLoxLXMI+52L9cLwIR2B6OllJZLHJ8vDxmWdtF+QJnmt1rsHPIWY20lftk8fYePkAIg6Hgn532QoIpegMxiWgAOfe5/U44APR8Ac0NeZrVh3gEhs12W+tVSiWiUQekf/YBECUy5fdYbA08dd7VzPAP9aiVcIB9k6tY7WdJ1wNV+bHeydNtmC6G5ICtFC1ZwmJU/j8hf0I8TRVKSiz5oYIa93EpUI78X8GYIAZabx47/n8LDAAJ0nNtP1rpROprqKMBRecShca6qXuTSI3jZBLOB3Vp381B5rCGhjSvh/NSVkYp2qIdP/Bg="), xr;
}
var Ds;
function li() {
  if (Ds) return vr;
  Ds = 1;
  var i = Da();
  return vr.init = function() {
    var e = Ga().BrotliDecompressBuffer, t = i.toByteArray(ii());
    return e(t);
  }, vr;
}
var Bs;
function Ua() {
  if (Bs) return o0;
  Bs = 1;
  var i = li();
  return o0.init = function() {
    o0.dictionary = i.init();
  }, o0.offsetsByLength = new Uint32Array([
    0,
    0,
    0,
    0,
    0,
    4096,
    9216,
    21504,
    35840,
    44032,
    53248,
    63488,
    74752,
    87040,
    93696,
    100864,
    104704,
    106752,
    108928,
    113536,
    115968,
    118528,
    119872,
    121280,
    122016
  ]), o0.sizeBitsByLength = new Uint8Array([
    0,
    0,
    0,
    0,
    10,
    10,
    11,
    11,
    10,
    10,
    10,
    10,
    10,
    9,
    9,
    8,
    7,
    7,
    8,
    7,
    7,
    6,
    6,
    5,
    5
  ]), o0.minDictionaryWordLength = 4, o0.maxDictionaryWordLength = 24, o0;
}
var bt = {}, Ls;
function Ms() {
  if (Ls) return bt;
  Ls = 1;
  function i(n, a) {
    this.bits = n, this.value = a;
  }
  bt.HuffmanCode = i;
  var e = 15;
  function t(n, a) {
    for (var o = 1 << a - 1; n & o; )
      o >>= 1;
    return (n & o - 1) + o;
  }
  function r(n, a, o, u, c) {
    do
      u -= o, n[a + u] = new i(c.bits, c.value);
    while (u > 0);
  }
  function s(n, a, o) {
    for (var u = 1 << a - o; a < e && (u -= n[a], !(u <= 0)); )
      ++a, u <<= 1;
    return a - o;
  }
  return bt.BrotliBuildHuffmanTable = function(n, a, o, u, c) {
    var d = a, f, p, m, C, O, G, L, T, w, I, h, W = new Int32Array(e + 1), V = new Int32Array(e + 1);
    for (h = new Int32Array(c), m = 0; m < c; m++)
      W[u[m]]++;
    for (V[1] = 0, p = 1; p < e; p++)
      V[p + 1] = V[p] + W[p];
    for (m = 0; m < c; m++)
      u[m] !== 0 && (h[V[u[m]]++] = m);
    if (T = o, w = 1 << T, I = w, V[e] === 1) {
      for (C = 0; C < I; ++C)
        n[a + C] = new i(0, h[0] & 65535);
      return I;
    }
    for (C = 0, m = 0, p = 1, O = 2; p <= o; ++p, O <<= 1)
      for (; W[p] > 0; --W[p])
        f = new i(p & 255, h[m++] & 65535), r(n, a + C, O, w, f), C = t(C, p);
    for (L = I - 1, G = -1, p = o + 1, O = 2; p <= e; ++p, O <<= 1)
      for (; W[p] > 0; --W[p])
        (C & L) !== G && (a += w, T = s(W, p, o), w = 1 << T, I += w, G = C & L, n[d + G] = new i(T + o & 255, a - d - G & 65535)), f = new i(p - o & 255, h[m++] & 65535), r(n, a + (C >> o), O, w, f), C = t(C, p);
    return I;
  }, bt;
}
var gt = {}, Rs;
function oi() {
  return Rs || (Rs = 1, gt.lookup = new Uint8Array([
    /* CONTEXT_UTF8, last byte. */
    /* ASCII range. */
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    4,
    4,
    0,
    0,
    4,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    8,
    12,
    16,
    12,
    12,
    20,
    12,
    16,
    24,
    28,
    12,
    12,
    32,
    12,
    36,
    12,
    44,
    44,
    44,
    44,
    44,
    44,
    44,
    44,
    44,
    44,
    32,
    32,
    24,
    40,
    28,
    12,
    12,
    48,
    52,
    52,
    52,
    48,
    52,
    52,
    52,
    48,
    52,
    52,
    52,
    52,
    52,
    48,
    52,
    52,
    52,
    52,
    52,
    48,
    52,
    52,
    52,
    52,
    52,
    24,
    12,
    28,
    12,
    12,
    12,
    56,
    60,
    60,
    60,
    56,
    60,
    60,
    60,
    56,
    60,
    60,
    60,
    60,
    60,
    56,
    60,
    60,
    60,
    60,
    60,
    56,
    60,
    60,
    60,
    60,
    60,
    24,
    12,
    28,
    12,
    0,
    /* UTF8 continuation byte range. */
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    0,
    1,
    /* UTF8 lead byte range. */
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    2,
    3,
    /* CONTEXT_UTF8 second last byte. */
    /* ASCII range. */
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    1,
    1,
    1,
    1,
    1,
    1,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    1,
    1,
    1,
    1,
    0,
    /* UTF8 continuation byte range. */
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    /* UTF8 lead byte range. */
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    /* CONTEXT_SIGNED, second last byte. */
    0,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    2,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    3,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    4,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    5,
    6,
    6,
    6,
    6,
    6,
    6,
    6,
    6,
    6,
    6,
    6,
    6,
    6,
    6,
    6,
    7,
    /* CONTEXT_SIGNED, last byte, same as the above values shifted by 3 bits. */
    0,
    8,
    8,
    8,
    8,
    8,
    8,
    8,
    8,
    8,
    8,
    8,
    8,
    8,
    8,
    8,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    16,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    24,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    32,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    40,
    48,
    48,
    48,
    48,
    48,
    48,
    48,
    48,
    48,
    48,
    48,
    48,
    48,
    48,
    48,
    56,
    /* CONTEXT_LSB6, last byte. */
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    20,
    21,
    22,
    23,
    24,
    25,
    26,
    27,
    28,
    29,
    30,
    31,
    32,
    33,
    34,
    35,
    36,
    37,
    38,
    39,
    40,
    41,
    42,
    43,
    44,
    45,
    46,
    47,
    48,
    49,
    50,
    51,
    52,
    53,
    54,
    55,
    56,
    57,
    58,
    59,
    60,
    61,
    62,
    63,
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    20,
    21,
    22,
    23,
    24,
    25,
    26,
    27,
    28,
    29,
    30,
    31,
    32,
    33,
    34,
    35,
    36,
    37,
    38,
    39,
    40,
    41,
    42,
    43,
    44,
    45,
    46,
    47,
    48,
    49,
    50,
    51,
    52,
    53,
    54,
    55,
    56,
    57,
    58,
    59,
    60,
    61,
    62,
    63,
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    20,
    21,
    22,
    23,
    24,
    25,
    26,
    27,
    28,
    29,
    30,
    31,
    32,
    33,
    34,
    35,
    36,
    37,
    38,
    39,
    40,
    41,
    42,
    43,
    44,
    45,
    46,
    47,
    48,
    49,
    50,
    51,
    52,
    53,
    54,
    55,
    56,
    57,
    58,
    59,
    60,
    61,
    62,
    63,
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    20,
    21,
    22,
    23,
    24,
    25,
    26,
    27,
    28,
    29,
    30,
    31,
    32,
    33,
    34,
    35,
    36,
    37,
    38,
    39,
    40,
    41,
    42,
    43,
    44,
    45,
    46,
    47,
    48,
    49,
    50,
    51,
    52,
    53,
    54,
    55,
    56,
    57,
    58,
    59,
    60,
    61,
    62,
    63,
    /* CONTEXT_MSB6, last byte. */
    0,
    0,
    0,
    0,
    1,
    1,
    1,
    1,
    2,
    2,
    2,
    2,
    3,
    3,
    3,
    3,
    4,
    4,
    4,
    4,
    5,
    5,
    5,
    5,
    6,
    6,
    6,
    6,
    7,
    7,
    7,
    7,
    8,
    8,
    8,
    8,
    9,
    9,
    9,
    9,
    10,
    10,
    10,
    10,
    11,
    11,
    11,
    11,
    12,
    12,
    12,
    12,
    13,
    13,
    13,
    13,
    14,
    14,
    14,
    14,
    15,
    15,
    15,
    15,
    16,
    16,
    16,
    16,
    17,
    17,
    17,
    17,
    18,
    18,
    18,
    18,
    19,
    19,
    19,
    19,
    20,
    20,
    20,
    20,
    21,
    21,
    21,
    21,
    22,
    22,
    22,
    22,
    23,
    23,
    23,
    23,
    24,
    24,
    24,
    24,
    25,
    25,
    25,
    25,
    26,
    26,
    26,
    26,
    27,
    27,
    27,
    27,
    28,
    28,
    28,
    28,
    29,
    29,
    29,
    29,
    30,
    30,
    30,
    30,
    31,
    31,
    31,
    31,
    32,
    32,
    32,
    32,
    33,
    33,
    33,
    33,
    34,
    34,
    34,
    34,
    35,
    35,
    35,
    35,
    36,
    36,
    36,
    36,
    37,
    37,
    37,
    37,
    38,
    38,
    38,
    38,
    39,
    39,
    39,
    39,
    40,
    40,
    40,
    40,
    41,
    41,
    41,
    41,
    42,
    42,
    42,
    42,
    43,
    43,
    43,
    43,
    44,
    44,
    44,
    44,
    45,
    45,
    45,
    45,
    46,
    46,
    46,
    46,
    47,
    47,
    47,
    47,
    48,
    48,
    48,
    48,
    49,
    49,
    49,
    49,
    50,
    50,
    50,
    50,
    51,
    51,
    51,
    51,
    52,
    52,
    52,
    52,
    53,
    53,
    53,
    53,
    54,
    54,
    54,
    54,
    55,
    55,
    55,
    55,
    56,
    56,
    56,
    56,
    57,
    57,
    57,
    57,
    58,
    58,
    58,
    58,
    59,
    59,
    59,
    59,
    60,
    60,
    60,
    60,
    61,
    61,
    61,
    61,
    62,
    62,
    62,
    62,
    63,
    63,
    63,
    63,
    /* CONTEXT_{M,L}SB6, second last byte, */
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0
  ]), gt.lookupOffsets = new Uint16Array([
    /* CONTEXT_LSB6 */
    1024,
    1536,
    /* CONTEXT_MSB6 */
    1280,
    1536,
    /* CONTEXT_UTF8 */
    0,
    256,
    /* CONTEXT_SIGNED */
    768,
    512
  ])), gt;
}
var m0 = {}, Ns;
function ui() {
  if (Ns) return m0;
  Ns = 1;
  function i(e, t) {
    this.offset = e, this.nbits = t;
  }
  return m0.kBlockLengthPrefixCode = [
    new i(1, 2),
    new i(5, 2),
    new i(9, 2),
    new i(13, 2),
    new i(17, 3),
    new i(25, 3),
    new i(33, 3),
    new i(41, 3),
    new i(49, 4),
    new i(65, 4),
    new i(81, 4),
    new i(97, 4),
    new i(113, 5),
    new i(145, 5),
    new i(177, 5),
    new i(209, 5),
    new i(241, 6),
    new i(305, 6),
    new i(369, 7),
    new i(497, 8),
    new i(753, 9),
    new i(1265, 10),
    new i(2289, 11),
    new i(4337, 12),
    new i(8433, 13),
    new i(16625, 24)
  ], m0.kInsertLengthPrefixCode = [
    new i(0, 0),
    new i(1, 0),
    new i(2, 0),
    new i(3, 0),
    new i(4, 0),
    new i(5, 0),
    new i(6, 1),
    new i(8, 1),
    new i(10, 2),
    new i(14, 2),
    new i(18, 3),
    new i(26, 3),
    new i(34, 4),
    new i(50, 4),
    new i(66, 5),
    new i(98, 5),
    new i(130, 6),
    new i(194, 7),
    new i(322, 8),
    new i(578, 9),
    new i(1090, 10),
    new i(2114, 12),
    new i(6210, 14),
    new i(22594, 24)
  ], m0.kCopyLengthPrefixCode = [
    new i(2, 0),
    new i(3, 0),
    new i(4, 0),
    new i(5, 0),
    new i(6, 0),
    new i(7, 0),
    new i(8, 0),
    new i(9, 0),
    new i(10, 1),
    new i(12, 1),
    new i(14, 2),
    new i(18, 2),
    new i(22, 3),
    new i(30, 3),
    new i(38, 4),
    new i(54, 4),
    new i(70, 5),
    new i(102, 5),
    new i(134, 6),
    new i(198, 7),
    new i(326, 8),
    new i(582, 9),
    new i(1094, 10),
    new i(2118, 24)
  ], m0.kInsertRangeLut = [
    0,
    0,
    8,
    8,
    0,
    16,
    8,
    16,
    16
  ], m0.kCopyRangeLut = [
    0,
    8,
    0,
    8,
    16,
    0,
    16,
    8,
    16
  ], m0;
}
var j0 = {}, Us;
function ci() {
  if (Us) return j0;
  Us = 1;
  var i = Ua(), e = 0, t = 1, r = 2, s = 3, n = 4, a = 5, o = 6, u = 7, c = 8, d = 9, f = 10, p = 11, m = 12, C = 13, O = 14, G = 15, L = 16, T = 17, w = 18, I = 20;
  function h(y, M, S) {
    this.prefix = new Uint8Array(y.length), this.transform = M, this.suffix = new Uint8Array(S.length);
    for (var N = 0; N < y.length; N++)
      this.prefix[N] = y.charCodeAt(N);
    for (var N = 0; N < S.length; N++)
      this.suffix[N] = S.charCodeAt(N);
  }
  var W = [
    new h("", e, ""),
    new h("", e, " "),
    new h(" ", e, " "),
    new h("", m, ""),
    new h("", f, " "),
    new h("", e, " the "),
    new h(" ", e, ""),
    new h("s ", e, " "),
    new h("", e, " of "),
    new h("", f, ""),
    new h("", e, " and "),
    new h("", C, ""),
    new h("", t, ""),
    new h(", ", e, " "),
    new h("", e, ", "),
    new h(" ", f, " "),
    new h("", e, " in "),
    new h("", e, " to "),
    new h("e ", e, " "),
    new h("", e, '"'),
    new h("", e, "."),
    new h("", e, '">'),
    new h("", e, `
`),
    new h("", s, ""),
    new h("", e, "]"),
    new h("", e, " for "),
    new h("", O, ""),
    new h("", r, ""),
    new h("", e, " a "),
    new h("", e, " that "),
    new h(" ", f, ""),
    new h("", e, ". "),
    new h(".", e, ""),
    new h(" ", e, ", "),
    new h("", G, ""),
    new h("", e, " with "),
    new h("", e, "'"),
    new h("", e, " from "),
    new h("", e, " by "),
    new h("", L, ""),
    new h("", T, ""),
    new h(" the ", e, ""),
    new h("", n, ""),
    new h("", e, ". The "),
    new h("", p, ""),
    new h("", e, " on "),
    new h("", e, " as "),
    new h("", e, " is "),
    new h("", u, ""),
    new h("", t, "ing "),
    new h("", e, `
	`),
    new h("", e, ":"),
    new h(" ", e, ". "),
    new h("", e, "ed "),
    new h("", I, ""),
    new h("", w, ""),
    new h("", o, ""),
    new h("", e, "("),
    new h("", f, ", "),
    new h("", c, ""),
    new h("", e, " at "),
    new h("", e, "ly "),
    new h(" the ", e, " of "),
    new h("", a, ""),
    new h("", d, ""),
    new h(" ", f, ", "),
    new h("", f, '"'),
    new h(".", e, "("),
    new h("", p, " "),
    new h("", f, '">'),
    new h("", e, '="'),
    new h(" ", e, "."),
    new h(".com/", e, ""),
    new h(" the ", e, " of the "),
    new h("", f, "'"),
    new h("", e, ". This "),
    new h("", e, ","),
    new h(".", e, " "),
    new h("", f, "("),
    new h("", f, "."),
    new h("", e, " not "),
    new h(" ", e, '="'),
    new h("", e, "er "),
    new h(" ", p, " "),
    new h("", e, "al "),
    new h(" ", p, ""),
    new h("", e, "='"),
    new h("", p, '"'),
    new h("", f, ". "),
    new h(" ", e, "("),
    new h("", e, "ful "),
    new h(" ", f, ". "),
    new h("", e, "ive "),
    new h("", e, "less "),
    new h("", p, "'"),
    new h("", e, "est "),
    new h(" ", f, "."),
    new h("", p, '">'),
    new h(" ", e, "='"),
    new h("", f, ","),
    new h("", e, "ize "),
    new h("", p, "."),
    new h("Â ", e, ""),
    new h(" ", e, ","),
    new h("", f, '="'),
    new h("", p, '="'),
    new h("", e, "ous "),
    new h("", p, ", "),
    new h("", f, "='"),
    new h(" ", f, ","),
    new h(" ", p, '="'),
    new h(" ", p, ", "),
    new h("", p, ","),
    new h("", p, "("),
    new h("", p, ". "),
    new h(" ", p, "."),
    new h("", p, "='"),
    new h(" ", p, ". "),
    new h(" ", f, '="'),
    new h(" ", p, "='"),
    new h(" ", f, "='")
  ];
  j0.kTransforms = W, j0.kNumTransforms = W.length;
  function V(y, M) {
    return y[M] < 192 ? (y[M] >= 97 && y[M] <= 122 && (y[M] ^= 32), 1) : y[M] < 224 ? (y[M + 1] ^= 32, 2) : (y[M + 2] ^= 5, 3);
  }
  return j0.transformDictionaryWord = function(y, M, S, N, R) {
    var H = W[R].prefix, ue = W[R].suffix, re = W[R].transform, le = re < m ? 0 : re - (m - 1), K = 0, Q = M, J;
    le > N && (le = N);
    for (var _ = 0; _ < H.length; )
      y[M++] = H[_++];
    for (S += le, N -= le, re <= d && (N -= re), K = 0; K < N; K++)
      y[M++] = i.dictionary[S + K];
    if (J = M - N, re === f)
      V(y, J);
    else if (re === p)
      for (; N > 0; ) {
        var Re = V(y, J);
        J += Re, N -= Re;
      }
    for (var Be = 0; Be < ue.length; )
      y[M++] = ue[Be++];
    return M - Q;
  }, j0;
}
var Gs;
function Ga() {
  if (Gs) return X0;
  Gs = 1;
  var i = Ts().BrotliInput, e = Ts().BrotliOutput, t = ni(), r = Ua(), s = Ms().HuffmanCode, n = Ms().BrotliBuildHuffmanTable, a = oi(), o = ui(), u = ci(), c = 8, d = 16, f = 256, p = 704, m = 26, C = 6, O = 2, G = 8, L = 255, T = 1080, w = 18, I = new Uint8Array([
    1,
    2,
    3,
    4,
    0,
    5,
    17,
    6,
    16,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15
  ]), h = 16, W = new Uint8Array([
    3,
    2,
    1,
    0,
    3,
    3,
    3,
    3,
    3,
    3,
    2,
    2,
    2,
    2,
    2,
    2
  ]), V = new Int8Array([
    0,
    0,
    0,
    0,
    -1,
    1,
    -2,
    2,
    -3,
    3,
    -1,
    1,
    -2,
    2,
    -3,
    3
  ]), y = new Uint16Array([
    256,
    402,
    436,
    468,
    500,
    534,
    566,
    598,
    630,
    662,
    694,
    726,
    758,
    790,
    822,
    854,
    886,
    920,
    952,
    984,
    1016,
    1048,
    1080
  ]);
  function M(B) {
    var P;
    return B.readBits(1) === 0 ? 16 : (P = B.readBits(3), P > 0 ? 17 + P : (P = B.readBits(3), P > 0 ? 8 + P : 17));
  }
  function S(B) {
    if (B.readBits(1)) {
      var P = B.readBits(3);
      return P === 0 ? 1 : B.readBits(P) + (1 << P);
    }
    return 0;
  }
  function N() {
    this.meta_block_length = 0, this.input_end = 0, this.is_uncompressed = 0, this.is_metadata = !1;
  }
  function R(B) {
    var P = new N(), k, A, z;
    if (P.input_end = B.readBits(1), P.input_end && B.readBits(1))
      return P;
    if (k = B.readBits(2) + 4, k === 7) {
      if (P.is_metadata = !0, B.readBits(1) !== 0)
        throw new Error("Invalid reserved bit");
      if (A = B.readBits(2), A === 0)
        return P;
      for (z = 0; z < A; z++) {
        var $ = B.readBits(8);
        if (z + 1 === A && A > 1 && $ === 0)
          throw new Error("Invalid size byte");
        P.meta_block_length |= $ << z * 8;
      }
    } else
      for (z = 0; z < k; ++z) {
        var q = B.readBits(4);
        if (z + 1 === k && k > 4 && q === 0)
          throw new Error("Invalid size nibble");
        P.meta_block_length |= q << z * 4;
      }
    return ++P.meta_block_length, !P.input_end && !P.is_metadata && (P.is_uncompressed = B.readBits(1)), P;
  }
  function H(B, P, k) {
    var A;
    return k.fillBitWindow(), P += k.val_ >>> k.bit_pos_ & L, A = B[P].bits - G, A > 0 && (k.bit_pos_ += G, P += B[P].value, P += k.val_ >>> k.bit_pos_ & (1 << A) - 1), k.bit_pos_ += B[P].bits, B[P].value;
  }
  function ue(B, P, k, A) {
    for (var z = 0, $ = c, q = 0, X = 0, ae = 32768, Y = [], U = 0; U < 32; U++)
      Y.push(new s(0, 0));
    for (n(Y, 0, 5, B, w); z < P && ae > 0; ) {
      var oe = 0, Ce;
      if (A.readMoreInput(), A.fillBitWindow(), oe += A.val_ >>> A.bit_pos_ & 31, A.bit_pos_ += Y[oe].bits, Ce = Y[oe].value & 255, Ce < d)
        q = 0, k[z++] = Ce, Ce !== 0 && ($ = Ce, ae -= 32768 >> Ce);
      else {
        var Le = Ce - 14, ge, ye, me = 0;
        if (Ce === d && (me = $), X !== me && (q = 0, X = me), ge = q, q > 0 && (q -= 2, q <<= Le), q += A.readBits(Le) + 3, ye = q - ge, z + ye > P)
          throw new Error("[ReadHuffmanCodeLengths] symbol + repeat_delta > num_symbols");
        for (var Te = 0; Te < ye; Te++)
          k[z + Te] = X;
        z += ye, X !== 0 && (ae -= ye << 15 - X);
      }
    }
    if (ae !== 0)
      throw new Error("[ReadHuffmanCodeLengths] space = " + ae);
    for (; z < P; z++)
      k[z] = 0;
  }
  function re(B, P, k, A) {
    var z = 0, $, q = new Uint8Array(B);
    if (A.readMoreInput(), $ = A.readBits(2), $ === 1) {
      for (var X, ae = B - 1, Y = 0, U = new Int32Array(4), oe = A.readBits(2) + 1; ae; )
        ae >>= 1, ++Y;
      for (X = 0; X < oe; ++X)
        U[X] = A.readBits(Y) % B, q[U[X]] = 2;
      switch (q[U[0]] = 1, oe) {
        case 1:
          break;
        case 3:
          if (U[0] === U[1] || U[0] === U[2] || U[1] === U[2])
            throw new Error("[ReadHuffmanCode] invalid symbols");
          break;
        case 2:
          if (U[0] === U[1])
            throw new Error("[ReadHuffmanCode] invalid symbols");
          q[U[1]] = 1;
          break;
        case 4:
          if (U[0] === U[1] || U[0] === U[2] || U[0] === U[3] || U[1] === U[2] || U[1] === U[3] || U[2] === U[3])
            throw new Error("[ReadHuffmanCode] invalid symbols");
          A.readBits(1) ? (q[U[2]] = 3, q[U[3]] = 3) : q[U[0]] = 2;
          break;
      }
    } else {
      var X, Ce = new Uint8Array(w), Le = 32, ge = 0, ye = [
        new s(2, 0),
        new s(2, 4),
        new s(2, 3),
        new s(3, 2),
        new s(2, 0),
        new s(2, 4),
        new s(2, 3),
        new s(4, 1),
        new s(2, 0),
        new s(2, 4),
        new s(2, 3),
        new s(3, 2),
        new s(2, 0),
        new s(2, 4),
        new s(2, 3),
        new s(4, 5)
      ];
      for (X = $; X < w && Le > 0; ++X) {
        var me = I[X], Te = 0, Ne;
        A.fillBitWindow(), Te += A.val_ >>> A.bit_pos_ & 15, A.bit_pos_ += ye[Te].bits, Ne = ye[Te].value, Ce[me] = Ne, Ne !== 0 && (Le -= 32 >> Ne, ++ge);
      }
      if (!(ge === 1 || Le === 0))
        throw new Error("[ReadHuffmanCode] invalid num_codes or space");
      ue(Ce, B, q, A);
    }
    if (z = n(P, k, G, q, B), z === 0)
      throw new Error("[ReadHuffmanCode] BuildHuffmanTable failed: ");
    return z;
  }
  function le(B, P, k) {
    var A, z;
    return A = H(B, P, k), z = o.kBlockLengthPrefixCode[A].nbits, o.kBlockLengthPrefixCode[A].offset + k.readBits(z);
  }
  function K(B, P, k) {
    var A;
    return B < h ? (k += W[B], k &= 3, A = P[k] + V[B]) : A = B - h + 1, A;
  }
  function Q(B, P) {
    for (var k = B[P], A = P; A; --A) B[A] = B[A - 1];
    B[0] = k;
  }
  function J(B, P) {
    var k = new Uint8Array(256), A;
    for (A = 0; A < 256; ++A)
      k[A] = A;
    for (A = 0; A < P; ++A) {
      var z = B[A];
      B[A] = k[z], z && Q(k, z);
    }
  }
  function _(B, P) {
    this.alphabet_size = B, this.num_htrees = P, this.codes = new Array(P + P * y[B + 31 >>> 5]), this.htrees = new Uint32Array(P);
  }
  _.prototype.decode = function(B) {
    var P, k, A = 0;
    for (P = 0; P < this.num_htrees; ++P)
      this.htrees[P] = A, k = re(this.alphabet_size, this.codes, A, B), A += k;
  };
  function Re(B, P) {
    var k = { num_htrees: null, context_map: null }, A, z = 0, $, q;
    P.readMoreInput();
    var X = k.num_htrees = S(P) + 1, ae = k.context_map = new Uint8Array(B);
    if (X <= 1)
      return k;
    for (A = P.readBits(1), A && (z = P.readBits(4) + 1), $ = [], q = 0; q < T; q++)
      $[q] = new s(0, 0);
    for (re(X + z, $, 0, P), q = 0; q < B; ) {
      var Y;
      if (P.readMoreInput(), Y = H($, 0, P), Y === 0)
        ae[q] = 0, ++q;
      else if (Y <= z)
        for (var U = 1 + (1 << Y) + P.readBits(Y); --U; ) {
          if (q >= B)
            throw new Error("[DecodeContextMap] i >= context_map_size");
          ae[q] = 0, ++q;
        }
      else
        ae[q] = Y - z, ++q;
    }
    return P.readBits(1) && J(ae, B), k;
  }
  function Be(B, P, k, A, z, $, q) {
    var X = k * 2, ae = k, Y = H(P, k * T, q), U;
    Y === 0 ? U = z[X + ($[ae] & 1)] : Y === 1 ? U = z[X + ($[ae] - 1 & 1)] + 1 : U = Y - 2, U >= B && (U -= B), A[k] = U, z[X + ($[ae] & 1)] = U, ++$[ae];
  }
  function a0(B, P, k, A, z, $) {
    var q = z + 1, X = k & z, ae = $.pos_ & t.IBUF_MASK, Y;
    if (P < 8 || $.bit_pos_ + (P << 3) < $.bit_end_pos_) {
      for (; P-- > 0; )
        $.readMoreInput(), A[X++] = $.readBits(8), X === q && (B.write(A, q), X = 0);
      return;
    }
    if ($.bit_end_pos_ < 32)
      throw new Error("[CopyUncompressedBlockToOutput] br.bit_end_pos_ < 32");
    for (; $.bit_pos_ < 32; )
      A[X] = $.val_ >>> $.bit_pos_, $.bit_pos_ += 8, ++X, --P;
    if (Y = $.bit_end_pos_ - $.bit_pos_ >> 3, ae + Y > t.IBUF_MASK) {
      for (var U = t.IBUF_MASK + 1 - ae, oe = 0; oe < U; oe++)
        A[X + oe] = $.buf_[ae + oe];
      Y -= U, X += U, P -= U, ae = 0;
    }
    for (var oe = 0; oe < Y; oe++)
      A[X + oe] = $.buf_[ae + oe];
    if (X += Y, P -= Y, X >= q) {
      B.write(A, q), X -= q;
      for (var oe = 0; oe < X; oe++)
        A[oe] = A[q + oe];
    }
    for (; X + P >= q; ) {
      if (Y = q - X, $.input_.read(A, X, Y) < Y)
        throw new Error("[CopyUncompressedBlockToOutput] not enough bytes");
      B.write(A, q), P -= Y, X = 0;
    }
    if ($.input_.read(A, X, P) < P)
      throw new Error("[CopyUncompressedBlockToOutput] not enough bytes");
    $.reset();
  }
  function n0(B) {
    var P = B.bit_pos_ + 7 & -8, k = B.readBits(P - B.bit_pos_);
    return k == 0;
  }
  function Je(B) {
    var P = new i(B), k = new t(P);
    M(k);
    var A = R(k);
    return A.meta_block_length;
  }
  X0.BrotliDecompressedSize = Je;
  function i0(B, P) {
    var k = new i(B);
    P == null && (P = Je(B));
    var A = new Uint8Array(P), z = new e(A);
    return Qe(k, z), z.pos < z.buffer.length && (z.buffer = z.buffer.subarray(0, z.pos)), z.buffer;
  }
  X0.BrotliDecompressBuffer = i0;
  function Qe(B, P) {
    var k, A = 0, z = 0, $ = 0, q, X = 0, ae, Y, U, oe, Ce = [16, 15, 11, 4], Le = 0, ge = 0, ye = 0, me = [new _(0, 0), new _(0, 0), new _(0, 0)], Te, Ne, ne, Cn = 128 + t.READ_SIZE;
    ne = new t(B), $ = M(ne), q = (1 << $) - 16, ae = 1 << $, Y = ae - 1, U = new Uint8Array(ae + Cn + r.maxDictionaryWordLength), oe = ae, Te = [], Ne = [];
    for (var ot = 0; ot < 3 * T; ot++)
      Te[ot] = new s(0, 0), Ne[ot] = new s(0, 0);
    for (; !z; ) {
      var Se = 0, Qr, We = [1 << 28, 1 << 28, 1 << 28], l0 = [0], Ue = [1, 1, 1], Kt = [0, 1, 0, 1, 0, 1], ut = [0], T0, V0, _r, es, ts = null, ct = null, rs, ss = null, as, ns = 0, Jt = null, is = 0, ls = 0, Qt = null, os = 0, _t = 0, er = 0, O0, tr;
      for (k = 0; k < 3; ++k)
        me[k].codes = null, me[k].htrees = null;
      ne.readMoreInput();
      var ft = R(ne);
      if (Se = ft.meta_block_length, A + Se > P.buffer.length) {
        var us = new Uint8Array(A + Se);
        us.set(P.buffer), P.buffer = us;
      }
      if (z = ft.input_end, Qr = ft.is_uncompressed, ft.is_metadata) {
        for (n0(ne); Se > 0; --Se)
          ne.readMoreInput(), ne.readBits(8);
        continue;
      }
      if (Se !== 0) {
        if (Qr) {
          ne.bit_pos_ = ne.bit_pos_ + 7 & -8, a0(
            P,
            Se,
            A,
            U,
            Y,
            ne
          ), A += Se;
          continue;
        }
        for (k = 0; k < 3; ++k)
          Ue[k] = S(ne) + 1, Ue[k] >= 2 && (re(Ue[k] + 2, Te, k * T, ne), re(m, Ne, k * T, ne), We[k] = le(Ne, k * T, ne), ut[k] = 1);
        for (ne.readMoreInput(), T0 = ne.readBits(2), V0 = h + (ne.readBits(4) << T0), _r = (1 << T0) - 1, es = V0 + (48 << T0), ct = new Uint8Array(Ue[0]), k = 0; k < Ue[0]; ++k)
          ne.readMoreInput(), ct[k] = ne.readBits(2) << 1;
        var cs = Re(Ue[0] << C, ne);
        rs = cs.num_htrees, ts = cs.context_map;
        var fs = Re(Ue[2] << O, ne);
        for (as = fs.num_htrees, ss = fs.context_map, me[0] = new _(f, rs), me[1] = new _(p, Ue[1]), me[2] = new _(es, as), k = 0; k < 3; ++k)
          me[k].decode(ne);
        for (Jt = 0, Qt = 0, O0 = ct[l0[0]], _t = a.lookupOffsets[O0], er = a.lookupOffsets[O0 + 1], tr = me[1].htrees[0]; Se > 0; ) {
          var dt, z0, rr, sr, ar, Oe, Me, _e, q0, F0, W0;
          for (ne.readMoreInput(), We[1] === 0 && (Be(
            Ue[1],
            Te,
            1,
            l0,
            Kt,
            ut,
            ne
          ), We[1] = le(Ne, T, ne), tr = me[1].htrees[l0[1]]), --We[1], dt = H(me[1].codes, tr, ne), z0 = dt >> 6, z0 >= 2 ? (z0 -= 2, Me = -1) : Me = 0, rr = o.kInsertRangeLut[z0] + (dt >> 3 & 7), sr = o.kCopyRangeLut[z0] + (dt & 7), ar = o.kInsertLengthPrefixCode[rr].offset + ne.readBits(o.kInsertLengthPrefixCode[rr].nbits), Oe = o.kCopyLengthPrefixCode[sr].offset + ne.readBits(o.kCopyLengthPrefixCode[sr].nbits), ge = U[A - 1 & Y], ye = U[A - 2 & Y], F0 = 0; F0 < ar; ++F0)
            ne.readMoreInput(), We[0] === 0 && (Be(
              Ue[0],
              Te,
              0,
              l0,
              Kt,
              ut,
              ne
            ), We[0] = le(Ne, 0, ne), ns = l0[0] << C, Jt = ns, O0 = ct[l0[0]], _t = a.lookupOffsets[O0], er = a.lookupOffsets[O0 + 1]), q0 = a.lookup[_t + ge] | a.lookup[er + ye], is = ts[Jt + q0], --We[0], ye = ge, ge = H(me[0].codes, me[0].htrees[is], ne), U[A & Y] = ge, (A & Y) === Y && P.write(U, ae), ++A;
          if (Se -= ar, Se <= 0) break;
          if (Me < 0) {
            var q0;
            if (ne.readMoreInput(), We[2] === 0 && (Be(
              Ue[2],
              Te,
              2,
              l0,
              Kt,
              ut,
              ne
            ), We[2] = le(Ne, 2 * T, ne), ls = l0[2] << O, Qt = ls), --We[2], q0 = (Oe > 4 ? 3 : Oe - 2) & 255, os = ss[Qt + q0], Me = H(me[2].codes, me[2].htrees[os], ne), Me >= V0) {
              var nr, ds, H0;
              Me -= V0, ds = Me & _r, Me >>= T0, nr = (Me >> 1) + 1, H0 = (2 + (Me & 1) << nr) - 4, Me = V0 + (H0 + ne.readBits(nr) << T0) + ds;
            }
          }
          if (_e = K(Me, Ce, Le), _e < 0)
            throw new Error("[BrotliDecompress] invalid distance");
          if (A < q && X !== q ? X = A : X = q, W0 = A & Y, _e > X)
            if (Oe >= r.minDictionaryWordLength && Oe <= r.maxDictionaryWordLength) {
              var H0 = r.offsetsByLength[Oe], hs = _e - X - 1, ps = r.sizeBitsByLength[Oe], Sn = (1 << ps) - 1, An = hs & Sn, bs = hs >> ps;
              if (H0 += An * Oe, bs < u.kNumTransforms) {
                var ir = u.transformDictionaryWord(U, W0, H0, Oe, bs);
                if (W0 += ir, A += ir, Se -= ir, W0 >= oe) {
                  P.write(U, ae);
                  for (var ht = 0; ht < W0 - oe; ht++)
                    U[ht] = U[oe + ht];
                }
              } else
                throw new Error("Invalid backward reference. pos: " + A + " distance: " + _e + " len: " + Oe + " bytes left: " + Se);
            } else
              throw new Error("Invalid backward reference. pos: " + A + " distance: " + _e + " len: " + Oe + " bytes left: " + Se);
          else {
            if (Me > 0 && (Ce[Le & 3] = _e, ++Le), Oe > Se)
              throw new Error("Invalid backward reference. pos: " + A + " distance: " + _e + " len: " + Oe + " bytes left: " + Se);
            for (F0 = 0; F0 < Oe; ++F0)
              U[A & Y] = U[A - _e & Y], (A & Y) === Y && P.write(U, ae), ++A, --Se;
          }
          ge = U[A - 1 & Y], ye = U[A - 2 & Y];
        }
        A &= 1073741823;
      }
    }
    P.write(U, A & Y);
  }
  return X0.BrotliDecompress = Qe, r.init(), X0;
}
var mr, Vs;
function fi() {
  return Vs || (Vs = 1, mr = Ga().BrotliDecompressBuffer), mr;
}
var di = fi();
const hi = /* @__PURE__ */ k0(di);
function nt(i, e, t, r) {
  Object.defineProperty(i, e, { get: t, set: r, enumerable: !0, configurable: !0 });
}
function qt(i) {
  return i && i.__esModule ? i.default : i;
}
var it = {};
nt(it, "logErrors", () => pi);
nt(it, "registerFormat", () => U0);
nt(it, "create", () => bi);
nt(it, "defaultLanguage", () => Pt);
nt(it, "setDefaultLanguage", () => gi);
let pi = !1, Fr = [];
function U0(i) {
  Fr.push(i);
}
function bi(i, e) {
  for (let t = 0; t < Fr.length; t++) {
    let r = Fr[t];
    if (r.probe(i)) {
      let s = new r(new Ae(i));
      return e ? s.getFont(e) : s;
    }
  }
  throw new Error("Unknown font format");
}
let Pt = "en";
function gi(i = "en") {
  Pt = i;
}
function ke(i, e, t) {
  if (t.get) {
    let r = t.get;
    t.get = function() {
      let s = r.call(this);
      return Object.defineProperty(this, e, {
        value: s
      }), s;
    };
  } else if (typeof t.value == "function") {
    let r = t.value;
    return {
      get() {
        let s = /* @__PURE__ */ new Map();
        function n(...a) {
          let o = a.length > 0 ? a[0] : "value";
          if (s.has(o)) return s.get(o);
          let u = r.apply(this, a);
          return s.set(o, u), u;
        }
        return Object.defineProperty(this, e, {
          value: n
        }), n;
      }
    };
  }
}
let vi = new x({
  firstCode: l,
  entryCount: l,
  idDelta: E,
  idRangeOffset: l
}), wr = new x({
  startCharCode: v,
  endCharCode: v,
  glyphID: v
}), xi = new x({
  startUnicodeValue: h0,
  additionalCount: D
}), mi = new x({
  unicodeValue: h0,
  glyphID: l
}), wi = new b(xi, v), yi = new b(mi, v), Ci = new x({
  varSelector: h0,
  defaultUVS: new g(v, wi, {
    type: "parent"
  }),
  nonDefaultUVS: new g(v, yi, {
    type: "parent"
  })
}), Si = new te(l, {
  0: {
    length: l,
    language: l,
    codeMap: new he(D, 256)
  },
  2: {
    length: l,
    language: l,
    subHeaderKeys: new b(l, 256),
    subHeaderCount: (i) => Math.max.apply(Math, i.subHeaderKeys),
    subHeaders: new he(vi, "subHeaderCount"),
    glyphIndexArray: new he(l, "subHeaderCount")
  },
  4: {
    length: l,
    language: l,
    segCountX2: l,
    segCount: (i) => i.segCountX2 >> 1,
    searchRange: l,
    entrySelector: l,
    rangeShift: l,
    endCode: new he(l, "segCount"),
    reservedPad: new be(l),
    startCode: new he(l, "segCount"),
    idDelta: new he(E, "segCount"),
    idRangeOffset: new he(l, "segCount"),
    glyphIndexArray: new he(l, (i) => (i.length - i._currentOffset) / 2)
  },
  6: {
    length: l,
    language: l,
    firstCode: l,
    entryCount: l,
    glyphIndices: new he(l, "entryCount")
  },
  8: {
    reserved: new be(l),
    length: v,
    language: l,
    is32: new he(D, 8192),
    nGroups: v,
    groups: new he(wr, "nGroups")
  },
  10: {
    reserved: new be(l),
    length: v,
    language: v,
    firstCode: v,
    entryCount: v,
    glyphIndices: new he(l, "numChars")
  },
  12: {
    reserved: new be(l),
    length: v,
    language: v,
    nGroups: v,
    groups: new he(wr, "nGroups")
  },
  13: {
    reserved: new be(l),
    length: v,
    language: v,
    nGroups: v,
    groups: new he(wr, "nGroups")
  },
  14: {
    length: v,
    numRecords: v,
    varSelectors: new he(Ci, "numRecords")
  }
}), Ai = new x({
  platformID: l,
  encodingID: l,
  table: new g(v, Si, {
    type: "parent",
    lazy: !0
  })
});
var Ii = new x({
  version: l,
  numSubtables: l,
  tables: new b(Ai, "numSubtables")
}), ki = new x({
  version: C0,
  revision: C0,
  checkSumAdjustment: v,
  magicNumber: v,
  flags: l,
  unitsPerEm: l,
  created: new b(C0, 2),
  modified: new b(C0, 2),
  xMin: E,
  yMin: E,
  xMax: E,
  yMax: E,
  macStyle: new ze(l, [
    "bold",
    "italic",
    "underline",
    "outline",
    "shadow",
    "condensed",
    "extended"
  ]),
  lowestRecPPEM: l,
  fontDirectionHint: E,
  indexToLocFormat: E,
  glyphDataFormat: E
  // 0 for current format
}), Ei = new x({
  version: C0,
  ascent: E,
  descent: E,
  lineGap: E,
  advanceWidthMax: l,
  minLeftSideBearing: E,
  minRightSideBearing: E,
  xMaxExtent: E,
  caretSlopeRise: E,
  caretSlopeRun: E,
  caretOffset: E,
  reserved: new be(E, 4),
  metricDataFormat: E,
  numberOfMetrics: l
  // Number of advance widths in 'hmtx' table
});
let Pi = new x({
  advance: l,
  bearing: E
});
var Ti = new x({
  metrics: new he(Pi, (i) => i.parent.hhea.numberOfMetrics),
  bearings: new he(E, (i) => i.parent.maxp.numGlyphs - i.parent.hhea.numberOfMetrics)
}), Oi = new x({
  version: C0,
  numGlyphs: l,
  maxPoints: l,
  maxContours: l,
  maxComponentPoints: l,
  maxComponentContours: l,
  maxZones: l,
  maxTwilightPoints: l,
  maxStorage: l,
  maxFunctionDefs: l,
  maxInstructionDefs: l,
  maxStackElements: l,
  maxSizeOfInstructions: l,
  maxComponentElements: l,
  maxComponentDepth: l
  // Maximum levels of recursion; 1 for simple components
});
function Va(i, e, t = 0) {
  return i === 1 && zs[t] ? zs[t] : Li[i][e];
}
const Fi = /* @__PURE__ */ new Set([
  "x-mac-roman",
  "x-mac-cyrillic",
  "iso-8859-6",
  "iso-8859-8"
]), Di = {
  "x-mac-croatian": "ÄÅÇÉÑÖÜáàâäãåçéèêëíìîïñóòôöõúùûü†°¢£§•¶ß®Š™´¨≠ŽØ∞±≤≥∆µ∂∑∏š∫ªºΩžø¿¡¬√ƒ≈Ć«Č… ÀÃÕŒœĐ—“”‘’÷◊©⁄€‹›Æ»–·‚„‰ÂćÁčÈÍÎÏÌÓÔđÒÚÛÙıˆ˜¯πË˚¸Êæˇ",
  "x-mac-gaelic": "ÄÅÇÉÑÖÜáàâäãåçéèêëíìîïñóòôöõúùûü†°¢£§•¶ß®©™´¨≠ÆØḂ±≤≥ḃĊċḊḋḞḟĠġṀæøṁṖṗɼƒſṠ«»… ÀÃÕŒœ–—“”‘’ṡẛÿŸṪ€‹›Ŷŷṫ·Ỳỳ⁊ÂÊÁËÈÍÎÏÌÓÔ♣ÒÚÛÙıÝýŴŵẄẅẀẁẂẃ",
  "x-mac-greek": "Ä¹²É³ÖÜ΅àâä΄¨çéèêë£™îï•½‰ôö¦€ùûü†ΓΔΘΛΞΠß®©ΣΪ§≠°·Α±≤≥¥ΒΕΖΗΙΚΜΦΫΨΩάΝ¬ΟΡ≈Τ«»… ΥΧΆΈœ–―“”‘’÷ΉΊΌΎέήίόΏύαβψδεφγηιξκλμνοπώρστθωςχυζϊϋΐΰ­",
  "x-mac-icelandic": "ÄÅÇÉÑÖÜáàâäãåçéèêëíìîïñóòôöõúùûüÝ°¢£§•¶ß®©™´¨≠ÆØ∞±≤≥¥µ∂∑∏π∫ªºΩæø¿¡¬√ƒ≈∆«»… ÀÃÕŒœ–—“”‘’÷◊ÿŸ⁄€ÐðÞþý·‚„‰ÂÊÁËÈÍÎÏÌÓÔÒÚÛÙıˆ˜¯˘˙˚¸˝˛ˇ",
  "x-mac-inuit": "ᐃᐄᐅᐆᐊᐋᐱᐲᐳᐴᐸᐹᑉᑎᑏᑐᑑᑕᑖᑦᑭᑮᑯᑰᑲᑳᒃᒋᒌᒍᒎᒐᒑ°ᒡᒥᒦ•¶ᒧ®©™ᒨᒪᒫᒻᓂᓃᓄᓅᓇᓈᓐᓯᓰᓱᓲᓴᓵᔅᓕᓖᓗᓘᓚᓛᓪᔨᔩᔪᔫᔭ… ᔮᔾᕕᕖᕗ–—“”‘’ᕘᕙᕚᕝᕆᕇᕈᕉᕋᕌᕐᕿᖀᖁᖂᖃᖄᖅᖏᖐᖑᖒᖓᖔᖕᙱᙲᙳᙴᙵᙶᖖᖠᖡᖢᖣᖤᖥᖦᕼŁł",
  "x-mac-ce": "ÄĀāÉĄÖÜáąČäčĆćéŹźĎíďĒēĖóėôöõúĚěü†°Ę£§•¶ß®©™ę¨≠ģĮįĪ≤≥īĶ∂∑łĻļĽľĹĺŅņŃ¬√ńŇ∆«»… ňŐÕőŌ–—“”‘’÷◊ōŔŕŘ‹›řŖŗŠ‚„šŚśÁŤťÍŽžŪÓÔūŮÚůŰűŲųÝýķŻŁżĢˇ",
  "x-mac-romanian": "ÄÅÇÉÑÖÜáàâäãåçéèêëíìîïñóòôöõúùûü†°¢£§•¶ß®©™´¨≠ĂȘ∞±≤≥¥µ∂∑∏π∫ªºΩăș¿¡¬√ƒ≈∆«»… ÀÃÕŒœ–—“”‘’÷◊ÿŸ⁄€‹›Țț‡·‚„‰ÂÊÁËÈÍÎÏÌÓÔÒÚÛÙıˆ˜¯˘˙˚¸˝˛ˇ",
  "x-mac-turkish": "ÄÅÇÉÑÖÜáàâäãåçéèêëíìîïñóòôöõúùûü†°¢£§•¶ß®©™´¨≠ÆØ∞±≤≥¥µ∂∑∏π∫ªºΩæø¿¡¬√ƒ≈∆«»… ÀÃÕŒœ–—“”‘’÷◊ÿŸĞğİıŞş‡·‚„‰ÂÊÁËÈÍÎÏÌÓÔÒÚÛÙˆ˜¯˘˙˚¸˝˛ˇ"
}, yr = /* @__PURE__ */ new Map();
function Bi(i) {
  let e = yr.get(i);
  if (e) return e;
  let t = Di[i];
  if (t) {
    let r = /* @__PURE__ */ new Map();
    for (let s = 0; s < t.length; s++) r.set(t.charCodeAt(s), 128 + s);
    return yr.set(i, r), r;
  }
  if (Fi.has(i)) {
    let r = new TextDecoder(i), s = new Uint8Array(128);
    for (let o = 0; o < 128; o++) s[o] = 128 + o;
    let n = /* @__PURE__ */ new Map(), a = r.decode(s);
    for (let o = 0; o < 128; o++) n.set(a.charCodeAt(o), 128 + o);
    return yr.set(i, n), n;
  }
}
const Li = [
  // unicode
  [
    "utf-16be",
    "utf-16be",
    "utf-16be",
    "utf-16be",
    "utf-16be",
    "utf-16be",
    "utf-16be"
  ],
  // macintosh
  // Mappings available at http://unicode.org/Public/MAPPINGS/VENDORS/APPLE/
  // 0	Roman                 17	Malayalam
  // 1	Japanese	            18	Sinhalese
  // 2	Traditional Chinese	  19	Burmese
  // 3	Korean	              20	Khmer
  // 4	Arabic	              21	Thai
  // 5	Hebrew	              22	Laotian
  // 6	Greek	                23	Georgian
  // 7	Russian	              24	Armenian
  // 8	RSymbol	              25	Simplified Chinese
  // 9	Devanagari	          26	Tibetan
  // 10	Gurmukhi	            27	Mongolian
  // 11	Gujarati	            28	Geez
  // 12	Oriya	                29	Slavic
  // 13	Bengali	              30	Vietnamese
  // 14	Tamil	                31	Sindhi
  // 15	Telugu	              32	(Uninterpreted)
  // 16	Kannada
  [
    "x-mac-roman",
    "shift-jis",
    "big5",
    "euc-kr",
    "iso-8859-6",
    "iso-8859-8",
    "x-mac-greek",
    "x-mac-cyrillic",
    "x-mac-symbol",
    "x-mac-devanagari",
    "x-mac-gurmukhi",
    "x-mac-gujarati",
    "Oriya",
    "Bengali",
    "Tamil",
    "Telugu",
    "Kannada",
    "Malayalam",
    "Sinhalese",
    "Burmese",
    "Khmer",
    "iso-8859-11",
    "Laotian",
    "Georgian",
    "Armenian",
    "gbk",
    "Tibetan",
    "Mongolian",
    "Geez",
    "x-mac-ce",
    "Vietnamese",
    "Sindhi"
  ],
  // ISO (deprecated)
  [
    "ascii",
    null,
    "iso-8859-1"
  ],
  // windows
  // Docs here: http://msdn.microsoft.com/en-us/library/system.text.encoding(v=vs.110).aspx
  [
    "symbol",
    "utf-16be",
    "shift-jis",
    "gb18030",
    "big5",
    "euc-kr",
    "johab",
    null,
    null,
    null,
    "utf-16be"
  ]
], zs = {
  15: "x-mac-icelandic",
  17: "x-mac-turkish",
  18: "x-mac-croatian",
  24: "x-mac-ce",
  25: "x-mac-ce",
  26: "x-mac-ce",
  27: "x-mac-ce",
  28: "x-mac-ce",
  30: "x-mac-icelandic",
  37: "x-mac-romanian",
  38: "x-mac-ce",
  39: "x-mac-ce",
  40: "x-mac-ce",
  143: "x-mac-inuit",
  146: "x-mac-gaelic"
}, Mi = [
  // unicode
  [],
  {
    0: "en",
    30: "fo",
    60: "ks",
    90: "rw",
    1: "fr",
    31: "fa",
    61: "ku",
    91: "rn",
    2: "de",
    32: "ru",
    62: "sd",
    92: "ny",
    3: "it",
    33: "zh",
    63: "bo",
    93: "mg",
    4: "nl",
    34: "nl-BE",
    64: "ne",
    94: "eo",
    5: "sv",
    35: "ga",
    65: "sa",
    128: "cy",
    6: "es",
    36: "sq",
    66: "mr",
    129: "eu",
    7: "da",
    37: "ro",
    67: "bn",
    130: "ca",
    8: "pt",
    38: "cz",
    68: "as",
    131: "la",
    9: "no",
    39: "sk",
    69: "gu",
    132: "qu",
    10: "he",
    40: "si",
    70: "pa",
    133: "gn",
    11: "ja",
    41: "yi",
    71: "or",
    134: "ay",
    12: "ar",
    42: "sr",
    72: "ml",
    135: "tt",
    13: "fi",
    43: "mk",
    73: "kn",
    136: "ug",
    14: "el",
    44: "bg",
    74: "ta",
    137: "dz",
    15: "is",
    45: "uk",
    75: "te",
    138: "jv",
    16: "mt",
    46: "be",
    76: "si",
    139: "su",
    17: "tr",
    47: "uz",
    77: "my",
    140: "gl",
    18: "hr",
    48: "kk",
    78: "km",
    141: "af",
    19: "zh-Hant",
    49: "az-Cyrl",
    79: "lo",
    142: "br",
    20: "ur",
    50: "az-Arab",
    80: "vi",
    143: "iu",
    21: "hi",
    51: "hy",
    81: "id",
    144: "gd",
    22: "th",
    52: "ka",
    82: "tl",
    145: "gv",
    23: "ko",
    53: "mo",
    83: "ms",
    146: "ga",
    24: "lt",
    54: "ky",
    84: "ms-Arab",
    147: "to",
    25: "pl",
    55: "tg",
    85: "am",
    148: "el-polyton",
    26: "hu",
    56: "tk",
    86: "ti",
    149: "kl",
    27: "es",
    57: "mn-CN",
    87: "om",
    150: "az",
    28: "lv",
    58: "mn",
    88: "so",
    151: "nn",
    29: "se",
    59: "ps",
    89: "sw"
  },
  // ISO (deprecated)
  [],
  {
    1078: "af",
    16393: "en-IN",
    1159: "rw",
    1074: "tn",
    1052: "sq",
    6153: "en-IE",
    1089: "sw",
    1115: "si",
    1156: "gsw",
    8201: "en-JM",
    1111: "kok",
    1051: "sk",
    1118: "am",
    17417: "en-MY",
    1042: "ko",
    1060: "sl",
    5121: "ar-DZ",
    5129: "en-NZ",
    1088: "ky",
    11274: "es-AR",
    15361: "ar-BH",
    13321: "en-PH",
    1108: "lo",
    16394: "es-BO",
    3073: "ar",
    18441: "en-SG",
    1062: "lv",
    13322: "es-CL",
    2049: "ar-IQ",
    7177: "en-ZA",
    1063: "lt",
    9226: "es-CO",
    11265: "ar-JO",
    11273: "en-TT",
    2094: "dsb",
    5130: "es-CR",
    13313: "ar-KW",
    2057: "en-GB",
    1134: "lb",
    7178: "es-DO",
    12289: "ar-LB",
    1033: "en",
    1071: "mk",
    12298: "es-EC",
    4097: "ar-LY",
    12297: "en-ZW",
    2110: "ms-BN",
    17418: "es-SV",
    6145: "ary",
    1061: "et",
    1086: "ms",
    4106: "es-GT",
    8193: "ar-OM",
    1080: "fo",
    1100: "ml",
    18442: "es-HN",
    16385: "ar-QA",
    1124: "fil",
    1082: "mt",
    2058: "es-MX",
    1025: "ar-SA",
    1035: "fi",
    1153: "mi",
    19466: "es-NI",
    10241: "ar-SY",
    2060: "fr-BE",
    1146: "arn",
    6154: "es-PA",
    7169: "aeb",
    3084: "fr-CA",
    1102: "mr",
    15370: "es-PY",
    14337: "ar-AE",
    1036: "fr",
    1148: "moh",
    10250: "es-PE",
    9217: "ar-YE",
    5132: "fr-LU",
    1104: "mn",
    20490: "es-PR",
    1067: "hy",
    6156: "fr-MC",
    2128: "mn-CN",
    3082: "es",
    1101: "as",
    4108: "fr-CH",
    1121: "ne",
    1034: "es",
    2092: "az-Cyrl",
    1122: "fy",
    1044: "nb",
    21514: "es-US",
    1068: "az",
    1110: "gl",
    2068: "nn",
    14346: "es-UY",
    1133: "ba",
    1079: "ka",
    1154: "oc",
    8202: "es-VE",
    1069: "eu",
    3079: "de-AT",
    1096: "or",
    2077: "sv-FI",
    1059: "be",
    1031: "de",
    1123: "ps",
    1053: "sv",
    2117: "bn",
    5127: "de-LI",
    1045: "pl",
    1114: "syr",
    1093: "bn-IN",
    4103: "de-LU",
    1046: "pt",
    1064: "tg",
    8218: "bs-Cyrl",
    2055: "de-CH",
    2070: "pt-PT",
    2143: "tzm",
    5146: "bs",
    1032: "el",
    1094: "pa",
    1097: "ta",
    1150: "br",
    1135: "kl",
    1131: "qu-BO",
    1092: "tt",
    1026: "bg",
    1095: "gu",
    2155: "qu-EC",
    1098: "te",
    1027: "ca",
    1128: "ha",
    3179: "qu",
    1054: "th",
    3076: "zh-HK",
    1037: "he",
    1048: "ro",
    1105: "bo",
    5124: "zh-MO",
    1081: "hi",
    1047: "rm",
    1055: "tr",
    2052: "zh",
    1038: "hu",
    1049: "ru",
    1090: "tk",
    4100: "zh-SG",
    1039: "is",
    9275: "smn",
    1152: "ug",
    1028: "zh-TW",
    1136: "ig",
    4155: "smj-NO",
    1058: "uk",
    1155: "co",
    1057: "id",
    5179: "smj",
    1070: "hsb",
    1050: "hr",
    1117: "iu",
    3131: "se-FI",
    1056: "ur",
    4122: "hr-BA",
    2141: "iu-Latn",
    1083: "se",
    2115: "uz-Cyrl",
    1029: "cs",
    2108: "ga",
    2107: "se-SE",
    1091: "uz",
    1030: "da",
    1076: "xh",
    8251: "sms",
    1066: "vi",
    1164: "prs",
    1077: "zu",
    6203: "sma-NO",
    1106: "cy",
    1125: "dv",
    1040: "it",
    7227: "sms",
    1160: "wo",
    2067: "nl-BE",
    2064: "it-CH",
    1103: "sa",
    1157: "sah",
    1043: "nl",
    1041: "ja",
    7194: "sr-Cyrl-BA",
    1144: "ii",
    3081: "en-AU",
    1099: "kn",
    3098: "sr",
    1130: "yo",
    10249: "en-BZ",
    1087: "kk",
    6170: "sr-Latn-BA",
    4105: "en-CA",
    1107: "km",
    2074: "sr-Latn",
    9225: "en-029",
    1158: "quc",
    1132: "nso"
  }
];
let qs = new x({
  platformID: l,
  encodingID: l,
  languageID: l,
  nameID: l,
  length: l,
  string: new g(l, new de("length", (i) => Va(i.platformID, i.encodingID, i.languageID)), {
    type: "parent",
    relativeTo: (i) => i.parent.stringOffset,
    allowNull: !1
  })
}), Ri = new x({
  length: l,
  tag: new g(l, new de("length", "utf16be"), {
    type: "parent",
    relativeTo: (i) => i.stringOffset
  })
});
var Tt = new te(l, {
  0: {
    count: l,
    stringOffset: l,
    records: new b(qs, "count")
  },
  1: {
    count: l,
    stringOffset: l,
    records: new b(qs, "count"),
    langTagCount: l,
    langTags: new b(Ri, "langTagCount")
  }
}), Ni = Tt;
const Dr = [
  "copyright",
  "fontFamily",
  "fontSubfamily",
  "uniqueSubfamily",
  "fullName",
  "version",
  "postscriptName",
  "trademark",
  "manufacturer",
  "designer",
  "description",
  "vendorURL",
  "designerURL",
  "license",
  "licenseURL",
  null,
  "preferredFamily",
  "preferredSubfamily",
  "compatibleFull",
  "sampleText",
  "postscriptCIDFontName",
  "wwsFamilyName",
  "wwsSubfamilyName"
];
Tt.process = function(i) {
  var e = {};
  for (let t of this.records) {
    let r = Mi[t.platformID][t.languageID];
    r == null && this.langTags != null && t.languageID >= 32768 && (r = this.langTags[t.languageID - 32768].tag), r == null && (r = t.platformID + "-" + t.languageID);
    let s = t.nameID >= 256 ? "fontFeatures" : Dr[t.nameID] || t.nameID;
    e[s] == null && (e[s] = {});
    let n = e[s];
    t.nameID >= 256 && (n = n[t.nameID] || (n[t.nameID] = {})), (typeof t.string == "string" || typeof n[r] != "string") && (n[r] = t.string);
  }
  this.records = e;
};
Tt.preEncode = function() {
  if (Array.isArray(this.records)) return;
  this.version = 0;
  let i = [];
  for (let e in this.records) {
    let t = this.records[e];
    e !== "fontFeatures" && (i.push({
      platformID: 3,
      encodingID: 1,
      languageID: 1033,
      nameID: Dr.indexOf(e),
      length: t.en.length * 2,
      string: t.en
    }), e === "postscriptName" && i.push({
      platformID: 1,
      encodingID: 0,
      languageID: 0,
      nameID: Dr.indexOf(e),
      length: t.en.length,
      string: t.en
    }));
  }
  this.records = i, this.count = i.length, this.stringOffset = Tt.size(this, null, !1);
};
var za = new te(l, {
  header: {
    xAvgCharWidth: E,
    usWeightClass: l,
    usWidthClass: l,
    fsType: new ze(l, [
      null,
      "noEmbedding",
      "viewOnly",
      "editable",
      null,
      null,
      null,
      null,
      "noSubsetting",
      "bitmapOnly"
    ]),
    ySubscriptXSize: E,
    ySubscriptYSize: E,
    ySubscriptXOffset: E,
    ySubscriptYOffset: E,
    ySuperscriptXSize: E,
    ySuperscriptYSize: E,
    ySuperscriptXOffset: E,
    ySuperscriptYOffset: E,
    yStrikeoutSize: E,
    yStrikeoutPosition: E,
    sFamilyClass: E,
    panose: new b(D, 10),
    ulCharRange: new b(v, 4),
    vendorID: new de(4),
    fsSelection: new ze(l, [
      "italic",
      "underscore",
      "negative",
      "outlined",
      "strikeout",
      "bold",
      "regular",
      "useTypoMetrics",
      "wws",
      "oblique"
    ]),
    usFirstCharIndex: l,
    usLastCharIndex: l
    // The maximum Unicode index in this font
  },
  // The Apple version of this table ends here, but the Microsoft one continues on...
  0: {},
  1: {
    typoAscender: E,
    typoDescender: E,
    typoLineGap: E,
    winAscent: l,
    winDescent: l,
    codePageRange: new b(v, 2)
  },
  2: {
    // these should be common with version 1 somehow
    typoAscender: E,
    typoDescender: E,
    typoLineGap: E,
    winAscent: l,
    winDescent: l,
    codePageRange: new b(v, 2),
    xHeight: E,
    capHeight: E,
    defaultChar: l,
    breakChar: l,
    maxContent: l
  },
  5: {
    typoAscender: E,
    typoDescender: E,
    typoLineGap: E,
    winAscent: l,
    winDescent: l,
    codePageRange: new b(v, 2),
    xHeight: E,
    capHeight: E,
    defaultChar: l,
    breakChar: l,
    maxContent: l,
    usLowerOpticalPointSize: l,
    usUpperOpticalPointSize: l
  }
});
let Cr = za.versions;
Cr[3] = Cr[4] = Cr[2];
var Ui = za, Gi = new te(ve, {
  header: {
    italicAngle: ve,
    underlinePosition: E,
    underlineThickness: E,
    isFixedPitch: v,
    minMemType42: v,
    maxMemType42: v,
    minMemType1: v,
    maxMemType1: v
    // Maximum memory usage when a TrueType font is downloaded as a Type 1 font
  },
  1: {},
  2: {
    numberOfGlyphs: l,
    glyphNameIndex: new b(l, "numberOfGlyphs"),
    names: new b(new de(D))
  },
  2.5: {
    numberOfGlyphs: l,
    offsets: new b(D, "numberOfGlyphs")
  },
  3: {},
  4: {
    map: new b(v, (i) => i.parent.maxp.numGlyphs)
  }
}), Vi = new x({
  controlValues: new b(E)
}), zi = new x({
  instructions: new b(D)
});
let Xr = new te("head.indexToLocFormat", {
  0: {
    offsets: new b(l)
  },
  1: {
    offsets: new b(v)
  }
});
Xr.process = function() {
  if (this.version === 0 && !this._processed) {
    for (let i = 0; i < this.offsets.length; i++) this.offsets[i] <<= 1;
    this._processed = !0;
  }
};
Xr.preEncode = function() {
  if (this.version === 0 && this._processed !== !1) {
    for (let i = 0; i < this.offsets.length; i++) this.offsets[i] >>>= 1;
    this._processed = !1;
  }
};
var qi = Xr, Wi = new x({
  controlValueProgram: new b(D)
}), Hi = new b(new Ye());
class Xe {
  getCFFVersion(e) {
    for (; e && !e.hdrSize; ) e = e.parent;
    return e ? e.version : -1;
  }
  decode(e, t) {
    let s = this.getCFFVersion(t) >= 2 ? e.readUInt32BE() : e.readUInt16BE();
    if (s === 0) return [];
    let n = e.readUInt8(), a;
    if (n === 1) a = D;
    else if (n === 2) a = l;
    else if (n === 3) a = h0;
    else if (n === 4) a = v;
    else throw new Error(`Bad offset size in CFFIndex: ${n} ${e.pos}`);
    let o = [], u = e.pos + (s + 1) * n - 1, c = a.decode(e);
    for (let d = 0; d < s; d++) {
      let f = a.decode(e);
      if (this.type != null) {
        let p = e.pos;
        e.pos = u + c, t.length = f - c, o.push(this.type.decode(e, t)), e.pos = p;
      } else o.push({
        offset: u + c,
        length: f - c
      });
      c = f;
    }
    return e.pos = u + c, o;
  }
  size(e, t) {
    let r = 2;
    if (e.length === 0) return r;
    let s = this.type || new Ye(), n = 1;
    for (let o = 0; o < e.length; o++) {
      let u = e[o];
      n += s.size(u, t);
    }
    let a;
    if (n <= 255) a = D;
    else if (n <= 65535) a = l;
    else if (n <= 16777215) a = h0;
    else if (n <= 4294967295) a = v;
    else throw new Error("Bad offset in CFFIndex");
    return r += 1 + a.size() * (e.length + 1), r += n - 1, r;
  }
  encode(e, t, r) {
    if (e.writeUInt16BE(t.length), t.length === 0) return;
    let s = this.type || new Ye(), n = [], a = 1;
    for (let u of t) {
      let c = s.size(u, r);
      n.push(c), a += c;
    }
    let o;
    if (a <= 255) o = D;
    else if (a <= 65535) o = l;
    else if (a <= 16777215) o = h0;
    else if (a <= 4294967295) o = v;
    else throw new Error("Bad offset in CFFIndex");
    e.writeUInt8(o.size()), a = 1, o.encode(e, a);
    for (let u of n)
      a += u, o.encode(e, a);
    for (let u of t) s.encode(e, u, r);
  }
  constructor(e) {
    this.type = e;
  }
}
const Y0 = 15, Ws = [
  "0",
  "1",
  "2",
  "3",
  "4",
  "5",
  "6",
  "7",
  "8",
  "9",
  ".",
  "E",
  "E-",
  null,
  "-"
], Hs = {
  ".": 10,
  E: 11,
  "E-": 12,
  "-": 14
};
class Sr {
  static decode(e, t) {
    if (32 <= t && t <= 246) return t - 139;
    if (247 <= t && t <= 250) return (t - 247) * 256 + e.readUInt8() + 108;
    if (251 <= t && t <= 254) return -(t - 251) * 256 - e.readUInt8() - 108;
    if (t === 28) return e.readInt16BE();
    if (t === 29) return e.readInt32BE();
    if (t === 30) {
      let r = "";
      for (; ; ) {
        let s = e.readUInt8(), n = s >> 4;
        if (n === Y0) break;
        r += Ws[n];
        let a = s & 15;
        if (a === Y0) break;
        r += Ws[a];
      }
      return parseFloat(r);
    }
    return null;
  }
  static size(e) {
    if (e.forceLarge && (e = 32768), (e | 0) !== e) {
      let t = "" + e;
      return 1 + Math.ceil((t.length + 1) / 2);
    } else return -107 <= e && e <= 107 ? 1 : 108 <= e && e <= 1131 || -1131 <= e && e <= -108 ? 2 : -32768 <= e && e <= 32767 ? 3 : 5;
  }
  static encode(e, t) {
    let r = Number(t);
    if (t.forceLarge)
      return e.writeUInt8(29), e.writeInt32BE(r);
    if ((r | 0) !== r) {
      e.writeUInt8(30);
      let n = "" + r;
      for (let a = 0; a < n.length; a += 2) {
        let o = n[a], u = Hs[o] || +o;
        if (a === n.length - 1) var s = Y0;
        else {
          let c = n[a + 1];
          var s = Hs[c] || +c;
        }
        e.writeUInt8(u << 4 | s & 15);
      }
      if (s !== Y0) return e.writeUInt8(Y0 << 4);
    } else return -107 <= r && r <= 107 ? e.writeUInt8(r + 139) : 108 <= r && r <= 1131 ? (r -= 108, e.writeUInt8((r >> 8) + 247), e.writeUInt8(r & 255)) : -1131 <= r && r <= -108 ? (r = -r - 108, e.writeUInt8((r >> 8) + 251), e.writeUInt8(r & 255)) : -32768 <= r && r <= 32767 ? (e.writeUInt8(28), e.writeInt16BE(r)) : (e.writeUInt8(29), e.writeInt32BE(r));
  }
}
class Wt {
  decodeOperands(e, t, r, s) {
    if (Array.isArray(e)) return s.map((n, a) => this.decodeOperands(e[a], t, r, [
      n
    ]));
    if (e.decode != null) return e.decode(t, r, s);
    switch (e) {
      case "number":
      case "offset":
      case "sid":
        return s[0];
      case "boolean":
        return !!s[0];
      default:
        return s;
    }
  }
  encodeOperands(e, t, r, s) {
    return Array.isArray(e) ? s.map((n, a) => this.encodeOperands(e[a], t, r, n)[0]) : e.encode != null ? e.encode(t, s, r) : typeof s == "number" ? [
      s
    ] : typeof s == "boolean" ? [
      +s
    ] : Array.isArray(s) ? s : [
      s
    ];
  }
  decode(e, t) {
    let r = e.pos + t.length, s = {}, n = [];
    Object.defineProperties(s, {
      parent: {
        value: t
      },
      _startOffset: {
        value: e.pos
      }
    });
    for (let a in this.fields) {
      let o = this.fields[a];
      s[o[1]] = o[3];
    }
    for (; e.pos < r; ) {
      let a = e.readUInt8();
      if (a < 28) {
        a === 12 && (a = a << 8 | e.readUInt8());
        let o = this.fields[a];
        if (!o) throw new Error(`Unknown operator ${a}`);
        let u = this.decodeOperands(o[2], e, s, n);
        u != null && (u instanceof zr ? Object.defineProperty(s, o[1], u) : s[o[1]] = u), n = [];
      } else n.push(Sr.decode(e, a));
    }
    return s;
  }
  size(e, t, r = !0) {
    let s = {
      parent: t,
      val: e,
      pointerSize: 0,
      startOffset: t.startOffset || 0
    }, n = 0;
    for (let a in this.fields) {
      let o = this.fields[a], u = e[o[1]];
      if (u == null || ws(u, o[3])) continue;
      let c = this.encodeOperands(o[2], null, s, u);
      for (let f of c) n += Sr.size(f);
      let d = Array.isArray(o[0]) ? o[0] : [
        o[0]
      ];
      n += d.length;
    }
    return r && (n += s.pointerSize), n;
  }
  encode(e, t, r) {
    let s = {
      pointers: [],
      startOffset: e.pos,
      parent: r,
      val: t,
      pointerSize: 0
    };
    s.pointerOffset = e.pos + this.size(t, s, !1);
    for (let a of this.ops) {
      let o = t[a[1]];
      if (o == null || ws(o, a[3])) continue;
      let u = this.encodeOperands(a[2], e, s, o);
      for (let d of u) Sr.encode(e, d);
      let c = Array.isArray(a[0]) ? a[0] : [
        a[0]
      ];
      for (let d of c) e.writeUInt8(d);
    }
    let n = 0;
    for (; n < s.pointers.length; ) {
      let a = s.pointers[n++];
      a.type.encode(e, a.val, a.parent);
    }
  }
  constructor(e = []) {
    this.ops = e, this.fields = {};
    for (let t of e) {
      let r = Array.isArray(t[0]) ? t[0][0] << 8 | t[0][1] : t[0];
      this.fields[r] = t;
    }
  }
}
class Ve extends g {
  decode(e, t, r) {
    return this.offsetType = {
      decode: () => r[0]
    }, super.decode(e, t, r);
  }
  encode(e, t, r) {
    if (!e)
      return this.offsetType = {
        size: () => 0
      }, this.size(t, r), [
        new $s(0)
      ];
    let s = null;
    return this.offsetType = {
      encode: (n, a) => s = a
    }, super.encode(e, t, r), [
      new $s(s)
    ];
  }
  constructor(e, t = {}) {
    t.type == null && (t.type = "global"), super(null, e, t);
  }
}
class $s {
  valueOf() {
    return this.val;
  }
  constructor(e) {
    this.val = e, this.forceLarge = !0;
  }
}
class $i {
  static decode(e, t, r) {
    let s = r.pop();
    for (; r.length > s; ) r.pop();
  }
}
var Br = new Wt([
  // key       name                    type                                          default
  [
    6,
    "BlueValues",
    "delta",
    null
  ],
  [
    7,
    "OtherBlues",
    "delta",
    null
  ],
  [
    8,
    "FamilyBlues",
    "delta",
    null
  ],
  [
    9,
    "FamilyOtherBlues",
    "delta",
    null
  ],
  [
    [
      12,
      9
    ],
    "BlueScale",
    "number",
    0.039625
  ],
  [
    [
      12,
      10
    ],
    "BlueShift",
    "number",
    7
  ],
  [
    [
      12,
      11
    ],
    "BlueFuzz",
    "number",
    1
  ],
  [
    10,
    "StdHW",
    "number",
    null
  ],
  [
    11,
    "StdVW",
    "number",
    null
  ],
  [
    [
      12,
      12
    ],
    "StemSnapH",
    "delta",
    null
  ],
  [
    [
      12,
      13
    ],
    "StemSnapV",
    "delta",
    null
  ],
  [
    [
      12,
      14
    ],
    "ForceBold",
    "boolean",
    !1
  ],
  [
    [
      12,
      17
    ],
    "LanguageGroup",
    "number",
    0
  ],
  [
    [
      12,
      18
    ],
    "ExpansionFactor",
    "number",
    0.06
  ],
  [
    [
      12,
      19
    ],
    "initialRandomSeed",
    "number",
    0
  ],
  [
    20,
    "defaultWidthX",
    "number",
    0
  ],
  [
    21,
    "nominalWidthX",
    "number",
    0
  ],
  [
    22,
    "vsindex",
    "number",
    0
  ],
  [
    23,
    "blend",
    $i,
    null
  ],
  [
    19,
    "Subrs",
    new Ve(new Xe(), {
      type: "local"
    }),
    null
  ]
]), St = [
  ".notdef",
  "space",
  "exclam",
  "quotedbl",
  "numbersign",
  "dollar",
  "percent",
  "ampersand",
  "quoteright",
  "parenleft",
  "parenright",
  "asterisk",
  "plus",
  "comma",
  "hyphen",
  "period",
  "slash",
  "zero",
  "one",
  "two",
  "three",
  "four",
  "five",
  "six",
  "seven",
  "eight",
  "nine",
  "colon",
  "semicolon",
  "less",
  "equal",
  "greater",
  "question",
  "at",
  "A",
  "B",
  "C",
  "D",
  "E",
  "F",
  "G",
  "H",
  "I",
  "J",
  "K",
  "L",
  "M",
  "N",
  "O",
  "P",
  "Q",
  "R",
  "S",
  "T",
  "U",
  "V",
  "W",
  "X",
  "Y",
  "Z",
  "bracketleft",
  "backslash",
  "bracketright",
  "asciicircum",
  "underscore",
  "quoteleft",
  "a",
  "b",
  "c",
  "d",
  "e",
  "f",
  "g",
  "h",
  "i",
  "j",
  "k",
  "l",
  "m",
  "n",
  "o",
  "p",
  "q",
  "r",
  "s",
  "t",
  "u",
  "v",
  "w",
  "x",
  "y",
  "z",
  "braceleft",
  "bar",
  "braceright",
  "asciitilde",
  "exclamdown",
  "cent",
  "sterling",
  "fraction",
  "yen",
  "florin",
  "section",
  "currency",
  "quotesingle",
  "quotedblleft",
  "guillemotleft",
  "guilsinglleft",
  "guilsinglright",
  "fi",
  "fl",
  "endash",
  "dagger",
  "daggerdbl",
  "periodcentered",
  "paragraph",
  "bullet",
  "quotesinglbase",
  "quotedblbase",
  "quotedblright",
  "guillemotright",
  "ellipsis",
  "perthousand",
  "questiondown",
  "grave",
  "acute",
  "circumflex",
  "tilde",
  "macron",
  "breve",
  "dotaccent",
  "dieresis",
  "ring",
  "cedilla",
  "hungarumlaut",
  "ogonek",
  "caron",
  "emdash",
  "AE",
  "ordfeminine",
  "Lslash",
  "Oslash",
  "OE",
  "ordmasculine",
  "ae",
  "dotlessi",
  "lslash",
  "oslash",
  "oe",
  "germandbls",
  "onesuperior",
  "logicalnot",
  "mu",
  "trademark",
  "Eth",
  "onehalf",
  "plusminus",
  "Thorn",
  "onequarter",
  "divide",
  "brokenbar",
  "degree",
  "thorn",
  "threequarters",
  "twosuperior",
  "registered",
  "minus",
  "eth",
  "multiply",
  "threesuperior",
  "copyright",
  "Aacute",
  "Acircumflex",
  "Adieresis",
  "Agrave",
  "Aring",
  "Atilde",
  "Ccedilla",
  "Eacute",
  "Ecircumflex",
  "Edieresis",
  "Egrave",
  "Iacute",
  "Icircumflex",
  "Idieresis",
  "Igrave",
  "Ntilde",
  "Oacute",
  "Ocircumflex",
  "Odieresis",
  "Ograve",
  "Otilde",
  "Scaron",
  "Uacute",
  "Ucircumflex",
  "Udieresis",
  "Ugrave",
  "Yacute",
  "Ydieresis",
  "Zcaron",
  "aacute",
  "acircumflex",
  "adieresis",
  "agrave",
  "aring",
  "atilde",
  "ccedilla",
  "eacute",
  "ecircumflex",
  "edieresis",
  "egrave",
  "iacute",
  "icircumflex",
  "idieresis",
  "igrave",
  "ntilde",
  "oacute",
  "ocircumflex",
  "odieresis",
  "ograve",
  "otilde",
  "scaron",
  "uacute",
  "ucircumflex",
  "udieresis",
  "ugrave",
  "yacute",
  "ydieresis",
  "zcaron",
  "exclamsmall",
  "Hungarumlautsmall",
  "dollaroldstyle",
  "dollarsuperior",
  "ampersandsmall",
  "Acutesmall",
  "parenleftsuperior",
  "parenrightsuperior",
  "twodotenleader",
  "onedotenleader",
  "zerooldstyle",
  "oneoldstyle",
  "twooldstyle",
  "threeoldstyle",
  "fouroldstyle",
  "fiveoldstyle",
  "sixoldstyle",
  "sevenoldstyle",
  "eightoldstyle",
  "nineoldstyle",
  "commasuperior",
  "threequartersemdash",
  "periodsuperior",
  "questionsmall",
  "asuperior",
  "bsuperior",
  "centsuperior",
  "dsuperior",
  "esuperior",
  "isuperior",
  "lsuperior",
  "msuperior",
  "nsuperior",
  "osuperior",
  "rsuperior",
  "ssuperior",
  "tsuperior",
  "ff",
  "ffi",
  "ffl",
  "parenleftinferior",
  "parenrightinferior",
  "Circumflexsmall",
  "hyphensuperior",
  "Gravesmall",
  "Asmall",
  "Bsmall",
  "Csmall",
  "Dsmall",
  "Esmall",
  "Fsmall",
  "Gsmall",
  "Hsmall",
  "Ismall",
  "Jsmall",
  "Ksmall",
  "Lsmall",
  "Msmall",
  "Nsmall",
  "Osmall",
  "Psmall",
  "Qsmall",
  "Rsmall",
  "Ssmall",
  "Tsmall",
  "Usmall",
  "Vsmall",
  "Wsmall",
  "Xsmall",
  "Ysmall",
  "Zsmall",
  "colonmonetary",
  "onefitted",
  "rupiah",
  "Tildesmall",
  "exclamdownsmall",
  "centoldstyle",
  "Lslashsmall",
  "Scaronsmall",
  "Zcaronsmall",
  "Dieresissmall",
  "Brevesmall",
  "Caronsmall",
  "Dotaccentsmall",
  "Macronsmall",
  "figuredash",
  "hypheninferior",
  "Ogoneksmall",
  "Ringsmall",
  "Cedillasmall",
  "questiondownsmall",
  "oneeighth",
  "threeeighths",
  "fiveeighths",
  "seveneighths",
  "onethird",
  "twothirds",
  "zerosuperior",
  "foursuperior",
  "fivesuperior",
  "sixsuperior",
  "sevensuperior",
  "eightsuperior",
  "ninesuperior",
  "zeroinferior",
  "oneinferior",
  "twoinferior",
  "threeinferior",
  "fourinferior",
  "fiveinferior",
  "sixinferior",
  "seveninferior",
  "eightinferior",
  "nineinferior",
  "centinferior",
  "dollarinferior",
  "periodinferior",
  "commainferior",
  "Agravesmall",
  "Aacutesmall",
  "Acircumflexsmall",
  "Atildesmall",
  "Adieresissmall",
  "Aringsmall",
  "AEsmall",
  "Ccedillasmall",
  "Egravesmall",
  "Eacutesmall",
  "Ecircumflexsmall",
  "Edieresissmall",
  "Igravesmall",
  "Iacutesmall",
  "Icircumflexsmall",
  "Idieresissmall",
  "Ethsmall",
  "Ntildesmall",
  "Ogravesmall",
  "Oacutesmall",
  "Ocircumflexsmall",
  "Otildesmall",
  "Odieresissmall",
  "OEsmall",
  "Oslashsmall",
  "Ugravesmall",
  "Uacutesmall",
  "Ucircumflexsmall",
  "Udieresissmall",
  "Yacutesmall",
  "Thornsmall",
  "Ydieresissmall",
  "001.000",
  "001.001",
  "001.002",
  "001.003",
  "Black",
  "Bold",
  "Book",
  "Light",
  "Medium",
  "Regular",
  "Roman",
  "Semibold"
];
let qa = [
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "space",
  "exclam",
  "quotedbl",
  "numbersign",
  "dollar",
  "percent",
  "ampersand",
  "quoteright",
  "parenleft",
  "parenright",
  "asterisk",
  "plus",
  "comma",
  "hyphen",
  "period",
  "slash",
  "zero",
  "one",
  "two",
  "three",
  "four",
  "five",
  "six",
  "seven",
  "eight",
  "nine",
  "colon",
  "semicolon",
  "less",
  "equal",
  "greater",
  "question",
  "at",
  "A",
  "B",
  "C",
  "D",
  "E",
  "F",
  "G",
  "H",
  "I",
  "J",
  "K",
  "L",
  "M",
  "N",
  "O",
  "P",
  "Q",
  "R",
  "S",
  "T",
  "U",
  "V",
  "W",
  "X",
  "Y",
  "Z",
  "bracketleft",
  "backslash",
  "bracketright",
  "asciicircum",
  "underscore",
  "quoteleft",
  "a",
  "b",
  "c",
  "d",
  "e",
  "f",
  "g",
  "h",
  "i",
  "j",
  "k",
  "l",
  "m",
  "n",
  "o",
  "p",
  "q",
  "r",
  "s",
  "t",
  "u",
  "v",
  "w",
  "x",
  "y",
  "z",
  "braceleft",
  "bar",
  "braceright",
  "asciitilde",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "exclamdown",
  "cent",
  "sterling",
  "fraction",
  "yen",
  "florin",
  "section",
  "currency",
  "quotesingle",
  "quotedblleft",
  "guillemotleft",
  "guilsinglleft",
  "guilsinglright",
  "fi",
  "fl",
  "",
  "endash",
  "dagger",
  "daggerdbl",
  "periodcentered",
  "",
  "paragraph",
  "bullet",
  "quotesinglbase",
  "quotedblbase",
  "quotedblright",
  "guillemotright",
  "ellipsis",
  "perthousand",
  "",
  "questiondown",
  "",
  "grave",
  "acute",
  "circumflex",
  "tilde",
  "macron",
  "breve",
  "dotaccent",
  "dieresis",
  "",
  "ring",
  "cedilla",
  "",
  "hungarumlaut",
  "ogonek",
  "caron",
  "emdash",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "AE",
  "",
  "ordfeminine",
  "",
  "",
  "",
  "",
  "Lslash",
  "Oslash",
  "OE",
  "ordmasculine",
  "",
  "",
  "",
  "",
  "",
  "ae",
  "",
  "",
  "",
  "dotlessi",
  "",
  "",
  "lslash",
  "oslash",
  "oe",
  "germandbls"
], Xi = [
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "space",
  "exclamsmall",
  "Hungarumlautsmall",
  "",
  "dollaroldstyle",
  "dollarsuperior",
  "ampersandsmall",
  "Acutesmall",
  "parenleftsuperior",
  "parenrightsuperior",
  "twodotenleader",
  "onedotenleader",
  "comma",
  "hyphen",
  "period",
  "fraction",
  "zerooldstyle",
  "oneoldstyle",
  "twooldstyle",
  "threeoldstyle",
  "fouroldstyle",
  "fiveoldstyle",
  "sixoldstyle",
  "sevenoldstyle",
  "eightoldstyle",
  "nineoldstyle",
  "colon",
  "semicolon",
  "commasuperior",
  "threequartersemdash",
  "periodsuperior",
  "questionsmall",
  "",
  "asuperior",
  "bsuperior",
  "centsuperior",
  "dsuperior",
  "esuperior",
  "",
  "",
  "isuperior",
  "",
  "",
  "lsuperior",
  "msuperior",
  "nsuperior",
  "osuperior",
  "",
  "",
  "rsuperior",
  "ssuperior",
  "tsuperior",
  "",
  "ff",
  "fi",
  "fl",
  "ffi",
  "ffl",
  "parenleftinferior",
  "",
  "parenrightinferior",
  "Circumflexsmall",
  "hyphensuperior",
  "Gravesmall",
  "Asmall",
  "Bsmall",
  "Csmall",
  "Dsmall",
  "Esmall",
  "Fsmall",
  "Gsmall",
  "Hsmall",
  "Ismall",
  "Jsmall",
  "Ksmall",
  "Lsmall",
  "Msmall",
  "Nsmall",
  "Osmall",
  "Psmall",
  "Qsmall",
  "Rsmall",
  "Ssmall",
  "Tsmall",
  "Usmall",
  "Vsmall",
  "Wsmall",
  "Xsmall",
  "Ysmall",
  "Zsmall",
  "colonmonetary",
  "onefitted",
  "rupiah",
  "Tildesmall",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "exclamdownsmall",
  "centoldstyle",
  "Lslashsmall",
  "",
  "",
  "Scaronsmall",
  "Zcaronsmall",
  "Dieresissmall",
  "Brevesmall",
  "Caronsmall",
  "",
  "Dotaccentsmall",
  "",
  "",
  "Macronsmall",
  "",
  "",
  "figuredash",
  "hypheninferior",
  "",
  "",
  "Ogoneksmall",
  "Ringsmall",
  "Cedillasmall",
  "",
  "",
  "",
  "onequarter",
  "onehalf",
  "threequarters",
  "questiondownsmall",
  "oneeighth",
  "threeeighths",
  "fiveeighths",
  "seveneighths",
  "onethird",
  "twothirds",
  "",
  "",
  "zerosuperior",
  "onesuperior",
  "twosuperior",
  "threesuperior",
  "foursuperior",
  "fivesuperior",
  "sixsuperior",
  "sevensuperior",
  "eightsuperior",
  "ninesuperior",
  "zeroinferior",
  "oneinferior",
  "twoinferior",
  "threeinferior",
  "fourinferior",
  "fiveinferior",
  "sixinferior",
  "seveninferior",
  "eightinferior",
  "nineinferior",
  "centinferior",
  "dollarinferior",
  "periodinferior",
  "commainferior",
  "Agravesmall",
  "Aacutesmall",
  "Acircumflexsmall",
  "Atildesmall",
  "Adieresissmall",
  "Aringsmall",
  "AEsmall",
  "Ccedillasmall",
  "Egravesmall",
  "Eacutesmall",
  "Ecircumflexsmall",
  "Edieresissmall",
  "Igravesmall",
  "Iacutesmall",
  "Icircumflexsmall",
  "Idieresissmall",
  "Ethsmall",
  "Ntildesmall",
  "Ogravesmall",
  "Oacutesmall",
  "Ocircumflexsmall",
  "Otildesmall",
  "Odieresissmall",
  "OEsmall",
  "Oslashsmall",
  "Ugravesmall",
  "Uacutesmall",
  "Ucircumflexsmall",
  "Udieresissmall",
  "Yacutesmall",
  "Thornsmall",
  "Ydieresissmall"
], Wa = [
  ".notdef",
  "space",
  "exclam",
  "quotedbl",
  "numbersign",
  "dollar",
  "percent",
  "ampersand",
  "quoteright",
  "parenleft",
  "parenright",
  "asterisk",
  "plus",
  "comma",
  "hyphen",
  "period",
  "slash",
  "zero",
  "one",
  "two",
  "three",
  "four",
  "five",
  "six",
  "seven",
  "eight",
  "nine",
  "colon",
  "semicolon",
  "less",
  "equal",
  "greater",
  "question",
  "at",
  "A",
  "B",
  "C",
  "D",
  "E",
  "F",
  "G",
  "H",
  "I",
  "J",
  "K",
  "L",
  "M",
  "N",
  "O",
  "P",
  "Q",
  "R",
  "S",
  "T",
  "U",
  "V",
  "W",
  "X",
  "Y",
  "Z",
  "bracketleft",
  "backslash",
  "bracketright",
  "asciicircum",
  "underscore",
  "quoteleft",
  "a",
  "b",
  "c",
  "d",
  "e",
  "f",
  "g",
  "h",
  "i",
  "j",
  "k",
  "l",
  "m",
  "n",
  "o",
  "p",
  "q",
  "r",
  "s",
  "t",
  "u",
  "v",
  "w",
  "x",
  "y",
  "z",
  "braceleft",
  "bar",
  "braceright",
  "asciitilde",
  "exclamdown",
  "cent",
  "sterling",
  "fraction",
  "yen",
  "florin",
  "section",
  "currency",
  "quotesingle",
  "quotedblleft",
  "guillemotleft",
  "guilsinglleft",
  "guilsinglright",
  "fi",
  "fl",
  "endash",
  "dagger",
  "daggerdbl",
  "periodcentered",
  "paragraph",
  "bullet",
  "quotesinglbase",
  "quotedblbase",
  "quotedblright",
  "guillemotright",
  "ellipsis",
  "perthousand",
  "questiondown",
  "grave",
  "acute",
  "circumflex",
  "tilde",
  "macron",
  "breve",
  "dotaccent",
  "dieresis",
  "ring",
  "cedilla",
  "hungarumlaut",
  "ogonek",
  "caron",
  "emdash",
  "AE",
  "ordfeminine",
  "Lslash",
  "Oslash",
  "OE",
  "ordmasculine",
  "ae",
  "dotlessi",
  "lslash",
  "oslash",
  "oe",
  "germandbls",
  "onesuperior",
  "logicalnot",
  "mu",
  "trademark",
  "Eth",
  "onehalf",
  "plusminus",
  "Thorn",
  "onequarter",
  "divide",
  "brokenbar",
  "degree",
  "thorn",
  "threequarters",
  "twosuperior",
  "registered",
  "minus",
  "eth",
  "multiply",
  "threesuperior",
  "copyright",
  "Aacute",
  "Acircumflex",
  "Adieresis",
  "Agrave",
  "Aring",
  "Atilde",
  "Ccedilla",
  "Eacute",
  "Ecircumflex",
  "Edieresis",
  "Egrave",
  "Iacute",
  "Icircumflex",
  "Idieresis",
  "Igrave",
  "Ntilde",
  "Oacute",
  "Ocircumflex",
  "Odieresis",
  "Ograve",
  "Otilde",
  "Scaron",
  "Uacute",
  "Ucircumflex",
  "Udieresis",
  "Ugrave",
  "Yacute",
  "Ydieresis",
  "Zcaron",
  "aacute",
  "acircumflex",
  "adieresis",
  "agrave",
  "aring",
  "atilde",
  "ccedilla",
  "eacute",
  "ecircumflex",
  "edieresis",
  "egrave",
  "iacute",
  "icircumflex",
  "idieresis",
  "igrave",
  "ntilde",
  "oacute",
  "ocircumflex",
  "odieresis",
  "ograve",
  "otilde",
  "scaron",
  "uacute",
  "ucircumflex",
  "udieresis",
  "ugrave",
  "yacute",
  "ydieresis",
  "zcaron"
], ji = [
  ".notdef",
  "space",
  "exclamsmall",
  "Hungarumlautsmall",
  "dollaroldstyle",
  "dollarsuperior",
  "ampersandsmall",
  "Acutesmall",
  "parenleftsuperior",
  "parenrightsuperior",
  "twodotenleader",
  "onedotenleader",
  "comma",
  "hyphen",
  "period",
  "fraction",
  "zerooldstyle",
  "oneoldstyle",
  "twooldstyle",
  "threeoldstyle",
  "fouroldstyle",
  "fiveoldstyle",
  "sixoldstyle",
  "sevenoldstyle",
  "eightoldstyle",
  "nineoldstyle",
  "colon",
  "semicolon",
  "commasuperior",
  "threequartersemdash",
  "periodsuperior",
  "questionsmall",
  "asuperior",
  "bsuperior",
  "centsuperior",
  "dsuperior",
  "esuperior",
  "isuperior",
  "lsuperior",
  "msuperior",
  "nsuperior",
  "osuperior",
  "rsuperior",
  "ssuperior",
  "tsuperior",
  "ff",
  "fi",
  "fl",
  "ffi",
  "ffl",
  "parenleftinferior",
  "parenrightinferior",
  "Circumflexsmall",
  "hyphensuperior",
  "Gravesmall",
  "Asmall",
  "Bsmall",
  "Csmall",
  "Dsmall",
  "Esmall",
  "Fsmall",
  "Gsmall",
  "Hsmall",
  "Ismall",
  "Jsmall",
  "Ksmall",
  "Lsmall",
  "Msmall",
  "Nsmall",
  "Osmall",
  "Psmall",
  "Qsmall",
  "Rsmall",
  "Ssmall",
  "Tsmall",
  "Usmall",
  "Vsmall",
  "Wsmall",
  "Xsmall",
  "Ysmall",
  "Zsmall",
  "colonmonetary",
  "onefitted",
  "rupiah",
  "Tildesmall",
  "exclamdownsmall",
  "centoldstyle",
  "Lslashsmall",
  "Scaronsmall",
  "Zcaronsmall",
  "Dieresissmall",
  "Brevesmall",
  "Caronsmall",
  "Dotaccentsmall",
  "Macronsmall",
  "figuredash",
  "hypheninferior",
  "Ogoneksmall",
  "Ringsmall",
  "Cedillasmall",
  "onequarter",
  "onehalf",
  "threequarters",
  "questiondownsmall",
  "oneeighth",
  "threeeighths",
  "fiveeighths",
  "seveneighths",
  "onethird",
  "twothirds",
  "zerosuperior",
  "onesuperior",
  "twosuperior",
  "threesuperior",
  "foursuperior",
  "fivesuperior",
  "sixsuperior",
  "sevensuperior",
  "eightsuperior",
  "ninesuperior",
  "zeroinferior",
  "oneinferior",
  "twoinferior",
  "threeinferior",
  "fourinferior",
  "fiveinferior",
  "sixinferior",
  "seveninferior",
  "eightinferior",
  "nineinferior",
  "centinferior",
  "dollarinferior",
  "periodinferior",
  "commainferior",
  "Agravesmall",
  "Aacutesmall",
  "Acircumflexsmall",
  "Atildesmall",
  "Adieresissmall",
  "Aringsmall",
  "AEsmall",
  "Ccedillasmall",
  "Egravesmall",
  "Eacutesmall",
  "Ecircumflexsmall",
  "Edieresissmall",
  "Igravesmall",
  "Iacutesmall",
  "Icircumflexsmall",
  "Idieresissmall",
  "Ethsmall",
  "Ntildesmall",
  "Ogravesmall",
  "Oacutesmall",
  "Ocircumflexsmall",
  "Otildesmall",
  "Odieresissmall",
  "OEsmall",
  "Oslashsmall",
  "Ugravesmall",
  "Uacutesmall",
  "Ucircumflexsmall",
  "Udieresissmall",
  "Yacutesmall",
  "Thornsmall",
  "Ydieresissmall"
], Yi = [
  ".notdef",
  "space",
  "dollaroldstyle",
  "dollarsuperior",
  "parenleftsuperior",
  "parenrightsuperior",
  "twodotenleader",
  "onedotenleader",
  "comma",
  "hyphen",
  "period",
  "fraction",
  "zerooldstyle",
  "oneoldstyle",
  "twooldstyle",
  "threeoldstyle",
  "fouroldstyle",
  "fiveoldstyle",
  "sixoldstyle",
  "sevenoldstyle",
  "eightoldstyle",
  "nineoldstyle",
  "colon",
  "semicolon",
  "commasuperior",
  "threequartersemdash",
  "periodsuperior",
  "asuperior",
  "bsuperior",
  "centsuperior",
  "dsuperior",
  "esuperior",
  "isuperior",
  "lsuperior",
  "msuperior",
  "nsuperior",
  "osuperior",
  "rsuperior",
  "ssuperior",
  "tsuperior",
  "ff",
  "fi",
  "fl",
  "ffi",
  "ffl",
  "parenleftinferior",
  "parenrightinferior",
  "hyphensuperior",
  "colonmonetary",
  "onefitted",
  "rupiah",
  "centoldstyle",
  "figuredash",
  "hypheninferior",
  "onequarter",
  "onehalf",
  "threequarters",
  "oneeighth",
  "threeeighths",
  "fiveeighths",
  "seveneighths",
  "onethird",
  "twothirds",
  "zerosuperior",
  "onesuperior",
  "twosuperior",
  "threesuperior",
  "foursuperior",
  "fivesuperior",
  "sixsuperior",
  "sevensuperior",
  "eightsuperior",
  "ninesuperior",
  "zeroinferior",
  "oneinferior",
  "twoinferior",
  "threeinferior",
  "fourinferior",
  "fiveinferior",
  "sixinferior",
  "seveninferior",
  "eightinferior",
  "nineinferior",
  "centinferior",
  "dollarinferior",
  "periodinferior",
  "commainferior"
], Ha = new x({
  reserved: new be(l),
  reqFeatureIndex: l,
  featureCount: l,
  featureIndexes: new b(l, "featureCount")
}), Zi = new x({
  tag: new de(4),
  langSys: new g(l, Ha, {
    type: "parent"
  })
}), Ki = new x({
  defaultLangSys: new g(l, Ha),
  count: l,
  langSysRecords: new b(Zi, "count")
}), Ji = new x({
  tag: new de(4),
  script: new g(l, Ki, {
    type: "parent"
  })
}), $a = new b(Ji, l), Qi = new x({
  version: l,
  nameID: l
}), Xa = new x({
  featureParams: new g(l, Qi),
  lookupCount: l,
  lookupListIndexes: new b(l, "lookupCount")
}), _i = new x({
  tag: new de(4),
  feature: new g(l, Xa, {
    type: "parent"
  })
}), ja = new b(_i, l), el = new x({
  markAttachmentType: D,
  flags: new ze(D, [
    "rightToLeft",
    "ignoreBaseGlyphs",
    "ignoreLigatures",
    "ignoreMarks",
    "useMarkFilteringSet"
  ])
});
function Ot(i) {
  let e = new x({
    lookupType: l,
    flags: el,
    subTableCount: l,
    subTables: new b(new g(l, i), "subTableCount"),
    markFilteringSet: new Et(l, (t) => t.flags.flags.useMarkFilteringSet)
  });
  return new he(new g(l, e), l);
}
let tl = new x({
  start: l,
  end: l,
  startCoverageIndex: l
}), fe = new te(l, {
  1: {
    glyphCount: l,
    glyphs: new b(l, "glyphCount")
  },
  2: {
    rangeCount: l,
    rangeRecords: new b(tl, "rangeCount")
  }
}), rl = new x({
  start: l,
  end: l,
  class: l
}), p0 = new te(l, {
  1: {
    startGlyph: l,
    glyphCount: l,
    classValueArray: new b(l, "glyphCount")
  },
  2: {
    classRangeCount: l,
    classRangeRecord: new b(rl, "classRangeCount")
  }
}), d0 = new x({
  a: l,
  b: l,
  deltaFormat: l
}), lt = new x({
  sequenceIndex: l,
  lookupListIndex: l
}), sl = new x({
  glyphCount: l,
  lookupCount: l,
  input: new b(l, (i) => i.glyphCount - 1),
  lookupRecords: new b(lt, "lookupCount")
}), al = new b(new g(l, sl), l), nl = new x({
  glyphCount: l,
  lookupCount: l,
  classes: new b(l, (i) => i.glyphCount - 1),
  lookupRecords: new b(lt, "lookupCount")
}), il = new b(new g(l, nl), l), Ya = new te(l, {
  1: {
    coverage: new g(l, fe),
    ruleSetCount: l,
    ruleSets: new b(new g(l, al), "ruleSetCount")
  },
  2: {
    coverage: new g(l, fe),
    classDef: new g(l, p0),
    classSetCnt: l,
    classSet: new b(new g(l, il), "classSetCnt")
  },
  3: {
    glyphCount: l,
    lookupCount: l,
    coverages: new b(new g(l, fe), "glyphCount"),
    lookupRecords: new b(lt, "lookupCount")
  }
}), ll = new x({
  backtrackGlyphCount: l,
  backtrack: new b(l, "backtrackGlyphCount"),
  inputGlyphCount: l,
  input: new b(l, (i) => i.inputGlyphCount - 1),
  lookaheadGlyphCount: l,
  lookahead: new b(l, "lookaheadGlyphCount"),
  lookupCount: l,
  lookupRecords: new b(lt, "lookupCount")
}), Xs = new b(new g(l, ll), l), Za = new te(l, {
  1: {
    coverage: new g(l, fe),
    chainCount: l,
    chainRuleSets: new b(new g(l, Xs), "chainCount")
  },
  2: {
    coverage: new g(l, fe),
    backtrackClassDef: new g(l, p0),
    inputClassDef: new g(l, p0),
    lookaheadClassDef: new g(l, p0),
    chainCount: l,
    chainClassSet: new b(new g(l, Xs), "chainCount")
  },
  3: {
    backtrackGlyphCount: l,
    backtrackCoverage: new b(new g(l, fe), "backtrackGlyphCount"),
    inputGlyphCount: l,
    inputCoverage: new b(new g(l, fe), "inputGlyphCount"),
    lookaheadGlyphCount: l,
    lookaheadCoverage: new b(new g(l, fe), "lookaheadGlyphCount"),
    lookupCount: l,
    lookupRecords: new b(lt, "lookupCount")
  }
}), J0 = new E0(16, "BE", 14), ol = new x({
  startCoord: J0,
  peakCoord: J0,
  endCoord: J0
}), ul = new x({
  axisCount: l,
  regionCount: l,
  variationRegions: new b(new b(ol, "axisCount"), "regionCount")
}), cl = new x({
  shortDeltas: new b(E, (i) => i.parent.shortDeltaCount),
  regionDeltas: new b(we, (i) => i.parent.regionIndexCount - i.parent.shortDeltaCount),
  deltas: (i) => i.shortDeltas.concat(i.regionDeltas)
}), fl = new x({
  itemCount: l,
  shortDeltaCount: l,
  regionIndexCount: l,
  regionIndexes: new b(l, "regionIndexCount"),
  deltaSets: new b(cl, "itemCount")
}), Ht = new x({
  format: l,
  variationRegionList: new g(v, ul),
  variationDataCount: l,
  itemVariationData: new b(new g(v, fl), "variationDataCount")
}), dl = new te(l, {
  1: {
    axisIndex: l,
    axisIndex: l,
    filterRangeMinValue: J0,
    filterRangeMaxValue: J0
  }
}), hl = new x({
  conditionCount: l,
  conditionTable: new b(new g(v, dl), "conditionCount")
}), pl = new x({
  featureIndex: l,
  alternateFeatureTable: new g(v, Xa, {
    type: "parent"
  })
}), bl = new x({
  version: ve,
  substitutionCount: l,
  substitutions: new b(pl, "substitutionCount")
}), gl = new x({
  conditionSet: new g(v, hl, {
    type: "parent"
  }),
  featureTableSubstitution: new g(v, bl, {
    type: "parent"
  })
}), Ka = new x({
  majorVersion: l,
  minorVersion: l,
  featureVariationRecordCount: v,
  featureVariationRecords: new b(gl, "featureVariationRecordCount")
});
class Ja {
  decode(e, t, r) {
    return this.predefinedOps[r[0]] ? this.predefinedOps[r[0]] : this.type.decode(e, t, r);
  }
  size(e, t) {
    return this.type.size(e, t);
  }
  encode(e, t, r) {
    let s = this.predefinedOps.indexOf(t);
    return s !== -1 ? s : this.type.encode(e, t, r);
  }
  constructor(e, t) {
    this.predefinedOps = e, this.type = t;
  }
}
class vl extends ce {
  decode(e) {
    return D.decode(e) & 127;
  }
  constructor() {
    super("UInt8");
  }
}
let Qa = new x({
  first: l,
  nLeft: D
}), xl = new x({
  first: l,
  nLeft: l
}), ml = new te(new vl(), {
  0: {
    nCodes: D,
    codes: new b(D, "nCodes")
  },
  1: {
    nRanges: D,
    ranges: new b(Qa, "nRanges")
  }
}), wl = new Ja([
  qa,
  Xi
], new Ve(ml, {
  lazy: !0
}));
class js extends b {
  decode(e, t) {
    let r = Ze(this.length, e, t), s = 0, n = [];
    for (; s < r; ) {
      let a = this.type.decode(e, t);
      a.offset = s, s += a.nLeft + 1, n.push(a);
    }
    return n;
  }
}
let yl = new te(D, {
  0: {
    glyphs: new b(l, (i) => i.parent.CharStrings.length - 1)
  },
  1: {
    ranges: new js(Qa, (i) => i.parent.CharStrings.length - 1)
  },
  2: {
    ranges: new js(xl, (i) => i.parent.CharStrings.length - 1)
  }
}), Cl = new Ja([
  Wa,
  ji,
  Yi
], new Ve(yl, {
  lazy: !0
})), Sl = new x({
  first: l,
  fd: D
}), Al = new x({
  first: v,
  fd: l
}), _a = new te(D, {
  0: {
    fds: new b(D, (i) => i.parent.CharStrings.length)
  },
  3: {
    nRanges: l,
    ranges: new b(Sl, "nRanges"),
    sentinel: l
  },
  4: {
    nRanges: v,
    ranges: new b(Al, "nRanges"),
    sentinel: v
  }
}), Ar = new Ve(Br);
class en {
  decode(e, t, r) {
    return t.length = r[0], Ar.decode(e, t, [
      r[1]
    ]);
  }
  size(e, t) {
    return [
      Br.size(e, t, !1),
      Ar.size(e, t)[0]
    ];
  }
  encode(e, t, r) {
    return [
      Br.size(t, r, !1),
      Ar.encode(e, t, r)[0]
    ];
  }
}
let tn = new Wt([
  // key       name                   type(s)                                 default
  [
    18,
    "Private",
    new en(),
    null
  ],
  [
    [
      12,
      38
    ],
    "FontName",
    "sid",
    null
  ],
  [
    [
      12,
      7
    ],
    "FontMatrix",
    "array",
    [
      1e-3,
      0,
      0,
      1e-3,
      0,
      0
    ]
  ],
  [
    [
      12,
      5
    ],
    "PaintType",
    "number",
    0
  ]
]), Il = new Wt([
  // key       name                   type(s)                                 default
  [
    [
      12,
      30
    ],
    "ROS",
    [
      "sid",
      "sid",
      "number"
    ],
    null
  ],
  [
    0,
    "version",
    "sid",
    null
  ],
  [
    1,
    "Notice",
    "sid",
    null
  ],
  [
    [
      12,
      0
    ],
    "Copyright",
    "sid",
    null
  ],
  [
    2,
    "FullName",
    "sid",
    null
  ],
  [
    3,
    "FamilyName",
    "sid",
    null
  ],
  [
    4,
    "Weight",
    "sid",
    null
  ],
  [
    [
      12,
      1
    ],
    "isFixedPitch",
    "boolean",
    !1
  ],
  [
    [
      12,
      2
    ],
    "ItalicAngle",
    "number",
    0
  ],
  [
    [
      12,
      3
    ],
    "UnderlinePosition",
    "number",
    -100
  ],
  [
    [
      12,
      4
    ],
    "UnderlineThickness",
    "number",
    50
  ],
  [
    [
      12,
      5
    ],
    "PaintType",
    "number",
    0
  ],
  [
    [
      12,
      6
    ],
    "CharstringType",
    "number",
    2
  ],
  [
    [
      12,
      7
    ],
    "FontMatrix",
    "array",
    [
      1e-3,
      0,
      0,
      1e-3,
      0,
      0
    ]
  ],
  [
    13,
    "UniqueID",
    "number",
    null
  ],
  [
    5,
    "FontBBox",
    "array",
    [
      0,
      0,
      0,
      0
    ]
  ],
  [
    [
      12,
      8
    ],
    "StrokeWidth",
    "number",
    0
  ],
  [
    14,
    "XUID",
    "array",
    null
  ],
  [
    15,
    "charset",
    Cl,
    Wa
  ],
  [
    16,
    "Encoding",
    wl,
    qa
  ],
  [
    17,
    "CharStrings",
    new Ve(new Xe()),
    null
  ],
  [
    18,
    "Private",
    new en(),
    null
  ],
  [
    [
      12,
      20
    ],
    "SyntheticBase",
    "number",
    null
  ],
  [
    [
      12,
      21
    ],
    "PostScript",
    "sid",
    null
  ],
  [
    [
      12,
      22
    ],
    "BaseFontName",
    "sid",
    null
  ],
  [
    [
      12,
      23
    ],
    "BaseFontBlend",
    "delta",
    null
  ],
  // CID font specific
  [
    [
      12,
      31
    ],
    "CIDFontVersion",
    "number",
    0
  ],
  [
    [
      12,
      32
    ],
    "CIDFontRevision",
    "number",
    0
  ],
  [
    [
      12,
      33
    ],
    "CIDFontType",
    "number",
    0
  ],
  [
    [
      12,
      34
    ],
    "CIDCount",
    "number",
    8720
  ],
  [
    [
      12,
      35
    ],
    "UIDBase",
    "number",
    null
  ],
  [
    [
      12,
      37
    ],
    "FDSelect",
    new Ve(_a),
    null
  ],
  [
    [
      12,
      36
    ],
    "FDArray",
    new Ve(new Xe(tn)),
    null
  ],
  [
    [
      12,
      38
    ],
    "FontName",
    "sid",
    null
  ]
]), kl = new x({
  length: l,
  itemVariationStore: Ht
}), El = new Wt([
  [
    [
      12,
      7
    ],
    "FontMatrix",
    "array",
    [
      1e-3,
      0,
      0,
      1e-3,
      0,
      0
    ]
  ],
  [
    17,
    "CharStrings",
    new Ve(new Xe()),
    null
  ],
  [
    [
      12,
      37
    ],
    "FDSelect",
    new Ve(_a),
    null
  ],
  [
    [
      12,
      36
    ],
    "FDArray",
    new Ve(new Xe(tn)),
    null
  ],
  [
    24,
    "vstore",
    new Ve(kl),
    null
  ],
  [
    25,
    "maxstack",
    "number",
    193
  ]
]), Pl = new te(Ln, {
  1: {
    hdrSize: D,
    offSize: D,
    nameIndex: new Xe(new de("length")),
    topDictIndex: new Xe(Il),
    stringIndex: new Xe(new de("length")),
    globalSubrIndex: new Xe()
  },
  2: {
    hdrSize: D,
    length: l,
    topDict: El,
    globalSubrIndex: new Xe()
  }
});
var rn = Pl;
class jr {
  static decode(e) {
    return new jr(e);
  }
  decode() {
    this.stream.pos;
    let e = rn.decode(this.stream);
    for (let t in e) {
      let r = e[t];
      this[t] = r;
    }
    if (this.version < 2) {
      if (this.topDictIndex.length !== 1) throw new Error("Only a single font is allowed in CFF");
      this.topDict = this.topDictIndex[0];
    }
    return this.isCIDFont = this.topDict.ROS != null, this;
  }
  string(e) {
    return this.version >= 2 ? null : e < St.length ? St[e] : this.stringIndex[e - St.length];
  }
  get postscriptName() {
    return this.version < 2 ? this.nameIndex[0] : null;
  }
  get fullName() {
    return this.string(this.topDict.FullName);
  }
  get familyName() {
    return this.string(this.topDict.FamilyName);
  }
  getCharString(e) {
    return this.stream.pos = this.topDict.CharStrings[e].offset, this.stream.readBuffer(this.topDict.CharStrings[e].length);
  }
  getGlyphName(e) {
    if (this.version >= 2 || this.isCIDFont) return null;
    let { charset: t } = this.topDict;
    if (Array.isArray(t)) return t[e];
    if (e === 0) return ".notdef";
    switch (e -= 1, t.version) {
      case 0:
        return this.string(t.glyphs[e]);
      case 1:
      case 2:
        for (let r = 0; r < t.ranges.length; r++) {
          let s = t.ranges[r];
          if (s.offset <= e && e <= s.offset + s.nLeft) return this.string(s.first + (e - s.offset));
        }
        break;
    }
    return null;
  }
  fdForGlyph(e) {
    if (!this.topDict.FDSelect) return null;
    switch (this.topDict.FDSelect.version) {
      case 0:
        return this.topDict.FDSelect.fds[e];
      case 3:
      case 4:
        let { ranges: t } = this.topDict.FDSelect, r = 0, s = t.length - 1;
        for (; r <= s; ) {
          let n = r + s >> 1;
          if (e < t[n].first) s = n - 1;
          else if (n < s && e >= t[n + 1].first) r = n + 1;
          else return t[n].fd;
        }
      default:
        throw new Error(`Unknown FDSelect version: ${this.topDict.FDSelect.version}`);
    }
  }
  privateDictForGlyph(e) {
    if (this.topDict.FDSelect) {
      let t = this.fdForGlyph(e);
      return this.topDict.FDArray[t] ? this.topDict.FDArray[t].Private : null;
    }
    return this.version < 2 ? this.topDict.Private : this.topDict.FDArray[0].Private;
  }
  constructor(e) {
    this.stream = e, this.decode();
  }
}
var sn = jr;
let Tl = new x({
  glyphIndex: l,
  vertOriginY: E
});
var Ol = new x({
  majorVersion: l,
  minorVersion: l,
  defaultVertOriginY: E,
  numVertOriginYMetrics: l,
  metrics: new b(Tl, "numVertOriginYMetrics")
});
let L0 = new x({
  height: D,
  width: D,
  horiBearingX: we,
  horiBearingY: we,
  horiAdvance: D,
  vertBearingX: we,
  vertBearingY: we,
  vertAdvance: D
}), vt = new x({
  height: D,
  width: D,
  bearingX: we,
  bearingY: we,
  advance: D
}), Ys = new x({
  glyph: l,
  xOffset: we,
  yOffset: we
});
class Zs {
}
class Ir {
}
new te("version", {
  1: {
    metrics: vt,
    data: Zs
  },
  2: {
    metrics: vt,
    data: Ir
  },
  // format 3 is deprecated
  // format 4 is not supported by Microsoft
  5: {
    data: Ir
  },
  6: {
    metrics: L0,
    data: Zs
  },
  7: {
    metrics: L0,
    data: Ir
  },
  8: {
    metrics: vt,
    pad: new be(D),
    numComponents: l,
    components: new b(Ys, "numComponents")
  },
  9: {
    metrics: L0,
    pad: new be(D),
    numComponents: l,
    components: new b(Ys, "numComponents")
  },
  17: {
    metrics: vt,
    dataLen: v,
    data: new Ye("dataLen")
  },
  18: {
    metrics: L0,
    dataLen: v,
    data: new Ye("dataLen")
  },
  19: {
    dataLen: v,
    data: new Ye("dataLen")
  }
});
let Ks = new x({
  ascender: we,
  descender: we,
  widthMax: D,
  caretSlopeNumerator: we,
  caretSlopeDenominator: we,
  caretOffset: we,
  minOriginSB: we,
  minAdvanceSB: we,
  maxBeforeBL: we,
  minAfterBL: we,
  pad: new be(we, 2)
}), Fl = new x({
  glyphCode: l,
  offset: l
}), Dl = new te(l, {
  header: {
    imageFormat: l,
    imageDataOffset: v
  },
  1: {
    offsetArray: new b(v, (i) => i.parent.lastGlyphIndex - i.parent.firstGlyphIndex + 1)
  },
  2: {
    imageSize: v,
    bigMetrics: L0
  },
  3: {
    offsetArray: new b(l, (i) => i.parent.lastGlyphIndex - i.parent.firstGlyphIndex + 1)
  },
  4: {
    numGlyphs: v,
    glyphArray: new b(Fl, (i) => i.numGlyphs + 1)
  },
  5: {
    imageSize: v,
    bigMetrics: L0,
    numGlyphs: v,
    glyphCodeArray: new b(l, "numGlyphs")
  }
}), Bl = new x({
  firstGlyphIndex: l,
  lastGlyphIndex: l,
  subtable: new g(v, Dl)
}), Ll = new x({
  indexSubTableArray: new g(v, new b(Bl, 1), {
    type: "parent"
  }),
  indexTablesSize: v,
  numberOfIndexSubTables: v,
  colorRef: v,
  hori: Ks,
  vert: Ks,
  startGlyphIndex: l,
  endGlyphIndex: l,
  ppemX: D,
  ppemY: D,
  bitDepth: D,
  flags: new ze(D, [
    "horizontal",
    "vertical"
  ])
});
var Ml = new x({
  version: v,
  numSizes: v,
  sizes: new b(Ll, "numSizes")
});
let Rl = new x({
  ppem: l,
  resolution: l,
  imageOffsets: new b(new g(v, "void"), (i) => i.parent.parent.maxp.numGlyphs + 1)
});
var Nl = new x({
  version: l,
  flags: new ze(l, [
    "renderOutlines"
  ]),
  numImgTables: v,
  imageTables: new b(new g(v, Rl), "numImgTables")
});
let Ul = new x({
  gid: l,
  paletteIndex: l
  // Index value to use in the appropriate palette. This value must
}), Gl = new x({
  gid: l,
  // and is not rendered for color.
  firstLayerIndex: l,
  // There will be numLayers consecutive entries for this base glyph.
  numLayers: l
});
var Vl = new x({
  version: l,
  numBaseGlyphRecords: l,
  baseGlyphRecord: new g(v, new b(Gl, "numBaseGlyphRecords")),
  layerRecords: new g(v, new b(Ul, "numLayerRecords"), {
    lazy: !0
  }),
  numLayerRecords: l
});
let zl = new x({
  blue: D,
  green: D,
  red: D,
  alpha: D
});
var ql = new te(l, {
  header: {
    numPaletteEntries: l,
    numPalettes: l,
    numColorRecords: l,
    colorRecords: new g(v, new b(zl, "numColorRecords")),
    colorRecordIndices: new b(l, "numPalettes")
  },
  0: {},
  1: {
    offsetPaletteTypeArray: new g(v, new b(v, "numPalettes")),
    offsetPaletteLabelArray: new g(v, new b(l, "numPalettes")),
    offsetPaletteEntryLabelArray: new g(v, new b(l, "numPaletteEntries"))
  }
});
let tt = new te(l, {
  1: {
    coordinate: E
    // X or Y value, in design units
  },
  2: {
    coordinate: E,
    referenceGlyph: l,
    baseCoordPoint: l
    // Index of contour point on the referenceGlyph
  },
  3: {
    coordinate: E,
    deviceTable: new g(l, d0)
    // Device table for X or Y value
  }
}), Wl = new x({
  defaultIndex: l,
  baseCoordCount: l,
  baseCoords: new b(new g(l, tt), "baseCoordCount")
}), Hl = new x({
  tag: new de(4),
  minCoord: new g(l, tt, {
    type: "parent"
  }),
  maxCoord: new g(l, tt, {
    type: "parent"
  })
  // May be NULL
}), an = new x({
  minCoord: new g(l, tt),
  maxCoord: new g(l, tt),
  featMinMaxCount: l,
  featMinMaxRecords: new b(Hl, "featMinMaxCount")
  // In alphabetical order
}), $l = new x({
  tag: new de(4),
  minMax: new g(l, an, {
    type: "parent"
  })
}), Xl = new x({
  baseValues: new g(l, Wl),
  defaultMinMax: new g(l, an),
  baseLangSysCount: l,
  baseLangSysRecords: new b($l, "baseLangSysCount")
  // in alphabetical order by BaseLangSysTag
}), jl = new x({
  tag: new de(4),
  script: new g(l, Xl, {
    type: "parent"
  })
}), Yl = new b(jl, l), Zl = new b(new de(4), l), Js = new x({
  baseTagList: new g(l, Zl),
  baseScriptList: new g(l, Yl)
});
var Kl = new te(v, {
  header: {
    horizAxis: new g(l, Js),
    vertAxis: new g(l, Js)
    // May be NULL
  },
  65536: {},
  65537: {
    itemVariationStore: new g(v, Ht)
  }
});
let Jl = new b(l, l), Ql = new x({
  coverage: new g(l, fe),
  glyphCount: l,
  attachPoints: new b(new g(l, Jl), "glyphCount")
}), _l = new te(l, {
  1: {
    coordinate: E
  },
  2: {
    caretValuePoint: l
  },
  3: {
    coordinate: E,
    deviceTable: new g(l, d0)
  }
}), eo = new b(new g(l, _l), l), to = new x({
  coverage: new g(l, fe),
  ligGlyphCount: l,
  ligGlyphs: new b(new g(l, eo), "ligGlyphCount")
}), Qs = new x({
  markSetTableFormat: l,
  markSetCount: l,
  coverage: new b(new g(v, fe), "markSetCount")
});
var ro = new te(v, {
  header: {
    glyphClassDef: new g(l, p0),
    attachList: new g(l, Ql),
    ligCaretList: new g(l, to),
    markAttachClassDef: new g(l, p0)
  },
  65536: {},
  65538: {
    markGlyphSetsDef: new g(l, Qs)
  },
  65539: {
    markGlyphSetsDef: new g(l, Qs),
    itemVariationStore: new g(v, Ht)
  }
});
let D0 = new ze(l, [
  "xPlacement",
  "yPlacement",
  "xAdvance",
  "yAdvance",
  "xPlaDevice",
  "yPlaDevice",
  "xAdvDevice",
  "yAdvDevice"
]), so = {
  xPlacement: E,
  yPlacement: E,
  xAdvance: E,
  yAdvance: E,
  xPlaDevice: new g(l, d0, {
    type: "global",
    relativeTo: (i) => i.rel
  }),
  yPlaDevice: new g(l, d0, {
    type: "global",
    relativeTo: (i) => i.rel
  }),
  xAdvDevice: new g(l, d0, {
    type: "global",
    relativeTo: (i) => i.rel
  }),
  yAdvDevice: new g(l, d0, {
    type: "global",
    relativeTo: (i) => i.rel
  })
};
class M0 {
  buildStruct(e) {
    let t = e;
    for (; !t[this.key] && t.parent; ) t = t.parent;
    if (!t[this.key]) return;
    let r = {};
    r.rel = () => t._startOffset;
    let s = t[this.key];
    for (let n in s) s[n] && (r[n] = so[n]);
    return new x(r);
  }
  size(e, t) {
    return this.buildStruct(t).size(e, t);
  }
  decode(e, t) {
    let r = this.buildStruct(t).decode(e, t);
    return delete r.rel, r;
  }
  constructor(e = "valueFormat") {
    this.key = e;
  }
}
let ao = new x({
  secondGlyph: l,
  value1: new M0("valueFormat1"),
  value2: new M0("valueFormat2")
}), no = new b(ao, l), io = new x({
  value1: new M0("valueFormat1"),
  value2: new M0("valueFormat2")
}), rt = new te(l, {
  1: {
    xCoordinate: E,
    yCoordinate: E
  },
  2: {
    xCoordinate: E,
    yCoordinate: E,
    anchorPoint: l
  },
  3: {
    xCoordinate: E,
    yCoordinate: E,
    xDeviceTable: new g(l, d0),
    yDeviceTable: new g(l, d0)
  }
}), lo = new x({
  entryAnchor: new g(l, rt, {
    type: "parent"
  }),
  exitAnchor: new g(l, rt, {
    type: "parent"
  })
}), oo = new x({
  class: l,
  markAnchor: new g(l, rt, {
    type: "parent"
  })
}), kr = new b(oo, l), uo = new b(new g(l, rt), (i) => i.parent.classCount), _s = new b(uo, l), co = new b(new g(l, rt), (i) => i.parent.parent.classCount), fo = new b(co, l), ho = new b(new g(l, fo), l), st = new te("lookupType", {
  1: new te(l, {
    1: {
      coverage: new g(l, fe),
      valueFormat: D0,
      value: new M0()
    },
    2: {
      coverage: new g(l, fe),
      valueFormat: D0,
      valueCount: l,
      values: new he(new M0(), "valueCount")
    }
  }),
  2: new te(l, {
    1: {
      coverage: new g(l, fe),
      valueFormat1: D0,
      valueFormat2: D0,
      pairSetCount: l,
      pairSets: new he(new g(l, no), "pairSetCount")
    },
    2: {
      coverage: new g(l, fe),
      valueFormat1: D0,
      valueFormat2: D0,
      classDef1: new g(l, p0),
      classDef2: new g(l, p0),
      class1Count: l,
      class2Count: l,
      classRecords: new he(new he(io, "class2Count"), "class1Count")
    }
  }),
  3: {
    format: l,
    coverage: new g(l, fe),
    entryExitCount: l,
    entryExitRecords: new b(lo, "entryExitCount")
  },
  4: {
    format: l,
    markCoverage: new g(l, fe),
    baseCoverage: new g(l, fe),
    classCount: l,
    markArray: new g(l, kr),
    baseArray: new g(l, _s)
  },
  5: {
    format: l,
    markCoverage: new g(l, fe),
    ligatureCoverage: new g(l, fe),
    classCount: l,
    markArray: new g(l, kr),
    ligatureArray: new g(l, ho)
  },
  6: {
    format: l,
    mark1Coverage: new g(l, fe),
    mark2Coverage: new g(l, fe),
    classCount: l,
    mark1Array: new g(l, kr),
    mark2Array: new g(l, _s)
  },
  7: Ya,
  8: Za,
  9: {
    posFormat: l,
    lookupType: l,
    extension: new g(v, null)
  }
});
st.versions[9].extension.type = st;
var po = new te(v, {
  header: {
    scriptList: new g(l, $a),
    featureList: new g(l, ja),
    lookupList: new g(l, new Ot(st))
  },
  65536: {},
  65537: {
    featureVariations: new g(v, Ka)
  }
});
let nn = new b(l, l), bo = nn, go = new x({
  glyph: l,
  compCount: l,
  components: new b(l, (i) => i.compCount - 1)
}), vo = new b(new g(l, go), l), Lr = new te("lookupType", {
  1: new te(l, {
    1: {
      coverage: new g(l, fe),
      deltaGlyphID: E
    },
    2: {
      coverage: new g(l, fe),
      glyphCount: l,
      substitute: new he(l, "glyphCount")
    }
  }),
  2: {
    substFormat: l,
    coverage: new g(l, fe),
    count: l,
    sequences: new he(new g(l, nn), "count")
  },
  3: {
    substFormat: l,
    coverage: new g(l, fe),
    count: l,
    alternateSet: new he(new g(l, bo), "count")
  },
  4: {
    substFormat: l,
    coverage: new g(l, fe),
    count: l,
    ligatureSets: new he(new g(l, vo), "count")
  },
  5: Ya,
  6: Za,
  7: {
    substFormat: l,
    lookupType: l,
    extension: new g(v, null)
  },
  8: {
    substFormat: l,
    coverage: new g(l, fe),
    backtrackCoverage: new b(new g(l, fe), "backtrackGlyphCount"),
    lookaheadGlyphCount: l,
    lookaheadCoverage: new b(new g(l, fe), "lookaheadGlyphCount"),
    glyphCount: l,
    substitutes: new b(l, "glyphCount")
  }
});
Lr.versions[7].extension.type = Lr;
var xo = new te(v, {
  header: {
    scriptList: new g(l, $a),
    featureList: new g(l, ja),
    lookupList: new g(l, new Ot(Lr))
  },
  65536: {},
  65537: {
    featureVariations: new g(v, Ka)
  }
});
let u0 = new b(l, l), mo = new x({
  shrinkageEnableGSUB: new g(l, u0),
  shrinkageDisableGSUB: new g(l, u0),
  shrinkageEnableGPOS: new g(l, u0),
  shrinkageDisableGPOS: new g(l, u0),
  shrinkageJstfMax: new g(l, new Ot(st)),
  extensionEnableGSUB: new g(l, u0),
  extensionDisableGSUB: new g(l, u0),
  extensionEnableGPOS: new g(l, u0),
  extensionDisableGPOS: new g(l, u0),
  extensionJstfMax: new g(l, new Ot(st))
}), ln = new b(new g(l, mo), l), wo = new x({
  tag: new de(4),
  jstfLangSys: new g(l, ln)
}), yo = new x({
  extenderGlyphs: new g(l, new b(l, l)),
  defaultLangSys: new g(l, ln),
  langSysCount: l,
  langSysRecords: new b(wo, "langSysCount")
}), Co = new x({
  tag: new de(4),
  script: new g(l, yo, {
    type: "parent"
  })
});
var So = new x({
  version: v,
  scriptCount: l,
  scriptList: new b(Co, "scriptCount")
});
class Ao {
  decode(e, t) {
    switch (this.size(0, t)) {
      case 1:
        return e.readUInt8();
      case 2:
        return e.readUInt16BE();
      case 3:
        return e.readUInt24BE();
      case 4:
        return e.readUInt32BE();
    }
  }
  size(e, t) {
    return Ze(this._size, null, t);
  }
  constructor(e) {
    this._size = e;
  }
}
let Io = new x({
  entry: new Ao((i) => ((i.parent.entryFormat & 48) >> 4) + 1),
  outerIndex: (i) => i.entry >> (i.parent.entryFormat & 15) + 1,
  innerIndex: (i) => i.entry & (1 << (i.parent.entryFormat & 15) + 1) - 1
}), Er = new x({
  entryFormat: l,
  mapCount: l,
  mapData: new b(Io, "mapCount")
});
var ko = new x({
  majorVersion: l,
  minorVersion: l,
  itemVariationStore: new g(v, Ht),
  advanceWidthMapping: new g(v, Er),
  LSBMapping: new g(v, Er),
  RSBMapping: new g(v, Er)
});
let Eo = new x({
  format: v,
  length: v,
  offset: v
}), Po = new x({
  reserved: new be(l, 2),
  cbSignature: v,
  signature: new Ye("cbSignature")
});
var To = new x({
  ulVersion: v,
  usNumSigs: l,
  usFlag: l,
  signatures: new b(Eo, "usNumSigs"),
  signatureBlocks: new b(Po, "usNumSigs")
});
let Oo = new x({
  rangeMaxPPEM: l,
  rangeGaspBehavior: new ze(l, [
    "grayscale",
    "gridfit",
    "symmetricSmoothing",
    "symmetricGridfit"
    // only in version 1, for ClearType
  ])
});
var Fo = new x({
  version: l,
  numRanges: l,
  gaspRanges: new b(Oo, "numRanges")
  // Sorted by ppem
});
let Do = new x({
  pixelSize: D,
  maximumWidth: D,
  widths: new b(D, (i) => i.parent.parent.maxp.numGlyphs)
});
var Bo = new x({
  version: l,
  numRecords: E,
  sizeDeviceRecord: C0,
  records: new b(Do, "numRecords")
});
let Lo = new x({
  left: l,
  right: l,
  value: E
}), ea = new x({
  firstGlyph: l,
  nGlyphs: l,
  offsets: new b(l, "nGlyphs"),
  max: (i) => i.offsets.length && Math.max.apply(Math, i.offsets)
}), Mo = new x({
  off: (i) => i._startOffset - i.parent.parent._startOffset,
  len: (i) => ((i.parent.leftTable.max - i.off) / i.parent.rowWidth + 1) * (i.parent.rowWidth / 2),
  values: new he(E, "len")
}), ta = new te("format", {
  0: {
    nPairs: l,
    searchRange: l,
    entrySelector: l,
    rangeShift: l,
    pairs: new b(Lo, "nPairs")
  },
  2: {
    rowWidth: l,
    leftTable: new g(l, ea, {
      type: "parent"
    }),
    rightTable: new g(l, ea, {
      type: "parent"
    }),
    array: new g(l, Mo, {
      type: "parent"
    })
  },
  3: {
    glyphCount: l,
    kernValueCount: D,
    leftClassCount: D,
    rightClassCount: D,
    flags: D,
    kernValue: new b(E, "kernValueCount"),
    leftClass: new b(D, "glyphCount"),
    rightClass: new b(D, "glyphCount"),
    kernIndex: new b(D, (i) => i.leftClassCount * i.rightClassCount)
  }
}), ra = new te("version", {
  0: {
    subVersion: l,
    length: l,
    format: D,
    coverage: new ze(D, [
      "horizontal",
      "minimum",
      "crossStream",
      "override"
      // If set to 1 the value in this table replaces the accumulated value
    ]),
    subtable: ta,
    padding: new be(D, (i) => i.length - i._currentOffset)
  },
  1: {
    length: v,
    coverage: new ze(D, [
      null,
      null,
      null,
      null,
      null,
      "variation",
      "crossStream",
      "vertical"
      // Set if table has vertical kerning values
    ]),
    format: D,
    tupleIndex: l,
    subtable: ta,
    padding: new be(D, (i) => i.length - i._currentOffset)
  }
});
var Ro = new te(l, {
  0: {
    nTables: l,
    tables: new b(ra, "nTables")
  },
  1: {
    reserved: new be(l),
    nTables: v,
    tables: new b(ra, "nTables")
  }
}), No = new x({
  version: l,
  numGlyphs: l,
  yPels: new b(D, "numGlyphs")
}), Uo = new x({
  version: l,
  fontNumber: v,
  pitch: l,
  xHeight: l,
  style: l,
  typeFamily: l,
  capHeight: l,
  symbolSet: l,
  typeface: new de(16),
  characterComplement: new de(8),
  fileName: new de(6),
  strokeWeight: new de(1),
  widthType: new de(1),
  serifStyle: D,
  reserved: new be(D)
});
let Go = new x({
  bCharSet: D,
  xRatio: D,
  yStartRatio: D,
  yEndRatio: D
  // Ending y-Ratio value
}), Vo = new x({
  yPelHeight: l,
  yMax: E,
  yMin: E
  // Minimum value (in pels) for this yPelHeight
}), zo = new x({
  recs: l,
  startsz: D,
  endsz: D,
  entries: new b(Vo, "recs")
  // The VDMX records
});
var qo = new x({
  version: l,
  numRecs: l,
  numRatios: l,
  ratioRanges: new b(Go, "numRatios"),
  offsets: new b(l, "numRatios"),
  groups: new b(zo, "numRecs")
  // The actual VDMX groupings
}), Wo = new x({
  version: l,
  ascent: E,
  descent: E,
  lineGap: E,
  advanceHeightMax: E,
  minTopSideBearing: E,
  minBottomSideBearing: E,
  yMaxExtent: E,
  caretSlopeRise: E,
  caretSlopeRun: E,
  caretOffset: E,
  reserved: new be(E, 4),
  metricDataFormat: E,
  numberOfMetrics: l
  // Number of advance heights in the Vertical Metrics table
});
let Ho = new x({
  advance: l,
  bearing: E
  // The top sidebearing of the glyph
});
var $o = new x({
  metrics: new he(Ho, (i) => i.parent.vhea.numberOfMetrics),
  bearings: new he(E, (i) => i.parent.maxp.numGlyphs - i.parent.vhea.numberOfMetrics)
});
let sa = new E0(16, "BE", 14), Xo = new x({
  fromCoord: sa,
  toCoord: sa
}), jo = new x({
  pairCount: l,
  correspondence: new b(Xo, "pairCount")
});
var Yo = new x({
  version: ve,
  axisCount: v,
  segment: new b(jo, "axisCount")
});
class Zo {
  getItem(e) {
    if (this._items[e] == null) {
      let t = this.stream.pos;
      this.stream.pos = this.base + this.type.size(null, this.parent) * e, this._items[e] = this.type.decode(this.stream, this.parent), this.stream.pos = t;
    }
    return this._items[e];
  }
  inspect() {
    return `[UnboundedArray ${this.type.constructor.name}]`;
  }
  constructor(e, t, r) {
    this.type = e, this.stream = t, this.parent = r, this.base = this.stream.pos, this._items = [];
  }
}
class je extends b {
  decode(e, t) {
    return new Zo(this.type, e, t);
  }
  constructor(e) {
    super(e, 0);
  }
}
let b0 = function(i = l) {
  class e {
    decode(o, u) {
      return u = u.parent.parent, this.type.decode(o, u);
    }
    size(o, u) {
      return u = u.parent.parent, this.type.size(o, u);
    }
    encode(o, u, c) {
      return c = c.parent.parent, this.type.encode(o, u, c);
    }
    constructor(o) {
      this.type = o;
    }
  }
  i = new e(i);
  let t = new x({
    unitSize: l,
    nUnits: l,
    searchRange: l,
    entrySelector: l,
    rangeShift: l
  }), r = new x({
    lastGlyph: l,
    firstGlyph: l,
    value: i
  }), s = new x({
    lastGlyph: l,
    firstGlyph: l,
    values: new g(l, new b(i, (a) => a.lastGlyph - a.firstGlyph + 1), {
      type: "parent"
    })
  }), n = new x({
    glyph: l,
    value: i
  });
  return new te(l, {
    0: {
      values: new je(i)
      // length == number of glyphs maybe?
    },
    2: {
      binarySearchHeader: t,
      segments: new b(r, (a) => a.binarySearchHeader.nUnits)
    },
    4: {
      binarySearchHeader: t,
      segments: new b(s, (a) => a.binarySearchHeader.nUnits)
    },
    6: {
      binarySearchHeader: t,
      segments: new b(n, (a) => a.binarySearchHeader.nUnits)
    },
    8: {
      firstGlyph: l,
      count: l,
      values: new b(i, "count")
    }
  });
};
function xt(i = {}, e = l) {
  let t = Object.assign({
    newState: l,
    flags: l
  }, i), r = new x(t), s = new je(new b(l, (a) => a.nClasses));
  return new x({
    nClasses: v,
    classTable: new g(v, new b0(e)),
    stateArray: new g(v, s),
    entryTable: new g(v, new je(r))
  });
}
function Ko(i = {}, e = l) {
  let t = new x({
    version() {
      return 8;
    },
    firstGlyph: l,
    values: new b(D, l)
  }), r = Object.assign({
    newStateOffset: l,
    // convert offset to stateArray index
    newState: (o) => (o.newStateOffset - (o.parent.stateArray.base - o.parent._startOffset)) / o.parent.nClasses,
    flags: l
  }, i), s = new x(r), n = new je(new b(D, (o) => o.nClasses));
  return new x({
    nClasses: l,
    classTable: new g(l, t),
    stateArray: new g(l, n),
    entryTable: new g(l, new je(s))
  });
}
let Jo = new te("format", {
  0: {
    deltas: new b(E, 32)
  },
  1: {
    deltas: new b(E, 32),
    mappingData: new b0(l)
  },
  2: {
    standardGlyph: l,
    controlPoints: new b(l, 32)
  },
  3: {
    standardGlyph: l,
    controlPoints: new b(l, 32),
    mappingData: new b0(l)
  }
});
var Qo = new x({
  version: ve,
  format: l,
  defaultBaseline: l,
  subtable: Jo
});
let _o = new x({
  setting: l,
  nameIndex: E,
  name: (i) => i.parent.parent.parent.name.records.fontFeatures[i.nameIndex]
}), eu = new x({
  feature: l,
  nSettings: l,
  settingTable: new g(v, new b(_o, "nSettings"), {
    type: "parent"
  }),
  featureFlags: new ze(D, [
    null,
    null,
    null,
    null,
    null,
    null,
    "hasDefault",
    "exclusive"
  ]),
  defaultSetting: D,
  nameIndex: E,
  name: (i) => i.parent.parent.name.records.fontFeatures[i.nameIndex]
});
var tu = new x({
  version: ve,
  featureNameCount: l,
  reserved1: new be(l),
  reserved2: new be(v),
  featureNames: new b(eu, "featureNameCount")
});
let ru = new x({
  axisTag: new de(4),
  minValue: ve,
  defaultValue: ve,
  maxValue: ve,
  flags: l,
  nameID: l,
  name: (i) => i.parent.parent.name.records.fontFeatures[i.nameID]
}), su = new x({
  nameID: l,
  name: (i) => i.parent.parent.name.records.fontFeatures[i.nameID],
  flags: l,
  coord: new b(ve, (i) => i.parent.axisCount),
  postscriptNameID: new Et(l, (i) => i.parent.instanceSize - i._currentOffset > 0)
});
var au = new x({
  version: ve,
  offsetToData: l,
  countSizePairs: l,
  axisCount: l,
  axisSize: l,
  instanceCount: l,
  instanceSize: l,
  axis: new b(ru, "axisCount"),
  instance: new b(su, "instanceCount")
});
let nu = new E0(16, "BE", 14);
class iu {
  static decode(e, t) {
    return t.flags ? e.readUInt32BE() : e.readUInt16BE() * 2;
  }
}
let lu = new x({
  version: l,
  reserved: new be(l),
  axisCount: l,
  globalCoordCount: l,
  globalCoords: new g(v, new b(new b(nu, "axisCount"), "globalCoordCount")),
  glyphCount: l,
  flags: l,
  offsetToData: v,
  offsets: new b(new g(iu, "void", {
    relativeTo: (i) => i.offsetToData,
    allowNull: !1
  }), (i) => i.glyphCount + 1)
});
var ou = lu;
let uu = new x({
  length: l,
  coverage: l,
  subFeatureFlags: v,
  stateTable: new Ko()
}), cu = new x({
  justClass: v,
  beforeGrowLimit: ve,
  beforeShrinkLimit: ve,
  afterGrowLimit: ve,
  afterShrinkLimit: ve,
  growFlags: l,
  shrinkFlags: l
}), fu = new b(cu, v), du = new te("actionType", {
  0: {
    lowerLimit: ve,
    upperLimit: ve,
    order: l,
    glyphs: new b(l, l)
  },
  1: {
    addGlyph: l
  },
  2: {
    substThreshold: ve,
    addGlyph: l,
    substGlyph: l
  },
  3: {},
  4: {
    variationAxis: v,
    minimumLimit: ve,
    noStretchValue: ve,
    maximumLimit: ve
  },
  5: {
    flags: l,
    glyph: l
  }
}), hu = new x({
  actionClass: l,
  actionType: l,
  actionLength: v,
  actionData: du,
  padding: new be(D, (i) => i.actionLength - i._currentOffset)
}), pu = new b(hu, v), bu = new x({
  lookupTable: new b0(new g(l, pu))
}), aa = new x({
  classTable: new g(l, uu, {
    type: "parent"
  }),
  wdcOffset: l,
  postCompensationTable: new g(l, bu, {
    type: "parent"
  }),
  widthDeltaClusters: new b0(new g(l, fu, {
    type: "parent",
    relativeTo: (i) => i.wdcOffset
  }))
});
var gu = new x({
  version: v,
  format: l,
  horizontal: new g(l, aa),
  vertical: new g(l, aa)
});
let vu = {
  action: l
}, xu = {
  markIndex: l,
  currentIndex: l
}, mu = {
  currentInsertIndex: l,
  markedInsertIndex: l
}, wu = new x({
  items: new je(new g(v, new b0()))
}), yu = new te("type", {
  0: {
    stateTable: new xt()
  },
  1: {
    stateTable: new xt(xu),
    substitutionTable: new g(v, wu)
  },
  2: {
    stateTable: new xt(vu),
    ligatureActions: new g(v, new je(v)),
    components: new g(v, new je(l)),
    ligatureList: new g(v, new je(l))
  },
  4: {
    lookupTable: new b0()
  },
  5: {
    stateTable: new xt(mu),
    insertionActions: new g(v, new je(l))
  }
}), Cu = new x({
  length: v,
  coverage: h0,
  type: D,
  subFeatureFlags: v,
  table: yu,
  padding: new be(D, (i) => i.length - i._currentOffset)
}), Su = new x({
  featureType: l,
  featureSetting: l,
  enableFlags: v,
  disableFlags: v
}), Au = new x({
  defaultFlags: v,
  chainLength: v,
  nFeatureEntries: v,
  nSubtables: v,
  features: new b(Su, "nFeatureEntries"),
  subtables: new b(Cu, "nSubtables")
});
var Iu = new x({
  version: l,
  unused: new be(l),
  nChains: v,
  chains: new b(Au, "nChains")
});
let ku = new x({
  left: E,
  top: E,
  right: E,
  bottom: E
});
var Eu = new x({
  version: ve,
  format: l,
  lookupTable: new b0(ku)
});
let Z = {};
var Ft = Z;
Z.cmap = Ii;
Z.head = ki;
Z.hhea = Ei;
Z.hmtx = Ti;
Z.maxp = Oi;
Z.name = Ni;
Z["OS/2"] = Ui;
Z.post = Gi;
Z.fpgm = zi;
Z.loca = qi;
Z.prep = Wi;
Z["cvt "] = Vi;
Z.glyf = Hi;
Z["CFF "] = sn;
Z.CFF2 = sn;
Z.VORG = Ol;
Z.EBLC = Ml;
Z.CBLC = Z.EBLC;
Z.sbix = Nl;
Z.COLR = Vl;
Z.CPAL = ql;
Z.BASE = Kl;
Z.GDEF = ro;
Z.GPOS = po;
Z.GSUB = xo;
Z.JSTF = So;
Z.HVAR = ko;
Z.DSIG = To;
Z.gasp = Fo;
Z.hdmx = Bo;
Z.kern = Ro;
Z.LTSH = No;
Z.PCLT = Uo;
Z.VDMX = qo;
Z.vhea = Wo;
Z.vmtx = $o;
Z.avar = Yo;
Z.bsln = Qo;
Z.feat = tu;
Z.fvar = au;
Z.gvar = ou;
Z.just = gu;
Z.morx = Iu;
Z.opbd = Eu;
let Pu = new x({
  tag: new de(4),
  checkSum: v,
  offset: new g(v, "void", {
    type: "global"
  }),
  length: v
}), Yr = new x({
  tag: new de(4),
  numTables: l,
  searchRange: l,
  entrySelector: l,
  rangeShift: l,
  tables: new b(Pu, "numTables")
});
Yr.process = function() {
  let i = {};
  for (let e of this.tables) i[e.tag] = e;
  this.tables = i;
};
Yr.preEncode = function() {
  if (!Array.isArray(this.tables)) {
    let t = [];
    for (let r in this.tables) {
      let s = this.tables[r];
      s && t.push({
        tag: r,
        checkSum: 0,
        offset: new Or(Ft[r], s),
        length: Ft[r].size(s)
      });
    }
    this.tables = t;
  }
  this.tag = "true", this.numTables = this.tables.length;
  let i = Math.floor(Math.log(this.numTables) / Math.LN2), e = Math.pow(2, i);
  this.searchRange = e * 16, this.entrySelector = Math.log(e) / Math.LN2, this.rangeShift = this.numTables * 16 - this.searchRange;
};
var on = Yr;
function At(i, e) {
  let t = 0, r = i.length - 1;
  for (; t <= r; ) {
    let s = t + r >> 1, n = e(i[s]);
    if (n < 0) r = s - 1;
    else if (n > 0) t = s + 1;
    else return s;
  }
  return -1;
}
function B0(i, e) {
  let t = [];
  for (; i < e; ) t.push(i++);
  return t;
}
const $t = new TextDecoder("ascii"), na = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", K0 = new Uint8Array(256);
for (let i = 0; i < na.length; i++) K0[na.charCodeAt(i)] = i;
function Zr(i) {
  let e = i.length * 0.75;
  i[i.length - 1] === "=" && (e--, i[i.length - 2] === "=" && e--);
  let t = new Uint8Array(e), r = 0;
  for (let s = 0, n = i.length; s < n; s += 4) {
    let a = K0[i.charCodeAt(s)], o = K0[i.charCodeAt(s + 1)], u = K0[i.charCodeAt(s + 2)], c = K0[i.charCodeAt(s + 3)];
    t[r++] = a << 2 | o >> 4, t[r++] = (o & 15) << 4 | u >> 2, t[r++] = (u & 3) << 6 | c & 63;
  }
  return t;
}
class Kr {
  findSubtable(e, t) {
    for (let [r, s] of t) for (let n of e.tables)
      if (n.platformID === r && n.encodingID === s) return n.table;
    return null;
  }
  lookup(e, t) {
    if (this.encoding) e = this.encoding.get(e) || e;
    else if (t) {
      let s = this.getVariationSelector(e, t);
      if (s) return s;
    }
    let r = this.cmap;
    switch (r.version) {
      case 0:
        return r.codeMap.get(e) || 0;
      case 4: {
        let s = 0, n = r.segCount - 1;
        for (; s <= n; ) {
          let a = s + n >> 1;
          if (e < r.startCode.get(a)) n = a - 1;
          else if (e > r.endCode.get(a)) s = a + 1;
          else {
            let o = r.idRangeOffset.get(a), u;
            if (o === 0) u = e + r.idDelta.get(a);
            else {
              let c = o / 2 + (e - r.startCode.get(a)) - (r.segCount - a);
              u = r.glyphIndexArray.get(c) || 0, u !== 0 && (u += r.idDelta.get(a));
            }
            return u & 65535;
          }
        }
        return 0;
      }
      case 8:
        throw new Error("TODO: cmap format 8");
      case 6:
      case 10:
        return r.glyphIndices.get(e - r.firstCode) || 0;
      case 12:
      case 13: {
        let s = 0, n = r.nGroups - 1;
        for (; s <= n; ) {
          let a = s + n >> 1, o = r.groups.get(a);
          if (e < o.startCharCode) n = a - 1;
          else if (e > o.endCharCode) s = a + 1;
          else
            return r.version === 12 ? o.glyphID + (e - o.startCharCode) : o.glyphID;
        }
        return 0;
      }
      case 14:
        throw new Error("TODO: cmap format 14");
      default:
        throw new Error(`Unknown cmap format ${r.version}`);
    }
  }
  getVariationSelector(e, t) {
    if (!this.uvs) return 0;
    let r = this.uvs.varSelectors.toArray(), s = At(r, (a) => t - a.varSelector), n = r[s];
    return s !== -1 && n.defaultUVS && (s = At(n.defaultUVS, (a) => e < a.startUnicodeValue ? -1 : e > a.startUnicodeValue + a.additionalCount ? 1 : 0)), s !== -1 && n.nonDefaultUVS && (s = At(n.nonDefaultUVS, (a) => e - a.unicodeValue), s !== -1) ? n.nonDefaultUVS[s].glyphID : 0;
  }
  getCharacterSet() {
    let e = this.cmap;
    switch (e.version) {
      case 0:
        return B0(0, e.codeMap.length);
      case 4: {
        let t = [], r = e.endCode.toArray();
        for (let s = 0; s < r.length; s++) {
          let n = r[s] + 1, a = e.startCode.get(s);
          t.push(...B0(a, n));
        }
        return t;
      }
      case 8:
        throw new Error("TODO: cmap format 8");
      case 6:
      case 10:
        return B0(e.firstCode, e.firstCode + e.glyphIndices.length);
      case 12:
      case 13: {
        let t = [];
        for (let r of e.groups.toArray()) t.push(...B0(r.startCharCode, r.endCharCode + 1));
        return t;
      }
      case 14:
        throw new Error("TODO: cmap format 14");
      default:
        throw new Error(`Unknown cmap format ${e.version}`);
    }
  }
  codePointsForGlyph(e) {
    let t = this.cmap;
    switch (t.version) {
      case 0: {
        let s = [];
        for (let n = 0; n < 256; n++) t.codeMap.get(n) === e && s.push(n);
        return s;
      }
      case 4: {
        let s = [];
        for (let n = 0; n < t.segCount; n++) {
          let a = t.endCode.get(n), o = t.startCode.get(n), u = t.idRangeOffset.get(n), c = t.idDelta.get(n);
          for (var r = o; r <= a; r++) {
            let d = 0;
            if (u === 0) d = r + c;
            else {
              let f = u / 2 + (r - o) - (t.segCount - n);
              d = t.glyphIndexArray.get(f) || 0, d !== 0 && (d += c);
            }
            d === e && s.push(r);
          }
        }
        return s;
      }
      case 12: {
        let s = [];
        for (let n of t.groups.toArray()) e >= n.glyphID && e <= n.glyphID + (n.endCharCode - n.startCharCode) && s.push(n.startCharCode + (e - n.glyphID));
        return s;
      }
      case 13: {
        let s = [];
        for (let n of t.groups.toArray()) e === n.glyphID && s.push(...B0(n.startCharCode, n.endCharCode + 1));
        return s;
      }
      default:
        throw new Error(`Unknown cmap format ${t.version}`);
    }
  }
  constructor(e) {
    if (this.encoding = null, this.cmap = this.findSubtable(e, [
      // 32-bit subtables
      [
        3,
        10
      ],
      [
        0,
        6
      ],
      [
        0,
        4
      ],
      // 16-bit subtables
      [
        3,
        1
      ],
      [
        0,
        3
      ],
      [
        0,
        2
      ],
      [
        0,
        1
      ],
      [
        0,
        0
      ]
    ]), !this.cmap) for (let t of e.tables) {
      let r = Va(t.platformID, t.encodingID, t.table.language - 1), s = Bi(r);
      s && (this.cmap = t.table, this.encoding = s);
    }
    if (!this.cmap) throw new Error("Could not find a supported cmap table");
    this.uvs = this.findSubtable(e, [
      [
        0,
        5
      ]
    ]), this.uvs && this.uvs.version !== 14 && (this.uvs = null);
  }
}
Ie([
  ke
], Kr.prototype, "getCharacterSet", null);
Ie([
  ke
], Kr.prototype, "codePointsForGlyph", null);
class Tu {
  process(e, t) {
    for (let r = 0; r < e.length - 1; r++) {
      let s = e[r].id, n = e[r + 1].id;
      t[r].xAdvance += this.getKerning(s, n);
    }
  }
  getKerning(e, t) {
    let r = 0;
    for (let s of this.kern.tables) {
      if (s.coverage.crossStream) continue;
      switch (s.version) {
        case 0:
          if (!s.coverage.horizontal) continue;
          break;
        case 1:
          if (s.coverage.vertical || s.coverage.variation) continue;
          break;
        default:
          throw new Error(`Unsupported kerning table version ${s.version}`);
      }
      let n = 0, a = s.subtable;
      switch (s.format) {
        case 0:
          let o = At(a.pairs, function(f) {
            return e - f.left || t - f.right;
          });
          o >= 0 && (n = a.pairs[o].value);
          break;
        case 2:
          let u = 0, c = 0;
          e >= a.leftTable.firstGlyph && e < a.leftTable.firstGlyph + a.leftTable.nGlyphs ? u = a.leftTable.offsets[e - a.leftTable.firstGlyph] : u = a.array.off, t >= a.rightTable.firstGlyph && t < a.rightTable.firstGlyph + a.rightTable.nGlyphs && (c = a.rightTable.offsets[t - a.rightTable.firstGlyph]);
          let d = (u + c - a.array.off) / 2;
          n = a.array.values.get(d);
          break;
        case 3:
          if (e >= a.glyphCount || t >= a.glyphCount) return 0;
          n = a.kernValue[a.kernIndex[a.leftClass[e] * a.rightClassCount + a.rightClass[t]]];
          break;
        default:
          throw new Error(`Unsupported kerning sub-table format ${s.format}`);
      }
      s.coverage.override ? r = n : r += n;
    }
    return r;
  }
  constructor(e) {
    this.kern = e.kern;
  }
}
class Ou {
  positionGlyphs(e, t) {
    let r = 0, s = 0;
    for (let n = 0; n < e.length; n++)
      e[n].isMark ? s = n : (r !== s && this.positionCluster(e, t, r, s), r = s = n);
    return r !== s && this.positionCluster(e, t, r, s), t;
  }
  positionCluster(e, t, r, s) {
    let n = e[r], a = n.cbox.copy();
    n.codePoints.length > 1 && (a.minX += (n.codePoints.length - 1) * a.width / n.codePoints.length);
    let o = -t[r].xAdvance, u = 0, c = this.font.unitsPerEm / 16;
    for (let d = r + 1; d <= s; d++) {
      let f = e[d], p = f.cbox, m = t[d], C = this.getCombiningClass(f.codePoints[0]);
      if (C !== "Not_Reordered") {
        switch (m.xOffset = m.yOffset = 0, C) {
          case "Double_Above":
          case "Double_Below":
            m.xOffset += a.minX - p.width / 2 - p.minX;
            break;
          case "Attached_Below_Left":
          case "Below_Left":
          case "Above_Left":
            m.xOffset += a.minX - p.minX;
            break;
          case "Attached_Above_Right":
          case "Below_Right":
          case "Above_Right":
            m.xOffset += a.maxX - p.width - p.minX;
            break;
          default:
            m.xOffset += a.minX + (a.width - p.width) / 2 - p.minX;
        }
        switch (C) {
          case "Double_Below":
          case "Below_Left":
          case "Below":
          case "Below_Right":
          case "Attached_Below_Left":
          case "Attached_Below":
            (C === "Attached_Below_Left" || C === "Attached_Below") && (a.minY += c), m.yOffset = -a.minY - p.maxY, a.minY += p.height;
            break;
          case "Double_Above":
          case "Above_Left":
          case "Above":
          case "Above_Right":
          case "Attached_Above":
          case "Attached_Above_Right":
            (C === "Attached_Above" || C === "Attached_Above_Right") && (a.maxY += c), m.yOffset = a.maxY - p.minY, a.maxY += p.height;
            break;
        }
        m.xAdvance = m.yAdvance = 0, m.xOffset += o, m.yOffset += u;
      } else
        o -= m.xAdvance, u -= m.yAdvance;
    }
  }
  getCombiningClass(e) {
    let t = Qn(e);
    if ((e & -256) === 3584) {
      if (t === "Not_Reordered") switch (e) {
        case 3633:
        case 3636:
        case 3637:
        case 3638:
        case 3639:
        case 3655:
        case 3660:
        case 3645:
        case 3662:
          return "Above_Right";
        case 3761:
        case 3764:
        case 3765:
        case 3766:
        case 3767:
        case 3771:
        case 3788:
        case 3789:
          return "Above";
        case 3772:
          return "Below";
      }
      else if (e === 3642) return "Below_Right";
    }
    switch (t) {
      // Hebrew
      case "CCC10":
      case "CCC11":
      case "CCC12":
      case "CCC13":
      case "CCC14":
      case "CCC15":
      case "CCC16":
      case "CCC17":
      case "CCC18":
      case "CCC20":
      case "CCC22":
        return "Below";
      case "CCC23":
        return "Attached_Above";
      case "CCC24":
        return "Above_Right";
      case "CCC25":
      case "CCC19":
        return "Above_Left";
      case "CCC26":
        return "Above";
      case "CCC21":
        break;
      // Arabic and Syriac
      case "CCC27":
      case "CCC28":
      case "CCC30":
      case "CCC31":
      case "CCC33":
      case "CCC34":
      case "CCC35":
      case "CCC36":
        return "Above";
      case "CCC29":
      case "CCC32":
        return "Below";
      // Thai
      case "CCC103":
        return "Below_Right";
      case "CCC107":
        return "Above_Right";
      // Lao
      case "CCC118":
        return "Below";
      case "CCC122":
        return "Above";
      // Tibetan
      case "CCC129":
      case "CCC132":
        return "Below";
      case "CCC130":
        return "Above";
    }
    return t;
  }
  constructor(e) {
    this.font = e;
  }
}
class g0 {
  /**
  * The width of the bounding box
  * @type {number}
  */
  get width() {
    return this.maxX - this.minX;
  }
  /**
  * The height of the bounding box
  * @type {number}
  */
  get height() {
    return this.maxY - this.minY;
  }
  addPoint(e, t) {
    Math.abs(e) !== 1 / 0 && (e < this.minX && (this.minX = e), e > this.maxX && (this.maxX = e)), Math.abs(t) !== 1 / 0 && (t < this.minY && (this.minY = t), t > this.maxY && (this.maxY = t));
  }
  copy() {
    return new g0(this.minX, this.minY, this.maxX, this.maxY);
  }
  constructor(e = 1 / 0, t = 1 / 0, r = -1 / 0, s = -1 / 0) {
    this.minX = e, this.minY = t, this.maxX = r, this.maxY = s;
  }
}
const R0 = {
  Caucasian_Albanian: "aghb",
  Arabic: "arab",
  Imperial_Aramaic: "armi",
  Armenian: "armn",
  Avestan: "avst",
  Balinese: "bali",
  Bamum: "bamu",
  Bassa_Vah: "bass",
  Batak: "batk",
  Bengali: [
    "bng2",
    "beng"
  ],
  Bopomofo: "bopo",
  Brahmi: "brah",
  Braille: "brai",
  Buginese: "bugi",
  Buhid: "buhd",
  Chakma: "cakm",
  Canadian_Aboriginal: "cans",
  Carian: "cari",
  Cham: "cham",
  Cherokee: "cher",
  Coptic: "copt",
  Cypriot: "cprt",
  Cyrillic: "cyrl",
  Devanagari: [
    "dev2",
    "deva"
  ],
  Deseret: "dsrt",
  Duployan: "dupl",
  Egyptian_Hieroglyphs: "egyp",
  Elbasan: "elba",
  Ethiopic: "ethi",
  Georgian: "geor",
  Glagolitic: "glag",
  Gothic: "goth",
  Grantha: "gran",
  Greek: "grek",
  Gujarati: [
    "gjr2",
    "gujr"
  ],
  Gurmukhi: [
    "gur2",
    "guru"
  ],
  Hangul: "hang",
  Han: "hani",
  Hanunoo: "hano",
  Hebrew: "hebr",
  Hiragana: "hira",
  Pahawh_Hmong: "hmng",
  Katakana_Or_Hiragana: "hrkt",
  Old_Italic: "ital",
  Javanese: "java",
  Kayah_Li: "kali",
  Katakana: "kana",
  Kharoshthi: "khar",
  Khmer: "khmr",
  Khojki: "khoj",
  Kannada: [
    "knd2",
    "knda"
  ],
  Kaithi: "kthi",
  Tai_Tham: "lana",
  Lao: "lao ",
  Latin: "latn",
  Lepcha: "lepc",
  Limbu: "limb",
  Linear_A: "lina",
  Linear_B: "linb",
  Lisu: "lisu",
  Lycian: "lyci",
  Lydian: "lydi",
  Mahajani: "mahj",
  Mandaic: "mand",
  Manichaean: "mani",
  Mende_Kikakui: "mend",
  Meroitic_Cursive: "merc",
  Meroitic_Hieroglyphs: "mero",
  Malayalam: [
    "mlm2",
    "mlym"
  ],
  Modi: "modi",
  Mongolian: "mong",
  Mro: "mroo",
  Meetei_Mayek: "mtei",
  Myanmar: [
    "mym2",
    "mymr"
  ],
  Old_North_Arabian: "narb",
  Nabataean: "nbat",
  Nko: "nko ",
  Ogham: "ogam",
  Ol_Chiki: "olck",
  Old_Turkic: "orkh",
  Oriya: [
    "ory2",
    "orya"
  ],
  Osmanya: "osma",
  Palmyrene: "palm",
  Pau_Cin_Hau: "pauc",
  Old_Permic: "perm",
  Phags_Pa: "phag",
  Inscriptional_Pahlavi: "phli",
  Psalter_Pahlavi: "phlp",
  Phoenician: "phnx",
  Miao: "plrd",
  Inscriptional_Parthian: "prti",
  Rejang: "rjng",
  Runic: "runr",
  Samaritan: "samr",
  Old_South_Arabian: "sarb",
  Saurashtra: "saur",
  Shavian: "shaw",
  Sharada: "shrd",
  Siddham: "sidd",
  Khudawadi: "sind",
  Sinhala: "sinh",
  Sora_Sompeng: "sora",
  Sundanese: "sund",
  Syloti_Nagri: "sylo",
  Syriac: "syrc",
  Tagbanwa: "tagb",
  Takri: "takr",
  Tai_Le: "tale",
  New_Tai_Lue: "talu",
  Tamil: [
    "tml2",
    "taml"
  ],
  Tai_Viet: "tavt",
  Telugu: [
    "tel2",
    "telu"
  ],
  Tifinagh: "tfng",
  Tagalog: "tglg",
  Thaana: "thaa",
  Thai: "thai",
  Tibetan: "tibt",
  Tirhuta: "tirh",
  Ugaritic: "ugar",
  Vai: "vai ",
  Warang_Citi: "wara",
  Old_Persian: "xpeo",
  Cuneiform: "xsux",
  Yi: "yi  ",
  Inherited: "zinh",
  Common: "zyyy",
  Unknown: "zzzz"
}, Mr = {};
for (let i in R0) {
  let e = R0[i];
  if (Array.isArray(e)) for (let t of e) Mr[t] = i;
  else Mr[e] = i;
}
function Fu(i) {
  return Mr[i];
}
function Du(i) {
  let e = i.length, t = 0;
  for (; t < e; ) {
    let r = i.charCodeAt(t++);
    if (55296 <= r && r <= 56319 && t < e) {
      let n = i.charCodeAt(t);
      56320 <= n && n <= 57343 && (t++, r = ((r & 1023) << 10) + (n & 1023) + 65536);
    }
    let s = Ma(r);
    if (s !== "Common" && s !== "Inherited" && s !== "Unknown") return R0[s];
  }
  return R0.Unknown;
}
function Bu(i) {
  for (let e = 0; e < i.length; e++) {
    let t = i[e], r = Ma(t);
    if (r !== "Common" && r !== "Inherited" && r !== "Unknown") return R0[r];
  }
  return R0.Unknown;
}
const Lu = {
  arab: !0,
  hebr: !0,
  syrc: !0,
  thaa: !0,
  cprt: !0,
  khar: !0,
  phnx: !0,
  "nko ": !0,
  lydi: !0,
  avst: !0,
  armi: !0,
  phli: !0,
  prti: !0,
  sarb: !0,
  orkh: !0,
  samr: !0,
  mand: !0,
  merc: !0,
  mero: !0,
  // Unicode 7.0 (not listed on http://www.microsoft.com/typography/otspec/scripttags.htm)
  mani: !0,
  mend: !0,
  nbat: !0,
  narb: !0,
  palm: !0,
  phlp: !0
  // Psalter Pahlavi
};
function un(i) {
  return Lu[i] ? "rtl" : "ltr";
}
class Mu {
  /**
  * The total advance width of the run.
  * @type {number}
  */
  get advanceWidth() {
    let e = 0;
    for (let t of this.positions) e += t.xAdvance;
    return e;
  }
  /**
  * The total advance height of the run.
  * @type {number}
  */
  get advanceHeight() {
    let e = 0;
    for (let t of this.positions) e += t.yAdvance;
    return e;
  }
  /**
  * The bounding box containing all glyphs in the run.
  * @type {BBox}
  */
  get bbox() {
    let e = new g0(), t = 0, r = 0;
    for (let s = 0; s < this.glyphs.length; s++) {
      let n = this.glyphs[s], a = this.positions[s], o = n.bbox;
      e.addPoint(o.minX + t + a.xOffset, o.minY + r + a.yOffset), e.addPoint(o.maxX + t + a.xOffset, o.maxY + r + a.yOffset), t += a.xAdvance, r += a.yAdvance;
    }
    return e;
  }
  constructor(e, t, r, s, n) {
    if (this.glyphs = e, this.positions = null, this.script = r, this.language = s || null, this.direction = n || un(r), this.features = {}, Array.isArray(t)) for (let a of t) this.features[a] = !0;
    else typeof t == "object" && (this.features = t);
  }
}
class Ru {
  constructor(e = 0, t = 0, r = 0, s = 0) {
    this.xAdvance = e, this.yAdvance = t, this.xOffset = r, this.yOffset = s;
  }
}
const S0 = {
  allTypographicFeatures: {
    code: 0,
    exclusive: !1,
    allTypeFeatures: 0
  },
  ligatures: {
    code: 1,
    exclusive: !1,
    requiredLigatures: 0,
    commonLigatures: 2,
    rareLigatures: 4,
    // logos: 6
    rebusPictures: 8,
    diphthongLigatures: 10,
    squaredLigatures: 12,
    abbrevSquaredLigatures: 14,
    symbolLigatures: 16,
    contextualLigatures: 18,
    historicalLigatures: 20
  },
  cursiveConnection: {
    code: 2,
    exclusive: !0,
    unconnected: 0,
    partiallyConnected: 1,
    cursive: 2
  },
  letterCase: {
    code: 3,
    exclusive: !0
  },
  // upperAndLowerCase: 0          # deprecated
  // allCaps: 1                    # deprecated
  // allLowerCase: 2               # deprecated
  // smallCaps: 3                  # deprecated
  // initialCaps: 4                # deprecated
  // initialCapsAndSmallCaps: 5    # deprecated
  verticalSubstitution: {
    code: 4,
    exclusive: !1,
    substituteVerticalForms: 0
  },
  linguisticRearrangement: {
    code: 5,
    exclusive: !1,
    linguisticRearrangement: 0
  },
  numberSpacing: {
    code: 6,
    exclusive: !0,
    monospacedNumbers: 0,
    proportionalNumbers: 1,
    thirdWidthNumbers: 2,
    quarterWidthNumbers: 3
  },
  smartSwash: {
    code: 8,
    exclusive: !1,
    wordInitialSwashes: 0,
    wordFinalSwashes: 2,
    // lineInitialSwashes: 4
    // lineFinalSwashes: 6
    nonFinalSwashes: 8
  },
  diacritics: {
    code: 9,
    exclusive: !0,
    showDiacritics: 0,
    hideDiacritics: 1,
    decomposeDiacritics: 2
  },
  verticalPosition: {
    code: 10,
    exclusive: !0,
    normalPosition: 0,
    superiors: 1,
    inferiors: 2,
    ordinals: 3,
    scientificInferiors: 4
  },
  fractions: {
    code: 11,
    exclusive: !0,
    noFractions: 0,
    verticalFractions: 1,
    diagonalFractions: 2
  },
  overlappingCharacters: {
    code: 13,
    exclusive: !1,
    preventOverlap: 0
  },
  typographicExtras: {
    code: 14,
    exclusive: !1,
    // hyphensToEmDash: 0
    // hyphenToEnDash: 2
    slashedZero: 4
  },
  // formInterrobang: 6
  // smartQuotes: 8
  // periodsToEllipsis: 10
  mathematicalExtras: {
    code: 15,
    exclusive: !1,
    // hyphenToMinus: 0
    // asteristoMultiply: 2
    // slashToDivide: 4
    // inequalityLigatures: 6
    // exponents: 8
    mathematicalGreek: 10
  },
  ornamentSets: {
    code: 16,
    exclusive: !0,
    noOrnaments: 0,
    dingbats: 1,
    piCharacters: 2,
    fleurons: 3,
    decorativeBorders: 4,
    internationalSymbols: 5,
    mathSymbols: 6
  },
  characterAlternatives: {
    code: 17,
    exclusive: !0,
    noAlternates: 0
  },
  // user defined options
  designComplexity: {
    code: 18,
    exclusive: !0,
    designLevel1: 0,
    designLevel2: 1,
    designLevel3: 2,
    designLevel4: 3,
    designLevel5: 4
  },
  styleOptions: {
    code: 19,
    exclusive: !0,
    noStyleOptions: 0,
    displayText: 1,
    engravedText: 2,
    illuminatedCaps: 3,
    titlingCaps: 4,
    tallCaps: 5
  },
  characterShape: {
    code: 20,
    exclusive: !0,
    traditionalCharacters: 0,
    simplifiedCharacters: 1,
    JIS1978Characters: 2,
    JIS1983Characters: 3,
    JIS1990Characters: 4,
    traditionalAltOne: 5,
    traditionalAltTwo: 6,
    traditionalAltThree: 7,
    traditionalAltFour: 8,
    traditionalAltFive: 9,
    expertCharacters: 10,
    JIS2004Characters: 11,
    hojoCharacters: 12,
    NLCCharacters: 13,
    traditionalNamesCharacters: 14
  },
  numberCase: {
    code: 21,
    exclusive: !0,
    lowerCaseNumbers: 0,
    upperCaseNumbers: 1
  },
  textSpacing: {
    code: 22,
    exclusive: !0,
    proportionalText: 0,
    monospacedText: 1,
    halfWidthText: 2,
    thirdWidthText: 3,
    quarterWidthText: 4,
    altProportionalText: 5,
    altHalfWidthText: 6
  },
  transliteration: {
    code: 23,
    exclusive: !0,
    noTransliteration: 0
  },
  // hanjaToHangul: 1
  // hiraganaToKatakana: 2
  // katakanaToHiragana: 3
  // kanaToRomanization: 4
  // romanizationToHiragana: 5
  // romanizationToKatakana: 6
  // hanjaToHangulAltOne: 7
  // hanjaToHangulAltTwo: 8
  // hanjaToHangulAltThree: 9
  annotation: {
    code: 24,
    exclusive: !0,
    noAnnotation: 0,
    boxAnnotation: 1,
    roundedBoxAnnotation: 2,
    circleAnnotation: 3,
    invertedCircleAnnotation: 4,
    parenthesisAnnotation: 5,
    periodAnnotation: 6,
    romanNumeralAnnotation: 7,
    diamondAnnotation: 8,
    invertedBoxAnnotation: 9,
    invertedRoundedBoxAnnotation: 10
  },
  kanaSpacing: {
    code: 25,
    exclusive: !0,
    fullWidthKana: 0,
    proportionalKana: 1
  },
  ideographicSpacing: {
    code: 26,
    exclusive: !0,
    fullWidthIdeographs: 0,
    proportionalIdeographs: 1,
    halfWidthIdeographs: 2
  },
  unicodeDecomposition: {
    code: 27,
    exclusive: !1,
    canonicalComposition: 0,
    compatibilityComposition: 2,
    transcodingComposition: 4
  },
  rubyKana: {
    code: 28,
    exclusive: !1,
    // noRubyKana: 0     # deprecated - use rubyKanaOff instead
    // rubyKana: 1     # deprecated - use rubyKanaOn instead
    rubyKana: 2
  },
  CJKSymbolAlternatives: {
    code: 29,
    exclusive: !0,
    noCJKSymbolAlternatives: 0,
    CJKSymbolAltOne: 1,
    CJKSymbolAltTwo: 2,
    CJKSymbolAltThree: 3,
    CJKSymbolAltFour: 4,
    CJKSymbolAltFive: 5
  },
  ideographicAlternatives: {
    code: 30,
    exclusive: !0,
    noIdeographicAlternatives: 0,
    ideographicAltOne: 1,
    ideographicAltTwo: 2,
    ideographicAltThree: 3,
    ideographicAltFour: 4,
    ideographicAltFive: 5
  },
  CJKVerticalRomanPlacement: {
    code: 31,
    exclusive: !0,
    CJKVerticalRomanCentered: 0,
    CJKVerticalRomanHBaseline: 1
  },
  italicCJKRoman: {
    code: 32,
    exclusive: !1,
    // noCJKItalicRoman: 0     # deprecated - use CJKItalicRomanOff instead
    // CJKItalicRoman: 1     # deprecated - use CJKItalicRomanOn instead
    CJKItalicRoman: 2
  },
  caseSensitiveLayout: {
    code: 33,
    exclusive: !1,
    caseSensitiveLayout: 0,
    caseSensitiveSpacing: 2
  },
  alternateKana: {
    code: 34,
    exclusive: !1,
    alternateHorizKana: 0,
    alternateVertKana: 2
  },
  stylisticAlternatives: {
    code: 35,
    exclusive: !1,
    noStylisticAlternates: 0,
    stylisticAltOne: 2,
    stylisticAltTwo: 4,
    stylisticAltThree: 6,
    stylisticAltFour: 8,
    stylisticAltFive: 10,
    stylisticAltSix: 12,
    stylisticAltSeven: 14,
    stylisticAltEight: 16,
    stylisticAltNine: 18,
    stylisticAltTen: 20,
    stylisticAltEleven: 22,
    stylisticAltTwelve: 24,
    stylisticAltThirteen: 26,
    stylisticAltFourteen: 28,
    stylisticAltFifteen: 30,
    stylisticAltSixteen: 32,
    stylisticAltSeventeen: 34,
    stylisticAltEighteen: 36,
    stylisticAltNineteen: 38,
    stylisticAltTwenty: 40
  },
  contextualAlternates: {
    code: 36,
    exclusive: !1,
    contextualAlternates: 0,
    swashAlternates: 2,
    contextualSwashAlternates: 4
  },
  lowerCase: {
    code: 37,
    exclusive: !0,
    defaultLowerCase: 0,
    lowerCaseSmallCaps: 1,
    lowerCasePetiteCaps: 2
  },
  upperCase: {
    code: 38,
    exclusive: !0,
    defaultUpperCase: 0,
    upperCaseSmallCaps: 1,
    upperCasePetiteCaps: 2
  },
  languageTag: {
    code: 39,
    exclusive: !0
  },
  CJKRomanSpacing: {
    code: 103,
    exclusive: !0,
    halfWidthCJKRoman: 0,
    proportionalCJKRoman: 1,
    defaultCJKRoman: 2,
    fullWidthCJKRoman: 3
  }
}, F = (i, e) => [
  S0[i].code,
  S0[i][e]
], Dt = {
  rlig: F("ligatures", "requiredLigatures"),
  clig: F("ligatures", "contextualLigatures"),
  dlig: F("ligatures", "rareLigatures"),
  hlig: F("ligatures", "historicalLigatures"),
  liga: F("ligatures", "commonLigatures"),
  hist: F("ligatures", "historicalLigatures"),
  smcp: F("lowerCase", "lowerCaseSmallCaps"),
  pcap: F("lowerCase", "lowerCasePetiteCaps"),
  frac: F("fractions", "diagonalFractions"),
  dnom: F("fractions", "diagonalFractions"),
  numr: F("fractions", "diagonalFractions"),
  afrc: F("fractions", "verticalFractions"),
  // aalt
  // abvf, abvm, abvs, akhn, blwf, blwm, blws, cfar, cjct, cpsp, falt, isol, jalt, ljmo, mset?
  // ltra, ltrm, nukt, pref, pres, pstf, psts, rand, rkrf, rphf, rtla, rtlm, size, tjmo, tnum?
  // unic, vatu, vhal, vjmo, vpal, vrt2
  // dist -> trak table?
  // kern, vkrn -> kern table
  // lfbd + opbd + rtbd -> opbd table?
  // mark, mkmk -> acnt table?
  // locl -> languageTag + ltag table
  case: F("caseSensitiveLayout", "caseSensitiveLayout"),
  ccmp: F("unicodeDecomposition", "canonicalComposition"),
  cpct: F("CJKVerticalRomanPlacement", "CJKVerticalRomanCentered"),
  valt: F("CJKVerticalRomanPlacement", "CJKVerticalRomanCentered"),
  swsh: F("contextualAlternates", "swashAlternates"),
  cswh: F("contextualAlternates", "contextualSwashAlternates"),
  curs: F("cursiveConnection", "cursive"),
  c2pc: F("upperCase", "upperCasePetiteCaps"),
  c2sc: F("upperCase", "upperCaseSmallCaps"),
  init: F("smartSwash", "wordInitialSwashes"),
  fin2: F("smartSwash", "wordFinalSwashes"),
  medi: F("smartSwash", "nonFinalSwashes"),
  med2: F("smartSwash", "nonFinalSwashes"),
  fin3: F("smartSwash", "wordFinalSwashes"),
  fina: F("smartSwash", "wordFinalSwashes"),
  pkna: F("kanaSpacing", "proportionalKana"),
  half: F("textSpacing", "halfWidthText"),
  halt: F("textSpacing", "altHalfWidthText"),
  hkna: F("alternateKana", "alternateHorizKana"),
  vkna: F("alternateKana", "alternateVertKana"),
  // hngl: feature 'transliteration', 'hanjaToHangulSelector' # deprecated
  ital: F("italicCJKRoman", "CJKItalicRoman"),
  lnum: F("numberCase", "upperCaseNumbers"),
  onum: F("numberCase", "lowerCaseNumbers"),
  mgrk: F("mathematicalExtras", "mathematicalGreek"),
  // nalt: not enough info. what type of annotation?
  // ornm: ditto, which ornament style?
  calt: F("contextualAlternates", "contextualAlternates"),
  vrt2: F("verticalSubstitution", "substituteVerticalForms"),
  vert: F("verticalSubstitution", "substituteVerticalForms"),
  tnum: F("numberSpacing", "monospacedNumbers"),
  pnum: F("numberSpacing", "proportionalNumbers"),
  sups: F("verticalPosition", "superiors"),
  subs: F("verticalPosition", "inferiors"),
  ordn: F("verticalPosition", "ordinals"),
  pwid: F("textSpacing", "proportionalText"),
  hwid: F("textSpacing", "halfWidthText"),
  qwid: F("textSpacing", "quarterWidthText"),
  twid: F("textSpacing", "thirdWidthText"),
  fwid: F("textSpacing", "proportionalText"),
  palt: F("textSpacing", "altProportionalText"),
  trad: F("characterShape", "traditionalCharacters"),
  smpl: F("characterShape", "simplifiedCharacters"),
  jp78: F("characterShape", "JIS1978Characters"),
  jp83: F("characterShape", "JIS1983Characters"),
  jp90: F("characterShape", "JIS1990Characters"),
  jp04: F("characterShape", "JIS2004Characters"),
  expt: F("characterShape", "expertCharacters"),
  hojo: F("characterShape", "hojoCharacters"),
  nlck: F("characterShape", "NLCCharacters"),
  tnam: F("characterShape", "traditionalNamesCharacters"),
  ruby: F("rubyKana", "rubyKana"),
  titl: F("styleOptions", "titlingCaps"),
  zero: F("typographicExtras", "slashedZero"),
  ss01: F("stylisticAlternatives", "stylisticAltOne"),
  ss02: F("stylisticAlternatives", "stylisticAltTwo"),
  ss03: F("stylisticAlternatives", "stylisticAltThree"),
  ss04: F("stylisticAlternatives", "stylisticAltFour"),
  ss05: F("stylisticAlternatives", "stylisticAltFive"),
  ss06: F("stylisticAlternatives", "stylisticAltSix"),
  ss07: F("stylisticAlternatives", "stylisticAltSeven"),
  ss08: F("stylisticAlternatives", "stylisticAltEight"),
  ss09: F("stylisticAlternatives", "stylisticAltNine"),
  ss10: F("stylisticAlternatives", "stylisticAltTen"),
  ss11: F("stylisticAlternatives", "stylisticAltEleven"),
  ss12: F("stylisticAlternatives", "stylisticAltTwelve"),
  ss13: F("stylisticAlternatives", "stylisticAltThirteen"),
  ss14: F("stylisticAlternatives", "stylisticAltFourteen"),
  ss15: F("stylisticAlternatives", "stylisticAltFifteen"),
  ss16: F("stylisticAlternatives", "stylisticAltSixteen"),
  ss17: F("stylisticAlternatives", "stylisticAltSeventeen"),
  ss18: F("stylisticAlternatives", "stylisticAltEighteen"),
  ss19: F("stylisticAlternatives", "stylisticAltNineteen"),
  ss20: F("stylisticAlternatives", "stylisticAltTwenty")
};
for (let i = 1; i <= 99; i++) Dt[`cv${`00${i}`.slice(-2)}`] = [
  S0.characterAlternatives.code,
  i
];
let A0 = {};
for (let i in Dt) {
  let e = Dt[i];
  A0[e[0]] == null && (A0[e[0]] = {}), A0[e[0]][e[1]] = i;
}
function Nu(i) {
  let e = {};
  for (let t in i) {
    let r;
    (r = Dt[t]) && (e[r[0]] == null && (e[r[0]] = {}), e[r[0]][r[1]] = i[t]);
  }
  return e;
}
function ia(i) {
  let [e, t] = i;
  if (isNaN(e)) var r = S0[e] && S0[e].code;
  else var r = e;
  if (isNaN(t)) var s = S0[e] && S0[e][t];
  else var s = t;
  return [
    r,
    s
  ];
}
function Uu(i) {
  let e = {};
  if (Array.isArray(i)) for (let t = 0; t < i.length; t++) {
    let r, s = ia(i[t]);
    (r = A0[s[0]] && A0[s[0]][s[1]]) && (e[r] = !0);
  }
  else if (typeof i == "object") for (let t in i) {
    let r = i[t];
    for (let s in r) {
      let n, a = ia([
        t,
        s
      ]);
      r[s] && (n = A0[a[0]] && A0[a[0]][a[1]]) && (e[n] = !0);
    }
  }
  return Object.keys(e);
}
class Q0 {
  lookup(e) {
    switch (this.table.version) {
      case 0:
        return this.table.values.getItem(e);
      case 2:
      case 4: {
        let s = 0, n = this.table.binarySearchHeader.nUnits - 1;
        for (; s <= n; ) {
          var t = s + n >> 1, r = this.table.segments[t];
          if (r.firstGlyph === 65535) return null;
          if (e < r.firstGlyph) n = t - 1;
          else if (e > r.lastGlyph) s = t + 1;
          else
            return this.table.version === 2 ? r.value : r.values[e - r.firstGlyph];
        }
        return null;
      }
      case 6: {
        let s = 0, n = this.table.binarySearchHeader.nUnits - 1;
        for (; s <= n; ) {
          var t = s + n >> 1, r = this.table.segments[t];
          if (r.glyph === 65535) return null;
          if (e < r.glyph) n = t - 1;
          else if (e > r.glyph) s = t + 1;
          else return r.value;
        }
        return null;
      }
      case 8:
        return this.table.values[e - this.table.firstGlyph];
      default:
        throw new Error(`Unknown lookup table format: ${this.table.version}`);
    }
  }
  glyphsForValue(e) {
    let t = [];
    switch (this.table.version) {
      case 2:
      case 4:
        for (let r of this.table.segments) if (this.table.version === 2 && r.value === e) t.push(...B0(r.firstGlyph, r.lastGlyph + 1));
        else
          for (let s = 0; s < r.values.length; s++) r.values[s] === e && t.push(r.firstGlyph + s);
        break;
      case 6:
        for (let r of this.table.segments) r.value === e && t.push(r.glyph);
        break;
      case 8:
        for (let r = 0; r < this.table.values.length; r++) this.table.values[r] === e && t.push(this.table.firstGlyph + r);
        break;
      default:
        throw new Error(`Unknown lookup table format: ${this.table.version}`);
    }
    return t;
  }
  constructor(e) {
    this.table = e;
  }
}
Ie([
  ke
], Q0.prototype, "glyphsForValue", null);
const Gu = 0, la = 0, oa = 1, ua = 2, Vu = 16384;
class zu {
  process(e, t, r) {
    let s = Gu, n = t ? e.length - 1 : 0, a = t ? -1 : 1;
    for (; a === 1 && n <= e.length || a === -1 && n >= -1; ) {
      let o = null, u = oa, c = !0;
      n === e.length || n === -1 ? u = la : (o = e[n], o.id === 65535 ? u = ua : (u = this.lookupTable.lookup(o.id), u == null && (u = oa)));
      let f = this.stateTable.stateArray.getItem(s)[u], p = this.stateTable.entryTable.getItem(f);
      u !== la && u !== ua && (r(o, p, n), c = !(p.flags & Vu)), s = p.newState, c && (n += a);
    }
    return e;
  }
  /**
  * Performs a depth-first traversal of the glyph strings
  * represented by the state machine.
  */
  traverse(e, t = 0, r = /* @__PURE__ */ new Set()) {
    if (r.has(t)) return;
    r.add(t);
    let { nClasses: s, stateArray: n, entryTable: a } = this.stateTable, o = n.getItem(t);
    for (let u = 4; u < s; u++) {
      let c = o[u], d = a.getItem(c);
      for (let f of this.lookupTable.glyphsForValue(u))
        e.enter && e.enter(f, d), d.newState !== 0 && this.traverse(e, d.newState, r), e.exit && e.exit(f, d);
    }
  }
  constructor(e) {
    this.stateTable = e, this.lookupTable = new Q0(e.classTable);
  }
}
const qu = 32768, Wu = 8192, Hu = 15, ca = 32768, $u = 32768, Xu = 8192, ju = 2147483648, Yu = 1073741824, Zu = 1073741823, fa = 4194304, Ku = 2048, Ju = 1024, Qu = 992, _u = 31;
class cn {
  // Processes an array of glyphs and applies the specified features
  // Features should be in the form of {featureType:{featureSetting:boolean}}
  process(e, t = {}) {
    for (let s of this.morx.chains) {
      let n = s.defaultFlags;
      for (let a of s.features) {
        let o;
        (o = t[a.featureType]) && (o[a.featureSetting] ? (n &= a.disableFlags, n |= a.enableFlags) : o[a.featureSetting] === !1 && (n |= ~a.disableFlags, n &= ~a.enableFlags));
      }
      for (let a of s.subtables) a.subFeatureFlags & n && this.processSubtable(a, e);
    }
    let r = e.length - 1;
    for (; r >= 0; )
      e[r].id === 65535 && e.splice(r, 1), r--;
    return e;
  }
  processSubtable(e, t) {
    if (this.subtable = e, this.glyphs = t, this.subtable.type === 4) {
      this.processNoncontextualSubstitutions(this.subtable, this.glyphs);
      return;
    }
    this.ligatureStack = [], this.markedGlyph = null, this.firstGlyph = null, this.lastGlyph = null, this.markedIndex = null;
    let r = this.getStateMachine(e), s = this.getProcessor(), n = !!(this.subtable.coverage & fa);
    return r.process(this.glyphs, n, s);
  }
  getStateMachine(e) {
    return new zu(e.table.stateTable);
  }
  getProcessor() {
    switch (this.subtable.type) {
      case 0:
        return this.processIndicRearragement;
      case 1:
        return this.processContextualSubstitution;
      case 2:
        return this.processLigature;
      case 4:
        return this.processNoncontextualSubstitutions;
      case 5:
        return this.processGlyphInsertion;
      default:
        throw new Error(`Invalid morx subtable type: ${this.subtable.type}`);
    }
  }
  processIndicRearragement(e, t, r) {
    t.flags & qu && (this.firstGlyph = r), t.flags & Wu && (this.lastGlyph = r), ec(this.glyphs, t.flags & Hu, this.firstGlyph, this.lastGlyph);
  }
  processContextualSubstitution(e, t, r) {
    let s = this.subtable.table.substitutionTable.items;
    if (t.markIndex !== 65535) {
      let a = s.getItem(t.markIndex), o = new Q0(a);
      e = this.glyphs[this.markedGlyph];
      var n = o.lookup(e.id);
      n && (this.glyphs[this.markedGlyph] = this.font.getGlyph(n, e.codePoints));
    }
    if (t.currentIndex !== 65535) {
      let a = s.getItem(t.currentIndex), o = new Q0(a);
      e = this.glyphs[r];
      var n = o.lookup(e.id);
      n && (this.glyphs[r] = this.font.getGlyph(n, e.codePoints));
    }
    t.flags & ca && (this.markedGlyph = r);
  }
  processLigature(e, t, r) {
    if (t.flags & $u && this.ligatureStack.push(r), t.flags & Xu) {
      let s = this.subtable.table.ligatureActions, n = this.subtable.table.components, a = this.subtable.table.ligatureList, o = t.action, u = !1, c = 0, d = [], f = [];
      for (; !u; ) {
        let p = this.ligatureStack.pop();
        d.unshift(...this.glyphs[p].codePoints);
        let m = s.getItem(o++);
        u = !!(m & ju);
        let C = !!(m & Yu), O = (m & Zu) << 2 >> 2;
        O += this.glyphs[p].id;
        let G = n.getItem(O);
        if (c += G, u || C) {
          let L = a.getItem(c);
          this.glyphs[p] = this.font.getGlyph(L, d), f.push(p), c = 0, d = [];
        } else this.glyphs[p] = this.font.getGlyph(65535);
      }
      this.ligatureStack.push(...f);
    }
  }
  processNoncontextualSubstitutions(e, t, r) {
    let s = new Q0(e.table.lookupTable);
    for (r = 0; r < t.length; r++) {
      let n = t[r];
      if (n.id !== 65535) {
        let a = s.lookup(n.id);
        a && (t[r] = this.font.getGlyph(a, n.codePoints));
      }
    }
  }
  _insertGlyphs(e, t, r, s) {
    let n = [];
    for (; r--; ) {
      let a = this.subtable.table.insertionActions.getItem(t++);
      n.push(this.font.getGlyph(a));
    }
    s || e++, this.glyphs.splice(e, 0, ...n);
  }
  processGlyphInsertion(e, t, r) {
    if (t.flags & ca && (this.markedIndex = r), t.markedInsertIndex !== 65535) {
      let s = (t.flags & _u) >>> 5, n = !!(t.flags & Ju);
      this._insertGlyphs(this.markedIndex, t.markedInsertIndex, s, n);
    }
    if (t.currentInsertIndex !== 65535) {
      let s = (t.flags & Qu) >>> 5, n = !!(t.flags & Ku);
      this._insertGlyphs(r, t.currentInsertIndex, s, n);
    }
  }
  getSupportedFeatures() {
    let e = [];
    for (let t of this.morx.chains) for (let r of t.features) e.push([
      r.featureType,
      r.featureSetting
    ]);
    return e;
  }
  generateInputs(e) {
    return this.inputCache || this.generateInputCache(), this.inputCache[e] || [];
  }
  generateInputCache() {
    this.inputCache = {};
    for (let e of this.morx.chains) {
      let t = e.defaultFlags;
      for (let r of e.subtables) r.subFeatureFlags & t && this.generateInputsForSubtable(r);
    }
  }
  generateInputsForSubtable(e) {
    if (e.type !== 2) return;
    if (!!(e.coverage & fa)) throw new Error("Reverse subtable, not supported.");
    this.subtable = e, this.ligatureStack = [];
    let r = this.getStateMachine(e), s = this.getProcessor(), n = [], a = [];
    this.glyphs = [], r.traverse({
      enter: (o, u) => {
        let c = this.glyphs;
        a.push({
          glyphs: c.slice(),
          ligatureStack: this.ligatureStack.slice()
        });
        let d = this.font.getGlyph(o);
        n.push(d), c.push(n[n.length - 1]), s(c[c.length - 1], u, c.length - 1);
        let f = 0, p = 0;
        for (let m = 0; m < c.length && f <= 1; m++) c[m].id !== 65535 && (f++, p = c[m].id);
        if (f === 1) {
          let m = n.map((O) => O.id), C = this.inputCache[p];
          C ? C.push(m) : this.inputCache[p] = [
            m
          ];
        }
      },
      exit: () => {
        ({ glyphs: this.glyphs, ligatureStack: this.ligatureStack } = a.pop()), n.pop();
      }
    });
  }
  constructor(e) {
    this.processIndicRearragement = this.processIndicRearragement.bind(this), this.processContextualSubstitution = this.processContextualSubstitution.bind(this), this.processLigature = this.processLigature.bind(this), this.processNoncontextualSubstitutions = this.processNoncontextualSubstitutions.bind(this), this.processGlyphInsertion = this.processGlyphInsertion.bind(this), this.font = e, this.morx = e.morx, this.inputCache = null;
  }
}
Ie([
  ke
], cn.prototype, "getStateMachine", null);
function Pe(i, e, t, r = !1, s = !1) {
  let n = i.splice(t[0] - (t[1] - 1), t[1]);
  s && n.reverse();
  let a = i.splice(e[0], e[1], ...n);
  return r && a.reverse(), i.splice(t[0] - (e[1] - 1), 0, ...a), i;
}
function ec(i, e, t, r) {
  switch (e) {
    case 0:
      return i;
    case 1:
      return Pe(i, [
        t,
        1
      ], [
        r,
        0
      ]);
    case 2:
      return Pe(i, [
        t,
        0
      ], [
        r,
        1
      ]);
    case 3:
      return Pe(i, [
        t,
        1
      ], [
        r,
        1
      ]);
    case 4:
      return Pe(i, [
        t,
        2
      ], [
        r,
        0
      ]);
    case 5:
      return Pe(i, [
        t,
        2
      ], [
        r,
        0
      ], !0, !1);
    case 6:
      return Pe(i, [
        t,
        0
      ], [
        r,
        2
      ]);
    case 7:
      return Pe(i, [
        t,
        0
      ], [
        r,
        2
      ], !1, !0);
    case 8:
      return Pe(i, [
        t,
        1
      ], [
        r,
        2
      ]);
    case 9:
      return Pe(i, [
        t,
        1
      ], [
        r,
        2
      ], !1, !0);
    case 10:
      return Pe(i, [
        t,
        2
      ], [
        r,
        1
      ]);
    case 11:
      return Pe(i, [
        t,
        2
      ], [
        r,
        1
      ], !0, !1);
    case 12:
      return Pe(i, [
        t,
        2
      ], [
        r,
        2
      ]);
    case 13:
      return Pe(i, [
        t,
        2
      ], [
        r,
        2
      ], !0, !1);
    case 14:
      return Pe(i, [
        t,
        2
      ], [
        r,
        2
      ], !1, !0);
    case 15:
      return Pe(i, [
        t,
        2
      ], [
        r,
        2
      ], !0, !0);
    default:
      throw new Error(`Unknown verb: ${e}`);
  }
}
class tc {
  substitute(e) {
    e.direction === "rtl" && e.glyphs.reverse(), this.morxProcessor.process(e.glyphs, Nu(e.features));
  }
  getAvailableFeatures(e, t) {
    return Uu(this.morxProcessor.getSupportedFeatures());
  }
  stringsForGlyph(e) {
    let t = this.morxProcessor.generateInputs(e), r = /* @__PURE__ */ new Set();
    for (let s of t) this._addStrings(s, 0, r, "");
    return r;
  }
  _addStrings(e, t, r, s) {
    let n = this.font._cmapProcessor.codePointsForGlyph(e[t]);
    for (let a of n) {
      let o = s + String.fromCodePoint(a);
      t < e.length - 1 ? this._addStrings(e, t + 1, r, o) : r.add(o);
    }
  }
  constructor(e) {
    this.font = e, this.morxProcessor = new cn(e), this.fallbackPosition = !1;
  }
}
class rc {
  /**
  * Adds the given features to the last stage.
  * Ignores features that have already been applied.
  */
  _addFeatures(e, t) {
    let r = this.stages.length - 1, s = this.stages[r];
    for (let n of e) this.allFeatures[n] == null && (s.push(n), this.allFeatures[n] = r, t && (this.globalFeatures[n] = !0));
  }
  /**
  * Add features to the last stage
  */
  add(e, t = !0) {
    if (this.stages.length === 0 && this.stages.push([]), typeof e == "string" && (e = [
      e
    ]), Array.isArray(e)) this._addFeatures(e, t);
    else if (typeof e == "object")
      this._addFeatures(e.global || [], !0), this._addFeatures(e.local || [], !1);
    else throw new Error("Unsupported argument to ShapingPlan#add");
  }
  /**
  * Add a new stage
  */
  addStage(e, t) {
    typeof e == "function" ? this.stages.push(e, []) : (this.stages.push([]), this.add(e, t));
  }
  setFeatureOverrides(e) {
    if (Array.isArray(e)) this.add(e);
    else if (typeof e == "object") {
      for (let t in e)
        if (e[t]) this.add(t);
        else if (this.allFeatures[t] != null) {
          let r = this.stages[this.allFeatures[t]];
          r.splice(r.indexOf(t), 1), delete this.allFeatures[t], delete this.globalFeatures[t];
        }
    }
  }
  /**
  * Assigns the global features to the given glyphs
  */
  assignGlobalFeatures(e) {
    for (let t of e) for (let r in this.globalFeatures) t.features[r] = !0;
  }
  /**
  * Executes the planned stages using the given OTProcessor
  */
  process(e, t, r) {
    for (let s of this.stages)
      typeof s == "function" ? r || s(this.font, t, this) : s.length > 0 && e.applyFeatures(s, t, r);
  }
  constructor(e, t, r) {
    this.font = e, this.script = t, this.direction = r, this.stages = [], this.globalFeatures = {}, this.allFeatures = {};
  }
}
const sc = [
  "rvrn"
], ac = [
  "ccmp",
  "locl",
  "rlig",
  "mark",
  "mkmk"
], nc = [
  "frac",
  "numr",
  "dnom"
], ic = [
  "calt",
  "clig",
  "liga",
  "rclt",
  "curs",
  "kern"
], lc = {
  ltr: [
    "ltra",
    "ltrm"
  ],
  rtl: [
    "rtla",
    "rtlm"
  ]
};
class v0 {
  static plan(e, t, r) {
    this.planPreprocessing(e), this.planFeatures(e), this.planPostprocessing(e, r), e.assignGlobalFeatures(t), this.assignFeatures(e, t);
  }
  static planPreprocessing(e) {
    e.add({
      global: [
        ...sc,
        ...lc[e.direction]
      ],
      local: nc
    });
  }
  static planFeatures(e) {
  }
  static planPostprocessing(e, t) {
    e.add([
      ...ac,
      ...ic
    ]), e.setFeatureOverrides(t);
  }
  static assignFeatures(e, t) {
    for (let r = 0; r < t.length; r++) {
      let s = t[r];
      if (s.codePoints[0] === 8260) {
        let n = r, a = r + 1;
        for (; n > 0 && Is(t[n - 1].codePoints[0]); )
          t[n - 1].features.numr = !0, t[n - 1].features.frac = !0, n--;
        for (; a < t.length && Is(t[a].codePoints[0]); )
          t[a].features.dnom = !0, t[a].features.frac = !0, a++;
        s.features.frac = !0, r = a - 1;
      }
    }
  }
}
De(v0, "zeroMarkWidths", "AFTER_GPOS");
const oc = new Gt(Zr("APABAAAAAAAAOAAAAf0BAv7tmi1MxDAUx7vtvjhAgcDgkEgEAnmXEBIMCYaEcygEiqBQ4FAkCE4ikUgMiiBJSAgSiUQSDMn9L9eSl6bddddug9t7yS/trevre+3r27pcNxZiG+yCfdCVv/9LeQxOwRm4AJegD27ALbgD9+ABPJF+z+BN/h7yDj5k/VOWX6SdmU5+wLWknggxDxaS8u0qiiX4uiz9XamQ3wzDMAzDMAzDMAzDVI/h959V/v7BMAzDMAzDMLlyNTNiMSdewVxbiA44B4/guz1qW58VYlMI0WsJ0W+N6kXw0spvPtdwhtkwnGM6uLaV4Xyzg3v3PM9DPfQ/sOg4xPWjipy31P8LTqbU304c/cLCUmWJLNB2Uz2U1KTeRKNmKHVMfbJC+/0loTZRH/W5cvEvBJPMbREkWt3FD1NcqXZBSpuE2Ad0PBehPtNrPtIEdYP+hiRt/V1jIiE69X4NT/uVZI3PUHE9bm5M7ePGdZWy951v7Nn6j8v1WWKP3mt6ttnsigx6VN7Vc0VomSSGqW2mGNP1muZPl7LfjNUaKNFtDGVf2fvE9O7VlBS5j333c5p/eeoOqcs1R/hIqDWLJ7TTlksirVT1SI7l8k4Yp+g3jafGcrU1RM6l9th80XOpnlN97bDNY4i4s61B0Si/ipa0uHMl6zqEjlFfCZm/TM8KmzQDjmuTAQ==")), da = [
  "isol",
  "fina",
  "fin2",
  "fin3",
  "medi",
  "med2",
  "init"
], Rr = {
  Non_Joining: 0,
  Transparent: 6
}, pe = "isol", c0 = "fina", Pr = "fin2", uc = "fin3", mt = "medi", wt = "med2", yt = "init", ie = null, cc = [
  //   Non_Joining,        Left_Joining,       Right_Joining,     Dual_Joining,           ALAPH,            DALATH RISH
  // State 0: prev was U,  not willing to join.
  [
    [
      ie,
      ie,
      0
    ],
    [
      ie,
      pe,
      2
    ],
    [
      ie,
      pe,
      1
    ],
    [
      ie,
      pe,
      2
    ],
    [
      ie,
      pe,
      1
    ],
    [
      ie,
      pe,
      6
    ]
  ],
  // State 1: prev was R or ISOL/ALAPH,  not willing to join.
  [
    [
      ie,
      ie,
      0
    ],
    [
      ie,
      pe,
      2
    ],
    [
      ie,
      pe,
      1
    ],
    [
      ie,
      pe,
      2
    ],
    [
      ie,
      Pr,
      5
    ],
    [
      ie,
      pe,
      6
    ]
  ],
  // State 2: prev was D/L in ISOL form,  willing to join.
  [
    [
      ie,
      ie,
      0
    ],
    [
      ie,
      pe,
      2
    ],
    [
      yt,
      c0,
      1
    ],
    [
      yt,
      c0,
      3
    ],
    [
      yt,
      c0,
      4
    ],
    [
      yt,
      c0,
      6
    ]
  ],
  // State 3: prev was D in FINA form,  willing to join.
  [
    [
      ie,
      ie,
      0
    ],
    [
      ie,
      pe,
      2
    ],
    [
      mt,
      c0,
      1
    ],
    [
      mt,
      c0,
      3
    ],
    [
      mt,
      c0,
      4
    ],
    [
      mt,
      c0,
      6
    ]
  ],
  // State 4: prev was FINA ALAPH,  not willing to join.
  [
    [
      ie,
      ie,
      0
    ],
    [
      ie,
      pe,
      2
    ],
    [
      wt,
      pe,
      1
    ],
    [
      wt,
      pe,
      2
    ],
    [
      wt,
      Pr,
      5
    ],
    [
      wt,
      pe,
      6
    ]
  ],
  // State 5: prev was FIN2/FIN3 ALAPH,  not willing to join.
  [
    [
      ie,
      ie,
      0
    ],
    [
      ie,
      pe,
      2
    ],
    [
      pe,
      pe,
      1
    ],
    [
      pe,
      pe,
      2
    ],
    [
      pe,
      Pr,
      5
    ],
    [
      pe,
      pe,
      6
    ]
  ],
  // State 6: prev was DALATH/RISH,  not willing to join.
  [
    [
      ie,
      ie,
      0
    ],
    [
      ie,
      pe,
      2
    ],
    [
      ie,
      pe,
      1
    ],
    [
      ie,
      pe,
      2
    ],
    [
      ie,
      uc,
      5
    ],
    [
      ie,
      pe,
      6
    ]
  ]
];
class f0 extends v0 {
  static planFeatures(e) {
    e.add([
      "ccmp",
      "locl"
    ]);
    for (let t = 0; t < da.length; t++) {
      let r = da[t];
      e.addStage(r, !1);
    }
    e.addStage("mset");
  }
  static assignFeatures(e, t) {
    super.assignFeatures(e, t);
    let r = -1, s = 0, n = [];
    for (let o = 0; o < t.length; o++) {
      let u, c;
      var a = t[o];
      let d = fc(a.codePoints[0]);
      if (d === Rr.Transparent) {
        n[o] = ie;
        continue;
      }
      [c, u, s] = cc[s][d], c !== ie && r !== -1 && (n[r] = c), n[o] = u, r = o;
    }
    for (let o = 0; o < t.length; o++) {
      let u;
      var a = t[o];
      (u = n[o]) && (a.features[u] = !0);
    }
  }
}
function fc(i) {
  let e = oc.get(i);
  if (e) return e - 1;
  let t = zt(i);
  return t === "Mn" || t === "Me" || t === "Cf" ? Rr.Transparent : Rr.Non_Joining;
}
class dc {
  reset(e = {}, t = 0) {
    this.options = e, this.flags = e.flags || {}, this.markAttachmentType = e.markAttachmentType || 0, this.index = t;
  }
  get cur() {
    return this.glyphs[this.index] || null;
  }
  shouldIgnore(e) {
    return this.flags.ignoreMarks && e.isMark || this.flags.ignoreBaseGlyphs && e.isBase || this.flags.ignoreLigatures && e.isLigature || this.markAttachmentType && e.isMark && e.markAttachmentType !== this.markAttachmentType;
  }
  move(e) {
    for (this.index += e; 0 <= this.index && this.index < this.glyphs.length && this.shouldIgnore(this.glyphs[this.index]); ) this.index += e;
    return 0 > this.index || this.index >= this.glyphs.length ? null : this.glyphs[this.index];
  }
  next() {
    return this.move(1);
  }
  prev() {
    return this.move(-1);
  }
  peek(e = 1) {
    let t = this.index, r = this.increment(e);
    return this.index = t, r;
  }
  peekIndex(e = 1) {
    let t = this.index;
    this.increment(e);
    let r = this.index;
    return this.index = t, r;
  }
  increment(e = 1) {
    let t = e < 0 ? -1 : 1;
    for (e = Math.abs(e); e--; ) this.move(t);
    return this.glyphs[this.index];
  }
  constructor(e, t) {
    this.glyphs = e, this.reset(t);
  }
}
const hc = [
  "DFLT",
  "dflt",
  "latn"
];
class Bt {
  findScript(e) {
    if (this.table.scriptList == null) return null;
    Array.isArray(e) || (e = [
      e
    ]);
    for (let t of e) for (let r of this.table.scriptList)
      if (r.tag === t) return r;
    return null;
  }
  selectScript(e, t, r) {
    let s = !1, n;
    if (!this.script || e !== this.scriptTag) {
      if (n = this.findScript(e), n || (n = this.findScript(hc)), !n) return this.scriptTag;
      this.scriptTag = n.tag, this.script = n.script, this.language = null, this.languageTag = null, s = !0;
    }
    if ((!r || r !== this.direction) && (this.direction = r || un(e)), t && t.length < 4 && (t += " ".repeat(4 - t.length)), !t || t !== this.languageTag) {
      this.language = null;
      for (let a of this.script.langSysRecords) if (a.tag === t) {
        this.language = a.langSys, this.languageTag = a.tag;
        break;
      }
      this.language || (this.language = this.script.defaultLangSys, this.languageTag = null), s = !0;
    }
    if (s && (this.features = {}, this.language))
      for (let a of this.language.featureIndexes) {
        let o = this.table.featureList[a], u = this.substituteFeatureForVariations(a);
        this.features[o.tag] = u || o.feature;
      }
    return this.scriptTag;
  }
  lookupsForFeatures(e = [], t) {
    let r = [];
    for (let s of e) {
      let n = this.features[s];
      if (n)
        for (let a of n.lookupListIndexes)
          t && t.indexOf(a) !== -1 || r.push({
            feature: s,
            index: a,
            lookup: this.table.lookupList.get(a)
          });
    }
    return r.sort((s, n) => s.index - n.index), r;
  }
  substituteFeatureForVariations(e) {
    if (this.variationsIndex === -1) return null;
    let r = this.table.featureVariations.featureVariationRecords[this.variationsIndex].featureTableSubstitution.substitutions;
    for (let s of r)
      if (s.featureIndex === e) return s.alternateFeatureTable;
    return null;
  }
  findVariationsIndex(e) {
    let t = this.table.featureVariations;
    if (!t) return -1;
    let r = t.featureVariationRecords;
    for (let s = 0; s < r.length; s++) {
      let n = r[s].conditionSet.conditionTable;
      if (this.variationConditionsMatch(n, e)) return s;
    }
    return -1;
  }
  variationConditionsMatch(e, t) {
    return e.every((r) => {
      let s = r.axisIndex < t.length ? t[r.axisIndex] : 0;
      return r.filterRangeMinValue <= s && s <= r.filterRangeMaxValue;
    });
  }
  applyFeatures(e, t, r) {
    let s = this.lookupsForFeatures(e);
    this.applyLookups(s, t, r);
  }
  applyLookups(e, t, r) {
    this.glyphs = t, this.positions = r, this.glyphIterator = new dc(t);
    for (let { feature: s, lookup: n } of e)
      for (this.currentFeature = s, this.glyphIterator.reset(n.flags); this.glyphIterator.index < t.length; ) {
        if (!(s in this.glyphIterator.cur.features)) {
          this.glyphIterator.next();
          continue;
        }
        for (let a of n.subTables)
          if (this.applyLookup(n.lookupType, a)) break;
        this.glyphIterator.next();
      }
  }
  applyLookup(e, t) {
    throw new Error("applyLookup must be implemented by subclasses");
  }
  applyLookupList(e) {
    let t = this.glyphIterator.options, r = this.glyphIterator.index;
    for (let s of e) {
      this.glyphIterator.reset(t, r), this.glyphIterator.increment(s.sequenceIndex);
      let n = this.table.lookupList.get(s.lookupListIndex);
      this.glyphIterator.reset(n.flags, this.glyphIterator.index);
      for (let a of n.subTables)
        if (this.applyLookup(n.lookupType, a)) break;
    }
    return this.glyphIterator.reset(t, r), !0;
  }
  coverageIndex(e, t) {
    switch (t == null && (t = this.glyphIterator.cur.id), e.version) {
      case 1:
        return e.glyphs.indexOf(t);
      case 2:
        for (let r of e.rangeRecords)
          if (r.start <= t && t <= r.end) return r.startCoverageIndex + t - r.start;
        break;
    }
    return -1;
  }
  match(e, t, r, s) {
    let n = this.glyphIterator.index, a = this.glyphIterator.increment(e), o = 0;
    for (; o < t.length && a && r(t[o], a); )
      s && s.push(this.glyphIterator.index), o++, a = this.glyphIterator.next();
    return this.glyphIterator.index = n, o < t.length ? !1 : s || !0;
  }
  sequenceMatches(e, t) {
    return this.match(e, t, (r, s) => r === s.id);
  }
  sequenceMatchIndices(e, t) {
    return this.match(e, t, (r, s) => this.currentFeature in s.features ? r === s.id : !1, []);
  }
  coverageSequenceMatches(e, t) {
    return this.match(e, t, (r, s) => this.coverageIndex(r, s.id) >= 0);
  }
  getClassID(e, t) {
    switch (t.version) {
      case 1:
        let r = e - t.startGlyph;
        if (r >= 0 && r < t.classValueArray.length) return t.classValueArray[r];
        break;
      case 2:
        for (let s of t.classRangeRecord)
          if (s.start <= e && e <= s.end) return s.class;
        break;
    }
    return 0;
  }
  classSequenceMatches(e, t, r) {
    return this.match(e, t, (s, n) => s === this.getClassID(n.id, r));
  }
  applyContext(e) {
    let t, r;
    switch (e.version) {
      case 1:
        if (t = this.coverageIndex(e.coverage), t === -1) return !1;
        r = e.ruleSets[t];
        for (let s of r)
          if (this.sequenceMatches(1, s.input)) return this.applyLookupList(s.lookupRecords);
        break;
      case 2:
        if (this.coverageIndex(e.coverage) === -1 || (t = this.getClassID(this.glyphIterator.cur.id, e.classDef), t === -1)) return !1;
        r = e.classSet[t];
        for (let s of r)
          if (this.classSequenceMatches(1, s.classes, e.classDef)) return this.applyLookupList(s.lookupRecords);
        break;
      case 3:
        if (this.coverageSequenceMatches(0, e.coverages)) return this.applyLookupList(e.lookupRecords);
        break;
    }
    return !1;
  }
  applyChainingContext(e) {
    let t;
    switch (e.version) {
      case 1:
        if (t = this.coverageIndex(e.coverage), t === -1) return !1;
        let r = e.chainRuleSets[t];
        for (let n of r)
          if (this.sequenceMatches(-n.backtrack.length, n.backtrack) && this.sequenceMatches(1, n.input) && this.sequenceMatches(1 + n.input.length, n.lookahead)) return this.applyLookupList(n.lookupRecords);
        break;
      case 2:
        if (this.coverageIndex(e.coverage) === -1) return !1;
        t = this.getClassID(this.glyphIterator.cur.id, e.inputClassDef);
        let s = e.chainClassSet[t];
        if (!s) return !1;
        for (let n of s)
          if (this.classSequenceMatches(-n.backtrack.length, n.backtrack, e.backtrackClassDef) && this.classSequenceMatches(1, n.input, e.inputClassDef) && this.classSequenceMatches(1 + n.input.length, n.lookahead, e.lookaheadClassDef)) return this.applyLookupList(n.lookupRecords);
        break;
      case 3:
        if (this.coverageSequenceMatches(-e.backtrackGlyphCount, e.backtrackCoverage) && this.coverageSequenceMatches(0, e.inputCoverage) && this.coverageSequenceMatches(e.inputGlyphCount, e.lookaheadCoverage)) return this.applyLookupList(e.lookupRecords);
        break;
    }
    return !1;
  }
  constructor(e, t) {
    this.font = e, this.table = t, this.script = null, this.scriptTag = null, this.language = null, this.languageTag = null, this.features = {}, this.lookups = {}, this.variationsIndex = e._variationProcessor ? this.findVariationsIndex(e._variationProcessor.normalizedCoords) : -1, this.selectScript(), this.glyphs = [], this.positions = [], this.ligatureID = 1, this.currentFeature = null;
  }
}
class qe {
  get id() {
    return this._id;
  }
  set id(e) {
    this._id = e, this.substituted = !0;
    let t = this._font.GDEF;
    if (t && t.glyphClassDef) {
      let r = Bt.prototype.getClassID(e, t.glyphClassDef);
      this.isBase = r === 1, this.isLigature = r === 2, this.isMark = r === 3, this.markAttachmentType = t.markAttachClassDef ? Bt.prototype.getClassID(e, t.markAttachClassDef) : 0;
    } else
      this.isMark = this.codePoints.length > 0 && this.codePoints.every(Ra), this.isBase = !this.isMark, this.isLigature = this.codePoints.length > 1, this.markAttachmentType = 0;
  }
  copy() {
    return new qe(this._font, this.id, this.codePoints, this.features);
  }
  constructor(e, t, r = [], s) {
    if (this._font = e, this.codePoints = r, this.id = t, this.features = {}, Array.isArray(s)) for (let n = 0; n < s.length; n++) {
      let a = s[n];
      this.features[a] = !0;
    }
    else typeof s == "object" && Object.assign(this.features, s);
    this.ligatureID = null, this.ligatureComponent = null, this.isLigated = !1, this.cursiveAttachment = null, this.markAttachment = null, this.shaperInfo = null, this.substituted = !1, this.isMultiplied = !1;
  }
}
class fn extends v0 {
  static planFeatures(e) {
    e.add([
      "ljmo",
      "vjmo",
      "tjmo"
    ], !1);
  }
  static assignFeatures(e, t) {
    let r = 0, s = 0;
    for (; s < t.length; ) {
      let n, o = t[s].codePoints[0], u = Nt(o);
      switch ([n, r] = Fc[r][u], n) {
        case t0:
          e.font.hasGlyphForCodePoint(o) || (s = pn(t, s, e.font));
          break;
        case Nr:
          s = Dc(t, s, e.font);
          break;
        case Ur:
          Lc(t, s, e.font);
          break;
        case Gr:
          s = Mc(t, s, e.font);
          break;
      }
      s++;
    }
  }
}
De(fn, "zeroMarkWidths", "NONE");
const N0 = 44032, dn = 55204, pc = dn - N0 + 1, Xt = 4352, jt = 4449, I0 = 4519, bc = 19, Lt = 21, at = 28, gc = Xt + bc - 1, vc = jt + Lt - 1, xc = I0 + at - 1, ha = 9676, mc = (i) => 4352 <= i && i <= 4447 || 43360 <= i && i <= 43388, wc = (i) => 4448 <= i && i <= 4519 || 55216 <= i && i <= 55238, yc = (i) => 4520 <= i && i <= 4607 || 55243 <= i && i <= 55291, Cc = (i) => 12334 <= i && i <= 12335, Sc = (i) => N0 <= i && i <= dn, Ac = (i) => i - N0 < pc && (i - N0) % at === 0, Ic = (i) => Xt <= i && i <= gc, kc = (i) => jt <= i && i <= vc, Ec = (i) => 1 <= i && i <= xc, Pc = 0, Tc = 1, Mt = 2, Jr = 3, Rt = 4, hn = 5, Oc = 6;
function Nt(i) {
  return mc(i) ? Tc : wc(i) ? Mt : yc(i) ? Jr : Ac(i) ? Rt : Sc(i) ? hn : Cc(i) ? Oc : Pc;
}
const Fe = 0, t0 = 1, Nr = 2, Ur = 4, Gr = 5, Fc = [
  //       X                 L                 V                T                  LV                LVT               M
  // State 0: start state
  [
    [
      Fe,
      0
    ],
    [
      Fe,
      1
    ],
    [
      Fe,
      0
    ],
    [
      Fe,
      0
    ],
    [
      t0,
      2
    ],
    [
      t0,
      3
    ],
    [
      Gr,
      0
    ]
  ],
  // State 1: <L>
  [
    [
      Fe,
      0
    ],
    [
      Fe,
      1
    ],
    [
      Nr,
      2
    ],
    [
      Fe,
      0
    ],
    [
      t0,
      2
    ],
    [
      t0,
      3
    ],
    [
      Gr,
      0
    ]
  ],
  // State 2: <L,V> or <LV>
  [
    [
      Fe,
      0
    ],
    [
      Fe,
      1
    ],
    [
      Fe,
      0
    ],
    [
      Nr,
      3
    ],
    [
      t0,
      2
    ],
    [
      t0,
      3
    ],
    [
      Ur,
      0
    ]
  ],
  // State 3: <L,V,T> or <LVT>
  [
    [
      Fe,
      0
    ],
    [
      Fe,
      1
    ],
    [
      Fe,
      0
    ],
    [
      Fe,
      0
    ],
    [
      t0,
      2
    ],
    [
      t0,
      3
    ],
    [
      Ur,
      0
    ]
  ]
];
function _0(i, e, t) {
  return new qe(i, i.glyphForCodePoint(e).id, [
    e
  ], t);
}
function pn(i, e, t) {
  let r = i[e], n = r.codePoints[0] - N0, a = I0 + n % at;
  n = n / at | 0;
  let o = Xt + n / Lt | 0, u = jt + n % Lt;
  if (!t.hasGlyphForCodePoint(o) || !t.hasGlyphForCodePoint(u) || a !== I0 && !t.hasGlyphForCodePoint(a)) return e;
  let c = _0(t, o, r.features);
  c.features.ljmo = !0;
  let d = _0(t, u, r.features);
  d.features.vjmo = !0;
  let f = [
    c,
    d
  ];
  if (a > I0) {
    let p = _0(t, a, r.features);
    p.features.tjmo = !0, f.push(p);
  }
  return i.splice(e, 1, ...f), e + f.length - 1;
}
function Dc(i, e, t) {
  let r = i[e], s = i[e].codePoints[0], n = Nt(s), a = i[e - 1].codePoints[0], o = Nt(a), u, c, d, f;
  if (o === Rt && n === Jr)
    u = a, f = r;
  else {
    n === Mt ? (c = i[e - 1], d = r) : (c = i[e - 2], d = i[e - 1], f = r);
    let m = c.codePoints[0], C = d.codePoints[0];
    Ic(m) && kc(C) && (u = N0 + ((m - Xt) * Lt + (C - jt)) * at);
  }
  let p = f && f.codePoints[0] || I0;
  if (u != null && (p === I0 || Ec(p))) {
    let m = u + (p - I0);
    if (t.hasGlyphForCodePoint(m)) {
      let C = o === Mt ? 3 : 2;
      return i.splice(e - C + 1, C, _0(t, m, r.features)), e - C + 1;
    }
  }
  return c && (c.features.ljmo = !0), d && (d.features.vjmo = !0), f && (f.features.tjmo = !0), o === Rt ? (pn(i, e - 1, t), e + 1) : e;
}
function Bc(i) {
  switch (Nt(i)) {
    case Rt:
    case hn:
      return 1;
    case Mt:
      return 2;
    case Jr:
      return 3;
  }
}
function Lc(i, e, t) {
  let r = i[e], s = i[e].codePoints[0];
  if (t.glyphForCodePoint(s).advanceWidth === 0) return;
  let n = i[e - 1].codePoints[0], a = Bc(n);
  return i.splice(e, 1), i.splice(e - a, 0, r);
}
function Mc(i, e, t) {
  let r = i[e], s = i[e].codePoints[0];
  if (t.hasGlyphForCodePoint(ha)) {
    let n = _0(t, ha, r.features), a = t.glyphForCodePoint(s).advanceWidth === 0 ? e : e + 1;
    i.splice(a, 0, n), e++;
  }
  return e;
}
var bn = {};
bn = JSON.parse('{"stateTable":[[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,2,3,4,5,6,7,8,9,0,10,11,11,12,13,14,15,16,17],[0,0,0,18,19,20,21,22,23,0,24,0,0,25,26,0,0,27,0],[0,0,0,28,29,30,31,32,33,0,34,0,0,35,36,0,0,37,0],[0,0,0,38,5,7,7,8,9,0,10,0,0,0,13,0,0,16,0],[0,39,0,0,0,40,41,0,9,0,10,0,0,0,42,0,39,0,0],[0,0,0,0,43,44,44,8,9,0,0,0,0,12,43,0,0,0,0],[0,0,0,0,43,44,44,8,9,0,0,0,0,0,43,0,0,0,0],[0,0,0,45,46,47,48,49,9,0,10,0,0,0,42,0,0,0,0],[0,0,0,0,0,50,0,0,51,0,10,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,52,0,0,0,0,0,0,0,0],[0,0,0,53,54,55,56,57,58,0,59,0,0,60,61,0,0,62,0],[0,0,0,4,5,7,7,8,9,0,10,0,0,0,13,0,0,16,0],[0,63,64,0,0,40,41,0,9,0,10,0,0,0,42,0,63,0,0],[0,2,3,4,5,6,7,8,9,0,10,11,11,12,13,0,2,16,0],[0,0,0,18,65,20,21,22,23,0,24,0,0,25,26,0,0,27,0],[0,0,0,0,66,67,67,8,9,0,10,0,0,0,68,0,0,0,0],[0,0,0,69,0,70,70,0,71,0,72,0,0,0,0,0,0,0,0],[0,0,0,73,19,74,74,22,23,0,24,0,0,0,26,0,0,27,0],[0,75,0,0,0,76,77,0,23,0,24,0,0,0,78,0,75,0,0],[0,0,0,0,79,80,80,22,23,0,0,0,0,25,79,0,0,0,0],[0,0,0,18,19,20,74,22,23,0,24,0,0,25,26,0,0,27,0],[0,0,0,81,82,83,84,85,23,0,24,0,0,0,78,0,0,0,0],[0,0,0,0,0,86,0,0,87,0,24,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,88,0,0,0,0,0,0,0,0],[0,0,0,18,19,74,74,22,23,0,24,0,0,0,26,0,0,27,0],[0,89,90,0,0,76,77,0,23,0,24,0,0,0,78,0,89,0,0],[0,0,0,0,91,92,92,22,23,0,24,0,0,0,93,0,0,0,0],[0,0,0,94,29,95,31,32,33,0,34,0,0,0,36,0,0,37,0],[0,96,0,0,0,97,98,0,33,0,34,0,0,0,99,0,96,0,0],[0,0,0,0,100,101,101,32,33,0,0,0,0,35,100,0,0,0,0],[0,0,0,0,100,101,101,32,33,0,0,0,0,0,100,0,0,0,0],[0,0,0,102,103,104,105,106,33,0,34,0,0,0,99,0,0,0,0],[0,0,0,0,0,107,0,0,108,0,34,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,109,0,0,0,0,0,0,0,0],[0,0,0,28,29,95,31,32,33,0,34,0,0,0,36,0,0,37,0],[0,110,111,0,0,97,98,0,33,0,34,0,0,0,99,0,110,0,0],[0,0,0,0,112,113,113,32,33,0,34,0,0,0,114,0,0,0,0],[0,0,0,0,5,7,7,8,9,0,10,0,0,0,13,0,0,16,0],[0,0,0,115,116,117,118,8,9,0,10,0,0,119,120,0,0,16,0],[0,0,0,0,0,121,121,0,9,0,10,0,0,0,42,0,0,0,0],[0,39,0,122,0,123,123,8,9,0,10,0,0,0,42,0,39,0,0],[0,124,64,0,0,0,0,0,0,0,0,0,0,0,0,0,124,0,0],[0,39,0,0,0,121,125,0,9,0,10,0,0,0,42,0,39,0,0],[0,0,0,0,0,126,126,8,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,46,47,48,49,9,0,10,0,0,0,42,0,0,0,0],[0,0,0,0,0,47,47,49,9,0,10,0,0,0,42,0,0,0,0],[0,0,0,0,0,127,127,49,9,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,128,127,127,49,9,0,0,0,0,0,0,0,0,0,0],[0,0,0,129,130,131,132,133,9,0,10,0,0,0,42,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,10,0,0,0,0,0,0,0,0],[0,0,0,0,0,50,0,0,0,0,10,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,134,0,0,0,0,0,0,0,0],[0,0,0,135,54,56,56,57,58,0,59,0,0,0,61,0,0,62,0],[0,136,0,0,0,137,138,0,58,0,59,0,0,0,139,0,136,0,0],[0,0,0,0,140,141,141,57,58,0,0,0,0,60,140,0,0,0,0],[0,0,0,0,140,141,141,57,58,0,0,0,0,0,140,0,0,0,0],[0,0,0,142,143,144,145,146,58,0,59,0,0,0,139,0,0,0,0],[0,0,0,0,0,147,0,0,148,0,59,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,149,0,0,0,0,0,0,0,0],[0,0,0,53,54,56,56,57,58,0,59,0,0,0,61,0,0,62,0],[0,150,151,0,0,137,138,0,58,0,59,0,0,0,139,0,150,0,0],[0,0,0,0,152,153,153,57,58,0,59,0,0,0,154,0,0,0,0],[0,0,0,155,116,156,157,8,9,0,10,0,0,158,120,0,0,16,0],[0,0,0,0,0,121,121,0,9,0,10,0,0,0,0,0,0,0,0],[0,75,3,4,5,159,160,8,161,0,162,0,11,12,163,0,75,16,0],[0,0,0,0,0,40,164,0,9,0,10,0,0,0,42,0,0,0,0],[0,0,0,0,165,44,44,8,9,0,0,0,0,0,165,0,0,0,0],[0,124,64,0,0,40,164,0,9,0,10,0,0,0,42,0,124,0,0],[0,0,0,0,0,70,70,0,71,0,72,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,71,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,166,0,0,167,0,72,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,168,0,0,0,0,0,0,0,0],[0,0,0,0,19,74,74,22,23,0,24,0,0,0,26,0,0,27,0],[0,0,0,0,79,80,80,22,23,0,0,0,0,0,79,0,0,0,0],[0,0,0,169,170,171,172,22,23,0,24,0,0,173,174,0,0,27,0],[0,0,0,0,0,175,175,0,23,0,24,0,0,0,78,0,0,0,0],[0,75,0,176,0,177,177,22,23,0,24,0,0,0,78,0,75,0,0],[0,178,90,0,0,0,0,0,0,0,0,0,0,0,0,0,178,0,0],[0,75,0,0,0,175,179,0,23,0,24,0,0,0,78,0,75,0,0],[0,0,0,0,0,180,180,22,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,82,83,84,85,23,0,24,0,0,0,78,0,0,0,0],[0,0,0,0,0,83,83,85,23,0,24,0,0,0,78,0,0,0,0],[0,0,0,0,0,181,181,85,23,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,182,181,181,85,23,0,0,0,0,0,0,0,0,0,0],[0,0,0,183,184,185,186,187,23,0,24,0,0,0,78,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,24,0,0,0,0,0,0,0,0],[0,0,0,0,0,86,0,0,0,0,24,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,188,0,0,0,0,0,0,0,0],[0,0,0,189,170,190,191,22,23,0,24,0,0,192,174,0,0,27,0],[0,0,0,0,0,175,175,0,23,0,24,0,0,0,0,0,0,0,0],[0,0,0,0,0,76,193,0,23,0,24,0,0,0,78,0,0,0,0],[0,0,0,0,194,80,80,22,23,0,0,0,0,0,194,0,0,0,0],[0,178,90,0,0,76,193,0,23,0,24,0,0,0,78,0,178,0,0],[0,0,0,0,29,95,31,32,33,0,34,0,0,0,36,0,0,37,0],[0,0,0,0,100,101,101,32,33,0,0,0,0,0,100,0,0,0,0],[0,0,0,195,196,197,198,32,33,0,34,0,0,199,200,0,0,37,0],[0,0,0,0,0,201,201,0,33,0,34,0,0,0,99,0,0,0,0],[0,96,0,202,0,203,203,32,33,0,34,0,0,0,99,0,96,0,0],[0,204,111,0,0,0,0,0,0,0,0,0,0,0,0,0,204,0,0],[0,96,0,0,0,201,205,0,33,0,34,0,0,0,99,0,96,0,0],[0,0,0,0,0,206,206,32,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,103,104,105,106,33,0,34,0,0,0,99,0,0,0,0],[0,0,0,0,0,104,104,106,33,0,34,0,0,0,99,0,0,0,0],[0,0,0,0,0,207,207,106,33,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,208,207,207,106,33,0,0,0,0,0,0,0,0,0,0],[0,0,0,209,210,211,212,213,33,0,34,0,0,0,99,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,34,0,0,0,0,0,0,0,0],[0,0,0,0,0,107,0,0,0,0,34,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,214,0,0,0,0,0,0,0,0],[0,0,0,215,196,216,217,32,33,0,34,0,0,218,200,0,0,37,0],[0,0,0,0,0,201,201,0,33,0,34,0,0,0,0,0,0,0,0],[0,0,0,0,0,97,219,0,33,0,34,0,0,0,99,0,0,0,0],[0,0,0,0,220,101,101,32,33,0,0,0,0,0,220,0,0,0,0],[0,204,111,0,0,97,219,0,33,0,34,0,0,0,99,0,204,0,0],[0,0,0,221,116,222,222,8,9,0,10,0,0,0,120,0,0,16,0],[0,223,0,0,0,40,224,0,9,0,10,0,0,0,42,0,223,0,0],[0,0,0,0,225,44,44,8,9,0,0,0,0,119,225,0,0,0,0],[0,0,0,115,116,117,222,8,9,0,10,0,0,119,120,0,0,16,0],[0,0,0,115,116,222,222,8,9,0,10,0,0,0,120,0,0,16,0],[0,226,64,0,0,40,224,0,9,0,10,0,0,0,42,0,226,0,0],[0,0,0,0,0,0,0,0,9,0,0,0,0,0,0,0,0,0,0],[0,39,0,0,0,121,121,0,9,0,10,0,0,0,42,0,39,0,0],[0,0,0,0,0,44,44,8,9,0,0,0,0,0,0,0,0,0,0],[0,0,0,227,0,228,229,0,9,0,10,0,0,230,0,0,0,0,0],[0,39,0,122,0,121,121,0,9,0,10,0,0,0,42,0,39,0,0],[0,0,0,0,0,0,0,8,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,231,231,49,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,232,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,130,131,132,133,9,0,10,0,0,0,42,0,0,0,0],[0,0,0,0,0,131,131,133,9,0,10,0,0,0,42,0,0,0,0],[0,0,0,0,0,233,233,133,9,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,234,233,233,133,9,0,0,0,0,0,0,0,0,0,0],[0,0,0,235,236,237,238,239,9,0,10,0,0,0,42,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,54,56,56,57,58,0,59,0,0,0,61,0,0,62,0],[0,0,0,240,241,242,243,57,58,0,59,0,0,244,245,0,0,62,0],[0,0,0,0,0,246,246,0,58,0,59,0,0,0,139,0,0,0,0],[0,136,0,247,0,248,248,57,58,0,59,0,0,0,139,0,136,0,0],[0,249,151,0,0,0,0,0,0,0,0,0,0,0,0,0,249,0,0],[0,136,0,0,0,246,250,0,58,0,59,0,0,0,139,0,136,0,0],[0,0,0,0,0,251,251,57,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,143,144,145,146,58,0,59,0,0,0,139,0,0,0,0],[0,0,0,0,0,144,144,146,58,0,59,0,0,0,139,0,0,0,0],[0,0,0,0,0,252,252,146,58,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,253,252,252,146,58,0,0,0,0,0,0,0,0,0,0],[0,0,0,254,255,256,257,258,58,0,59,0,0,0,139,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,59,0,0,0,0,0,0,0,0],[0,0,0,0,0,147,0,0,0,0,59,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,259,0,0,0,0,0,0,0,0],[0,0,0,260,241,261,262,57,58,0,59,0,0,263,245,0,0,62,0],[0,0,0,0,0,246,246,0,58,0,59,0,0,0,0,0,0,0,0],[0,0,0,0,0,137,264,0,58,0,59,0,0,0,139,0,0,0,0],[0,0,0,0,265,141,141,57,58,0,0,0,0,0,265,0,0,0,0],[0,249,151,0,0,137,264,0,58,0,59,0,0,0,139,0,249,0,0],[0,0,0,221,116,222,222,8,9,0,10,0,0,0,120,0,0,16,0],[0,0,0,0,225,44,44,8,9,0,0,0,0,158,225,0,0,0,0],[0,0,0,155,116,156,222,8,9,0,10,0,0,158,120,0,0,16,0],[0,0,0,155,116,222,222,8,9,0,10,0,0,0,120,0,0,16,0],[0,0,0,0,43,266,266,8,161,0,24,0,0,12,267,0,0,0,0],[0,75,0,176,43,268,268,269,161,0,24,0,0,0,267,0,75,0,0],[0,0,0,0,0,270,0,0,271,0,162,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,272,0,0,0,0,0,0,0,0],[0,273,274,0,0,40,41,0,9,0,10,0,0,0,42,0,273,0,0],[0,0,0,40,0,123,123,8,9,0,10,0,0,0,42,0,0,0,0],[0,0,0,0,0,121,275,0,9,0,10,0,0,0,42,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,72,0,0,0,0,0,0,0,0],[0,0,0,0,0,166,0,0,0,0,72,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,276,0,0,0,0,0,0,0,0],[0,0,0,277,170,278,278,22,23,0,24,0,0,0,174,0,0,27,0],[0,279,0,0,0,76,280,0,23,0,24,0,0,0,78,0,279,0,0],[0,0,0,0,281,80,80,22,23,0,0,0,0,173,281,0,0,0,0],[0,0,0,169,170,171,278,22,23,0,24,0,0,173,174,0,0,27,0],[0,0,0,169,170,278,278,22,23,0,24,0,0,0,174,0,0,27,0],[0,282,90,0,0,76,280,0,23,0,24,0,0,0,78,0,282,0,0],[0,0,0,0,0,0,0,0,23,0,0,0,0,0,0,0,0,0,0],[0,75,0,0,0,175,175,0,23,0,24,0,0,0,78,0,75,0,0],[0,0,0,0,0,80,80,22,23,0,0,0,0,0,0,0,0,0,0],[0,0,0,283,0,284,285,0,23,0,24,0,0,286,0,0,0,0,0],[0,75,0,176,0,175,175,0,23,0,24,0,0,0,78,0,75,0,0],[0,0,0,0,0,0,0,22,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,287,287,85,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,288,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,184,185,186,187,23,0,24,0,0,0,78,0,0,0,0],[0,0,0,0,0,185,185,187,23,0,24,0,0,0,78,0,0,0,0],[0,0,0,0,0,289,289,187,23,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,290,289,289,187,23,0,0,0,0,0,0,0,0,0,0],[0,0,0,291,292,293,294,295,23,0,24,0,0,0,78,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,277,170,278,278,22,23,0,24,0,0,0,174,0,0,27,0],[0,0,0,0,281,80,80,22,23,0,0,0,0,192,281,0,0,0,0],[0,0,0,189,170,190,278,22,23,0,24,0,0,192,174,0,0,27,0],[0,0,0,189,170,278,278,22,23,0,24,0,0,0,174,0,0,27,0],[0,0,0,76,0,177,177,22,23,0,24,0,0,0,78,0,0,0,0],[0,0,0,0,0,175,296,0,23,0,24,0,0,0,78,0,0,0,0],[0,0,0,297,196,298,298,32,33,0,34,0,0,0,200,0,0,37,0],[0,299,0,0,0,97,300,0,33,0,34,0,0,0,99,0,299,0,0],[0,0,0,0,301,101,101,32,33,0,0,0,0,199,301,0,0,0,0],[0,0,0,195,196,197,298,32,33,0,34,0,0,199,200,0,0,37,0],[0,0,0,195,196,298,298,32,33,0,34,0,0,0,200,0,0,37,0],[0,302,111,0,0,97,300,0,33,0,34,0,0,0,99,0,302,0,0],[0,0,0,0,0,0,0,0,33,0,0,0,0,0,0,0,0,0,0],[0,96,0,0,0,201,201,0,33,0,34,0,0,0,99,0,96,0,0],[0,0,0,0,0,101,101,32,33,0,0,0,0,0,0,0,0,0,0],[0,0,0,303,0,304,305,0,33,0,34,0,0,306,0,0,0,0,0],[0,96,0,202,0,201,201,0,33,0,34,0,0,0,99,0,96,0,0],[0,0,0,0,0,0,0,32,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,307,307,106,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,308,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,210,211,212,213,33,0,34,0,0,0,99,0,0,0,0],[0,0,0,0,0,211,211,213,33,0,34,0,0,0,99,0,0,0,0],[0,0,0,0,0,309,309,213,33,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,310,309,309,213,33,0,0,0,0,0,0,0,0,0,0],[0,0,0,311,312,313,314,315,33,0,34,0,0,0,99,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,297,196,298,298,32,33,0,34,0,0,0,200,0,0,37,0],[0,0,0,0,301,101,101,32,33,0,0,0,0,218,301,0,0,0,0],[0,0,0,215,196,216,298,32,33,0,34,0,0,218,200,0,0,37,0],[0,0,0,215,196,298,298,32,33,0,34,0,0,0,200,0,0,37,0],[0,0,0,97,0,203,203,32,33,0,34,0,0,0,99,0,0,0,0],[0,0,0,0,0,201,316,0,33,0,34,0,0,0,99,0,0,0,0],[0,0,0,0,116,222,222,8,9,0,10,0,0,0,120,0,0,16,0],[0,0,0,0,225,44,44,8,9,0,0,0,0,0,225,0,0,0,0],[0,0,0,317,318,319,320,8,9,0,10,0,0,321,322,0,0,16,0],[0,223,0,323,0,123,123,8,9,0,10,0,0,0,42,0,223,0,0],[0,223,0,0,0,121,324,0,9,0,10,0,0,0,42,0,223,0,0],[0,0,0,325,318,326,327,8,9,0,10,0,0,328,322,0,0,16,0],[0,0,0,64,0,121,121,0,9,0,10,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,9,0,0,0,0,230,0,0,0,0,0],[0,0,0,227,0,228,121,0,9,0,10,0,0,230,0,0,0,0,0],[0,0,0,227,0,121,121,0,9,0,10,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,49,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,46,0,0],[0,0,0,0,0,329,329,133,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,330,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,236,237,238,239,9,0,10,0,0,0,42,0,0,0,0],[0,0,0,0,0,237,237,239,9,0,10,0,0,0,42,0,0,0,0],[0,0,0,0,0,331,331,239,9,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,332,331,331,239,9,0,0,0,0,0,0,0,0,0,0],[0,0,0,333,40,121,334,0,9,0,10,0,0,0,42,0,0,0,0],[0,0,0,335,241,336,336,57,58,0,59,0,0,0,245,0,0,62,0],[0,337,0,0,0,137,338,0,58,0,59,0,0,0,139,0,337,0,0],[0,0,0,0,339,141,141,57,58,0,0,0,0,244,339,0,0,0,0],[0,0,0,240,241,242,336,57,58,0,59,0,0,244,245,0,0,62,0],[0,0,0,240,241,336,336,57,58,0,59,0,0,0,245,0,0,62,0],[0,340,151,0,0,137,338,0,58,0,59,0,0,0,139,0,340,0,0],[0,0,0,0,0,0,0,0,58,0,0,0,0,0,0,0,0,0,0],[0,136,0,0,0,246,246,0,58,0,59,0,0,0,139,0,136,0,0],[0,0,0,0,0,141,141,57,58,0,0,0,0,0,0,0,0,0,0],[0,0,0,341,0,342,343,0,58,0,59,0,0,344,0,0,0,0,0],[0,136,0,247,0,246,246,0,58,0,59,0,0,0,139,0,136,0,0],[0,0,0,0,0,0,0,57,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,345,345,146,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,346,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,255,256,257,258,58,0,59,0,0,0,139,0,0,0,0],[0,0,0,0,0,256,256,258,58,0,59,0,0,0,139,0,0,0,0],[0,0,0,0,0,347,347,258,58,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,348,347,347,258,58,0,0,0,0,0,0,0,0,0,0],[0,0,0,349,350,351,352,353,58,0,59,0,0,0,139,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,335,241,336,336,57,58,0,59,0,0,0,245,0,0,62,0],[0,0,0,0,339,141,141,57,58,0,0,0,0,263,339,0,0,0,0],[0,0,0,260,241,261,336,57,58,0,59,0,0,263,245,0,0,62,0],[0,0,0,260,241,336,336,57,58,0,59,0,0,0,245,0,0,62,0],[0,0,0,137,0,248,248,57,58,0,59,0,0,0,139,0,0,0,0],[0,0,0,0,0,246,354,0,58,0,59,0,0,0,139,0,0,0,0],[0,0,0,0,0,126,126,8,23,0,0,0,0,0,0,0,0,0,0],[0,355,90,0,0,121,125,0,9,0,10,0,0,0,42,0,355,0,0],[0,0,0,0,0,356,356,269,23,0,0,0,0,0,0,0,0,0,0],[0,0,0,357,358,359,360,361,161,0,162,0,0,0,362,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,162,0,0,0,0,0,0,0,0],[0,0,0,0,0,270,0,0,0,0,162,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,363,0,0,0,0,0,0,0,0],[0,0,0,364,116,365,366,8,161,0,162,0,0,367,120,0,0,16,0],[0,0,0,0,0,368,368,0,161,0,162,0,0,0,0,0,0,0,0],[0,0,0,40,0,121,121,0,9,0,10,0,0,0,42,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,170,278,278,22,23,0,24,0,0,0,174,0,0,27,0],[0,0,0,0,281,80,80,22,23,0,0,0,0,0,281,0,0,0,0],[0,0,0,369,370,371,372,22,23,0,24,0,0,373,374,0,0,27,0],[0,279,0,375,0,177,177,22,23,0,24,0,0,0,78,0,279,0,0],[0,279,0,0,0,175,376,0,23,0,24,0,0,0,78,0,279,0,0],[0,0,0,377,370,378,379,22,23,0,24,0,0,380,374,0,0,27,0],[0,0,0,90,0,175,175,0,23,0,24,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,23,0,0,0,0,286,0,0,0,0,0],[0,0,0,283,0,284,175,0,23,0,24,0,0,286,0,0,0,0,0],[0,0,0,283,0,175,175,0,23,0,24,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,85,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,82,0,0],[0,0,0,0,0,381,381,187,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,382,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,292,293,294,295,23,0,24,0,0,0,78,0,0,0,0],[0,0,0,0,0,293,293,295,23,0,24,0,0,0,78,0,0,0,0],[0,0,0,0,0,383,383,295,23,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,384,383,383,295,23,0,0,0,0,0,0,0,0,0,0],[0,0,0,385,76,175,386,0,23,0,24,0,0,0,78,0,0,0,0],[0,0,0,76,0,175,175,0,23,0,24,0,0,0,78,0,0,0,0],[0,0,0,0,196,298,298,32,33,0,34,0,0,0,200,0,0,37,0],[0,0,0,0,301,101,101,32,33,0,0,0,0,0,301,0,0,0,0],[0,0,0,387,388,389,390,32,33,0,34,0,0,391,392,0,0,37,0],[0,299,0,393,0,203,203,32,33,0,34,0,0,0,99,0,299,0,0],[0,299,0,0,0,201,394,0,33,0,34,0,0,0,99,0,299,0,0],[0,0,0,395,388,396,397,32,33,0,34,0,0,398,392,0,0,37,0],[0,0,0,111,0,201,201,0,33,0,34,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,33,0,0,0,0,306,0,0,0,0,0],[0,0,0,303,0,304,201,0,33,0,34,0,0,306,0,0,0,0,0],[0,0,0,303,0,201,201,0,33,0,34,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,106,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,103,0,0],[0,0,0,0,0,399,399,213,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,400,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,312,313,314,315,33,0,34,0,0,0,99,0,0,0,0],[0,0,0,0,0,313,313,315,33,0,34,0,0,0,99,0,0,0,0],[0,0,0,0,0,401,401,315,33,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,402,401,401,315,33,0,0,0,0,0,0,0,0,0,0],[0,0,0,403,97,201,404,0,33,0,34,0,0,0,99,0,0,0,0],[0,0,0,97,0,201,201,0,33,0,34,0,0,0,99,0,0,0,0],[0,0,0,405,318,406,406,8,9,0,10,0,0,0,322,0,0,16,0],[0,407,0,0,0,40,408,0,9,0,10,0,0,0,42,0,407,0,0],[0,0,0,0,409,44,44,8,9,0,0,0,0,321,409,0,0,0,0],[0,0,0,317,318,319,406,8,9,0,10,0,0,321,322,0,0,16,0],[0,0,0,317,318,406,406,8,9,0,10,0,0,0,322,0,0,16,0],[0,410,64,0,0,40,408,0,9,0,10,0,0,0,42,0,410,0,0],[0,223,0,0,0,121,121,0,9,0,10,0,0,0,42,0,223,0,0],[0,223,0,323,0,121,121,0,9,0,10,0,0,0,42,0,223,0,0],[0,0,0,405,318,406,406,8,9,0,10,0,0,0,322,0,0,16,0],[0,0,0,0,409,44,44,8,9,0,0,0,0,328,409,0,0,0,0],[0,0,0,325,318,326,406,8,9,0,10,0,0,328,322,0,0,16,0],[0,0,0,325,318,406,406,8,9,0,10,0,0,0,322,0,0,16,0],[0,0,0,0,0,0,0,133,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,130,0,0],[0,0,0,0,0,411,411,239,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,412,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,40,121,334,0,9,0,10,0,0,0,42,0,0,0,0],[0,0,0,0,413,0,0,0,9,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,241,336,336,57,58,0,59,0,0,0,245,0,0,62,0],[0,0,0,0,339,141,141,57,58,0,0,0,0,0,339,0,0,0,0],[0,0,0,414,415,416,417,57,58,0,59,0,0,418,419,0,0,62,0],[0,337,0,420,0,248,248,57,58,0,59,0,0,0,139,0,337,0,0],[0,337,0,0,0,246,421,0,58,0,59,0,0,0,139,0,337,0,0],[0,0,0,422,415,423,424,57,58,0,59,0,0,425,419,0,0,62,0],[0,0,0,151,0,246,246,0,58,0,59,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,58,0,0,0,0,344,0,0,0,0,0],[0,0,0,341,0,342,246,0,58,0,59,0,0,344,0,0,0,0,0],[0,0,0,341,0,246,246,0,58,0,59,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,146,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,143,0,0],[0,0,0,0,0,426,426,258,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,427,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,350,351,352,353,58,0,59,0,0,0,139,0,0,0,0],[0,0,0,0,0,351,351,353,58,0,59,0,0,0,139,0,0,0,0],[0,0,0,0,0,428,428,353,58,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,429,428,428,353,58,0,0,0,0,0,0,0,0,0,0],[0,0,0,430,137,246,431,0,58,0,59,0,0,0,139,0,0,0,0],[0,0,0,137,0,246,246,0,58,0,59,0,0,0,139,0,0,0,0],[0,0,0,432,116,433,434,8,161,0,162,0,0,435,120,0,0,16,0],[0,0,0,0,0,180,180,269,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,358,359,360,361,161,0,162,0,0,0,362,0,0,0,0],[0,0,0,0,0,359,359,361,161,0,162,0,0,0,362,0,0,0,0],[0,0,0,0,0,436,436,361,161,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,437,436,436,361,161,0,0,0,0,0,0,0,0,0,0],[0,0,0,438,439,440,441,442,161,0,162,0,0,0,362,0,0,0,0],[0,443,274,0,0,0,0,0,0,0,0,0,0,0,0,0,443,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,444,116,445,445,8,161,0,162,0,0,0,120,0,0,16,0],[0,0,0,0,225,44,44,8,161,0,0,0,0,367,225,0,0,0,0],[0,0,0,364,116,365,445,8,161,0,162,0,0,367,120,0,0,16,0],[0,0,0,364,116,445,445,8,161,0,162,0,0,0,120,0,0,16,0],[0,0,0,0,0,0,0,0,161,0,0,0,0,0,0,0,0,0,0],[0,0,0,446,370,447,447,22,23,0,24,0,0,0,374,0,0,27,0],[0,448,0,0,0,76,449,0,23,0,24,0,0,0,78,0,448,0,0],[0,0,0,0,450,80,80,22,23,0,0,0,0,373,450,0,0,0,0],[0,0,0,369,370,371,447,22,23,0,24,0,0,373,374,0,0,27,0],[0,0,0,369,370,447,447,22,23,0,24,0,0,0,374,0,0,27,0],[0,451,90,0,0,76,449,0,23,0,24,0,0,0,78,0,451,0,0],[0,279,0,0,0,175,175,0,23,0,24,0,0,0,78,0,279,0,0],[0,279,0,375,0,175,175,0,23,0,24,0,0,0,78,0,279,0,0],[0,0,0,446,370,447,447,22,23,0,24,0,0,0,374,0,0,27,0],[0,0,0,0,450,80,80,22,23,0,0,0,0,380,450,0,0,0,0],[0,0,0,377,370,378,447,22,23,0,24,0,0,380,374,0,0,27,0],[0,0,0,377,370,447,447,22,23,0,24,0,0,0,374,0,0,27,0],[0,0,0,0,0,0,0,187,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,184,0,0],[0,0,0,0,0,452,452,295,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,453,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,76,175,386,0,23,0,24,0,0,0,78,0,0,0,0],[0,0,0,0,454,0,0,0,23,0,0,0,0,0,0,0,0,0,0],[0,0,0,455,388,456,456,32,33,0,34,0,0,0,392,0,0,37,0],[0,457,0,0,0,97,458,0,33,0,34,0,0,0,99,0,457,0,0],[0,0,0,0,459,101,101,32,33,0,0,0,0,391,459,0,0,0,0],[0,0,0,387,388,389,456,32,33,0,34,0,0,391,392,0,0,37,0],[0,0,0,387,388,456,456,32,33,0,34,0,0,0,392,0,0,37,0],[0,460,111,0,0,97,458,0,33,0,34,0,0,0,99,0,460,0,0],[0,299,0,0,0,201,201,0,33,0,34,0,0,0,99,0,299,0,0],[0,299,0,393,0,201,201,0,33,0,34,0,0,0,99,0,299,0,0],[0,0,0,455,388,456,456,32,33,0,34,0,0,0,392,0,0,37,0],[0,0,0,0,459,101,101,32,33,0,0,0,0,398,459,0,0,0,0],[0,0,0,395,388,396,456,32,33,0,34,0,0,398,392,0,0,37,0],[0,0,0,395,388,456,456,32,33,0,34,0,0,0,392,0,0,37,0],[0,0,0,0,0,0,0,213,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,210,0,0],[0,0,0,0,0,461,461,315,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,462,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,97,201,404,0,33,0,34,0,0,0,99,0,0,0,0],[0,0,0,0,463,0,0,0,33,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,318,406,406,8,9,0,10,0,0,0,322,0,0,16,0],[0,0,0,0,409,44,44,8,9,0,0,0,0,0,409,0,0,0,0],[0,0,0,464,465,466,467,8,9,0,10,0,0,468,469,0,0,16,0],[0,407,0,470,0,123,123,8,9,0,10,0,0,0,42,0,407,0,0],[0,407,0,0,0,121,471,0,9,0,10,0,0,0,42,0,407,0,0],[0,0,0,472,465,473,474,8,9,0,10,0,0,475,469,0,0,16,0],[0,0,0,0,0,0,0,239,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,236,0,0],[0,0,0,0,0,0,476,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,477,415,478,478,57,58,0,59,0,0,0,419,0,0,62,0],[0,479,0,0,0,137,480,0,58,0,59,0,0,0,139,0,479,0,0],[0,0,0,0,481,141,141,57,58,0,0,0,0,418,481,0,0,0,0],[0,0,0,414,415,416,478,57,58,0,59,0,0,418,419,0,0,62,0],[0,0,0,414,415,478,478,57,58,0,59,0,0,0,419,0,0,62,0],[0,482,151,0,0,137,480,0,58,0,59,0,0,0,139,0,482,0,0],[0,337,0,0,0,246,246,0,58,0,59,0,0,0,139,0,337,0,0],[0,337,0,420,0,246,246,0,58,0,59,0,0,0,139,0,337,0,0],[0,0,0,477,415,478,478,57,58,0,59,0,0,0,419,0,0,62,0],[0,0,0,0,481,141,141,57,58,0,0,0,0,425,481,0,0,0,0],[0,0,0,422,415,423,478,57,58,0,59,0,0,425,419,0,0,62,0],[0,0,0,422,415,478,478,57,58,0,59,0,0,0,419,0,0,62,0],[0,0,0,0,0,0,0,258,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,0,0],[0,0,0,0,0,483,483,353,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,484,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,137,246,431,0,58,0,59,0,0,0,139,0,0,0,0],[0,0,0,0,485,0,0,0,58,0,0,0,0,0,0,0,0,0,0],[0,0,0,444,116,445,445,8,161,0,162,0,0,0,120,0,0,16,0],[0,0,0,0,225,44,44,8,161,0,0,0,0,435,225,0,0,0,0],[0,0,0,432,116,433,445,8,161,0,162,0,0,435,120,0,0,16,0],[0,0,0,432,116,445,445,8,161,0,162,0,0,0,120,0,0,16,0],[0,0,0,0,0,486,486,361,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,487,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,439,440,441,442,161,0,162,0,0,0,362,0,0,0,0],[0,0,0,0,0,440,440,442,161,0,162,0,0,0,362,0,0,0,0],[0,0,0,0,0,488,488,442,161,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,489,488,488,442,161,0,0,0,0,0,0,0,0,0,0],[0,0,0,490,491,492,493,494,161,0,162,0,0,0,362,0,0,0,0],[0,0,0,495,0,496,497,0,161,0,162,0,0,498,0,0,0,0,0],[0,0,0,0,116,445,445,8,161,0,162,0,0,0,120,0,0,16,0],[0,0,0,0,225,44,44,8,161,0,0,0,0,0,225,0,0,0,0],[0,0,0,0,370,447,447,22,23,0,24,0,0,0,374,0,0,27,0],[0,0,0,0,450,80,80,22,23,0,0,0,0,0,450,0,0,0,0],[0,0,0,499,500,501,502,22,23,0,24,0,0,503,504,0,0,27,0],[0,448,0,505,0,177,177,22,23,0,24,0,0,0,78,0,448,0,0],[0,448,0,0,0,175,506,0,23,0,24,0,0,0,78,0,448,0,0],[0,0,0,507,500,508,509,22,23,0,24,0,0,510,504,0,0,27,0],[0,0,0,0,0,0,0,295,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,292,0,0],[0,0,0,0,0,0,511,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,388,456,456,32,33,0,34,0,0,0,392,0,0,37,0],[0,0,0,0,459,101,101,32,33,0,0,0,0,0,459,0,0,0,0],[0,0,0,512,513,514,515,32,33,0,34,0,0,516,517,0,0,37,0],[0,457,0,518,0,203,203,32,33,0,34,0,0,0,99,0,457,0,0],[0,457,0,0,0,201,519,0,33,0,34,0,0,0,99,0,457,0,0],[0,0,0,520,513,521,522,32,33,0,34,0,0,523,517,0,0,37,0],[0,0,0,0,0,0,0,315,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,312,0,0],[0,0,0,0,0,0,524,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,525,465,526,526,8,9,0,10,0,0,0,469,0,0,16,0],[0,527,0,0,0,40,528,0,9,0,10,0,0,0,42,0,527,0,0],[0,0,0,0,529,44,44,8,9,0,0,0,0,468,529,0,0,0,0],[0,0,0,464,465,466,526,8,9,0,10,0,0,468,469,0,0,16,0],[0,0,0,464,465,526,526,8,9,0,10,0,0,0,469,0,0,16,0],[0,530,64,0,0,40,528,0,9,0,10,0,0,0,42,0,530,0,0],[0,407,0,0,0,121,121,0,9,0,10,0,0,0,42,0,407,0,0],[0,407,0,470,0,121,121,0,9,0,10,0,0,0,42,0,407,0,0],[0,0,0,525,465,526,526,8,9,0,10,0,0,0,469,0,0,16,0],[0,0,0,0,529,44,44,8,9,0,0,0,0,475,529,0,0,0,0],[0,0,0,472,465,473,526,8,9,0,10,0,0,475,469,0,0,16,0],[0,0,0,472,465,526,526,8,9,0,10,0,0,0,469,0,0,16,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,40,0,0],[0,0,0,0,415,478,478,57,58,0,59,0,0,0,419,0,0,62,0],[0,0,0,0,481,141,141,57,58,0,0,0,0,0,481,0,0,0,0],[0,0,0,531,532,533,534,57,58,0,59,0,0,535,536,0,0,62,0],[0,479,0,537,0,248,248,57,58,0,59,0,0,0,139,0,479,0,0],[0,479,0,0,0,246,538,0,58,0,59,0,0,0,139,0,479,0,0],[0,0,0,539,532,540,541,57,58,0,59,0,0,542,536,0,0,62,0],[0,0,0,0,0,0,0,353,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,350,0,0],[0,0,0,0,0,0,543,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,361,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,358,0,0],[0,0,0,0,0,544,544,442,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,545,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,491,492,493,494,161,0,162,0,0,0,362,0,0,0,0],[0,0,0,0,0,492,492,494,161,0,162,0,0,0,362,0,0,0,0],[0,0,0,0,0,546,546,494,161,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,547,546,546,494,161,0,0,0,0,0,0,0,0,0,0],[0,0,0,548,549,368,550,0,161,0,162,0,0,0,362,0,0,0,0],[0,0,0,274,0,368,368,0,161,0,162,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,161,0,0,0,0,498,0,0,0,0,0],[0,0,0,495,0,496,368,0,161,0,162,0,0,498,0,0,0,0,0],[0,0,0,495,0,368,368,0,161,0,162,0,0,0,0,0,0,0,0],[0,0,0,551,500,552,552,22,23,0,24,0,0,0,504,0,0,27,0],[0,553,0,0,0,76,554,0,23,0,24,0,0,0,78,0,553,0,0],[0,0,0,0,555,80,80,22,23,0,0,0,0,503,555,0,0,0,0],[0,0,0,499,500,501,552,22,23,0,24,0,0,503,504,0,0,27,0],[0,0,0,499,500,552,552,22,23,0,24,0,0,0,504,0,0,27,0],[0,556,90,0,0,76,554,0,23,0,24,0,0,0,78,0,556,0,0],[0,448,0,0,0,175,175,0,23,0,24,0,0,0,78,0,448,0,0],[0,448,0,505,0,175,175,0,23,0,24,0,0,0,78,0,448,0,0],[0,0,0,551,500,552,552,22,23,0,24,0,0,0,504,0,0,27,0],[0,0,0,0,555,80,80,22,23,0,0,0,0,510,555,0,0,0,0],[0,0,0,507,500,508,552,22,23,0,24,0,0,510,504,0,0,27,0],[0,0,0,507,500,552,552,22,23,0,24,0,0,0,504,0,0,27,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,76,0,0],[0,0,0,557,513,558,558,32,33,0,34,0,0,0,517,0,0,37,0],[0,559,0,0,0,97,560,0,33,0,34,0,0,0,99,0,559,0,0],[0,0,0,0,561,101,101,32,33,0,0,0,0,516,561,0,0,0,0],[0,0,0,512,513,514,558,32,33,0,34,0,0,516,517,0,0,37,0],[0,0,0,512,513,558,558,32,33,0,34,0,0,0,517,0,0,37,0],[0,562,111,0,0,97,560,0,33,0,34,0,0,0,99,0,562,0,0],[0,457,0,0,0,201,201,0,33,0,34,0,0,0,99,0,457,0,0],[0,457,0,518,0,201,201,0,33,0,34,0,0,0,99,0,457,0,0],[0,0,0,557,513,558,558,32,33,0,34,0,0,0,517,0,0,37,0],[0,0,0,0,561,101,101,32,33,0,0,0,0,523,561,0,0,0,0],[0,0,0,520,513,521,558,32,33,0,34,0,0,523,517,0,0,37,0],[0,0,0,520,513,558,558,32,33,0,34,0,0,0,517,0,0,37,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,97,0,0],[0,0,0,0,465,526,526,8,9,0,10,0,0,0,469,0,0,16,0],[0,0,0,0,529,44,44,8,9,0,0,0,0,0,529,0,0,0,0],[0,0,0,563,66,564,565,8,9,0,10,0,0,566,68,0,0,16,0],[0,527,0,567,0,123,123,8,9,0,10,0,0,0,42,0,527,0,0],[0,527,0,0,0,121,568,0,9,0,10,0,0,0,42,0,527,0,0],[0,0,0,569,66,570,571,8,9,0,10,0,0,572,68,0,0,16,0],[0,0,0,573,532,574,574,57,58,0,59,0,0,0,536,0,0,62,0],[0,575,0,0,0,137,576,0,58,0,59,0,0,0,139,0,575,0,0],[0,0,0,0,577,141,141,57,58,0,0,0,0,535,577,0,0,0,0],[0,0,0,531,532,533,574,57,58,0,59,0,0,535,536,0,0,62,0],[0,0,0,531,532,574,574,57,58,0,59,0,0,0,536,0,0,62,0],[0,578,151,0,0,137,576,0,58,0,59,0,0,0,139,0,578,0,0],[0,479,0,0,0,246,246,0,58,0,59,0,0,0,139,0,479,0,0],[0,479,0,537,0,246,246,0,58,0,59,0,0,0,139,0,479,0,0],[0,0,0,573,532,574,574,57,58,0,59,0,0,0,536,0,0,62,0],[0,0,0,0,577,141,141,57,58,0,0,0,0,542,577,0,0,0,0],[0,0,0,539,532,540,574,57,58,0,59,0,0,542,536,0,0,62,0],[0,0,0,539,532,574,574,57,58,0,59,0,0,0,536,0,0,62,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,137,0,0],[0,0,0,0,0,0,0,442,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,439,0,0],[0,0,0,0,0,579,579,494,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,580,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,549,368,550,0,161,0,162,0,0,0,362,0,0,0,0],[0,0,0,0,0,368,368,0,161,0,162,0,0,0,362,0,0,0,0],[0,0,0,0,581,0,0,0,161,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,500,552,552,22,23,0,24,0,0,0,504,0,0,27,0],[0,0,0,0,555,80,80,22,23,0,0,0,0,0,555,0,0,0,0],[0,0,0,582,91,583,584,22,23,0,24,0,0,585,93,0,0,27,0],[0,553,0,586,0,177,177,22,23,0,24,0,0,0,78,0,553,0,0],[0,553,0,0,0,175,587,0,23,0,24,0,0,0,78,0,553,0,0],[0,0,0,588,91,589,590,22,23,0,24,0,0,591,93,0,0,27,0],[0,0,0,0,513,558,558,32,33,0,34,0,0,0,517,0,0,37,0],[0,0,0,0,561,101,101,32,33,0,0,0,0,0,561,0,0,0,0],[0,0,0,592,112,593,594,32,33,0,34,0,0,595,114,0,0,37,0],[0,559,0,596,0,203,203,32,33,0,34,0,0,0,99,0,559,0,0],[0,559,0,0,0,201,597,0,33,0,34,0,0,0,99,0,559,0,0],[0,0,0,598,112,599,600,32,33,0,34,0,0,601,114,0,0,37,0],[0,0,0,602,66,67,67,8,9,0,10,0,0,0,68,0,0,16,0],[0,0,0,0,165,44,44,8,9,0,0,0,0,566,165,0,0,0,0],[0,0,0,563,66,564,67,8,9,0,10,0,0,566,68,0,0,16,0],[0,0,0,563,66,67,67,8,9,0,10,0,0,0,68,0,0,16,0],[0,527,0,0,0,121,121,0,9,0,10,0,0,0,42,0,527,0,0],[0,527,0,567,0,121,121,0,9,0,10,0,0,0,42,0,527,0,0],[0,0,0,602,66,67,67,8,9,0,10,0,0,0,68,0,0,16,0],[0,0,0,0,165,44,44,8,9,0,0,0,0,572,165,0,0,0,0],[0,0,0,569,66,570,67,8,9,0,10,0,0,572,68,0,0,16,0],[0,0,0,569,66,67,67,8,9,0,10,0,0,0,68,0,0,16,0],[0,0,0,0,532,574,574,57,58,0,59,0,0,0,536,0,0,62,0],[0,0,0,0,577,141,141,57,58,0,0,0,0,0,577,0,0,0,0],[0,0,0,603,152,604,605,57,58,0,59,0,0,606,154,0,0,62,0],[0,575,0,607,0,248,248,57,58,0,59,0,0,0,139,0,575,0,0],[0,575,0,0,0,246,608,0,58,0,59,0,0,0,139,0,575,0,0],[0,0,0,609,152,610,611,57,58,0,59,0,0,612,154,0,0,62,0],[0,0,0,0,0,0,0,494,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,491,0,0],[0,0,0,0,0,0,613,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,614,91,92,92,22,23,0,24,0,0,0,93,0,0,27,0],[0,0,0,0,194,80,80,22,23,0,0,0,0,585,194,0,0,0,0],[0,0,0,582,91,583,92,22,23,0,24,0,0,585,93,0,0,27,0],[0,0,0,582,91,92,92,22,23,0,24,0,0,0,93,0,0,27,0],[0,553,0,0,0,175,175,0,23,0,24,0,0,0,78,0,553,0,0],[0,553,0,586,0,175,175,0,23,0,24,0,0,0,78,0,553,0,0],[0,0,0,614,91,92,92,22,23,0,24,0,0,0,93,0,0,27,0],[0,0,0,0,194,80,80,22,23,0,0,0,0,591,194,0,0,0,0],[0,0,0,588,91,589,92,22,23,0,24,0,0,591,93,0,0,27,0],[0,0,0,588,91,92,92,22,23,0,24,0,0,0,93,0,0,27,0],[0,0,0,615,112,113,113,32,33,0,34,0,0,0,114,0,0,37,0],[0,0,0,0,220,101,101,32,33,0,0,0,0,595,220,0,0,0,0],[0,0,0,592,112,593,113,32,33,0,34,0,0,595,114,0,0,37,0],[0,0,0,592,112,113,113,32,33,0,34,0,0,0,114,0,0,37,0],[0,559,0,0,0,201,201,0,33,0,34,0,0,0,99,0,559,0,0],[0,559,0,596,0,201,201,0,33,0,34,0,0,0,99,0,559,0,0],[0,0,0,615,112,113,113,32,33,0,34,0,0,0,114,0,0,37,0],[0,0,0,0,220,101,101,32,33,0,0,0,0,601,220,0,0,0,0],[0,0,0,598,112,599,113,32,33,0,34,0,0,601,114,0,0,37,0],[0,0,0,598,112,113,113,32,33,0,34,0,0,0,114,0,0,37,0],[0,0,0,0,66,67,67,8,9,0,10,0,0,0,68,0,0,16,0],[0,0,0,616,152,153,153,57,58,0,59,0,0,0,154,0,0,62,0],[0,0,0,0,265,141,141,57,58,0,0,0,0,606,265,0,0,0,0],[0,0,0,603,152,604,153,57,58,0,59,0,0,606,154,0,0,62,0],[0,0,0,603,152,153,153,57,58,0,59,0,0,0,154,0,0,62,0],[0,575,0,0,0,246,246,0,58,0,59,0,0,0,139,0,575,0,0],[0,575,0,607,0,246,246,0,58,0,59,0,0,0,139,0,575,0,0],[0,0,0,616,152,153,153,57,58,0,59,0,0,0,154,0,0,62,0],[0,0,0,0,265,141,141,57,58,0,0,0,0,612,265,0,0,0,0],[0,0,0,609,152,610,153,57,58,0,59,0,0,612,154,0,0,62,0],[0,0,0,609,152,153,153,57,58,0,59,0,0,0,154,0,0,62,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,549,0,0],[0,0,0,0,91,92,92,22,23,0,24,0,0,0,93,0,0,27,0],[0,0,0,0,112,113,113,32,33,0,34,0,0,0,114,0,0,37,0],[0,0,0,0,152,153,153,57,58,0,59,0,0,0,154,0,0,62,0]],"accepting":[false,true,true,true,true,true,false,false,true,true,true,true,true,true,true,true,true,true,true,true,false,true,true,true,true,true,true,true,true,true,false,true,true,true,true,true,true,true,true,true,true,true,false,true,false,true,true,false,false,true,true,true,true,true,true,false,false,true,true,true,true,true,true,true,true,true,true,false,true,true,false,true,true,true,false,true,true,true,false,true,false,true,true,false,false,true,true,true,true,true,true,true,false,true,true,false,true,true,true,false,true,false,true,true,false,false,true,true,true,true,true,true,true,false,true,true,true,false,true,true,true,false,true,false,true,true,false,false,false,true,true,false,false,true,true,true,true,true,true,false,true,false,true,true,false,false,true,true,true,true,true,true,true,false,true,true,false,true,true,true,true,true,true,true,true,true,true,true,true,true,true,false,true,true,true,false,true,false,true,true,false,false,false,true,true,false,false,true,true,true,false,true,true,true,true,true,true,false,true,true,true,false,true,false,true,true,false,false,false,true,true,false,false,true,true,true,false,true,true,true,true,true,false,true,true,true,true,true,false,true,true,false,false,false,false,true,true,false,false,true,true,true,false,true,true,true,false,true,false,true,true,false,false,false,true,true,false,false,true,true,true,false,true,true,true,true,false,true,false,true,true,true,true,true,true,true,true,true,false,true,true,true,true,true,false,true,true,false,false,false,false,true,true,false,false,true,true,true,false,true,true,true,true,true,false,true,true,false,false,false,false,true,true,false,false,true,true,true,true,false,true,true,true,true,true,true,false,true,true,false,false,false,false,true,false,true,false,true,true,true,true,true,false,true,true,false,false,false,false,true,true,false,false,true,true,true,false,true,true,false,false,true,false,true,true,false,true,true,false,true,true,false,true,true,true,true,true,true,false,true,true,false,false,false,false,true,false,true,true,false,true,true,true,true,true,true,false,true,true,false,false,false,false,true,false,true,false,true,true,true,true,false,false,false,true,true,false,true,true,true,true,true,true,false,true,true,false,false,false,false,true,false,true,false,true,true,false,false,true,true,false,false,true,true,true,false,true,false,true,true,true,true,false,false,false,true,false,true,true,true,true,false,false,false,true,true,false,true,true,true,true,true,true,false,true,true,false,true,false,true,true,true,true,false,false,false,false,false,false,false,true,true,false,false,true,true,false,true,true,true,true,false,true,true,true,true,true,true,false,true,true,false,true,true,false,true,true,true,true,true,true,false,true,true,false,true,false,true,true,true,true,true,true,false,true,true,true,true,true,true,false,true,true,false,false,false,false,false,true,true,false,true,false,true,true,true,true,true,false,true,true,true,true,true,false,true,true,true,true,true,false,true,true,true,false,true,true,true,true,false,false,false,true,false,true,true,true,true,true,false,true,true,true,false,true,true,true,true,true,false,true,true,true,true,false,true,true,true,true,true,false,true,true,false,true,true,true],"tags":[[],["broken_cluster"],["consonant_syllable"],["vowel_syllable"],["broken_cluster"],["broken_cluster"],[],[],["broken_cluster"],["broken_cluster"],["broken_cluster"],["standalone_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],["consonant_syllable"],["broken_cluster"],["symbol_cluster"],["consonant_syllable"],["consonant_syllable"],[],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["vowel_syllable"],["vowel_syllable"],[],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],[],["broken_cluster"],[],["broken_cluster"],["broken_cluster"],[],[],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],["standalone_cluster"],["standalone_cluster"],[],[],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],["broken_cluster"],["broken_cluster"],["consonant_syllable","broken_cluster"],["broken_cluster"],[],["broken_cluster"],["symbol_cluster"],[],["symbol_cluster"],["symbol_cluster"],["consonant_syllable"],[],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],[],["consonant_syllable"],[],["consonant_syllable"],["consonant_syllable"],[],[],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],[],["consonant_syllable"],["vowel_syllable"],[],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],[],["vowel_syllable"],[],["vowel_syllable"],["vowel_syllable"],[],[],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],[],["vowel_syllable"],["broken_cluster"],["broken_cluster"],[],["broken_cluster"],["broken_cluster"],["broken_cluster"],[],["broken_cluster"],[],["broken_cluster"],["broken_cluster"],[],[],[],["broken_cluster"],["broken_cluster"],[],[],["broken_cluster"],["broken_cluster"],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],[],["standalone_cluster"],[],["standalone_cluster"],["standalone_cluster"],[],[],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],[],["standalone_cluster"],["broken_cluster"],[],["broken_cluster"],["broken_cluster"],["consonant_syllable"],["consonant_syllable"],["consonant_syllable","broken_cluster"],["consonant_syllable","broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],["symbol_cluster"],["symbol_cluster"],["symbol_cluster"],["consonant_syllable"],["consonant_syllable"],[],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],[],["consonant_syllable"],[],["consonant_syllable"],["consonant_syllable"],[],[],[],["consonant_syllable"],["consonant_syllable"],[],[],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],[],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["vowel_syllable"],["vowel_syllable"],[],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],[],["vowel_syllable"],[],["vowel_syllable"],["vowel_syllable"],[],[],[],["vowel_syllable"],["vowel_syllable"],[],[],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],[],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["broken_cluster"],[],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],[],["broken_cluster"],["broken_cluster"],[],[],[],[],["broken_cluster"],["broken_cluster"],[],[],["broken_cluster"],["standalone_cluster"],["standalone_cluster"],[],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],[],["standalone_cluster"],[],["standalone_cluster"],["standalone_cluster"],[],[],[],["standalone_cluster"],["standalone_cluster"],[],[],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],[],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],[],["broken_cluster"],[],["consonant_syllable","broken_cluster"],["consonant_syllable","broken_cluster"],["consonant_syllable","broken_cluster"],["consonant_syllable","broken_cluster"],["consonant_syllable","broken_cluster"],["consonant_syllable","broken_cluster"],["broken_cluster"],["symbol_cluster"],["consonant_syllable"],[],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],[],["consonant_syllable"],["consonant_syllable"],[],[],[],[],["consonant_syllable"],["consonant_syllable"],[],[],["consonant_syllable"],["consonant_syllable"],["vowel_syllable"],[],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],[],["vowel_syllable"],["vowel_syllable"],[],[],[],[],["vowel_syllable"],["vowel_syllable"],[],[],["vowel_syllable"],["vowel_syllable"],["broken_cluster"],["broken_cluster"],[],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],[],["broken_cluster"],["broken_cluster"],[],[],[],[],["broken_cluster"],[],["standalone_cluster"],[],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],[],["standalone_cluster"],["standalone_cluster"],[],[],[],[],["standalone_cluster"],["standalone_cluster"],[],[],["standalone_cluster"],["standalone_cluster"],["consonant_syllable","broken_cluster"],[],["consonant_syllable","broken_cluster"],["consonant_syllable","broken_cluster"],[],[],["consonant_syllable","broken_cluster"],[],["consonant_syllable","broken_cluster"],["consonant_syllable","broken_cluster"],[],["consonant_syllable","broken_cluster"],["consonant_syllable","broken_cluster"],[],["consonant_syllable"],["consonant_syllable"],[],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],[],["consonant_syllable"],["consonant_syllable"],[],[],[],[],["consonant_syllable"],[],["vowel_syllable"],["vowel_syllable"],[],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],[],["vowel_syllable"],["vowel_syllable"],[],[],[],[],["vowel_syllable"],[],["broken_cluster"],[],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],[],[],[],["standalone_cluster"],["standalone_cluster"],[],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],[],["standalone_cluster"],["standalone_cluster"],[],[],[],[],["standalone_cluster"],[],["consonant_syllable","broken_cluster"],[],["consonant_syllable","broken_cluster"],["consonant_syllable","broken_cluster"],[],[],["consonant_syllable","broken_cluster"],["consonant_syllable","broken_cluster"],[],[],["consonant_syllable","broken_cluster"],["consonant_syllable","broken_cluster"],["consonant_syllable","broken_cluster"],[],["consonant_syllable"],[],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],[],[],[],["vowel_syllable"],[],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],[],[],[],["broken_cluster"],["broken_cluster"],[],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],[],["broken_cluster"],["broken_cluster"],[],["standalone_cluster"],[],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],[],[],[],[],[],[],[],["consonant_syllable","broken_cluster"],["consonant_syllable","broken_cluster"],[],[],["consonant_syllable","broken_cluster"],["consonant_syllable","broken_cluster"],[],["consonant_syllable","broken_cluster"],["consonant_syllable","broken_cluster"],["consonant_syllable"],["consonant_syllable"],[],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],[],["consonant_syllable"],["consonant_syllable"],[],["vowel_syllable"],["vowel_syllable"],[],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],[],["vowel_syllable"],["vowel_syllable"],[],["broken_cluster"],[],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],["standalone_cluster"],["standalone_cluster"],[],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],[],["standalone_cluster"],["standalone_cluster"],[],[],[],[],[],["consonant_syllable","broken_cluster"],["consonant_syllable","broken_cluster"],[],["consonant_syllable"],[],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["vowel_syllable"],[],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["broken_cluster"],[],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],[],["broken_cluster"],["broken_cluster"],["standalone_cluster"],[],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],[],[],[],["consonant_syllable"],[],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],["consonant_syllable"],[],["consonant_syllable"],["consonant_syllable"],["vowel_syllable"],[],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],["vowel_syllable"],[],["vowel_syllable"],["vowel_syllable"],["broken_cluster"],["standalone_cluster"],[],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],["standalone_cluster"],[],["standalone_cluster"],["standalone_cluster"],[],["consonant_syllable"],["vowel_syllable"],["standalone_cluster"]]}');
var Yt = {};
Yt = JSON.parse('{"categories":["O","IND","S","GB","B","FM","CGJ","VMAbv","VMPst","VAbv","VPst","CMBlw","VPre","VBlw","H","VMBlw","CMAbv","MBlw","CS","R","SUB","MPst","MPre","FAbv","FPst","FBlw","null","SMAbv","SMBlw","VMPre","ZWNJ","ZWJ","WJ","M","VS","N","HN","MAbv"],"decompositions":{"2507":[2503,2494],"2508":[2503,2519],"2888":[2887,2902],"2891":[2887,2878],"2892":[2887,2903],"3018":[3014,3006],"3019":[3015,3006],"3020":[3014,3031],"3144":[3142,3158],"3264":[3263,3285],"3271":[3270,3285],"3272":[3270,3286],"3274":[3270,3266],"3275":[3270,3266,3285],"3402":[3398,3390],"3403":[3399,3390],"3404":[3398,3415],"3546":[3545,3530],"3548":[3545,3535],"3549":[3545,3535,3530],"3550":[3545,3551],"3635":[3661,3634],"3763":[3789,3762],"3955":[3953,3954],"3957":[3953,3956],"3958":[4018,3968],"3959":[4018,3953,3968],"3960":[4019,3968],"3961":[4019,3953,3968],"3969":[3953,3968],"6971":[6970,6965],"6973":[6972,6965],"6976":[6974,6965],"6977":[6975,6965],"6979":[6978,6965],"69934":[69937,69927],"69935":[69938,69927],"70475":[70471,70462],"70476":[70471,70487],"70843":[70841,70842],"70844":[70841,70832],"70846":[70841,70845],"71098":[71096,71087],"71099":[71097,71087]},"stateTable":[[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[2,2,3,4,4,5,0,6,7,8,9,10,11,12,13,14,15,16,0,17,18,11,19,20,21,22,0,0,0,23,0,0,2,0,0,24,0,25],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,26,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,27,28,0,0,0,0,0,27,0,0,0],[0,0,0,0,0,29,0,30,31,32,33,34,35,36,37,38,39,40,0,0,41,35,42,43,44,45,0,0,0,46,0,0,0,0,39,0,0,47],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,5,0,6,7,0,0,0,0,0,0,14,0,0,0,0,0,0,0,20,21,22,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,5,0,0,7,0,0,0,0,0,0,0,0,0,0,0,0,0,0,20,21,22,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,5,0,6,7,8,9,0,0,12,0,14,0,0,0,0,0,0,0,20,21,22,0,0,0,23,0,0,0,0,0,0,0,0],[0,0,0,0,0,5,0,6,7,0,9,0,0,0,0,14,0,0,0,0,0,0,0,20,21,22,0,0,0,23,0,0,0,0,0,0,0,0],[0,0,0,0,0,5,0,6,7,8,9,10,11,12,13,14,0,16,0,0,18,11,19,20,21,22,0,0,0,23,0,0,0,0,0,0,0,25],[0,0,0,0,0,5,0,6,7,8,9,0,11,12,0,14,0,0,0,0,0,0,0,20,21,22,0,0,0,23,0,0,0,0,0,0,0,0],[0,0,0,0,0,5,0,6,7,0,9,0,0,12,0,14,0,0,0,0,0,0,0,20,21,22,0,0,0,23,0,0,0,0,0,0,0,0],[0,0,0,0,18,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,5,0,0,7,0,0,0,0,0,0,14,0,0,0,0,0,0,0,20,21,22,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,5,0,6,7,8,9,10,11,12,13,14,15,16,0,0,18,11,19,20,21,22,0,0,0,23,0,0,0,0,0,0,0,25],[0,0,0,0,0,5,0,6,7,8,9,0,11,12,0,14,0,0,0,0,0,11,0,20,21,22,0,0,0,23,0,0,0,0,0,0,0,0],[0,0,0,4,4,5,0,6,7,8,9,10,11,12,13,14,15,16,0,0,18,11,19,20,21,22,0,0,0,23,0,0,0,0,0,0,0,25],[0,0,0,0,0,5,0,6,7,8,9,48,11,12,13,14,48,16,0,0,18,11,19,20,21,22,0,0,0,23,0,0,0,0,49,0,0,25],[0,0,0,0,0,5,0,6,7,8,9,0,11,12,0,14,0,16,0,0,0,11,0,20,21,22,0,0,0,23,0,0,0,0,0,0,0,25],[0,0,0,0,0,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,20,21,22,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,21,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,21,22,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,5,0,6,7,0,0,0,0,0,0,14,0,0,0,0,0,0,0,20,21,22,0,0,0,23,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,50,0,51,0],[0,0,0,0,0,5,0,6,7,8,9,0,11,12,0,14,0,16,0,0,0,11,0,20,21,22,0,0,0,23,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,27,28,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,28,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,29,0,30,31,0,0,0,0,0,0,38,0,0,0,0,0,0,0,43,44,45,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,29,0,0,31,0,0,0,0,0,0,0,0,0,0,0,0,0,0,43,44,45,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,29,0,30,31,32,33,0,0,36,0,38,0,0,0,0,0,0,0,43,44,45,0,0,0,46,0,0,0,0,0,0,0,0],[0,0,0,0,0,29,0,30,31,0,33,0,0,0,0,38,0,0,0,0,0,0,0,43,44,45,0,0,0,46,0,0,0,0,0,0,0,0],[0,0,0,0,0,29,0,30,31,32,33,34,35,36,37,38,0,40,0,0,41,35,42,43,44,45,0,0,0,46,0,0,0,0,0,0,0,47],[0,0,0,0,0,29,0,30,31,32,33,0,35,36,0,38,0,0,0,0,0,0,0,43,44,45,0,0,0,46,0,0,0,0,0,0,0,0],[0,0,0,0,0,29,0,30,31,0,33,0,0,36,0,38,0,0,0,0,0,0,0,43,44,45,0,0,0,46,0,0,0,0,0,0,0,0],[0,0,0,0,41,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,29,0,0,31,0,0,0,0,0,0,38,0,0,0,0,0,0,0,43,44,45,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,29,0,30,31,32,33,34,35,36,37,38,39,40,0,0,41,35,42,43,44,45,0,0,0,46,0,0,0,0,0,0,0,47],[0,0,0,0,0,29,0,30,31,32,33,0,35,36,0,38,0,0,0,0,0,35,0,43,44,45,0,0,0,46,0,0,0,0,0,0,0,0],[0,0,0,0,0,29,0,30,31,32,33,52,35,36,37,38,52,40,0,0,41,35,42,43,44,45,0,0,0,46,0,0,0,0,53,0,0,47],[0,0,0,0,0,29,0,30,31,32,33,0,35,36,0,38,0,40,0,0,0,35,0,43,44,45,0,0,0,46,0,0,0,0,0,0,0,47],[0,0,0,0,0,29,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,43,44,45,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,29,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,44,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,29,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,44,45,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,29,0,30,31,0,0,0,0,0,0,38,0,0,0,0,0,0,0,43,44,45,0,0,0,46,0,0,0,0,0,0,0,0],[0,0,0,0,0,29,0,30,31,32,33,0,35,36,0,38,0,40,0,0,0,35,0,43,44,45,0,0,0,46,0,0,0,0,0,0,0,0],[0,0,0,0,0,5,0,6,7,8,9,48,11,12,13,14,0,16,0,0,18,11,19,20,21,22,0,0,0,23,0,0,0,0,0,0,0,25],[0,0,0,0,0,5,0,6,7,8,9,48,11,12,13,14,48,16,0,0,18,11,19,20,21,22,0,0,0,23,0,0,0,0,0,0,0,25],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,51,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,54,0,0],[0,0,0,0,0,29,0,30,31,32,33,52,35,36,37,38,0,40,0,0,41,35,42,43,44,45,0,0,0,46,0,0,0,0,0,0,0,47],[0,0,0,0,0,29,0,30,31,32,33,52,35,36,37,38,52,40,0,0,41,35,42,43,44,45,0,0,0,46,0,0,0,0,0,0,0,47],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,50,0,51,0]],"accepting":[false,true,true,true,true,true,true,true,true,true,true,true,true,false,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true],"tags":[[],["broken_cluster"],["independent_cluster"],["symbol_cluster"],["standard_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],[],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],["broken_cluster"],["numeral_cluster"],["broken_cluster"],["independent_cluster"],["symbol_cluster"],["symbol_cluster"],["standard_cluster"],["standard_cluster"],["standard_cluster"],["standard_cluster"],["standard_cluster"],["standard_cluster"],["standard_cluster"],["standard_cluster"],["virama_terminated_cluster"],["standard_cluster"],["standard_cluster"],["standard_cluster"],["standard_cluster"],["standard_cluster"],["standard_cluster"],["standard_cluster"],["standard_cluster"],["standard_cluster"],["standard_cluster"],["broken_cluster"],["broken_cluster"],["numeral_cluster"],["number_joiner_terminated_cluster"],["standard_cluster"],["standard_cluster"],["numeral_cluster"]]}');
const se = {
  X: 1,
  C: 2,
  V: 4,
  N: 8,
  H: 16,
  ZWNJ: 32,
  ZWJ: 64,
  M: 128,
  Placeholder: 2048,
  Dotted_Circle: 4096,
  RS: 8192,
  Coeng: 16384,
  Repha: 32768,
  Ra: 65536,
  CM: 131072
}, j = {
  Start: 1,
  Ra_To_Become_Reph: 2,
  Pre_M: 4,
  Pre_C: 8,
  Base_C: 16,
  After_Main: 32,
  Before_Sub: 128,
  Below_C: 256,
  After_Sub: 512,
  Before_Post: 1024,
  Post_C: 2048,
  After_Post: 4096,
  Final_C: 8192,
  SMVD: 16384,
  End: 32768
}, Rc = se.C | se.Ra | se.CM | se.V | se.Placeholder | se.Dotted_Circle, gn = se.ZWJ | se.ZWNJ, et = se.H | se.Coeng, pa = {
  Default: {
    hasOldSpec: !1,
    virama: 0,
    basePos: "Last",
    rephPos: j.Before_Post,
    rephMode: "Implicit",
    blwfMode: "Pre_And_Post"
  },
  Devanagari: {
    hasOldSpec: !0,
    virama: 2381,
    basePos: "Last",
    rephPos: j.Before_Post,
    rephMode: "Implicit",
    blwfMode: "Pre_And_Post"
  },
  Bengali: {
    hasOldSpec: !0,
    virama: 2509,
    basePos: "Last",
    rephPos: j.After_Sub,
    rephMode: "Implicit",
    blwfMode: "Pre_And_Post"
  },
  Gurmukhi: {
    hasOldSpec: !0,
    virama: 2637,
    basePos: "Last",
    rephPos: j.Before_Sub,
    rephMode: "Implicit",
    blwfMode: "Pre_And_Post"
  },
  Gujarati: {
    hasOldSpec: !0,
    virama: 2765,
    basePos: "Last",
    rephPos: j.Before_Post,
    rephMode: "Implicit",
    blwfMode: "Pre_And_Post"
  },
  Oriya: {
    hasOldSpec: !0,
    virama: 2893,
    basePos: "Last",
    rephPos: j.After_Main,
    rephMode: "Implicit",
    blwfMode: "Pre_And_Post"
  },
  Tamil: {
    hasOldSpec: !0,
    virama: 3021,
    basePos: "Last",
    rephPos: j.After_Post,
    rephMode: "Implicit",
    blwfMode: "Pre_And_Post"
  },
  Telugu: {
    hasOldSpec: !0,
    virama: 3149,
    basePos: "Last",
    rephPos: j.After_Post,
    rephMode: "Explicit",
    blwfMode: "Post_Only"
  },
  Kannada: {
    hasOldSpec: !0,
    virama: 3277,
    basePos: "Last",
    rephPos: j.After_Post,
    rephMode: "Implicit",
    blwfMode: "Post_Only"
  },
  Malayalam: {
    hasOldSpec: !0,
    virama: 3405,
    basePos: "Last",
    rephPos: j.After_Main,
    rephMode: "Log_Repha",
    blwfMode: "Pre_And_Post"
  },
  // Handled by UniversalShaper
  // Sinhala: {
  //   hasOldSpec: false,
  //   virama: 0x0DCA,
  //   basePos: 'Last_Sinhala',
  //   rephPos: POSITIONS.After_Main,
  //   rephMode: 'Explicit',
  //   blwfMode: 'Pre_And_Post'
  // },
  Khmer: {
    hasOldSpec: !1,
    virama: 6098,
    basePos: "First",
    rephPos: j.Ra_To_Become_Reph,
    rephMode: "Vis_Repha",
    blwfMode: "Pre_And_Post"
  }
}, Nc = {
  // Khmer
  6078: [
    6081,
    6078
  ],
  6079: [
    6081,
    6079
  ],
  6080: [
    6081,
    6080
  ],
  6084: [
    6081,
    6084
  ],
  6085: [
    6081,
    6085
  ]
}, { decompositions: Uc } = /* @__PURE__ */ qt(Yt), vn = new Gt(Zr("AAARAAAAAABg2AAAAWYPmfDtnXuMXFUdx+/uzs7M7szudAtECGJRIMRQbUAithQWkGAKiVhNpFVRRAmIQVCDkDYICGotIA9BTCz8IeUviv7BQ2PBtBIRLBBQIWAUsKg1BKxRAqIgfs/cc+aeOXPej3tnZX7JJ/dxzj3nd36/8753Z5fUsuxgsAwcAU4Gp4BPgM+Cd4P3RjieDs4GXwLrHJ5bDy4DG8A14LvgZrAZbAF3gns0z18ALgY/B78C94NHwBPgabAE/AX8DbwM5sF/QX0yD5vFcU/wVnAgWAoOAyvAceBE8CGwBpwGzgJfAF8BXwXfAFeC68EmsBlsAXeCreA+8CB4DDwF/gh2gd3gFfAGmKxn2QzYC+wHDgRLweFgJTgWrKrnuq/GcQ04jV6fheN54EJwEbgcXAG+Q8O/j+Mt4DZwB9haz8t9Hz3a8iCN/xiOvwRP0evH6fE68AzOH+Ke2eWYhw3PcGnuxvkr4A3QaGRZB7wFLAEHg2XgiEZ/fHKcp/ceBh/A+cngFPCpRm6vM3E8l8a5gN67GMdvgqsbeX2ap9yI601gM7gN3AG20mfuo8cdOP6GpvdUg9oKxz839GV90RDO2/glxN1B790NXsN1rZll7WYRdw+c70uvTwIHNAfTO0RyL5TDmnnbc3lmRQI9UnM0dD5eovfz4FpJ/BNpXNYWV+N6Lfg0hY97JK1vn+Pur9DoQur2F7m436bHDUK8C5t5/8vruo4+97WmXG+GLmzEiBF+PDwEOowYMWLEiBEjRoxYeBw5BDqIPEfXut9yWN+vVNxfrnnmWqR/PdgENoMt4E5wD9gOHgCPgifBs2BXM99b2o3jP8F/wMRUlrXAHNgHvH0q3895J46HguXgWHAGLctmLv9VuL96qnp7jxgxYsSbCbJvuRZ97/tqxT59VVRtixEjRsThBG7OSt5zzoPT0M+cBc4T5noXOs79TqLHeZrHUeCSqeJ96gacXy2kecNU8V6Hh7yXuQlhtw7B/PO1RTkr52Aj8JNFZjYg3gOKuC/g/v6Ls2wNuAY8urg//PcIb+6RZXuDNeCS6SzbBrJWlh0DLiFHco8ed9IjzzvaWfa9sZzTcf6D9mCcnbg3PlNcH4fzS8F2MDaLdQG4dLZIJxbbaZqv4ri8k58f3+mPs66T6/TTzqDeI0aMGDGiHP5dcR8ce/xxYcWi6vOfr725uRzcjnngXVOD61Hync+9uL+Nmyfej/NHpvL56A5Jeuz7uyfo+pqcPz2Vf1NH0ttJ03pekt8SmuY/EPYy9zzbN319ym/9TL6ZIt9MHCXRdxJtoAkWTRdz472n87D9cTwYLJvuz++I6WIePo/zE8AHp4v8WLyP0nufnM6/+zoDx8+DL08P6r9+urheRtO+jD6/cdrsx3mqu8w+xH4PScKIXa5D2jeCm8Et4DbwI/BjcC/4BXgI/Bb8DuwEu8Bu8Ap4A9RaRZptnO8J9gUHgEPAoWA5OLY1qMO90GEV7q+mYWtxPBWcIYnL4p+DsPNbxfVFOP86uAr8DNc34HgTDb8Vx9sVaRFI/LtagzYjnCqpb908EX87eBA8Bh4Hf2jle/9/wvGFVv787rrZZy8h7qtgDOuFOmiBuXYRvg/O9wMHgXeB97SLspk4sq0OI/q9v13+ek+sh3zYSRp9jrYorw9ll1/GRzR+KotYZSHf8laVP2lvpA/8OGdPMk59hqtXZ+L8nHbxvWwqO65ryu+fT3VZz+l4dET7L0R072ljsMyzTpaJqQxsbL8M9WajY789DO85XMp/Dcp3Qztdn+9qf/a97ZWK8PXc3G+TpC/nv8Mncy7ZvICF302P5O+aNiOtLdTXd+D4Q7DVwfcvWvx9zTEJ/o5iG3R8YAjGNFseha5PGuZKz7b7xxXbOrXMcu5eJSo//rXdH/73Enz6L1q/X+fyIu8wZGtNBmkjkzNZNgP2AvuBg2bysKUzduXn/66JtNeN4PCZvO0/x7Ujdn4VnYOvRJzjZ/I+9sQZeftX2Tc1RPcPz/Tf4/si0g+t5Mq+kfZjZL34Mc5ul3PPnE7TOxvHK2qDaZ+L++db2HyYqMo/qVnb/P8uH8/rmnFxR0k6DCu/rjj/RxT7KGUSWgbd+LMQuEgYB1zsk2qtvJD8v5AhdfdttbEunSxbcJD9Zf7chqp1Hlbe7FK1/aPVTfp7FgtC1yGGiSncFK/DhZvi+epZta0WWjlsfDZMyPRdSPrryqSSKnXx1bkq/Ye9TlRpk7Lrjq1UrfdC9X+MtKqwP6+3a/4pJFUZF0pZZpv91MYjMBaRRXbxpho5zQmUY3F+Pt4o7rvQrBXPdm00TaE24uMadaM2meLSI7iu071t3er3b6ZLi8JEde3qw+6zGv+ycF5kaRBh/m1T/7Yl/mMyTuMwadP4xL9ifjJpNwbvDZRJ8G8vnqV/Wf12aa/kyOdl69+BspTsXzGueE6E+JfZnvmXIfNPW+FfXkjb1YmqPNpnLP3b61fHCj/X5tzGANf2y3yqvC7Jv7btV4TVbdammI9l/g0dS5lNxLrk2j9r8xjjxhBQnygg0lgg/bOrfyct+udJi/Yrk0lFnxC7f+5kRbsNmcexfrubt0X/rGvLqrGSnYv3ZPHEe8r7lvMvUfi2LOu/2dg8LrRtQt2yfcv8r5IU70VkIs6nbebUXf0M/o7Znl39Sdoz+X1oEb5N8ffF67qhPfPP6eoUbxf+GRf/6sRnvaSdmw+Bf1VxmbD+2sa//DU7t/Gv2PfKpKdrBP92Ojk+IvqX16ks/2qxbL8EZnc2HqsgYuqPuzZV+I3RbujbDm+T0PmWCVO/5jqftp1zy+wSA6s0JWtp2z5e1oZV+yMsjB3ZXolsv0Ulrv01v3/iKrF94Qtbt9siCnmeb6fjjf59KnLk1xaEbvtvFnFirGvEOqmycQrbm/IMsXd3P28uh4nM3swXRER717OiX8kc7K2qqyn2p3maFGU/aruP5VCv+PraoTYU8yUmmbDwcYo6pusnM486xdoga4dkPCb1pK7Sfc6ebvkd4qeAtQcd/N63bB3lU3dlUnUf38VyvqCqK7JxlNSd7lydrDlm+/uqHiRvl30Nrp/n9zpkZRjoJ3V1diyP05rIYXHYs+w+D5+WMS8b5gZtKcuX0KT5d/WwtB97VnyvY6rjMukI56HI0rFJPwt8PjT/1OXzSbcMeEmdh294qvKK4rNu7j4n3LNZg8TKXwafv025U+XvKjHsT8Q7/7LGaJt9lAh7Asz3uv0XEX6t0duDoWN/93wmh92XpUHmCKb9GALbG+rZP3AfNbQPKKv/jpF/bP0JXfuW1QYk7dhljcyvk5mw+933Hpo1g26PQ2ZP6zVmTJt47P25jncD9vPwGS+q9QS/V6RaY8j8K8LmvUr9HfYCpH5OWL9lZY+Sv6pesHCJHbtrf9k6etZvf0G1L0ja4cAe1UT/s3zdCe3/Q5/n372wMc97/E1Qh0Tbmfwh3m/V9On72tNnrCF1sJkVe1EyXMdBa7+lHMsk44zMF6St9e2djNnbm8ybpHkq+gbbemMaH0UZmD8obKGrk7r+nt+3bE7o83YZp/vqOKdv6PzJNN6mTJsI/51XR7i2ZrGA5B6zFwnjzxmqPjaGfW3tZNrz1eljq29mOOqeCfF/irRt87PNw0uXSVAvrmOMNT569MptsYaV0sic/wbY13e8hPrb9K2ySUJ0j6G/Lu0U4qpTrR23jMp6m5hU+YTaWCeh9aIsm/rqUHV4bFv42kgnZdfH1PUj1D7DVH9d8khRN1zFRl/+/TW//qxL1uH83+mk3H+SvRtS2TDU90nX2TpM6/1xzZpZtoYdK763dqlz0f6uNeFehcs+H/nbGP77MpX06n/ofpzP+tVmTUvRtVuX/cjS67OE5kRBrxyJ+w/dPo7r+9cO1160e3gqu0S2uW7PjN/L6ns/UfMf10Lai87frJ+3KndAfc8yTf1M3T4s6qm4/yh7/2GSkG8UMw//DvRLgbYZSEOxr0LCWvRdjfh9XGzfqN4NivfZd7rsmFp08zmbssrKJEuTfVMZopdpbuwSrhNv3/N2s+0PDG3KNB6RMrFvJHv6B85HXObAoWsd3zm3i+6uZYytv+5+pohbpo6+tpZJFfmGlrcMf4c8b1Pe2OUIsaXJrinCTfaxtZOt+NYnU3hIfQlN20Z/1+dt7JaqLsbIzycNWZmrlNg2Dc2/LJ1T+T6WrrYSml4Ku7ik7yIx2opJD51vU9UfVRmrqL8u/olZj0PyCLV5irxcdKoi/6rKb8qTrHsnhW9jyZH/nSpeWDzxd9769uQ016lgUuf2pAfKPhu2FpfZL2Yb9snLNl/fNIepXaUsj4vNXCXUZ75px8ojNP8UPvAta2g6fb+F1ckZuneshv1vGXXDeyRRrN/bBPS1Jul+l+7zW86R7Wv63WXyDpt/RxraRjvC+TC3O61/Sqj/prag8x372yQivn+XwudrI2X2E2KdtJEov52e0L+uv4FO3p/rvssgsL8F4d/z9PzlWS94m8fqS3361Fi+6qaVYHwi9Yz4iH2fobIj+45cpz/TUaarr/4+z+vaWtVtyAX2d1LG8W9C3f+F1mnf36/k4w3YPrLv+XBVXCJs3cr+n4MKJuLv/fN9GhNdXVP5pJMN9vFi3rpv3/r8Ywg3SYp66zNOsO8QGcxPpnmRS/1mvmJjju3v7absI2xspQrvs1dNbjOj/wP7h1RlZyKGy8occ408UL8En4v6xfC/K3z52XzJd62T8vuZGGsxo/6O46ntmNqqFb/jps2/hHV4rPKH0svT4pstU7t2tZ9u/ZdqbJL1MwP6O86Fyt4jYaIrGz9mjEt8lFL4PtVE6votG2P6fpdf/GZRse7s3bf4BtSl/DIbKMctx++Z+8o6K6z9FPOwKsRmXiaNl7C+6NYRpjlbqG1j72f49qsuY4brd/amb4ZVc8TQ+sSH985LrEe8iPWJnfPrJRbWbb+dwn4x6o+r/aS2S7w3qWt//LnYz2ntE0vH1uDcyKatx1rH+EiMPEN1SZG/iz6+9o01Rob6O7Q+xLZ1jHobK61U+pWVvo2EpuWqzzD6Poa+pvhli0wn8Zq/72Mzm2d90o5VN1x9ZKuzbTgvqWwUIin8FSpl1CXXvFRxU0iozVPYJDRtF3uFphn6XAyJUUdD7SjTJ8v6n9fVbVObkKWp001lc9VRlqdOf5v0ZM+bymdbfp1NfG0bq27Y5JMyfxeJkU6o/inKH8O2Zfgidb6h/g3VJ7QcVbWL0Pxt6rlrPqa4KfQ25a2zl4/E8GdM/4fK/wA=")), Gc = new Na(/* @__PURE__ */ qt(bn));
class xe extends v0 {
  static planFeatures(e) {
    e.addStage(Vc), e.addStage([
      "locl",
      "ccmp"
    ]), e.addStage(qc), e.addStage("nukt"), e.addStage("akhn"), e.addStage("rphf", !1), e.addStage("rkrf"), e.addStage("pref", !1), e.addStage("blwf", !1), e.addStage("abvf", !1), e.addStage("half", !1), e.addStage("pstf", !1), e.addStage("vatu"), e.addStage("cjct"), e.addStage("cfar", !1), e.addStage(Wc), e.addStage({
      local: [
        "init"
      ],
      global: [
        "pres",
        "abvs",
        "blws",
        "psts",
        "haln",
        "dist",
        "abvm",
        "blwm",
        "calt",
        "clig"
      ]
    }), e.unicodeScript = Fu(e.script), e.indicConfig = pa[e.unicodeScript] || pa.Default, e.isOldSpec = e.indicConfig.hasOldSpec && e.script[e.script.length - 1] !== "2";
  }
  static assignFeatures(e, t) {
    for (let r = t.length - 1; r >= 0; r--) {
      let s = t[r].codePoints[0], n = Nc[s] || Uc[s];
      if (n) {
        let a = n.map((o) => {
          let u = e.font.glyphForCodePoint(o);
          return new qe(e.font, u.id, [
            o
          ], t[r].features);
        });
        t.splice(r, 1, ...a);
      }
    }
  }
}
De(xe, "zeroMarkWidths", "NONE");
function Vr(i) {
  return vn.get(i.codePoints[0]) >> 8;
}
function xn(i) {
  return 1 << (vn.get(i.codePoints[0]) & 255);
}
class It {
  constructor(e, t, r, s) {
    this.category = e, this.position = t, this.syllableType = r, this.syllable = s;
  }
}
function Vc(i, e) {
  let t = 0, r = 0;
  for (let [s, n, a] of Gc.match(e.map(Vr))) {
    if (s > r) {
      ++t;
      for (let o = r; o < s; o++) e[o].shaperInfo = new It(se.X, j.End, "non_indic_cluster", t);
    }
    ++t;
    for (let o = s; o <= n; o++) e[o].shaperInfo = new It(1 << Vr(e[o]), xn(e[o]), a[0], t);
    r = n + 1;
  }
  if (r < e.length) {
    ++t;
    for (let s = r; s < e.length; s++) e[s].shaperInfo = new It(se.X, j.End, "non_indic_cluster", t);
  }
}
function y0(i) {
  return i.shaperInfo.category & Rc;
}
function $e(i) {
  return i.shaperInfo.category & gn;
}
function e0(i) {
  return i.shaperInfo.category & et;
}
function r0(i, e) {
  for (let r of i) r.features = {
    [e]: !0
  };
  return i[0]._font._layoutEngine.engine.GSUBProcessor.applyFeatures([
    e
  ], i), i.length === 1;
}
function zc(i, e, t) {
  let r = [
    t,
    e,
    t
  ];
  return r0(r.slice(0, 2), "blwf") || r0(r.slice(1, 3), "blwf") ? j.Below_C : r0(r.slice(0, 2), "pstf") || r0(r.slice(1, 3), "pstf") || r0(r.slice(0, 2), "pref") || r0(r.slice(1, 3), "pref") ? j.Post_C : j.Base_C;
}
function qc(i, e, t) {
  let r = t.indicConfig, s = i._layoutEngine.engine.GSUBProcessor.features, n = i.glyphForCodePoint(9676).id, a = i.glyphForCodePoint(r.virama).id;
  if (a) {
    let o = new qe(i, a, [
      r.virama
    ]);
    for (let u = 0; u < e.length; u++) e[u].shaperInfo.position === j.Base_C && (e[u].shaperInfo.position = zc(i, e[u].copy(), o));
  }
  for (let o = 0, u = Ut(e, 0); o < e.length; o = u, u = Ut(e, o)) {
    let { category: c, syllableType: d } = e[o].shaperInfo;
    if (d === "symbol_cluster" || d === "non_indic_cluster") continue;
    if (d === "broken_cluster" && n) {
      let w = new qe(i, n, [
        9676
      ]);
      w.shaperInfo = new It(1 << Vr(w), xn(w), e[o].shaperInfo.syllableType, e[o].shaperInfo.syllable);
      let I = o;
      for (; I < u && e[I].shaperInfo.category === se.Repha; ) I++;
      e.splice(I++, 0, w), u++;
    }
    let f = u, p = o, m = !1;
    if (r.rephPos !== j.Ra_To_Become_Reph && s.rphf && o + 3 <= u && (r.rephMode === "Implicit" && !$e(e[o + 2]) || r.rephMode === "Explicit" && e[o + 2].shaperInfo.category === se.ZWJ)) {
      let w = [
        e[o].copy(),
        e[o + 1].copy(),
        e[o + 2].copy()
      ];
      if (r0(w.slice(0, 2), "rphf") || r.rephMode === "Explicit" && r0(w, "rphf")) {
        for (p += 2; p < u && $e(e[p]); ) p++;
        f = o, m = !0;
      }
    } else if (r.rephMode === "Log_Repha" && e[o].shaperInfo.category === se.Repha) {
      for (p++; p < u && $e(e[p]); ) p++;
      f = o, m = !0;
    }
    switch (r.basePos) {
      case "Last": {
        let w = u, I = !1;
        do {
          let h = e[--w].shaperInfo;
          if (y0(e[w])) {
            if (h.position !== j.Below_C && (h.position !== j.Post_C || I)) {
              f = w;
              break;
            }
            h.position === j.Below_C && (I = !0), f = w;
          } else if (o < w && h.category === se.ZWJ && e[w - 1].shaperInfo.category === se.H) break;
        } while (w > p);
        break;
      }
      case "First":
        f = o;
        for (let w = f + 1; w < u; w++) y0(e[w]) && (e[w].shaperInfo.position = j.Below_C);
    }
    m && f === o && p - f <= 2 && (m = !1);
    for (let w = o; w < f; w++) {
      let I = e[w].shaperInfo;
      I.position = Math.min(j.Pre_C, I.position);
    }
    f < u && (e[f].shaperInfo.position = j.Base_C);
    for (let w = f + 1; w < u; w++) if (e[w].shaperInfo.category === se.M) {
      for (let I = w + 1; I < u; I++) if (y0(e[I])) {
        e[I].shaperInfo.position = j.Final_C;
        break;
      }
      break;
    }
    if (m && (e[o].shaperInfo.position = j.Ra_To_Become_Reph), t.isOldSpec) {
      let w = t.unicodeScript !== "Malayalam";
      for (let I = f + 1; I < u; I++) if (e[I].shaperInfo.category === se.H) {
        let h;
        for (h = u - 1; h > I && !(y0(e[h]) || w && e[h].shaperInfo.category === se.H); h--)
          ;
        if (e[h].shaperInfo.category !== se.H && h > I) {
          let W = e[I];
          e.splice(I, 0, ...e.splice(I + 1, h - I)), e[h] = W;
        }
        break;
      }
    }
    let C = j.Start;
    for (let w = o; w < u; w++) {
      let I = e[w].shaperInfo;
      if (I.category & (gn | se.N | se.RS | se.CM | et & I.category)) {
        if (I.position = C, I.category === se.H && I.position === j.Pre_M) {
          for (let h = w; h > o; h--) if (e[h - 1].shaperInfo.position !== j.Pre_M) {
            I.position = e[h - 1].shaperInfo.position;
            break;
          }
        }
      } else I.position !== j.SMVD && (C = I.position);
    }
    let O = f;
    for (let w = f + 1; w < u; w++)
      if (y0(e[w])) {
        for (let I = O + 1; I < w; I++) e[I].shaperInfo.position < j.SMVD && (e[I].shaperInfo.position = e[w].shaperInfo.position);
        O = w;
      } else e[w].shaperInfo.category === se.M && (O = w);
    let G = e.slice(o, u);
    G.sort((w, I) => w.shaperInfo.position - I.shaperInfo.position), e.splice(o, G.length, ...G);
    for (let w = o; w < u; w++) if (e[w].shaperInfo.position === j.Base_C) {
      f = w;
      break;
    }
    for (let w = o; w < u && e[w].shaperInfo.position === j.Ra_To_Become_Reph; w++) e[w].features.rphf = !0;
    let L = !t.isOldSpec && r.blwfMode === "Pre_And_Post";
    for (let w = o; w < f; w++)
      e[w].features.half = !0, L && (e[w].features.blwf = !0);
    for (let w = f + 1; w < u; w++)
      e[w].features.abvf = !0, e[w].features.pstf = !0, e[w].features.blwf = !0;
    if (t.isOldSpec && t.unicodeScript === "Devanagari")
      for (let w = o; w + 1 < f; w++) e[w].shaperInfo.category === se.Ra && e[w + 1].shaperInfo.category === se.H && (w + 1 === f || e[w + 2].shaperInfo.category === se.ZWJ) && (e[w].features.blwf = !0, e[w + 1].features.blwf = !0);
    let T = 2;
    if (s.pref && f + T < u)
      for (let w = f + 1; w + T - 1 < u; w++) {
        let I = [
          e[w].copy(),
          e[w + 1].copy()
        ];
        if (r0(I, "pref")) {
          for (let h = 0; h < T; h++) e[w++].features.pref = !0;
          if (s.cfar) for (; w < u; w++) e[w].features.cfar = !0;
          break;
        }
      }
    for (let w = o + 1; w < u; w++) if ($e(e[w])) {
      let I = e[w].shaperInfo.category === se.ZWNJ, h = w;
      do
        h--, I && delete e[h].features.half;
      while (h > o && !y0(e[h]));
    }
  }
}
function Wc(i, e, t) {
  let r = t.indicConfig, s = i._layoutEngine.engine.GSUBProcessor.features;
  for (let n = 0, a = Ut(e, 0); n < e.length; n = a, a = Ut(e, n)) {
    let o = !!s.pref, u = n;
    for (; u < a; u++) if (e[u].shaperInfo.position >= j.Base_C) {
      if (o && u + 1 < a) {
        for (let c = u + 1; c < a; c++) if (e[c].features.pref) {
          if (!(e[c].substituted && e[c].isLigated && !e[c].isMultiplied)) {
            for (u = c; u < a && e0(e[u]); ) u++;
            e[u].shaperInfo.position = j.BASE_C, o = !1;
          }
          break;
        }
      }
      if (t.unicodeScript === "Malayalam") for (let c = u + 1; c < a; c++) {
        for (; c < a && $e(e[c]); ) c++;
        if (c === a || !e0(e[c])) break;
        for (c++; c < a && $e(e[c]); ) c++;
        c < a && y0(e[c]) && e[c].shaperInfo.position === j.Below_C && (u = c, e[u].shaperInfo.position = j.Base_C);
      }
      n < u && e[u].shaperInfo.position > j.Base_C && u--;
      break;
    }
    if (u === a && n < u && e[u - 1].shaperInfo.category === se.ZWJ && u--, u < a) for (; n < u && e[u].shaperInfo.category & (se.N | et); ) u--;
    if (n + 1 < a && n < u) {
      let c = u === a ? u - 2 : u - 1;
      if (t.unicodeScript !== "Malayalam" && t.unicodeScript !== "Tamil") {
        for (; c > n && !(e[c].shaperInfo.category & (se.M | et)); ) c--;
        e0(e[c]) && e[c].shaperInfo.position !== j.Pre_M ? c + 1 < a && $e(e[c + 1]) && c++ : c = n;
      }
      if (n < c && e[c].shaperInfo.position !== j.Pre_M) {
        for (let d = c; d > n; d--) if (e[d - 1].shaperInfo.position === j.Pre_M) {
          let f = d - 1;
          f < u && u <= c && u--;
          let p = e[f];
          e.splice(f, 0, ...e.splice(f + 1, c - f)), e[c] = p, c--;
        }
      }
    }
    if (n + 1 < a && e[n].shaperInfo.position === j.Ra_To_Become_Reph && e[n].shaperInfo.category === se.Repha !== (e[n].isLigated && !e[n].isMultiplied)) {
      let c, d = r.rephPos, f = !1;
      if (d !== j.After_Post) {
        for (c = n + 1; c < u && !e0(e[c]); ) c++;
        if (c < u && e0(e[c]) && (c + 1 < u && $e(e[c + 1]) && c++, f = !0), !f && d === j.After_Main) {
          for (c = u; c + 1 < a && e[c + 1].shaperInfo.position <= j.After_Main; ) c++;
          f = c < a;
        }
        if (!f && d === j.After_Sub) {
          for (c = u; c + 1 < a && !(e[c + 1].shaperInfo.position & (j.Post_C | j.After_Post | j.SMVD)); ) c++;
          f = c < a;
        }
      }
      if (!f) {
        for (c = n + 1; c < u && !e0(e[c]); ) c++;
        c < u && e0(e[c]) && (c + 1 < u && $e(e[c + 1]) && c++, f = !0);
      }
      if (!f) {
        for (c = a - 1; c > n && e[c].shaperInfo.position === j.SMVD; ) c--;
        if (e0(e[c]))
          for (let m = u + 1; m < c; m++) e[m].shaperInfo.category === se.M && c--;
      }
      let p = e[n];
      e.splice(n, 0, ...e.splice(n + 1, c - n)), e[c] = p, n < u && u <= c && u--;
    }
    if (o && u + 1 < a) {
      for (let c = u + 1; c < a; c++) if (e[c].features.pref) {
        if (e[c].isLigated && !e[c].isMultiplied) {
          let d = u;
          if (t.unicodeScript !== "Malayalam" && t.unicodeScript !== "Tamil") {
            for (; d > n && !(e[d - 1].shaperInfo.category & (se.M | et)); ) d--;
            if (d > n && e[d - 1].shaperInfo.category === se.M) {
              let m = c;
              for (let C = u + 1; C < m; C++) if (e[C].shaperInfo.category === se.M) {
                d--;
                break;
              }
            }
          }
          d > n && e0(e[d - 1]) && d < a && $e(e[d]) && d++;
          let f = c, p = e[f];
          e.splice(d + 1, 0, ...e.splice(d, f - d)), e[d] = p, d <= u && u < f && u++;
        }
        break;
      }
    }
    e[n].shaperInfo.position === j.Pre_M && (!n || !/Cf|Mn/.test(zt(e[n - 1].codePoints[0]))) && (e[n].features.init = !0);
  }
}
function Ut(i, e) {
  if (e >= i.length) return e;
  let t = i[e].shaperInfo.syllable;
  for (; ++e < i.length && i[e].shaperInfo.syllable === t; ) ;
  return e;
}
const { categories: Hc, decompositions: ba } = /* @__PURE__ */ qt(Yt), $c = new Gt(Zr("AAACAAAAAAAQugAAAQUO+vHtnHuMX0UVx2d3u/t7bXe7FlqgvB+mpQhFmhikMRAg0ZQmakMU+cPWBzZisEGNjUpoiIYCEgmGUGOEGqOVNPUZUGNA+QNIBU2KREEFFSMBUYRISMXE+B3vnPzOzp553tcWfif5ZO5jnufMzJ2ZO/eumlDqFLAWnAMuBBvBZnC5uXZeBe4WsA1sBzs8/naCXcL1G8GtYDfYA74NvgfuAfcZHmT+fwEeBb8DTwvxPQWeAavACyZvq8z9VYxXwCGglijVBcvACnA8eCM4E6wHG8BF4BLwbvA+8AHwUbAd7AA7wS5wC9gN7gR7wX5wN7gXPAAeBr8Gvwd/Ac+CF8EhoCaV6oBZsBKcAE4FZ0wWeV8P9zxwoTnfCHczuBxsAdvAx8Gnzf1r4X4B3AxuA1+bHJb9m5PzdVGW/Yjv+xXHyfmxFfd9OH8Q/Ar8Bjw1WZT3GfACeAX8N5CfqSmlZsAKsGqqCH8K3DXgbHCuuXYB3HeAd4HLpgrdarbi+EPgY+CT4HPg8ybMTcb9MtyvghtYut/A+b4pf95+ELgfw08Qx/3gADgInjDl0veehPtX8A/wsrn2KtzxDuogWNoJx38k/BzXKeI8Ee5qcBZYD9aZtDbg+AwT19uMX83F7JizCdcvBZdZ97c6/BMfMWmfzfTm88/95aLj+DDSvApcDXZ04uPfaen3TMHPLvi5BezuFPVtD4t/qUcfe3FvP7gb3Ouwo9T+H+gMy/UIjh8DfwBPm7T08d/M8WMBe1Sh3xEjXo+M2s+IESNGjBgxYsSI1wLrOsM1gRsi/P+TzV3/Zc1jvxgR/j8IM9Et1mEGcJeDFeA4cJq5/ia467uF/w1wzwdvB+80998LdwvYZs63w90Bdnbd6Wp/uzz3R4wYMWJEvZzTMm2Xf8SIEfVQd/v+EsaPt3eL90J3wP2WMJ78Trd4t6+P77Hu37cIxp9/ny6YXqrUJeCR6TA74e/nll81MzxejeMtYA94HBwy91bPYow+O/S3A8d7oIM/gRN7CAP29Iqx/B1ThfuwOecM+vA3NmRjf6Gfm3BtH7v+PI7XDpS6EuwDz4O10+0/f9om1F4ehO4OmHp6EO7jxl56nvhsN/15ut+4Z0b657yYkZ7UJ0jhX0bcr3bn+6P87vekN4762QNzvWHZtL+jcH5srzg/uTf0f3pvfj5i+6tYW7rK9+aefO+tuL4BXAQ2gs3gPeBJc//9OL4CXAWuNvc/A64DN4Jbwe0s7jtxvBfsAz8EPwX3gwPgoJAHPQ9/Atf/bO7p/TTP4fglwS/5/zfujfWH5z0cz4Gj+8X5Sf1ib4m+vwbHZ/fdOtP+z+3LOnPp/QL4vxhsApeCy8BWk/a2ftFmYu22Hf4/Ba4B14Hrwc0sP7fh+Cvg6+Au8F1WthA/8pT7UeTxZ/12njkuXT8UyM9i6iur1EEb6f+yPz/eg0b3v4X7x365fMaW42lPu7PTv6vi8i/G+lWF/cvUk7bLl1r+5/rN5tu3j2qvWTd/qV+4h+AqjDGnBsX59GDo94iBXDa6v6Yjl6vu+h8itJcsZq/ZykHhHg/3tMHhUe9s/Yfuny7YNxTvQ8LYdrER2+/c0GBezhrMv3ZNRv7PmYirh7oOv4W1Y72/cwPOzx8U7X8d2295sfE3MPnbBPfSQbHv9nK4HxTqiK/trI7Yy5mLzvuVg/nX+N7V51A3r+gMy/4J434W7l2dYf5PZWGuNX6uh3uzEPetuLY7sZ20zTETY2oxyBhj3DrnfsidYPeXRGLHpxzX6pbFofGRkFBdGhcgW40L4cYtd9JAElO36q4LEzXHX7VMtZ2BEhJjy9dT25fazOtJxhwsBrHzwfu8w12kMYN9fLhIbp2RxlI59rX1dzjpsKl2Fxt3iu6rbofc9q5+KcRrXVzzDn6/Crvk6p/y1GFgGhs9/6maHjBLgv8/18fTxl1q0bPoW8ywsFTGWaazHosrNn/kP2eeqEroZYLZphsZl7L82eephMIqNT8dyT9JjH1Jpg32ubZvTB/SF665ymSnnaqjUHum+1Qn+NyOtz9f2r6y5OQ51b6hYy0D40r2tYXar30+Y/mbVX6JqY+hMC60XZapoh3S/HdOpT3DYu3rs0lKnquyb277JZvyPlqp+f1zVVK2/dJYNpQGf04uYyh1+PTPqfalZ2tO/xwSu+3bOrDzmWvfcTW/fLmibRx6lkvlcOlc8qsE/y5/rnSk67F1iAu1VT6+4jKt5tufn8e2b+n57JKcckhrsKG1Cd6Wu+Y8tf2l5DenPafqQZ/7xstKLeyr+XnInjSelvRgS9n27JPQM5n6Am7jmLG8VK6m7OvyS2L313XYV2r/tth5LWPfNxhyhI+1Up7HVbe/HMgeZE8brtNQ/7tcyX0cn//H2LTO9kpir5VI6yYp9szJW9W2jI1Tqfl5ic2v1GZ5XaG6RDZbyvxMO/DVh1SdUj5y1vraaHs+2/TYNXvtSRoXk4wrf9w6fEctnFt0zL2y+xFsfSrLza2zOTqMiZv8xOpbn8+xsL5ykdj6VsxNKb/Lvxb7nX8u48y1x6yuMW3V9tNxTlouzXslibVxndjC14xda8g2NIbg5x01XAP2lfeIBFSi/zrQEporTXru8fCueiy1CUnqrhspSM9SzbSS64tep9R1ZsZcOxKsUEUfNZeYtr0vjY5DeXW915hT8/PRV8MxlR1HV4DHZZc9R7dzajgWoXikdLtGr0uEfPigsGS/NvYjSHW87XejoXZehZ74XrcqpQ4d5T5f7Gu8f6g7fQmefoqOqk4/VarQv2o4/VDetPDnhjR2dc3BCBp/9NVw7KGfwStVMf6aZNAajj6224j9HCZbpZa/LvH1gU30i/q5WnUdSNEprxv2eIOwx2pcjjLMsmObo008k0J4u69P3d9QdbspW/dy080Nb8PXqcrmj0vsc7tu6qwD1A5oLYr3U3XWSxqj6/a10nCMkudJMyxvrvbK55jUrqU+Xlr/Iai98jY7mVAml5QNHxq31j2m5TrSdmp6z5p+9kpzQntdQbI1Pafr6I9C60gxrALHGtdF6tyhLTtxeBuW+hhqyzPMX931xl6rJ5f6n5h3blpsW7vKbvdBfL1gpYfjDLrvob1drrRT+mcuMf1OrJSdW/P+RfufdUB+pOtdTzhpL5t0jfKr46P3obQfQdPGt1jS+DEkx4MT2PmEg1j72OthqfZNWX+JuZ4at/2sTAmn5cSIMqZIjk0pnD0+aUI6YS9ekdaspWsp8cWEC62dS66UTkq+ypajyvXSlPz4xhQhm/ns6wpXBVI560jHN9aKkdT46spvWT916rONdHNsGSNtl6Hp8oakTVukpF9n3U3Jx0TNefbp3R4jltVfFfpvQkJpNaH/puyco++qbZPz7sE1L3DFGVovc4XPLUPO3ELyrzLiSpmPhaTJfqeJ+t60PiTh9snNW2656upDQ+Wtyg6ueJquB7HSVPspW9a28lDWJouhb6iyv7XjTfVL67j2vjDpvUfMt1Vl4GvctMaeq/vYcFWXIfV5Ku3XaxK951H6dsWFrhcxa3pU/pz3C1xc71tTcaXjGjtJbYIj7UHm7wxSyx+D/d7SfpfJ3wPpfSQp32tS2dt8V2tD7+Bce3rpPa3eC6Dr8Ulq+K+J3HFvbn312Zv2RdStr9g0pP0P/B04XbP3Q8cIT2dlRF6orkrhY/Rv27FqHfL1DP480ffo/V6V7aTHXLKDbTdXOOrnyG1ScvSv6xqve30lPzdpj36M8Pilb+L5vr0xE3dd30nWIfZ45uSSxK4x+CRmTUK6F/LrSsfnj+aOdYyvpXyMK7/OpHWjlDTsa0rJum5K7Ppnj7F9c+0q0qtr7pQji2X9oMwcVrJfmblwU2V2SV3rEk3YuO46XXf8MfrQz077G2zftyDkj/ZqhcZr9nldkOg5ykAt3GunJbR3NGYsUfWafd3ts853C4dLHppOM6WcfM5C+xSbaC/2HMa1H9v1vXdoXm/LKSVpYh5wqmr/X67SfwHtPc9a97p/k8bt0hpbW0j1Svr2m+7Rd98qIQ1pvSF273dKOjHYNmk6fd8/JX3tWIddblBqoU5p7zrZKnd9TppjVq0DSitWqkwz12b2exb7vwjaRvS/TFd/S+8AYvIo+Suri5TwvvZRdV1IQevQ1/8SA+UeH5eto7n/X1Oe86ptaafl8kPjcF7P7W93eD9d5n+oSvn7fFe7I/G9q1IBfylSR71N6fft94ZU18hOXKR+JqUO8f4+5dvLsmWlMQb/Vov+CUDlpTGUndeQlG3fdZWdRPoPgl3mmDlsLnaey/4X3tVuU+o6L3/Pym+qlLV/jk6rlBRd8394hZ6JdnuqIv2ykOh3pfq96Wkq/E8qu2xl88/tOJ4R3tfmpbGi3c5T859bzqr7MbsN03iI5itUNj5eaEKWqIX/KJCQ/iFWNZMmHXs8ovWk53JzFq5vPul6zDjLV36pX7bzvNzB0YlQOZephWtRS5T7eeSq8030R77/HvC1d7tN83Zt9yltrDdwSR0XxsZd5l+MvvvU1/M9jSnj+Nh6FPJbBld/w6XHXH5MZeXrOfS/65g9RTl1JCa8chzX2RZ9/3lXSh4/VqWfEBNq4b82Ytp6m+9Qqxir1jX+rfPdT1vvsWhM6bPbmON6E1LnPCZW7L0qqXswmtqf0MQelZj4myrzYtzvIYmURlvtqapyx+gzRfd0XPfahVSOquMoG+dibBdl46iyfdbV1qvUW9m8+KTudMvkzZe/pqTJ+pWTflX5zw1fVfox6ZTVc8hvHflOSb+OuG1JsZ0kufXAJf8D")), Xc = new Na(/* @__PURE__ */ qt(Yt));
class ee extends v0 {
  static planFeatures(e) {
    e.addStage(Yc), e.addStage([
      "locl",
      "ccmp",
      "nukt",
      "akhn"
    ]), e.addStage(va), e.addStage([
      "rphf"
    ], !1), e.addStage(Zc), e.addStage(va), e.addStage([
      "pref"
    ]), e.addStage(Kc), e.addStage([
      "rkrf",
      "abvf",
      "blwf",
      "half",
      "pstf",
      "vatu",
      "cjct"
    ]), e.addStage(Jc), e.addStage([
      "abvs",
      "blws",
      "pres",
      "psts",
      "dist",
      "abvm",
      "blwm"
    ]);
  }
  static assignFeatures(e, t) {
    for (let r = t.length - 1; r >= 0; r--) {
      let s = t[r].codePoints[0];
      if (ba[s]) {
        let n = ba[s].map((a) => {
          let o = e.font.glyphForCodePoint(a);
          return new qe(e.font, o.id, [
            a
          ], t[r].features);
        });
        t.splice(r, 1, ...n);
      }
    }
  }
}
De(ee, "zeroMarkWidths", "BEFORE_GPOS");
function ga(i) {
  return $c.get(i.codePoints[0]);
}
class jc {
  constructor(e, t, r) {
    this.category = e, this.syllableType = t, this.syllable = r;
  }
}
function Yc(i, e) {
  let t = 0;
  for (let [r, s, n] of Xc.match(e.map(ga))) {
    ++t;
    for (let o = r; o <= s; o++) e[o].shaperInfo = new jc(Hc[ga(e[o])], n[0], t);
    let a = e[r].shaperInfo.category === "R" ? 1 : Math.min(3, s - r);
    for (let o = r; o < r + a; o++) e[o].features.rphf = !0;
  }
}
function va(i, e) {
  for (let t of e) t.substituted = !1;
}
function Zc(i, e) {
  for (let t of e) t.substituted && t.features.rphf && (t.shaperInfo.category = "R");
}
function Kc(i, e) {
  for (let t of e) t.substituted && (t.shaperInfo.category = "VPre");
}
function Jc(i, e) {
  let t = i.glyphForCodePoint(9676).id;
  for (let r = 0, s = xa(e, 0); r < e.length; r = s, s = xa(e, r)) {
    let n, a, o = e[r].shaperInfo, u = o.syllableType;
    if (!(u !== "virama_terminated_cluster" && u !== "standard_cluster" && u !== "broken_cluster")) {
      if (u === "broken_cluster" && t) {
        let c = new qe(i, t, [
          9676
        ]);
        for (c.shaperInfo = o, n = r; n < s && e[n].shaperInfo.category === "R"; n++) ;
        e.splice(++n, 0, c), s++;
      }
      if (o.category === "R" && s - r > 1) {
        for (n = r + 1; n < s; n++)
          if (o = e[n].shaperInfo, ma(o) || Ct(e[n])) {
            Ct(e[n]) && n--, e.splice(r, 0, ...e.splice(r + 1, n - r), e[n]);
            break;
          }
      }
      for (n = r, a = s; n < s; n++)
        o = e[n].shaperInfo, ma(o) || Ct(e[n]) ? a = Ct(e[n]) ? n + 1 : n : (o.category === "VPre" || o.category === "VMPre") && a < n && e.splice(a, 1, e[n], ...e.splice(a, n - a));
    }
  }
}
function xa(i, e) {
  if (e >= i.length) return e;
  let t = i[e].shaperInfo.syllable;
  for (; ++e < i.length && i[e].shaperInfo.syllable === t; ) ;
  return e;
}
function Ct(i) {
  return i.shaperInfo.category === "H" && !i.isLigated;
}
function ma(i) {
  return i.category === "B" || i.category === "GB";
}
const Qc = {
  arab: f0,
  mong: f0,
  syrc: f0,
  "nko ": f0,
  phag: f0,
  mand: f0,
  mani: f0,
  phlp: f0,
  hang: fn,
  bng2: xe,
  beng: xe,
  dev2: xe,
  deva: xe,
  gjr2: xe,
  gujr: xe,
  guru: xe,
  gur2: xe,
  knda: xe,
  knd2: xe,
  mlm2: xe,
  mlym: xe,
  ory2: xe,
  orya: xe,
  taml: xe,
  tml2: xe,
  telu: xe,
  tel2: xe,
  khmr: xe,
  bali: ee,
  batk: ee,
  brah: ee,
  bugi: ee,
  buhd: ee,
  cakm: ee,
  cham: ee,
  dupl: ee,
  egyp: ee,
  gran: ee,
  hano: ee,
  java: ee,
  kthi: ee,
  kali: ee,
  khar: ee,
  khoj: ee,
  sind: ee,
  lepc: ee,
  limb: ee,
  mahj: ee,
  // mand: UniversalShaper, // Mandaic
  // mani: UniversalShaper, // Manichaean
  mtei: ee,
  modi: ee,
  // mong: UniversalShaper, // Mongolian
  // 'nko ': UniversalShaper, // N’Ko
  hmng: ee,
  // phag: UniversalShaper, // Phags-pa
  // phlp: UniversalShaper, // Psalter Pahlavi
  rjng: ee,
  saur: ee,
  shrd: ee,
  sidd: ee,
  sinh: xe,
  sund: ee,
  sylo: ee,
  tglg: ee,
  tagb: ee,
  tale: ee,
  lana: ee,
  tavt: ee,
  takr: ee,
  tibt: ee,
  tfng: ee,
  tirh: ee,
  latn: v0,
  DFLT: v0
};
function _c(i) {
  Array.isArray(i) || (i = [
    i
  ]);
  for (let e of i) {
    let t = Qc[e];
    if (t) return t;
  }
  return v0;
}
class ef extends Bt {
  applyLookup(e, t) {
    switch (e) {
      case 1: {
        let s = this.coverageIndex(t.coverage);
        if (s === -1) return !1;
        let n = this.glyphIterator.cur;
        switch (t.version) {
          case 1:
            n.id = n.id + t.deltaGlyphID & 65535;
            break;
          case 2:
            n.id = t.substitute.get(s);
            break;
        }
        return !0;
      }
      case 2: {
        let s = this.coverageIndex(t.coverage);
        if (s !== -1) {
          let n = t.sequences.get(s);
          if (n.length === 0)
            return this.glyphs.splice(this.glyphIterator.index, 1), !0;
          this.glyphIterator.cur.id = n[0], this.glyphIterator.cur.ligatureComponent = 0;
          let a = this.glyphIterator.cur.features, o = this.glyphIterator.cur, u = n.slice(1).map((c, d) => {
            let f = new qe(this.font, c, void 0, a);
            return f.shaperInfo = o.shaperInfo, f.isLigated = o.isLigated, f.ligatureComponent = d + 1, f.substituted = !0, f.isMultiplied = !0, f;
          });
          return this.glyphs.splice(this.glyphIterator.index + 1, 0, ...u), !0;
        }
        return !1;
      }
      case 3: {
        let s = this.coverageIndex(t.coverage);
        if (s !== -1) {
          let n = 0;
          return this.glyphIterator.cur.id = t.alternateSet.get(s)[n], !0;
        }
        return !1;
      }
      case 4: {
        let s = this.coverageIndex(t.coverage);
        if (s === -1) return !1;
        for (let n of t.ligatureSets.get(s)) {
          let a = this.sequenceMatchIndices(1, n.components);
          if (!a) continue;
          let o = this.glyphIterator.cur, u = o.codePoints.slice();
          for (let O of a) u.push(...this.glyphs[O].codePoints);
          let c = new qe(this.font, n.glyph, u, o.features);
          c.shaperInfo = o.shaperInfo, c.isLigated = !0, c.substituted = !0;
          let d = o.isMark;
          for (let O = 0; O < a.length && d; O++) d = this.glyphs[a[O]].isMark;
          c.ligatureID = d ? null : this.ligatureID++;
          let f = o.ligatureID, p = o.codePoints.length, m = p, C = this.glyphIterator.index + 1;
          for (let O of a) {
            if (d) C = O;
            else for (; C < O; ) {
              var r = m - p + Math.min(this.glyphs[C].ligatureComponent || 1, p);
              this.glyphs[C].ligatureID = c.ligatureID, this.glyphs[C].ligatureComponent = r, C++;
            }
            f = this.glyphs[C].ligatureID, p = this.glyphs[C].codePoints.length, m += p, C++;
          }
          if (f && !d) for (let O = C; O < this.glyphs.length && this.glyphs[O].ligatureID === f; O++) {
            var r = m - p + Math.min(this.glyphs[O].ligatureComponent || 1, p);
            this.glyphs[O].ligatureComponent = r;
          }
          for (let O = a.length - 1; O >= 0; O--) this.glyphs.splice(a[O], 1);
          return this.glyphs[this.glyphIterator.index] = c, !0;
        }
        return !1;
      }
      case 5:
        return this.applyContext(t);
      case 6:
        return this.applyChainingContext(t);
      case 7:
        return this.applyLookup(t.lookupType, t.extension);
      default:
        throw new Error(`GSUB lookupType ${e} is not supported`);
    }
  }
}
class tf extends Bt {
  applyPositionValue(e, t) {
    let r = this.positions[this.glyphIterator.peekIndex(e)];
    t.xAdvance != null && (r.xAdvance += t.xAdvance), t.yAdvance != null && (r.yAdvance += t.yAdvance), t.xPlacement != null && (r.xOffset += t.xPlacement), t.yPlacement != null && (r.yOffset += t.yPlacement);
    let s = this.font._variationProcessor, n = this.font.GDEF && this.font.GDEF.itemVariationStore;
    s && n && (t.xPlaDevice && (r.xOffset += s.getDelta(n, t.xPlaDevice.a, t.xPlaDevice.b)), t.yPlaDevice && (r.yOffset += s.getDelta(n, t.yPlaDevice.a, t.yPlaDevice.b)), t.xAdvDevice && (r.xAdvance += s.getDelta(n, t.xAdvDevice.a, t.xAdvDevice.b)), t.yAdvDevice && (r.yAdvance += s.getDelta(n, t.yAdvDevice.a, t.yAdvDevice.b)));
  }
  applyLookup(e, t) {
    switch (e) {
      case 1: {
        let s = this.coverageIndex(t.coverage);
        if (s === -1) return !1;
        switch (t.version) {
          case 1:
            this.applyPositionValue(0, t.value);
            break;
          case 2:
            this.applyPositionValue(0, t.values.get(s));
            break;
        }
        return !0;
      }
      case 2: {
        let s = this.glyphIterator.peek();
        if (!s) return !1;
        let n = this.coverageIndex(t.coverage);
        if (n === -1) return !1;
        switch (t.version) {
          case 1:
            let a = t.pairSets.get(n);
            for (let c of a) if (c.secondGlyph === s.id)
              return this.applyPositionValue(0, c.value1), this.applyPositionValue(1, c.value2), !0;
            return !1;
          case 2:
            let o = this.getClassID(this.glyphIterator.cur.id, t.classDef1), u = this.getClassID(s.id, t.classDef2);
            if (o === -1 || u === -1) return !1;
            var r = t.classRecords.get(o).get(u);
            return this.applyPositionValue(0, r.value1), this.applyPositionValue(1, r.value2), !0;
        }
      }
      case 3: {
        let s = this.glyphIterator.peekIndex(), n = this.glyphs[s];
        if (!n) return !1;
        let a = t.entryExitRecords[this.coverageIndex(t.coverage)];
        if (!a || !a.exitAnchor) return !1;
        let o = t.entryExitRecords[this.coverageIndex(t.coverage, n.id)];
        if (!o || !o.entryAnchor) return !1;
        let u = this.getAnchor(o.entryAnchor), c = this.getAnchor(a.exitAnchor), d = this.positions[this.glyphIterator.index], f = this.positions[s], p;
        switch (this.direction) {
          case "ltr":
            d.xAdvance = c.x + d.xOffset, p = u.x + f.xOffset, f.xAdvance -= p, f.xOffset -= p;
            break;
          case "rtl":
            p = c.x + d.xOffset, d.xAdvance -= p, d.xOffset -= p, f.xAdvance = u.x + f.xOffset;
            break;
        }
        return this.glyphIterator.flags.rightToLeft ? (this.glyphIterator.cur.cursiveAttachment = s, d.yOffset = u.y - c.y) : (n.cursiveAttachment = this.glyphIterator.index, d.yOffset = c.y - u.y), !0;
      }
      case 4: {
        let s = this.coverageIndex(t.markCoverage);
        if (s === -1) return !1;
        let n = this.glyphIterator.index;
        for (; --n >= 0 && (this.glyphs[n].isMark || this.glyphs[n].ligatureComponent > 0); ) ;
        if (n < 0) return !1;
        let a = this.coverageIndex(t.baseCoverage, this.glyphs[n].id);
        if (a === -1) return !1;
        let o = t.markArray[s], u = t.baseArray[a][o.class];
        return this.applyAnchor(o, u, n), !0;
      }
      case 5: {
        let s = this.coverageIndex(t.markCoverage);
        if (s === -1) return !1;
        let n = this.glyphIterator.index;
        for (; --n >= 0 && this.glyphs[n].isMark; ) ;
        if (n < 0) return !1;
        let a = this.coverageIndex(t.ligatureCoverage, this.glyphs[n].id);
        if (a === -1) return !1;
        let o = t.ligatureArray[a], u = this.glyphIterator.cur, c = this.glyphs[n], d = c.ligatureID && c.ligatureID === u.ligatureID && u.ligatureComponent > 0 ? Math.min(u.ligatureComponent, c.codePoints.length) - 1 : c.codePoints.length - 1, f = t.markArray[s], p = o[d][f.class];
        return this.applyAnchor(f, p, n), !0;
      }
      case 6: {
        let s = this.coverageIndex(t.mark1Coverage);
        if (s === -1) return !1;
        let n = this.glyphIterator.peekIndex(-1), a = this.glyphs[n];
        if (!a || !a.isMark) return !1;
        let o = this.glyphIterator.cur, u = !1;
        if (o.ligatureID === a.ligatureID ? o.ligatureID ? o.ligatureComponent === a.ligatureComponent && (u = !0) : u = !0 : (o.ligatureID && !o.ligatureComponent || a.ligatureID && !a.ligatureComponent) && (u = !0), !u) return !1;
        let c = this.coverageIndex(t.mark2Coverage, a.id);
        if (c === -1) return !1;
        let d = t.mark1Array[s], f = t.mark2Array[c][d.class];
        return this.applyAnchor(d, f, n), !0;
      }
      case 7:
        return this.applyContext(t);
      case 8:
        return this.applyChainingContext(t);
      case 9:
        return this.applyLookup(t.lookupType, t.extension);
      default:
        throw new Error(`Unsupported GPOS table: ${e}`);
    }
  }
  applyAnchor(e, t, r) {
    let s = this.getAnchor(t), n = this.getAnchor(e.markAnchor);
    this.positions[r];
    let a = this.positions[this.glyphIterator.index];
    a.xOffset = s.x - n.x, a.yOffset = s.y - n.y, this.glyphIterator.cur.markAttachment = r;
  }
  getAnchor(e) {
    let t = e.xCoordinate, r = e.yCoordinate, s = this.font._variationProcessor, n = this.font.GDEF && this.font.GDEF.itemVariationStore;
    return s && n && (e.xDeviceTable && (t += s.getDelta(n, e.xDeviceTable.a, e.xDeviceTable.b)), e.yDeviceTable && (r += s.getDelta(n, e.yDeviceTable.a, e.yDeviceTable.b))), {
      x: t,
      y: r
    };
  }
  applyFeatures(e, t, r) {
    super.applyFeatures(e, t, r);
    for (var s = 0; s < this.glyphs.length; s++) this.fixCursiveAttachment(s);
    this.fixMarkAttachment();
  }
  fixCursiveAttachment(e) {
    let t = this.glyphs[e];
    if (t.cursiveAttachment != null) {
      let r = t.cursiveAttachment;
      t.cursiveAttachment = null, this.fixCursiveAttachment(r), this.positions[e].yOffset += this.positions[r].yOffset;
    }
  }
  fixMarkAttachment() {
    for (let e = 0; e < this.glyphs.length; e++) {
      let t = this.glyphs[e];
      if (t.markAttachment != null) {
        let r = t.markAttachment;
        if (this.positions[e].xOffset += this.positions[r].xOffset, this.positions[e].yOffset += this.positions[r].yOffset, this.direction === "ltr") for (let s = r; s < e; s++)
          this.positions[e].xOffset -= this.positions[s].xAdvance, this.positions[e].yOffset -= this.positions[s].yAdvance;
        else for (let s = r + 1; s < e + 1; s++)
          this.positions[e].xOffset += this.positions[s].xAdvance, this.positions[e].yOffset += this.positions[s].yAdvance;
      }
    }
  }
}
class rf {
  setup(e) {
    this.glyphInfos = e.glyphs.map((r) => new qe(this.font, r.id, [
      ...r.codePoints
    ]));
    let t = null;
    this.GPOSProcessor && (t = this.GPOSProcessor.selectScript(e.script, e.language, e.direction)), this.GSUBProcessor && (t = this.GSUBProcessor.selectScript(e.script, e.language, e.direction)), this.shaper = _c(t), this.plan = new rc(this.font, t, e.direction), this.shaper.plan(this.plan, this.glyphInfos, e.features);
    for (let r in this.plan.allFeatures) e.features[r] = !0;
  }
  substitute(e) {
    this.GSUBProcessor && (this.plan.process(this.GSUBProcessor, this.glyphInfos), e.glyphs = this.glyphInfos.map((t) => this.font.getGlyph(t.id, t.codePoints)));
  }
  position(e) {
    return this.shaper.zeroMarkWidths === "BEFORE_GPOS" && this.zeroMarkAdvances(e.positions), this.GPOSProcessor && this.plan.process(this.GPOSProcessor, this.glyphInfos, e.positions), this.shaper.zeroMarkWidths === "AFTER_GPOS" && this.zeroMarkAdvances(e.positions), e.direction === "rtl" && (e.glyphs.reverse(), e.positions.reverse()), this.GPOSProcessor && this.GPOSProcessor.features;
  }
  zeroMarkAdvances(e) {
    for (let t = 0; t < this.glyphInfos.length; t++) this.glyphInfos[t].isMark && (e[t].xAdvance = 0, e[t].yAdvance = 0);
  }
  cleanup() {
    this.glyphInfos = null, this.plan = null, this.shaper = null;
  }
  getAvailableFeatures(e, t) {
    let r = [];
    return this.GSUBProcessor && (this.GSUBProcessor.selectScript(e, t), r.push(...Object.keys(this.GSUBProcessor.features))), this.GPOSProcessor && (this.GPOSProcessor.selectScript(e, t), r.push(...Object.keys(this.GPOSProcessor.features))), r;
  }
  constructor(e) {
    this.font = e, this.glyphInfos = null, this.plan = null, this.GSUBProcessor = null, this.GPOSProcessor = null, this.fallbackPosition = !0, e.GSUB && (this.GSUBProcessor = new ef(e, e.GSUB)), e.GPOS && (this.GPOSProcessor = new tf(e, e.GPOS));
  }
}
class sf {
  layout(e, t, r, s, n) {
    if (typeof t == "string" && (n = s, s = r, r = t, t = []), typeof e == "string") {
      r == null && (r = Du(e));
      var a = this.font.glyphsForString(e);
    } else {
      if (r == null) {
        let c = [];
        for (let d of e) c.push(...d.codePoints);
        r = Bu(c);
      }
      var a = e;
    }
    let o = new Mu(a, t, r, s, n);
    return a.length === 0 ? (o.positions = [], o) : (this.engine && this.engine.setup && this.engine.setup(o), this.substitute(o), this.position(o), this.hideDefaultIgnorables(o.glyphs, o.positions), this.engine && this.engine.cleanup && this.engine.cleanup(), o);
  }
  substitute(e) {
    this.engine && this.engine.substitute && this.engine.substitute(e);
  }
  position(e) {
    e.positions = e.glyphs.map((r) => new Ru(r.advanceWidth));
    let t = null;
    this.engine && this.engine.position && (t = this.engine.position(e)), !t && (!this.engine || this.engine.fallbackPosition) && (this.unicodeLayoutEngine || (this.unicodeLayoutEngine = new Ou(this.font)), this.unicodeLayoutEngine.positionGlyphs(e.glyphs, e.positions)), (!t || !t.kern) && e.features.kern !== !1 && this.font.kern && (this.kernProcessor || (this.kernProcessor = new Tu(this.font)), this.kernProcessor.process(e.glyphs, e.positions), e.features.kern = !0);
  }
  hideDefaultIgnorables(e, t) {
    let r = this.font.glyphForCodePoint(32);
    for (let s = 0; s < e.length; s++) this.isDefaultIgnorable(e[s].codePoints[0]) && (e[s] = r, t[s].xAdvance = 0, t[s].yAdvance = 0);
  }
  isDefaultIgnorable(e) {
    let t = e >> 16;
    if (t === 0)
      switch (e >> 8) {
        case 0:
          return e === 173;
        case 3:
          return e === 847;
        case 6:
          return e === 1564;
        case 23:
          return 6068 <= e && e <= 6069;
        case 24:
          return 6155 <= e && e <= 6158;
        case 32:
          return 8203 <= e && e <= 8207 || 8234 <= e && e <= 8238 || 8288 <= e && e <= 8303;
        case 254:
          return 65024 <= e && e <= 65039 || e === 65279;
        case 255:
          return 65520 <= e && e <= 65528;
        default:
          return !1;
      }
    else
      switch (t) {
        case 1:
          return 113824 <= e && e <= 113827 || 119155 <= e && e <= 119162;
        case 14:
          return 917504 <= e && e <= 921599;
        default:
          return !1;
      }
  }
  getAvailableFeatures(e, t) {
    let r = [];
    return this.engine && r.push(...this.engine.getAvailableFeatures(e, t)), this.font.kern && r.indexOf("kern") === -1 && r.push("kern"), r;
  }
  stringsForGlyph(e) {
    let t = /* @__PURE__ */ new Set(), r = this.font._cmapProcessor.codePointsForGlyph(e);
    for (let s of r) t.add(String.fromCodePoint(s));
    if (this.engine && this.engine.stringsForGlyph) for (let s of this.engine.stringsForGlyph(e)) t.add(s);
    return Array.from(t);
  }
  constructor(e) {
    this.font = e, this.unicodeLayoutEngine = null, this.kernProcessor = null, this.font.morx ? this.engine = new tc(this.font) : (this.font.GSUB || this.font.GPOS) && (this.engine = new rf(this.font));
  }
}
const af = {
  moveTo: "M",
  lineTo: "L",
  quadraticCurveTo: "Q",
  bezierCurveTo: "C",
  closePath: "Z"
};
class G0 {
  /**
  * Compiles the path to a JavaScript function that can be applied with
  * a graphics context in order to render the path.
  * @return {string}
  */
  toFunction() {
    return (e) => {
      this.commands.forEach((t) => e[t.command].apply(e, t.args));
    };
  }
  /**
  * Converts the path to an SVG path data string
  * @return {string}
  */
  toSVG() {
    return this.commands.map((t) => {
      let r = t.args.map((s) => Math.round(s * 100) / 100);
      return `${af[t.command]}${r.join(" ")}`;
    }).join("");
  }
  /**
  * Gets the "control box" of a path.
  * This is like the bounding box, but it includes all points including
  * control points of bezier segments and is much faster to compute than
  * the real bounding box.
  * @type {BBox}
  */
  get cbox() {
    if (!this._cbox) {
      let e = new g0();
      for (let t of this.commands) for (let r = 0; r < t.args.length; r += 2) e.addPoint(t.args[r], t.args[r + 1]);
      this._cbox = Object.freeze(e);
    }
    return this._cbox;
  }
  /**
  * Gets the exact bounding box of the path by evaluating curve segments.
  * Slower to compute than the control box, but more accurate.
  * @type {BBox}
  */
  get bbox() {
    if (this._bbox) return this._bbox;
    let e = new g0(), t = 0, r = 0, s = (T) => Math.pow(1 - T, 3) * m[L] + 3 * Math.pow(1 - T, 2) * T * C[L] + 3 * (1 - T) * Math.pow(T, 2) * O[L] + Math.pow(T, 3) * G[L];
    for (let T of this.commands) switch (T.command) {
      case "moveTo":
      case "lineTo":
        let [w, I] = T.args;
        e.addPoint(w, I), t = w, r = I;
        break;
      case "quadraticCurveTo":
      case "bezierCurveTo":
        if (T.command === "quadraticCurveTo")
          var [n, a, f, p] = T.args, o = t + 2 / 3 * (n - t), u = r + 2 / 3 * (a - r), c = f + 2 / 3 * (n - f), d = p + 2 / 3 * (a - p);
        else var [o, u, c, d, f, p] = T.args;
        e.addPoint(f, p);
        for (var m = [
          t,
          r
        ], C = [
          o,
          u
        ], O = [
          c,
          d
        ], G = [
          f,
          p
        ], L = 0; L <= 1; L++) {
          let h = 6 * m[L] - 12 * C[L] + 6 * O[L], W = -3 * m[L] + 9 * C[L] - 9 * O[L] + 3 * G[L];
          if (T = 3 * C[L] - 3 * m[L], W === 0) {
            if (h === 0) continue;
            let S = -T / h;
            0 < S && S < 1 && (L === 0 ? e.addPoint(s(S), e.maxY) : L === 1 && e.addPoint(e.maxX, s(S)));
            continue;
          }
          let V = Math.pow(h, 2) - 4 * T * W;
          if (V < 0) continue;
          let y = (-h + Math.sqrt(V)) / (2 * W);
          0 < y && y < 1 && (L === 0 ? e.addPoint(s(y), e.maxY) : L === 1 && e.addPoint(e.maxX, s(y)));
          let M = (-h - Math.sqrt(V)) / (2 * W);
          0 < M && M < 1 && (L === 0 ? e.addPoint(s(M), e.maxY) : L === 1 && e.addPoint(e.maxX, s(M)));
        }
        t = f, r = p;
        break;
    }
    return this._bbox = Object.freeze(e);
  }
  /**
  * Applies a mapping function to each point in the path.
  * @param {function} fn
  * @return {Path}
  */
  mapPoints(e) {
    let t = new G0();
    for (let r of this.commands) {
      let s = [];
      for (let n = 0; n < r.args.length; n += 2) {
        let [a, o] = e(r.args[n], r.args[n + 1]);
        s.push(a, o);
      }
      t[r.command](...s);
    }
    return t;
  }
  /**
  * Transforms the path by the given matrix.
  */
  transform(e, t, r, s, n, a) {
    return this.mapPoints((o, u) => {
      const c = e * o + r * u + n, d = t * o + s * u + a;
      return [
        c,
        d
      ];
    });
  }
  /**
  * Translates the path by the given offset.
  */
  translate(e, t) {
    return this.transform(1, 0, 0, 1, e, t);
  }
  /**
  * Rotates the path by the given angle (in radians).
  */
  rotate(e) {
    let t = Math.cos(e), r = Math.sin(e);
    return this.transform(t, r, -r, t, 0, 0);
  }
  /**
  * Scales the path.
  */
  scale(e, t = e) {
    return this.transform(e, 0, 0, t, 0, 0);
  }
  constructor() {
    this.commands = [], this._bbox = null, this._cbox = null;
  }
}
for (let i of [
  "moveTo",
  "lineTo",
  "quadraticCurveTo",
  "bezierCurveTo",
  "closePath"
]) G0.prototype[i] = function(...e) {
  return this._bbox = this._cbox = null, this.commands.push({
    command: i,
    args: e
  }), this;
};
var Z0 = [
  ".notdef",
  ".null",
  "nonmarkingreturn",
  "space",
  "exclam",
  "quotedbl",
  "numbersign",
  "dollar",
  "percent",
  "ampersand",
  "quotesingle",
  "parenleft",
  "parenright",
  "asterisk",
  "plus",
  "comma",
  "hyphen",
  "period",
  "slash",
  "zero",
  "one",
  "two",
  "three",
  "four",
  "five",
  "six",
  "seven",
  "eight",
  "nine",
  "colon",
  "semicolon",
  "less",
  "equal",
  "greater",
  "question",
  "at",
  "A",
  "B",
  "C",
  "D",
  "E",
  "F",
  "G",
  "H",
  "I",
  "J",
  "K",
  "L",
  "M",
  "N",
  "O",
  "P",
  "Q",
  "R",
  "S",
  "T",
  "U",
  "V",
  "W",
  "X",
  "Y",
  "Z",
  "bracketleft",
  "backslash",
  "bracketright",
  "asciicircum",
  "underscore",
  "grave",
  "a",
  "b",
  "c",
  "d",
  "e",
  "f",
  "g",
  "h",
  "i",
  "j",
  "k",
  "l",
  "m",
  "n",
  "o",
  "p",
  "q",
  "r",
  "s",
  "t",
  "u",
  "v",
  "w",
  "x",
  "y",
  "z",
  "braceleft",
  "bar",
  "braceright",
  "asciitilde",
  "Adieresis",
  "Aring",
  "Ccedilla",
  "Eacute",
  "Ntilde",
  "Odieresis",
  "Udieresis",
  "aacute",
  "agrave",
  "acircumflex",
  "adieresis",
  "atilde",
  "aring",
  "ccedilla",
  "eacute",
  "egrave",
  "ecircumflex",
  "edieresis",
  "iacute",
  "igrave",
  "icircumflex",
  "idieresis",
  "ntilde",
  "oacute",
  "ograve",
  "ocircumflex",
  "odieresis",
  "otilde",
  "uacute",
  "ugrave",
  "ucircumflex",
  "udieresis",
  "dagger",
  "degree",
  "cent",
  "sterling",
  "section",
  "bullet",
  "paragraph",
  "germandbls",
  "registered",
  "copyright",
  "trademark",
  "acute",
  "dieresis",
  "notequal",
  "AE",
  "Oslash",
  "infinity",
  "plusminus",
  "lessequal",
  "greaterequal",
  "yen",
  "mu",
  "partialdiff",
  "summation",
  "product",
  "pi",
  "integral",
  "ordfeminine",
  "ordmasculine",
  "Omega",
  "ae",
  "oslash",
  "questiondown",
  "exclamdown",
  "logicalnot",
  "radical",
  "florin",
  "approxequal",
  "Delta",
  "guillemotleft",
  "guillemotright",
  "ellipsis",
  "nonbreakingspace",
  "Agrave",
  "Atilde",
  "Otilde",
  "OE",
  "oe",
  "endash",
  "emdash",
  "quotedblleft",
  "quotedblright",
  "quoteleft",
  "quoteright",
  "divide",
  "lozenge",
  "ydieresis",
  "Ydieresis",
  "fraction",
  "currency",
  "guilsinglleft",
  "guilsinglright",
  "fi",
  "fl",
  "daggerdbl",
  "periodcentered",
  "quotesinglbase",
  "quotedblbase",
  "perthousand",
  "Acircumflex",
  "Ecircumflex",
  "Aacute",
  "Edieresis",
  "Egrave",
  "Iacute",
  "Icircumflex",
  "Idieresis",
  "Igrave",
  "Oacute",
  "Ocircumflex",
  "apple",
  "Ograve",
  "Uacute",
  "Ucircumflex",
  "Ugrave",
  "dotlessi",
  "circumflex",
  "tilde",
  "macron",
  "breve",
  "dotaccent",
  "ring",
  "cedilla",
  "hungarumlaut",
  "ogonek",
  "caron",
  "Lslash",
  "lslash",
  "Scaron",
  "scaron",
  "Zcaron",
  "zcaron",
  "brokenbar",
  "Eth",
  "eth",
  "Yacute",
  "yacute",
  "Thorn",
  "thorn",
  "minus",
  "multiply",
  "onesuperior",
  "twosuperior",
  "threesuperior",
  "onehalf",
  "onequarter",
  "threequarters",
  "franc",
  "Gbreve",
  "gbreve",
  "Idotaccent",
  "Scedilla",
  "scedilla",
  "Cacute",
  "cacute",
  "Ccaron",
  "ccaron",
  "dcroat"
];
class Ke {
  _getPath() {
    return new G0();
  }
  _getCBox() {
    return this.path.cbox;
  }
  _getBBox() {
    return this.path.bbox;
  }
  _getTableMetrics(e) {
    if (this.id < e.metrics.length) return e.metrics.get(this.id);
    let t = e.metrics.get(e.metrics.length - 1);
    return {
      advance: t ? t.advance : 0,
      bearing: e.bearings.get(this.id - e.metrics.length) || 0
    };
  }
  _getMetrics(e) {
    if (this._metrics) return this._metrics;
    let { advance: t, bearing: r } = this._getTableMetrics(this._font.hmtx);
    if (this._font.vmtx) var { advance: s, bearing: n } = this._getTableMetrics(this._font.vmtx);
    else {
      let a;
      if ((typeof e > "u" || e === null) && ({ cbox: e } = this), (a = this._font["OS/2"]) && a.version > 0)
        var s = Math.abs(a.typoAscender - a.typoDescender), n = a.typoAscender - e.maxY;
      else {
        let { hhea: o } = this._font;
        var s = Math.abs(o.ascent - o.descent), n = o.ascent - e.maxY;
      }
    }
    return this._font._variationProcessor && this._font.HVAR && (t += this._font._variationProcessor.getAdvanceAdjustment(this.id, this._font.HVAR)), this._metrics = {
      advanceWidth: t,
      advanceHeight: s,
      leftBearing: r,
      topBearing: n
    };
  }
  /**
  * The glyph’s control box.
  * This is often the same as the bounding box, but is faster to compute.
  * Because of the way bezier curves are defined, some of the control points
  * can be outside of the bounding box. Where `bbox` takes this into account,
  * `cbox` does not. Thus, cbox is less accurate, but faster to compute.
  * See [here](http://www.freetype.org/freetype2/docs/glyphs/glyphs-6.html#section-2)
  * for a more detailed description.
  *
  * @type {BBox}
  */
  get cbox() {
    return this._getCBox();
  }
  /**
  * The glyph’s bounding box, i.e. the rectangle that encloses the
  * glyph outline as tightly as possible.
  * @type {BBox}
  */
  get bbox() {
    return this._getBBox();
  }
  /**
  * A vector Path object representing the glyph outline.
  * @type {Path}
  */
  get path() {
    return this._getPath();
  }
  /**
  * Returns a path scaled to the given font size.
  * @param {number} size
  * @return {Path}
  */
  getScaledPath(e) {
    let t = 1 / this._font.unitsPerEm * e;
    return this.path.scale(t);
  }
  /**
  * The glyph's advance width.
  * @type {number}
  */
  get advanceWidth() {
    return this._getMetrics().advanceWidth;
  }
  /**
  * The glyph's advance height.
  * @type {number}
  */
  get advanceHeight() {
    return this._getMetrics().advanceHeight;
  }
  get ligatureCaretPositions() {
  }
  _getName() {
    let { post: e } = this._font;
    if (!e) return null;
    switch (e.version) {
      case 1:
        return Z0[this.id];
      case 2:
        let t = e.glyphNameIndex[this.id];
        return t < Z0.length ? Z0[t] : e.names[t - Z0.length];
      case 2.5:
        return Z0[this.id + e.offsets[this.id]];
      case 4:
        return String.fromCharCode(e.map[this.id]);
    }
  }
  /**
  * The glyph's name
  * @type {string}
  */
  get name() {
    return this._getName();
  }
  /**
  * Renders the glyph to the given graphics context, at the specified font size.
  * @param {CanvasRenderingContext2d} ctx
  * @param {number} size
  */
  render(e, t) {
    e.save();
    let r = 1 / this._font.head.unitsPerEm * t;
    e.scale(r, r), this.path.toFunction()(e), e.fill(), e.restore();
  }
  constructor(e, t, r) {
    this.id = e, this.codePoints = t, this._font = r, this.isMark = this.codePoints.length > 0 && this.codePoints.every(Ra), this.isLigature = this.codePoints.length > 1;
  }
}
Ie([
  ke
], Ke.prototype, "cbox", null);
Ie([
  ke
], Ke.prototype, "bbox", null);
Ie([
  ke
], Ke.prototype, "path", null);
Ie([
  ke
], Ke.prototype, "advanceWidth", null);
Ie([
  ke
], Ke.prototype, "advanceHeight", null);
Ie([
  ke
], Ke.prototype, "name", null);
let wa = new x({
  numberOfContours: E,
  xMin: E,
  yMin: E,
  xMax: E,
  yMax: E
});
const nf = 1, lf = 2, of = 4, uf = 8, cf = 16, ff = 32, df = 1, hf = 8, ya = 32, pf = 64, bf = 128, gf = 256;
class Ge {
  copy() {
    return new Ge(this.onCurve, this.endContour, this.x, this.y);
  }
  constructor(e, t, r = 0, s = 0) {
    this.onCurve = e, this.endContour = t, this.x = r, this.y = s;
  }
}
class vf {
  constructor(e, t, r) {
    this.glyphID = e, this.dx = t, this.dy = r, this.pos = 0, this.scaleX = this.scaleY = 1, this.scale01 = this.scale10 = 0;
  }
}
class Zt extends Ke {
  // Parses just the glyph header and returns the bounding box
  _getCBox(e) {
    if (this._font._variationProcessor && !e) return this.path.cbox;
    let t = this._font._getTableStream("glyf");
    t.pos += this._font.loca.offsets[this.id];
    let r = wa.decode(t), s = new g0(r.xMin, r.yMin, r.xMax, r.yMax);
    return Object.freeze(s);
  }
  // Parses a single glyph coordinate
  _parseGlyphCoord(e, t, r, s) {
    if (r) {
      var n = e.readUInt8();
      s || (n = -n), n += t;
    } else if (s) var n = t;
    else var n = t + e.readInt16BE();
    return n;
  }
  // Decodes the glyph data into points for simple glyphs,
  // or components for composite glyphs
  _decode() {
    let e = this._font.loca.offsets[this.id], t = this._font.loca.offsets[this.id + 1];
    if (e === t) return null;
    let r = this._font._getTableStream("glyf");
    r.pos += e;
    let s = r.pos, n = wa.decode(r);
    return n.numberOfContours > 0 ? this._decodeSimple(n, r) : n.numberOfContours < 0 && this._decodeComposite(n, r, s), n;
  }
  _decodeSimple(e, t) {
    e.points = [];
    let r = new b(l, e.numberOfContours).decode(t);
    e.instructions = new b(D, l).decode(t);
    let s = [], n = r[r.length - 1] + 1;
    for (; s.length < n; ) {
      var a = t.readUInt8();
      if (s.push(a), a & uf) {
        let d = t.readUInt8();
        for (let f = 0; f < d; f++) s.push(a);
      }
    }
    for (var o = 0; o < s.length; o++) {
      var a = s[o];
      let f = new Ge(!!(a & nf), r.indexOf(o) >= 0, 0, 0);
      e.points.push(f);
    }
    let u = 0;
    for (var o = 0; o < s.length; o++) {
      var a = s[o];
      e.points[o].x = u = this._parseGlyphCoord(t, u, a & lf, a & cf);
    }
    let c = 0;
    for (var o = 0; o < s.length; o++) {
      var a = s[o];
      e.points[o].y = c = this._parseGlyphCoord(t, c, a & of, a & ff);
    }
    if (this._font._variationProcessor) {
      let d = e.points.slice();
      d.push(...this._getPhantomPoints(e)), this._font._variationProcessor.transformPoints(this.id, d), e.phantomPoints = d.slice(-4);
    }
  }
  _decodeComposite(e, t, r = 0) {
    e.components = [];
    let s = !1, n = ya;
    for (; n & ya; ) {
      n = t.readUInt16BE();
      let c = t.pos - r, d = t.readUInt16BE();
      if (s || (s = (n & gf) !== 0), n & df)
        var a = t.readInt16BE(), o = t.readInt16BE();
      else
        var a = t.readInt8(), o = t.readInt8();
      var u = new vf(d, a, o);
      u.pos = c, n & hf ? u.scaleX = u.scaleY = (t.readUInt8() << 24 | t.readUInt8() << 16) / 1073741824 : n & pf ? (u.scaleX = (t.readUInt8() << 24 | t.readUInt8() << 16) / 1073741824, u.scaleY = (t.readUInt8() << 24 | t.readUInt8() << 16) / 1073741824) : n & bf && (u.scaleX = (t.readUInt8() << 24 | t.readUInt8() << 16) / 1073741824, u.scale01 = (t.readUInt8() << 24 | t.readUInt8() << 16) / 1073741824, u.scale10 = (t.readUInt8() << 24 | t.readUInt8() << 16) / 1073741824, u.scaleY = (t.readUInt8() << 24 | t.readUInt8() << 16) / 1073741824), e.components.push(u);
    }
    if (this._font._variationProcessor) {
      let c = [];
      for (let d = 0; d < e.components.length; d++) {
        var u = e.components[d];
        c.push(new Ge(!0, !0, u.dx, u.dy));
      }
      c.push(...this._getPhantomPoints(e)), this._font._variationProcessor.transformPoints(this.id, c), e.phantomPoints = c.splice(-4, 4);
      for (let d = 0; d < c.length; d++) {
        let f = c[d];
        e.components[d].dx = f.x, e.components[d].dy = f.y;
      }
    }
    return s;
  }
  _getPhantomPoints(e) {
    let t = this._getCBox(!0);
    this._metrics == null && (this._metrics = Ke.prototype._getMetrics.call(this, t));
    let { advanceWidth: r, advanceHeight: s, leftBearing: n, topBearing: a } = this._metrics;
    return [
      new Ge(!1, !0, e.xMin - n, 0),
      new Ge(!1, !0, e.xMin - n + r, 0),
      new Ge(!1, !0, 0, e.yMax + a),
      new Ge(!1, !0, 0, e.yMax + a + s)
    ];
  }
  // Decodes font data, resolves composite glyphs, and returns an array of contours
  _getContours() {
    let e = this._decode();
    if (!e) return [];
    let t = [];
    if (e.numberOfContours < 0)
      for (let a of e.components) {
        let o = this._font.getGlyph(a.glyphID)._getContours();
        for (let u = 0; u < o.length; u++) {
          let c = o[u];
          for (let d = 0; d < c.length; d++) {
            let f = c[d], p = f.x * a.scaleX + f.y * a.scale01 + a.dx, m = f.y * a.scaleY + f.x * a.scale10 + a.dy;
            t.push(new Ge(f.onCurve, f.endContour, p, m));
          }
        }
      }
    else t = e.points || [];
    e.phantomPoints && !this._font.directory.tables.HVAR && (this._metrics.advanceWidth = e.phantomPoints[1].x - e.phantomPoints[0].x, this._metrics.advanceHeight = e.phantomPoints[3].y - e.phantomPoints[2].y, this._metrics.leftBearing = e.xMin - e.phantomPoints[0].x, this._metrics.topBearing = e.phantomPoints[2].y - e.yMax);
    let r = [], s = [];
    for (let a = 0; a < t.length; a++) {
      var n = t[a];
      s.push(n), n.endContour && (r.push(s), s = []);
    }
    return r;
  }
  _getMetrics() {
    if (this._metrics) return this._metrics;
    let e = this._getCBox(!0);
    return super._getMetrics(e), this._font._variationProcessor && !this._font.HVAR && this.path, this._metrics;
  }
  // Converts contours to a Path object that can be rendered
  _getPath() {
    let e = this._getContours(), t = new G0();
    for (let s = 0; s < e.length; s++) {
      let n = e[s], a = n[0], o = n[n.length - 1], u = 0;
      if (a.onCurve) {
        var r = null;
        u = 1;
      } else {
        o.onCurve ? a = o : a = new Ge(!1, !1, (a.x + o.x) / 2, (a.y + o.y) / 2);
        var r = a;
      }
      t.moveTo(a.x, a.y);
      for (let c = u; c < n.length; c++) {
        let d = n[c], f = c === 0 ? a : n[c - 1];
        if (f.onCurve && d.onCurve) t.lineTo(d.x, d.y);
        else if (f.onCurve && !d.onCurve) var r = d;
        else if (!f.onCurve && !d.onCurve) {
          let m = (f.x + d.x) / 2, C = (f.y + d.y) / 2;
          t.quadraticCurveTo(f.x, f.y, m, C);
          var r = d;
        } else if (!f.onCurve && d.onCurve) {
          t.quadraticCurveTo(r.x, r.y, d.x, d.y);
          var r = null;
        } else throw new Error("Unknown TTF path state");
      }
      r && t.quadraticCurveTo(r.x, r.y, a.x, a.y), t.closePath();
    }
    return t;
  }
  constructor(...e) {
    super(...e), De(this, "type", "TTF");
  }
}
class xf extends Ke {
  _getName() {
    return this._font.CFF2 ? super._getName() : this._font["CFF "].getGlyphName(this.id);
  }
  bias(e) {
    return e.length < 1240 ? 107 : e.length < 33900 ? 1131 : 32768;
  }
  _getPath() {
    let e = this._font.CFF2 || this._font["CFF "], { stream: t } = e, r = e.topDict.CharStrings[this.id], s = r.offset + r.length;
    t.pos = r.offset;
    let n = new G0(), a = [], o = [], u = null, c = 0, d = 0, f = 0, p, m, C = !1;
    this._usedGsubrs = p = {}, this._usedSubrs = m = {};
    let O = e.globalSubrIndex || [], G = this.bias(O), L = e.privateDictForGlyph(this.id) || {}, T = L.Subrs || [], w = this.bias(T), I = e.topDict.vstore && e.topDict.vstore.itemVariationStore, h = L.vsindex, W = this._font._variationProcessor;
    function V() {
      u == null && (u = a.shift() + L.nominalWidthX);
    }
    function y() {
      return a.length % 2 !== 0 && V(), c += a.length >> 1, a.length = 0;
    }
    function M(N, R) {
      C && n.closePath(), n.moveTo(N, R), C = !0;
    }
    let S = function() {
      for (; t.pos < s; ) {
        let H = t.readUInt8();
        if (H < 32) {
          let ue, re, le, K, Q, J, _, Re, Be, a0, n0, Je, i0, Qe, B, P;
          switch (H) {
            case 1:
            case 3:
            case 18:
            case 23:
              y();
              break;
            case 4:
              a.length > 1 && V(), f += a.shift(), M(d, f);
              break;
            case 5:
              for (; a.length >= 2; )
                d += a.shift(), f += a.shift(), n.lineTo(d, f);
              break;
            case 6:
            case 7:
              for (le = H === 6; a.length >= 1; )
                le ? d += a.shift() : f += a.shift(), n.lineTo(d, f), le = !le;
              break;
            case 8:
              for (; a.length > 0; )
                K = d + a.shift(), Q = f + a.shift(), J = K + a.shift(), _ = Q + a.shift(), d = J + a.shift(), f = _ + a.shift(), n.bezierCurveTo(K, Q, J, _, d, f);
              break;
            case 10:
              if (ue = a.pop() + w, re = T[ue], re) {
                m[ue] = !0;
                let k = t.pos, A = s;
                t.pos = re.offset, s = re.offset + re.length, S(), t.pos = k, s = A;
              }
              break;
            case 11:
              if (e.version >= 2) break;
              return;
            case 14:
              if (e.version >= 2) break;
              a.length > 0 && V(), C && (n.closePath(), C = !1);
              break;
            case 15:
              if (e.version < 2) throw new Error("vsindex operator not supported in CFF v1");
              h = a.pop();
              break;
            case 16: {
              if (e.version < 2) throw new Error("blend operator not supported in CFF v1");
              if (!W) throw new Error("blend operator in non-variation font");
              let k = W.getBlendVector(I, h), A = a.pop(), z = A * k.length, $ = a.length - z, q = $ - A;
              for (let X = 0; X < A; X++) {
                let ae = a[q + X];
                for (let Y = 0; Y < k.length; Y++) ae += k[Y] * a[$++];
                a[q + X] = ae;
              }
              for (; z--; ) a.pop();
              break;
            }
            case 19:
            case 20:
              y(), t.pos += c + 7 >> 3;
              break;
            case 21:
              a.length > 2 && V(), d += a.shift(), f += a.shift(), M(d, f);
              break;
            case 22:
              a.length > 1 && V(), d += a.shift(), M(d, f);
              break;
            case 24:
              for (; a.length >= 8; )
                K = d + a.shift(), Q = f + a.shift(), J = K + a.shift(), _ = Q + a.shift(), d = J + a.shift(), f = _ + a.shift(), n.bezierCurveTo(K, Q, J, _, d, f);
              d += a.shift(), f += a.shift(), n.lineTo(d, f);
              break;
            case 25:
              for (; a.length >= 8; )
                d += a.shift(), f += a.shift(), n.lineTo(d, f);
              K = d + a.shift(), Q = f + a.shift(), J = K + a.shift(), _ = Q + a.shift(), d = J + a.shift(), f = _ + a.shift(), n.bezierCurveTo(K, Q, J, _, d, f);
              break;
            case 26:
              for (a.length % 2 && (d += a.shift()); a.length >= 4; )
                K = d, Q = f + a.shift(), J = K + a.shift(), _ = Q + a.shift(), d = J, f = _ + a.shift(), n.bezierCurveTo(K, Q, J, _, d, f);
              break;
            case 27:
              for (a.length % 2 && (f += a.shift()); a.length >= 4; )
                K = d + a.shift(), Q = f, J = K + a.shift(), _ = Q + a.shift(), d = J + a.shift(), f = _, n.bezierCurveTo(K, Q, J, _, d, f);
              break;
            case 28:
              a.push(t.readInt16BE());
              break;
            case 29:
              if (ue = a.pop() + G, re = O[ue], re) {
                p[ue] = !0;
                let k = t.pos, A = s;
                t.pos = re.offset, s = re.offset + re.length, S(), t.pos = k, s = A;
              }
              break;
            case 30:
            case 31:
              for (le = H === 31; a.length >= 4; )
                le ? (K = d + a.shift(), Q = f, J = K + a.shift(), _ = Q + a.shift(), f = _ + a.shift(), d = J + (a.length === 1 ? a.shift() : 0)) : (K = d, Q = f + a.shift(), J = K + a.shift(), _ = Q + a.shift(), d = J + a.shift(), f = _ + (a.length === 1 ? a.shift() : 0)), n.bezierCurveTo(K, Q, J, _, d, f), le = !le;
              break;
            case 12:
              switch (H = t.readUInt8(), H) {
                case 3:
                  let k = a.pop(), A = a.pop();
                  a.push(k && A ? 1 : 0);
                  break;
                case 4:
                  k = a.pop(), A = a.pop(), a.push(k || A ? 1 : 0);
                  break;
                case 5:
                  k = a.pop(), a.push(k ? 0 : 1);
                  break;
                case 9:
                  k = a.pop(), a.push(Math.abs(k));
                  break;
                case 10:
                  k = a.pop(), A = a.pop(), a.push(k + A);
                  break;
                case 11:
                  k = a.pop(), A = a.pop(), a.push(k - A);
                  break;
                case 12:
                  k = a.pop(), A = a.pop(), a.push(k / A);
                  break;
                case 14:
                  k = a.pop(), a.push(-k);
                  break;
                case 15:
                  k = a.pop(), A = a.pop(), a.push(k === A ? 1 : 0);
                  break;
                case 18:
                  a.pop();
                  break;
                case 20:
                  let z = a.pop(), $ = a.pop();
                  o[$] = z;
                  break;
                case 21:
                  $ = a.pop(), a.push(o[$] || 0);
                  break;
                case 22:
                  let q = a.pop(), X = a.pop(), ae = a.pop(), Y = a.pop();
                  a.push(ae <= Y ? q : X);
                  break;
                case 23:
                  a.push(Math.random());
                  break;
                case 24:
                  k = a.pop(), A = a.pop(), a.push(k * A);
                  break;
                case 26:
                  k = a.pop(), a.push(Math.sqrt(k));
                  break;
                case 27:
                  k = a.pop(), a.push(k, k);
                  break;
                case 28:
                  k = a.pop(), A = a.pop(), a.push(A, k);
                  break;
                case 29:
                  $ = a.pop(), $ < 0 ? $ = 0 : $ > a.length - 1 && ($ = a.length - 1), a.push(a[$]);
                  break;
                case 30:
                  let U = a.pop(), oe = a.pop();
                  if (oe >= 0) for (; oe > 0; ) {
                    var N = a[U - 1];
                    for (let ge = U - 2; ge >= 0; ge--) a[ge + 1] = a[ge];
                    a[0] = N, oe--;
                  }
                  else for (; oe < 0; ) {
                    var N = a[0];
                    for (let ye = 0; ye <= U; ye++) a[ye] = a[ye + 1];
                    a[U - 1] = N, oe++;
                  }
                  break;
                case 34:
                  K = d + a.shift(), Q = f, J = K + a.shift(), _ = Q + a.shift(), Re = J + a.shift(), Be = _, a0 = Re + a.shift(), n0 = Be, Je = a0 + a.shift(), i0 = n0, Qe = Je + a.shift(), B = i0, d = Qe, f = B, n.bezierCurveTo(K, Q, J, _, Re, Be), n.bezierCurveTo(a0, n0, Je, i0, Qe, B);
                  break;
                case 35:
                  P = [];
                  for (let ge = 0; ge <= 5; ge++)
                    d += a.shift(), f += a.shift(), P.push(d, f);
                  n.bezierCurveTo(...P.slice(0, 6)), n.bezierCurveTo(...P.slice(6)), a.shift();
                  break;
                case 36:
                  K = d + a.shift(), Q = f + a.shift(), J = K + a.shift(), _ = Q + a.shift(), Re = J + a.shift(), Be = _, a0 = Re + a.shift(), n0 = Be, Je = a0 + a.shift(), i0 = n0 + a.shift(), Qe = Je + a.shift(), B = i0, d = Qe, f = B, n.bezierCurveTo(K, Q, J, _, Re, Be), n.bezierCurveTo(a0, n0, Je, i0, Qe, B);
                  break;
                case 37:
                  let Ce = d, Le = f;
                  P = [];
                  for (let ge = 0; ge <= 4; ge++)
                    d += a.shift(), f += a.shift(), P.push(d, f);
                  Math.abs(d - Ce) > Math.abs(f - Le) ? (d += a.shift(), f = Le) : (d = Ce, f += a.shift()), P.push(d, f), n.bezierCurveTo(...P.slice(0, 6)), n.bezierCurveTo(...P.slice(6));
                  break;
                default:
                  throw new Error(`Unknown op: 12 ${H}`);
              }
              break;
            default:
              throw new Error(`Unknown op: ${H}`);
          }
        } else if (H < 247) a.push(H - 139);
        else if (H < 251) {
          var R = t.readUInt8();
          a.push((H - 247) * 256 + R + 108);
        } else if (H < 255) {
          var R = t.readUInt8();
          a.push(-(H - 251) * 256 - R - 108);
        } else a.push(t.readInt32BE() / 65536);
      }
    };
    return S(), C && n.closePath(), n;
  }
  constructor(...e) {
    super(...e), De(this, "type", "CFF");
  }
}
let mf = new x({
  originX: l,
  originY: l,
  type: new de(4),
  data: new Ye((i) => i.parent.buflen - i._currentOffset)
});
class wf extends Zt {
  /**
  * Returns an object representing a glyph image at the given point size.
  * The object has a data property with a Buffer containing the actual image data,
  * along with the image type, and origin.
  *
  * @param {number} size
  * @return {object}
  */
  getImageForSize(e) {
    for (let a = 0; a < this._font.sbix.imageTables.length; a++) {
      var t = this._font.sbix.imageTables[a];
      if (t.ppem >= e) break;
    }
    let r = t.imageOffsets, s = r[this.id], n = r[this.id + 1];
    return s === n ? null : (this._font.stream.pos = s, mf.decode(this._font.stream, {
      buflen: n - s
    }));
  }
  render(e, t) {
    let r = this.getImageForSize(t);
    if (r != null) {
      let s = t / this._font.unitsPerEm;
      e.image(r.data, {
        height: t,
        x: r.originX,
        y: (this.bbox.minY - r.originY) * s
      });
    }
    this._font.sbix.flags.renderOutlines && super.render(e, t);
  }
  constructor(...e) {
    super(...e), De(this, "type", "SBIX");
  }
}
class Ca {
  constructor(e, t) {
    this.glyph = e, this.color = t;
  }
}
class yf extends Ke {
  _getBBox() {
    let e = new g0();
    for (let t = 0; t < this.layers.length; t++) {
      let s = this.layers[t].glyph.bbox;
      e.addPoint(s.minX, s.minY), e.addPoint(s.maxX, s.maxY);
    }
    return e;
  }
  /**
  * Returns an array of objects containing the glyph and color for
  * each layer in the composite color glyph.
  * @type {object[]}
  */
  get layers() {
    let e = this._font.CPAL, t = this._font.COLR, r = 0, s = t.baseGlyphRecord.length - 1;
    for (; r <= s; ) {
      let d = r + s >> 1;
      var n = t.baseGlyphRecord[d];
      if (this.id < n.gid) s = d - 1;
      else if (this.id > n.gid) r = d + 1;
      else {
        var a = n;
        break;
      }
    }
    if (a == null) {
      var o = this._font._getBaseGlyph(this.id), u = {
        red: 0,
        green: 0,
        blue: 0,
        alpha: 255
      };
      return [
        new Ca(o, u)
      ];
    }
    let c = [];
    for (let d = a.firstLayerIndex; d < a.firstLayerIndex + a.numLayers; d++) {
      var n = t.layerRecords[d], u = e.colorRecords[n.paletteIndex], o = this._font._getBaseGlyph(n.gid);
      c.push(new Ca(o, u));
    }
    return c;
  }
  render(e, t) {
    for (let { glyph: r, color: s } of this.layers)
      e.fillColor([
        s.red,
        s.green,
        s.blue
      ], s.alpha / 255 * 100), r.render(e, t);
  }
  constructor(...e) {
    super(...e), De(this, "type", "COLR");
  }
}
const Cf = 32768, Sf = 4095, Af = 32768, Sa = 16384, If = 8192, Aa = 4095, Ia = 128, ka = 127, kf = 128, Ef = 64, Pf = 63;
class Tf {
  normalizeCoords(e) {
    let t = [];
    for (var r = 0; r < this.font.fvar.axis.length; r++) {
      let s = this.font.fvar.axis[r];
      e[r] < s.defaultValue ? t.push((e[r] - s.defaultValue + Number.EPSILON) / (s.defaultValue - s.minValue + Number.EPSILON)) : t.push((e[r] - s.defaultValue + Number.EPSILON) / (s.maxValue - s.defaultValue + Number.EPSILON));
    }
    if (this.font.avar) for (var r = 0; r < this.font.avar.segment.length; r++) {
      let n = this.font.avar.segment[r];
      for (let a = 0; a < n.correspondence.length; a++) {
        let o = n.correspondence[a];
        if (a >= 1 && t[r] < o.fromCoord) {
          let u = n.correspondence[a - 1];
          t[r] = ((t[r] - u.fromCoord) * (o.toCoord - u.toCoord) + Number.EPSILON) / (o.fromCoord - u.fromCoord + Number.EPSILON) + u.toCoord;
          break;
        }
      }
    }
    return t;
  }
  transformPoints(e, t) {
    if (!this.font.fvar || !this.font.gvar) return;
    let { gvar: r } = this.font;
    if (e >= r.glyphCount) return;
    let s = r.offsets[e];
    if (s === r.offsets[e + 1]) return;
    let { stream: n } = this.font;
    if (n.pos = s, n.pos >= n.length) return;
    let a = n.readUInt16BE(), o = s + n.readUInt16BE();
    if (a & Cf) {
      var u = n.pos;
      n.pos = o;
      var c = this.decodePoints();
      o = n.pos, n.pos = u;
    }
    let d = t.map((G) => G.copy());
    a &= Sf;
    for (let G = 0; G < a; G++) {
      let L = n.readUInt16BE(), T = n.readUInt16BE();
      if (T & Af) {
        var f = [];
        for (let y = 0; y < r.axisCount; y++) f.push(n.readInt16BE() / 16384);
      } else {
        if ((T & Aa) >= r.globalCoordCount) throw new Error("Invalid gvar table");
        var f = r.globalCoords[T & Aa];
      }
      if (T & Sa) {
        var p = [];
        for (let y = 0; y < r.axisCount; y++) p.push(n.readInt16BE() / 16384);
        var m = [];
        for (let y = 0; y < r.axisCount; y++) m.push(n.readInt16BE() / 16384);
      }
      let w = this.tupleFactor(T, f, p, m);
      if (w === 0) {
        o += L;
        continue;
      }
      var u = n.pos;
      if (n.pos = o, T & If) var C = this.decodePoints();
      else var C = c;
      let h = C.length === 0 ? t.length : C.length, W = this.decodeDeltas(h), V = this.decodeDeltas(h);
      if (C.length === 0) for (let y = 0; y < t.length; y++) {
        var O = t[y];
        O.x += Math.round(W[y] * w), O.y += Math.round(V[y] * w);
      }
      else {
        let y = d.map((S) => S.copy()), M = t.map(() => !1);
        for (let S = 0; S < C.length; S++) {
          let N = C[S];
          if (N < t.length) {
            let R = y[N];
            M[N] = !0, R.x += W[S] * w, R.y += V[S] * w;
          }
        }
        this.interpolateMissingDeltas(y, d, M);
        for (let S = 0; S < t.length; S++) {
          let N = y[S].x - d[S].x, R = y[S].y - d[S].y;
          t[S].x = Math.round(t[S].x + N), t[S].y = Math.round(t[S].y + R);
        }
      }
      o += L, n.pos = u;
    }
  }
  decodePoints() {
    let e = this.font.stream, t = e.readUInt8();
    t & Ia && (t = (t & ka) << 8 | e.readUInt8());
    let r = new Uint16Array(t), s = 0, n = 0;
    for (; s < t; ) {
      let a = e.readUInt8(), o = (a & ka) + 1, u = a & Ia ? e.readUInt16 : e.readUInt8;
      for (let c = 0; c < o && s < t; c++)
        n += u.call(e), r[s++] = n;
    }
    return r;
  }
  decodeDeltas(e) {
    let t = this.font.stream, r = 0, s = new Int16Array(e);
    for (; r < e; ) {
      let n = t.readUInt8(), a = (n & Pf) + 1;
      if (n & kf) r += a;
      else {
        let o = n & Ef ? t.readInt16BE : t.readInt8;
        for (let u = 0; u < a && r < e; u++) s[r++] = o.call(t);
      }
    }
    return s;
  }
  tupleFactor(e, t, r, s) {
    let n = this.normalizedCoords, { gvar: a } = this.font, o = 1;
    for (let u = 0; u < a.axisCount; u++)
      if (t[u] !== 0) {
        if (n[u] === 0) return 0;
        if ((e & Sa) === 0) {
          if (n[u] < Math.min(0, t[u]) || n[u] > Math.max(0, t[u])) return 0;
          o = (o * n[u] + Number.EPSILON) / (t[u] + Number.EPSILON);
        } else {
          if (n[u] < r[u] || n[u] > s[u]) return 0;
          n[u] < t[u] ? o = o * (n[u] - r[u] + Number.EPSILON) / (t[u] - r[u] + Number.EPSILON) : o = o * (s[u] - n[u] + Number.EPSILON) / (s[u] - t[u] + Number.EPSILON);
        }
      }
    return o;
  }
  // Interpolates points without delta values.
  // Needed for the Ø and Q glyphs in Skia.
  // Algorithm from Freetype.
  interpolateMissingDeltas(e, t, r) {
    if (e.length === 0) return;
    let s = 0;
    for (; s < e.length; ) {
      let n = s, a = s, o = e[a];
      for (; !o.endContour; ) o = e[++a];
      for (; s <= a && !r[s]; ) s++;
      if (s > a) continue;
      let u = s, c = s;
      for (s++; s <= a; )
        r[s] && (this.deltaInterpolate(c + 1, s - 1, c, s, t, e), c = s), s++;
      c === u ? this.deltaShift(n, a, c, t, e) : (this.deltaInterpolate(c + 1, a, c, u, t, e), u > 0 && this.deltaInterpolate(n, u - 1, c, u, t, e)), s = a + 1;
    }
  }
  deltaInterpolate(e, t, r, s, n, a) {
    if (e > t) return;
    let o = [
      "x",
      "y"
    ];
    for (let c = 0; c < o.length; c++) {
      let d = o[c];
      if (n[r][d] > n[s][d]) {
        var u = r;
        r = s, s = u;
      }
      let f = n[r][d], p = n[s][d], m = a[r][d], C = a[s][d];
      if (f !== p || m === C) {
        let O = f === p ? 0 : (C - m) / (p - f);
        for (let G = e; G <= t; G++) {
          let L = n[G][d];
          L <= f ? L += m - f : L >= p ? L += C - p : L = m + (L - f) * O, a[G][d] = L;
        }
      }
    }
  }
  deltaShift(e, t, r, s, n) {
    let a = n[r].x - s[r].x, o = n[r].y - s[r].y;
    if (!(a === 0 && o === 0))
      for (let u = e; u <= t; u++) u !== r && (n[u].x += a, n[u].y += o);
  }
  getAdvanceAdjustment(e, t) {
    let r, s;
    if (t.advanceWidthMapping) {
      let n = e;
      n >= t.advanceWidthMapping.mapCount && (n = t.advanceWidthMapping.mapCount - 1), t.advanceWidthMapping.entryFormat, { outerIndex: r, innerIndex: s } = t.advanceWidthMapping.mapData[n];
    } else
      r = 0, s = e;
    return this.getDelta(t.itemVariationStore, r, s);
  }
  // See pseudo code from `Font Variations Overview'
  // in the OpenType specification.
  getDelta(e, t, r) {
    if (t >= e.itemVariationData.length) return 0;
    let s = e.itemVariationData[t];
    if (r >= s.deltaSets.length) return 0;
    let n = s.deltaSets[r], a = this.getBlendVector(e, t), o = 0;
    for (let u = 0; u < s.regionIndexCount; u++) o += n.deltas[u] * a[u];
    return o;
  }
  getBlendVector(e, t) {
    let r = e.itemVariationData[t];
    if (this.blendVectors.has(r)) return this.blendVectors.get(r);
    let s = this.normalizedCoords, n = [];
    for (let a = 0; a < r.regionIndexCount; a++) {
      let o = 1, u = r.regionIndexes[a], c = e.variationRegionList.variationRegions[u];
      for (let d = 0; d < c.length; d++) {
        let f = c[d], p;
        f.startCoord > f.peakCoord || f.peakCoord > f.endCoord || f.startCoord < 0 && f.endCoord > 0 && f.peakCoord !== 0 || f.peakCoord === 0 ? p = 1 : s[d] < f.startCoord || s[d] > f.endCoord ? p = 0 : s[d] === f.peakCoord ? p = 1 : s[d] < f.peakCoord ? p = (s[d] - f.startCoord + Number.EPSILON) / (f.peakCoord - f.startCoord + Number.EPSILON) : p = (f.endCoord - s[d] + Number.EPSILON) / (f.endCoord - f.peakCoord + Number.EPSILON), o *= p;
      }
      n[a] = o;
    }
    return this.blendVectors.set(r, n), n;
  }
  constructor(e, t) {
    this.font = e, this.normalizedCoords = this.normalizeCoords(t), this.blendVectors = /* @__PURE__ */ new Map();
  }
}
Promise.resolve();
class mn {
  includeGlyph(e) {
    return typeof e == "object" && (e = e.id), this.mapping[e] == null && (this.glyphs.push(e), this.mapping[e] = this.glyphs.length - 1), this.mapping[e];
  }
  constructor(e) {
    this.font = e, this.glyphs = [], this.mapping = {}, this.includeGlyph(0);
  }
}
const Of = 1, Ff = 2, Df = 4, Bf = 8, Lf = 16, Mf = 32;
class Ea {
  static size(e) {
    return e >= 0 && e <= 255 ? 1 : 2;
  }
  static encode(e, t) {
    t >= 0 && t <= 255 ? e.writeUInt8(t) : e.writeInt16BE(t);
  }
}
let Pa = new x({
  numberOfContours: E,
  xMin: E,
  yMin: E,
  xMax: E,
  yMax: E,
  endPtsOfContours: new b(l, "numberOfContours"),
  instructions: new b(D, l),
  flags: new b(D, 0),
  xPoints: new b(Ea, 0),
  yPoints: new b(Ea, 0)
});
class Rf {
  encodeSimple(e, t = []) {
    let r = [], s = [], n = [], a = [], o = 0, u = 0, c = 0, d = 0, f = 0;
    for (let L = 0; L < e.commands.length; L++) {
      let T = e.commands[L];
      for (let w = 0; w < T.args.length; w += 2) {
        let I = T.args[w], h = T.args[w + 1], W = 0;
        if (T.command === "quadraticCurveTo" && w === 2) {
          let V = e.commands[L + 1];
          if (V && V.command === "quadraticCurveTo") {
            let y = (u + V.args[0]) / 2, M = (c + V.args[1]) / 2;
            if (I === y && h === M) continue;
          }
        }
        T.command === "quadraticCurveTo" && w === 0 || (W |= Of), W = this._encodePoint(I, u, s, W, Ff, Lf), W = this._encodePoint(h, c, n, W, Df, Mf), W === d && o < 255 ? (a[a.length - 1] |= Bf, o++) : (o > 0 && (a.push(o), o = 0), a.push(W), d = W), u = I, c = h, f++;
      }
      T.command === "closePath" && r.push(f - 1);
    }
    e.commands.length > 1 && e.commands[e.commands.length - 1].command !== "closePath" && r.push(f - 1);
    let p = e.bbox, m = {
      numberOfContours: r.length,
      xMin: p.minX,
      yMin: p.minY,
      xMax: p.maxX,
      yMax: p.maxY,
      endPtsOfContours: r,
      instructions: t,
      flags: a,
      xPoints: s,
      yPoints: n
    }, C = Pa.size(m), O = 4 - C % 4, G = new kt(C + O);
    return Pa.encode(G, m), O !== 0 && G.fill(0, O), G.buffer;
  }
  _encodePoint(e, t, r, s, n, a) {
    let o = e - t;
    return e === t ? s |= a : (-255 <= o && o <= 255 && (s |= n, o < 0 ? o = -o : s |= a), r.push(o)), s;
  }
}
class Nf extends mn {
  _addGlyph(e) {
    let t = this.font.getGlyph(e), r = t._decode(), s = this.font.loca.offsets[e], n = this.font.loca.offsets[e + 1], a = this.font._getTableStream("glyf");
    a.pos += s;
    let o = a.readBuffer(n - s);
    if (r && r.numberOfContours < 0) {
      o = new Uint8Array(o);
      let u = new DataView(o.buffer);
      for (let c of r.components)
        e = this.includeGlyph(c.glyphID), u.setUint16(c.pos, e);
    } else r && this.font._variationProcessor && (o = this.glyphEncoder.encodeSimple(t.path, r.instructions));
    return this.glyf.push(o), this.loca.offsets.push(this.offset), this.hmtx.metrics.push({
      advance: t.advanceWidth,
      bearing: t._getMetrics().leftBearing
    }), this.offset += o.length, this.glyf.length - 1;
  }
  encode() {
    this.glyf = [], this.offset = 0, this.loca = {
      offsets: [],
      version: this.font.loca.version
    }, this.hmtx = {
      metrics: [],
      bearings: []
    };
    let e = 0;
    for (; e < this.glyphs.length; ) this._addGlyph(this.glyphs[e++]);
    let t = br(this.font.maxp);
    t.numGlyphs = this.glyf.length, this.loca.offsets.push(this.offset);
    let r = br(this.font.head);
    r.indexToLocFormat = this.loca.version;
    let s = br(this.font.hhea);
    return s.numberOfMetrics = this.hmtx.metrics.length, on.toBuffer({
      tables: {
        head: r,
        hhea: s,
        loca: this.loca,
        maxp: t,
        "cvt ": this.font["cvt "],
        prep: this.font.prep,
        glyf: this.glyf,
        hmtx: this.hmtx,
        fpgm: this.font.fpgm
      }
    });
  }
  constructor(e) {
    super(e), this.glyphEncoder = new Rf();
  }
}
class Uf extends mn {
  subsetCharstrings() {
    this.charstrings = [];
    let e = {};
    for (let t of this.glyphs) {
      this.charstrings.push(this.cff.getCharString(t));
      let r = this.font.getGlyph(t);
      r.path;
      for (let s in r._usedGsubrs) e[s] = !0;
    }
    this.gsubrs = this.subsetSubrs(this.cff.globalSubrIndex, e);
  }
  subsetSubrs(e, t) {
    let r = [];
    for (let s = 0; s < e.length; s++) {
      let n = e[s];
      t[s] ? (this.cff.stream.pos = n.offset, r.push(this.cff.stream.readBuffer(n.length))) : r.push(new Uint8Array([
        11
      ]));
    }
    return r;
  }
  subsetFontdict(e) {
    e.FDArray = [], e.FDSelect = {
      version: 0,
      fds: []
    };
    let t = {}, r = [], s = {};
    for (let n of this.glyphs) {
      let a = this.cff.fdForGlyph(n);
      if (a == null) continue;
      t[a] || (e.FDArray.push(Object.assign({}, this.cff.topDict.FDArray[a])), r.push({}), s[a] = e.FDArray.length - 1), t[a] = !0, e.FDSelect.fds.push(s[a]);
      let o = this.font.getGlyph(n);
      o.path;
      for (let u in o._usedSubrs) r[s[a]][u] = !0;
    }
    for (let n = 0; n < e.FDArray.length; n++) {
      let a = e.FDArray[n];
      delete a.FontName, a.Private && a.Private.Subrs && (a.Private = Object.assign({}, a.Private), a.Private.Subrs = this.subsetSubrs(a.Private.Subrs, r[n]));
    }
  }
  createCIDFontdict(e) {
    let t = {};
    for (let s of this.glyphs) {
      let n = this.font.getGlyph(s);
      n.path;
      for (let a in n._usedSubrs) t[a] = !0;
    }
    let r = Object.assign({}, this.cff.topDict.Private);
    return this.cff.topDict.Private && this.cff.topDict.Private.Subrs && (r.Subrs = this.subsetSubrs(this.cff.topDict.Private.Subrs, t)), e.FDArray = [
      {
        Private: r
      }
    ], e.FDSelect = {
      version: 3,
      nRanges: 1,
      ranges: [
        {
          first: 0,
          fd: 0
        }
      ],
      sentinel: this.charstrings.length
    };
  }
  addString(e) {
    return e ? (this.strings || (this.strings = []), this.strings.push(e), St.length + this.strings.length - 1) : null;
  }
  encode() {
    this.subsetCharstrings();
    let e = {
      version: this.charstrings.length > 255 ? 2 : 1,
      ranges: [
        {
          first: 1,
          nLeft: this.charstrings.length - 2
        }
      ]
    }, t = Object.assign({}, this.cff.topDict);
    t.Private = null, t.charset = e, t.Encoding = null, t.CharStrings = this.charstrings;
    for (let s of [
      "version",
      "Notice",
      "Copyright",
      "FullName",
      "FamilyName",
      "Weight",
      "PostScript",
      "BaseFontName",
      "FontName"
    ]) t[s] = this.addString(this.cff.string(t[s]));
    t.ROS = [
      this.addString("Adobe"),
      this.addString("Identity"),
      0
    ], t.CIDCount = this.charstrings.length, this.cff.isCIDFont ? this.subsetFontdict(t) : this.createCIDFontdict(t);
    let r = {
      version: 1,
      hdrSize: this.cff.hdrSize,
      offSize: 4,
      header: this.cff.header,
      nameIndex: [
        this.cff.postscriptName
      ],
      topDictIndex: [
        t
      ],
      stringIndex: this.strings,
      globalSubrIndex: this.gsubrs
    };
    return rn.toBuffer(r);
  }
  constructor(e) {
    if (super(e), this.cff = this.font["CFF "], !this.cff) throw new Error("Not a CFF Font");
  }
}
class Ee {
  static probe(e) {
    let t = $t.decode(e.slice(0, 4));
    return t === "true" || t === "OTTO" || t === "\0\0\0";
  }
  setDefaultLanguage(e = null) {
    this.defaultLanguage = e;
  }
  _getTable(e) {
    if (!(e.tag in this._tables)) try {
      this._tables[e.tag] = this._decodeTable(e);
    } catch {
    }
    return this._tables[e.tag];
  }
  _getTableStream(e) {
    let t = this.directory.tables[e];
    return t ? (this.stream.pos = t.offset, this.stream) : null;
  }
  _decodeDirectory() {
    return this.directory = on.decode(this.stream, {
      _startOffset: 0
    });
  }
  _decodeTable(e) {
    let t = this.stream.pos, r = this._getTableStream(e.tag), s = Ft[e.tag].decode(r, this, e.length);
    return this.stream.pos = t, s;
  }
  /**
  * Gets a string from the font's `name` table
  * `lang` is a BCP-47 language code.
  * @return {string}
  */
  getName(e, t = this.defaultLanguage || Pt) {
    let r = this.name && this.name.records[e];
    return r && (r[t] || r[this.defaultLanguage] || r[Pt] || r.en || r[Object.keys(r)[0]]) || null;
  }
  /**
  * The unique PostScript name for this font, e.g. "Helvetica-Bold"
  * @type {string}
  */
  get postscriptName() {
    return this.getName("postscriptName");
  }
  /**
  * The font's full name, e.g. "Helvetica Bold"
  * @type {string}
  */
  get fullName() {
    return this.getName("fullName");
  }
  /**
  * The font's family name, e.g. "Helvetica"
  * @type {string}
  */
  get familyName() {
    return this.getName("fontFamily");
  }
  /**
  * The font's sub-family, e.g. "Bold".
  * @type {string}
  */
  get subfamilyName() {
    return this.getName("fontSubfamily");
  }
  /**
  * The font's copyright information
  * @type {string}
  */
  get copyright() {
    return this.getName("copyright");
  }
  /**
  * The font's version number
  * @type {string}
  */
  get version() {
    return this.getName("version");
  }
  /**
  * The font’s [ascender](https://en.wikipedia.org/wiki/Ascender_(typography))
  * @type {number}
  */
  get ascent() {
    return this.hhea.ascent;
  }
  /**
  * The font’s [descender](https://en.wikipedia.org/wiki/Descender)
  * @type {number}
  */
  get descent() {
    return this.hhea.descent;
  }
  /**
  * The amount of space that should be included between lines
  * @type {number}
  */
  get lineGap() {
    return this.hhea.lineGap;
  }
  /**
  * The offset from the normal underline position that should be used
  * @type {number}
  */
  get underlinePosition() {
    return this.post.underlinePosition;
  }
  /**
  * The weight of the underline that should be used
  * @type {number}
  */
  get underlineThickness() {
    return this.post.underlineThickness;
  }
  /**
  * If this is an italic font, the angle the cursor should be drawn at to match the font design
  * @type {number}
  */
  get italicAngle() {
    return this.post.italicAngle;
  }
  /**
  * The height of capital letters above the baseline.
  * See [here](https://en.wikipedia.org/wiki/Cap_height) for more details.
  * @type {number}
  */
  get capHeight() {
    let e = this["OS/2"];
    return e ? e.capHeight : this.ascent;
  }
  /**
  * The height of lower case letters in the font.
  * See [here](https://en.wikipedia.org/wiki/X-height) for more details.
  * @type {number}
  */
  get xHeight() {
    let e = this["OS/2"];
    return e ? e.xHeight : 0;
  }
  /**
  * The number of glyphs in the font.
  * @type {number}
  */
  get numGlyphs() {
    return this.maxp.numGlyphs;
  }
  /**
  * The size of the font’s internal coordinate grid
  * @type {number}
  */
  get unitsPerEm() {
    return this.head.unitsPerEm;
  }
  /**
  * The font’s bounding box, i.e. the box that encloses all glyphs in the font.
  * @type {BBox}
  */
  get bbox() {
    return Object.freeze(new g0(this.head.xMin, this.head.yMin, this.head.xMax, this.head.yMax));
  }
  get _cmapProcessor() {
    return new Kr(this.cmap);
  }
  /**
  * An array of all of the unicode code points supported by the font.
  * @type {number[]}
  */
  get characterSet() {
    return this._cmapProcessor.getCharacterSet();
  }
  /**
  * Returns whether there is glyph in the font for the given unicode code point.
  *
  * @param {number} codePoint
  * @return {boolean}
  */
  hasGlyphForCodePoint(e) {
    return !!this._cmapProcessor.lookup(e);
  }
  /**
  * Maps a single unicode code point to a Glyph object.
  * Does not perform any advanced substitutions (there is no context to do so).
  *
  * @param {number} codePoint
  * @return {Glyph}
  */
  glyphForCodePoint(e) {
    return this.getGlyph(this._cmapProcessor.lookup(e), [
      e
    ]);
  }
  /**
  * Returns an array of Glyph objects for the given string.
  * This is only a one-to-one mapping from characters to glyphs.
  * For most uses, you should use font.layout (described below), which
  * provides a much more advanced mapping supporting AAT and OpenType shaping.
  *
  * @param {string} string
  * @return {Glyph[]}
  */
  glyphsForString(e) {
    let t = [], r = e.length, s = 0, n = -1, a = -1;
    for (; s <= r; ) {
      let o = 0, u = 0;
      if (s < r) {
        if (o = e.charCodeAt(s++), 55296 <= o && o <= 56319 && s < r) {
          let c = e.charCodeAt(s);
          56320 <= c && c <= 57343 && (s++, o = ((o & 1023) << 10) + (c & 1023) + 65536);
        }
        u = 65024 <= o && o <= 65039 || 917760 <= o && o <= 917999 ? 1 : 0;
      } else s++;
      a === 0 && u === 1 ? t.push(this.getGlyph(this._cmapProcessor.lookup(n, o), [
        n,
        o
      ])) : a === 0 && u === 0 && t.push(this.glyphForCodePoint(n)), n = o, a = u;
    }
    return t;
  }
  get _layoutEngine() {
    return new sf(this);
  }
  /**
  * Returns a GlyphRun object, which includes an array of Glyphs and GlyphPositions for the given string.
  *
  * @param {string} string
  * @param {string[]} [userFeatures]
  * @param {string} [script]
  * @param {string} [language]
  * @param {string} [direction]
  * @return {GlyphRun}
  */
  layout(e, t, r, s, n) {
    return this._layoutEngine.layout(e, t, r, s, n);
  }
  /**
  * Returns an array of strings that map to the given glyph id.
  * @param {number} gid - glyph id
  */
  stringsForGlyph(e) {
    return this._layoutEngine.stringsForGlyph(e);
  }
  /**
  * An array of all [OpenType feature tags](https://www.microsoft.com/typography/otspec/featuretags.htm)
  * (or mapped AAT tags) supported by the font.
  * The features parameter is an array of OpenType feature tags to be applied in addition to the default set.
  * If this is an AAT font, the OpenType feature tags are mapped to AAT features.
  *
  * @type {string[]}
  */
  get availableFeatures() {
    return this._layoutEngine.getAvailableFeatures();
  }
  getAvailableFeatures(e, t) {
    return this._layoutEngine.getAvailableFeatures(e, t);
  }
  _getBaseGlyph(e, t = []) {
    return this._glyphs[e] || (this.directory.tables.glyf ? this._glyphs[e] = new Zt(e, t, this) : (this.directory.tables["CFF "] || this.directory.tables.CFF2) && (this._glyphs[e] = new xf(e, t, this))), this._glyphs[e] || null;
  }
  /**
  * Returns a glyph object for the given glyph id.
  * You can pass the array of code points this glyph represents for
  * your use later, and it will be stored in the glyph object.
  *
  * @param {number} glyph
  * @param {number[]} characters
  * @return {Glyph}
  */
  getGlyph(e, t = []) {
    return this._glyphs[e] || (this.directory.tables.sbix ? this._glyphs[e] = new wf(e, t, this) : this.directory.tables.COLR && this.directory.tables.CPAL ? this._glyphs[e] = new yf(e, t, this) : this._getBaseGlyph(e, t)), this._glyphs[e] || null;
  }
  /**
  * Returns a Subset for this font.
  * @return {Subset}
  */
  createSubset() {
    return this.directory.tables["CFF "] ? new Uf(this) : new Nf(this);
  }
  /**
  * Returns an object describing the available variation axes
  * that this font supports. Keys are setting tags, and values
  * contain the axis name, range, and default value.
  *
  * @type {object}
  */
  get variationAxes() {
    let e = {};
    if (!this.fvar) return e;
    for (let t of this.fvar.axis) e[t.axisTag.trim()] = {
      name: t.name.en,
      min: t.minValue,
      default: t.defaultValue,
      max: t.maxValue
    };
    return e;
  }
  /**
  * Returns an object describing the named variation instances
  * that the font designer has specified. Keys are variation names
  * and values are the variation settings for this instance.
  *
  * @type {object}
  */
  get namedVariations() {
    let e = {};
    if (!this.fvar) return e;
    for (let t of this.fvar.instance) {
      let r = {};
      for (let s = 0; s < this.fvar.axis.length; s++) {
        let n = this.fvar.axis[s];
        r[n.axisTag.trim()] = t.coord[s];
      }
      e[t.name.en] = r;
    }
    return e;
  }
  /**
  * Returns a new font with the given variation settings applied.
  * Settings can either be an instance name, or an object containing
  * variation tags as specified by the `variationAxes` property.
  *
  * @param {object} settings
  * @return {TTFFont}
  */
  getVariation(e) {
    if (!(this.directory.tables.fvar && (this.directory.tables.gvar && this.directory.tables.glyf || this.directory.tables.CFF2))) throw new Error("Variations require a font with the fvar, gvar and glyf, or CFF2 tables.");
    if (typeof e == "string" && (e = this.namedVariations[e]), typeof e != "object") throw new Error("Variation settings must be either a variation name or settings object.");
    let t = this.fvar.axis.map((n, a) => {
      let o = n.axisTag.trim();
      return o in e ? Math.max(n.minValue, Math.min(n.maxValue, e[o])) : n.defaultValue;
    }), r = new Ae(this.stream.buffer);
    r.pos = this._directoryPos;
    let s = new Ee(r, t);
    return s._tables = this._tables, s;
  }
  get _variationProcessor() {
    if (!this.fvar) return null;
    let e = this.variationCoords;
    return !e && !this.CFF2 ? null : (e || (e = this.fvar.axis.map((t) => t.defaultValue)), new Tf(this, e));
  }
  // Standardized format plugin API
  getFont(e) {
    return this.getVariation(e);
  }
  constructor(e, t = null) {
    De(this, "type", "TTF"), this.defaultLanguage = null, this.stream = e, this.variationCoords = t, this._directoryPos = this.stream.pos, this._tables = {}, this._glyphs = {}, this._decodeDirectory();
    for (let r in this.directory.tables) {
      let s = this.directory.tables[r];
      Ft[r] && s.length > 0 && Object.defineProperty(this, r, {
        get: this._getTable.bind(this, s)
      });
    }
  }
}
Ie([
  ke
], Ee.prototype, "bbox", null);
Ie([
  ke
], Ee.prototype, "_cmapProcessor", null);
Ie([
  ke
], Ee.prototype, "characterSet", null);
Ie([
  ke
], Ee.prototype, "_layoutEngine", null);
Ie([
  ke
], Ee.prototype, "variationAxes", null);
Ie([
  ke
], Ee.prototype, "namedVariations", null);
Ie([
  ke
], Ee.prototype, "_variationProcessor", null);
let Gf = new x({
  tag: new de(4),
  offset: new g(v, "void", {
    type: "global"
  }),
  compLength: v,
  length: v,
  origChecksum: v
}), wn = new x({
  tag: new de(4),
  flavor: v,
  length: v,
  numTables: l,
  reserved: new be(l),
  totalSfntSize: v,
  majorVersion: l,
  minorVersion: l,
  metaOffset: v,
  metaLength: v,
  metaOrigLength: v,
  privOffset: v,
  privLength: v,
  tables: new b(Gf, "numTables")
});
wn.process = function() {
  let i = {};
  for (let e of this.tables) i[e.tag] = e;
  this.tables = i;
};
var Vf = wn;
class zf extends Ee {
  static probe(e) {
    return $t.decode(e.slice(0, 4)) === "wOFF";
  }
  _decodeDirectory() {
    this.directory = Vf.decode(this.stream, {
      _startOffset: 0
    });
  }
  _getTableStream(e) {
    let t = this.directory.tables[e];
    if (t)
      if (this.stream.pos = t.offset, t.compLength < t.length) {
        this.stream.pos += 2;
        let r = new Uint8Array(t.length), s = ai(this.stream.readBuffer(t.compLength - 2), r);
        return new Ae(s);
      } else return this.stream;
    return null;
  }
  constructor(...e) {
    super(...e), De(this, "type", "WOFF");
  }
}
class qf extends Zt {
  _decode() {
    return this._font._transformedGlyphs[this.id];
  }
  _getCBox() {
    return this.path.bbox;
  }
  constructor(...e) {
    super(...e), De(this, "type", "WOFF2");
  }
}
const Ta = {
  decode(i) {
    let e = 0, t = [
      0,
      1,
      2,
      3,
      4
    ];
    for (let r = 0; r < t.length; r++) {
      let s = i.readUInt8();
      if (e & 3758096384) throw new Error("Overflow");
      if (e = e << 7 | s & 127, (s & 128) === 0) return e;
    }
    throw new Error("Bad base 128 number");
  }
};
let Wf = [
  "cmap",
  "head",
  "hhea",
  "hmtx",
  "maxp",
  "name",
  "OS/2",
  "post",
  "cvt ",
  "fpgm",
  "glyf",
  "loca",
  "prep",
  "CFF ",
  "VORG",
  "EBDT",
  "EBLC",
  "gasp",
  "hdmx",
  "kern",
  "LTSH",
  "PCLT",
  "VDMX",
  "vhea",
  "vmtx",
  "BASE",
  "GDEF",
  "GPOS",
  "GSUB",
  "EBSC",
  "JSTF",
  "MATH",
  "CBDT",
  "CBLC",
  "COLR",
  "CPAL",
  "SVG ",
  "sbix",
  "acnt",
  "avar",
  "bdat",
  "bloc",
  "bsln",
  "cvar",
  "fdsc",
  "feat",
  "fmtx",
  "fvar",
  "gvar",
  "hsty",
  "just",
  "lcar",
  "mort",
  "morx",
  "opbd",
  "prop",
  "trak",
  "Zapf",
  "Silf",
  "Glat",
  "Gloc",
  "Feat",
  "Sill"
], Hf = new x({
  flags: D,
  customTag: new Et(new de(4), (i) => (i.flags & 63) === 63),
  tag: (i) => i.customTag || Wf[i.flags & 63],
  length: Ta,
  transformVersion: (i) => i.flags >>> 6 & 3,
  transformed: (i) => i.tag === "glyf" || i.tag === "loca" ? i.transformVersion === 0 : i.transformVersion !== 0,
  transformLength: new Et(Ta, (i) => i.transformed)
}), yn = new x({
  tag: new de(4),
  flavor: v,
  length: v,
  numTables: l,
  reserved: new be(l),
  totalSfntSize: v,
  totalCompressedSize: v,
  majorVersion: l,
  minorVersion: l,
  metaOffset: v,
  metaLength: v,
  metaOrigLength: v,
  privOffset: v,
  privLength: v,
  tables: new b(Hf, "numTables")
});
yn.process = function() {
  let i = {};
  for (let e = 0; e < this.tables.length; e++) {
    let t = this.tables[e];
    i[t.tag] = t;
  }
  return this.tables = i;
};
var $f = yn;
class Xf extends Ee {
  static probe(e) {
    return $t.decode(e.slice(0, 4)) === "wOF2";
  }
  _decodeDirectory() {
    this.directory = $f.decode(this.stream), this._dataPos = this.stream.pos;
  }
  _decompress() {
    if (!this._decompressed) {
      this.stream.pos = this._dataPos;
      let e = this.stream.readBuffer(this.directory.totalCompressedSize), t = 0;
      for (let s in this.directory.tables) {
        let n = this.directory.tables[s];
        n.offset = t, t += n.transformLength != null ? n.transformLength : n.length;
      }
      let r = hi(e, t);
      if (!r) throw new Error("Error decoding compressed data in WOFF2");
      this.stream = new Ae(r), this._decompressed = !0;
    }
  }
  _decodeTable(e) {
    return this._decompress(), super._decodeTable(e);
  }
  // Override this method to get a glyph and return our
  // custom subclass if there is a glyf table.
  _getBaseGlyph(e, t = []) {
    if (!this._glyphs[e])
      return this.directory.tables.glyf && this.directory.tables.glyf.transformed ? (this._transformedGlyphs || this._transformGlyfTable(), this._glyphs[e] = new qf(e, t, this)) : super._getBaseGlyph(e, t);
  }
  _transformGlyfTable() {
    this._decompress(), this.stream.pos = this.directory.tables.glyf.offset;
    let e = jf.decode(this.stream), t = [];
    for (let s = 0; s < e.numGlyphs; s++) {
      let n = {}, a = e.nContours.readInt16BE();
      if (n.numberOfContours = a, a > 0) {
        let o = [], u = 0;
        for (let c = 0; c < a; c++) {
          let d = Tr(e.nPoints);
          u += d, o.push(u);
        }
        n.points = Jf(e.flags, e.glyphs, u);
        for (let c = 0; c < a; c++) n.points[o[c] - 1].endContour = !0;
        var r = Tr(e.glyphs);
      } else if (a < 0 && Zt.prototype._decodeComposite.call({
        _font: this
      }, n, e.composites))
        var r = Tr(e.glyphs);
      t.push(n);
    }
    this._transformedGlyphs = t;
  }
  constructor(...e) {
    super(...e), De(this, "type", "WOFF2");
  }
}
class w0 {
  decode(e, t) {
    return new Ae(this._buf.decode(e, t));
  }
  constructor(e) {
    this.length = e, this._buf = new Ye(e);
  }
}
let jf = new x({
  version: v,
  numGlyphs: l,
  indexFormat: l,
  nContourStreamSize: v,
  nPointsStreamSize: v,
  flagStreamSize: v,
  glyphStreamSize: v,
  compositeStreamSize: v,
  bboxStreamSize: v,
  instructionStreamSize: v,
  nContours: new w0("nContourStreamSize"),
  nPoints: new w0("nPointsStreamSize"),
  flags: new w0("flagStreamSize"),
  glyphs: new w0("glyphStreamSize"),
  composites: new w0("compositeStreamSize"),
  bboxes: new w0("bboxStreamSize"),
  instructions: new w0("instructionStreamSize")
});
const Yf = 253, Zf = 254, Kf = 255, Oa = 253;
function Tr(i) {
  let e = i.readUInt8();
  return e === Yf ? i.readUInt16BE() : e === Kf ? i.readUInt8() + Oa : e === Zf ? i.readUInt8() + Oa * 2 : e;
}
function He(i, e) {
  return i & 1 ? e : -e;
}
function Jf(i, e, t) {
  let r, s = r = 0, n = [];
  for (let u = 0; u < t; u++) {
    let c = 0, d = 0, f = i.readUInt8(), p = !(f >> 7);
    if (f &= 127, f < 10)
      c = 0, d = He(f, ((f & 14) << 7) + e.readUInt8());
    else if (f < 20)
      c = He(f, ((f - 10 & 14) << 7) + e.readUInt8()), d = 0;
    else if (f < 84) {
      var a = f - 20, o = e.readUInt8();
      c = He(f, 1 + (a & 48) + (o >> 4)), d = He(f >> 1, 1 + ((a & 12) << 2) + (o & 15));
    } else if (f < 120) {
      var a = f - 84;
      c = He(f, 1 + (a / 12 << 8) + e.readUInt8()), d = He(f >> 1, 1 + (a % 12 >> 2 << 8) + e.readUInt8());
    } else if (f < 124) {
      var o = e.readUInt8();
      let C = e.readUInt8();
      c = He(f, (o << 4) + (C >> 4)), d = He(f >> 1, ((C & 15) << 8) + e.readUInt8());
    } else
      c = He(f, e.readUInt16BE()), d = He(f >> 1, e.readUInt16BE());
    s += c, r += d, n.push(new Ge(p, !1, s, r));
  }
  return n;
}
let Qf = new te(v, {
  65536: {
    numFonts: v,
    offsets: new b(v, "numFonts")
  },
  131072: {
    numFonts: v,
    offsets: new b(v, "numFonts"),
    dsigTag: v,
    dsigLength: v,
    dsigOffset: v
  }
});
class _f {
  static probe(e) {
    return $t.decode(e.slice(0, 4)) === "ttcf";
  }
  getFont(e) {
    for (let t of this.header.offsets) {
      let r = new Ae(this.stream.buffer);
      r.pos = t;
      let s = new Ee(r);
      if (s.postscriptName === e || s.postscriptName instanceof Uint8Array && e instanceof Uint8Array && s.postscriptName.every((n, a) => e[a] === n)) return s;
    }
    return null;
  }
  get fonts() {
    let e = [];
    for (let t of this.header.offsets) {
      let r = new Ae(this.stream.buffer);
      r.pos = t, e.push(new Ee(r));
    }
    return e;
  }
  constructor(e) {
    if (De(this, "type", "TTC"), this.stream = e, e.readString(4) !== "ttcf") throw new Error("Not a TrueType collection");
    this.header = Qf.decode(e);
  }
}
let e1 = new de(D);
new x({
  len: v,
  buf: new Ye("len")
});
let t1 = new x({
  id: l,
  nameOffset: E,
  attr: D,
  dataOffset: h0,
  handle: v
}), r1 = new x({
  name: new de(4),
  maxTypeIndex: l,
  refList: new g(l, new b(t1, (i) => i.maxTypeIndex + 1), {
    type: "parent"
  })
}), s1 = new x({
  length: l,
  types: new b(r1, (i) => i.length + 1)
}), a1 = new x({
  reserved: new be(D, 24),
  typeList: new g(l, s1),
  nameListOffset: new g(l, "void")
}), Fa = new x({
  dataOffset: v,
  map: new g(v, a1),
  dataLength: v,
  mapLength: v
});
class n1 {
  static probe(e) {
    let t = new Ae(e);
    try {
      var r = Fa.decode(t);
    } catch {
      return !1;
    }
    for (let s of r.map.typeList.types)
      if (s.name === "sfnt") return !0;
    return !1;
  }
  getFont(e) {
    if (!this.sfnt) return null;
    for (let t of this.sfnt.refList) {
      let r = this.header.dataOffset + t.dataOffset + 4, s = new Ae(this.stream.buffer.slice(r)), n = new Ee(s);
      if (n.postscriptName === e || n.postscriptName instanceof Uint8Array && e instanceof Uint8Array && n.postscriptName.every((a, o) => e[o] === a)) return n;
    }
    return null;
  }
  get fonts() {
    let e = [];
    for (let t of this.sfnt.refList) {
      let r = this.header.dataOffset + t.dataOffset + 4, s = new Ae(this.stream.buffer.slice(r));
      e.push(new Ee(s));
    }
    return e;
  }
  constructor(e) {
    De(this, "type", "DFont"), this.stream = e, this.header = Fa.decode(this.stream);
    for (let t of this.header.map.typeList.types) {
      for (let r of t.refList) r.nameOffset >= 0 ? (this.stream.pos = r.nameOffset + this.header.map.nameListOffset, r.name = e1.decode(this.stream)) : r.name = null;
      t.name === "sfnt" && (this.sfnt = t);
    }
  }
}
U0(Ee);
U0(zf);
U0(Xf);
U0(_f);
U0(n1);
export {
  bi as create,
  Pt as defaultLanguage,
  pi as logErrors,
  U0 as registerFormat,
  gi as setDefaultLanguage
};
