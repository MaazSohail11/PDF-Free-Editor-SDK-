'use strict';

class VanillaPDFEditor {
  constructor(container, options = {}) {
    this.container = container;
    this.options = options;
    this.instance = null;
    this.disposed = false;

    this.ready = import('./pdf-editor-sdk.es.js')
      .then(({ VanillaPDFEditor: Editor }) => {
        if (this.disposed) return null;
        this.instance = new Editor(this.container, this.options);
        return this.instance;
      })
      .catch((error) => {
        if (typeof this.options?.onError === 'function') this.options.onError({ phase: 'mount', error });
        throw error;
      });
  }

  updateOptions(newOptions = {}) {
    this.options = { ...this.options, ...newOptions };
    if (this.instance) this.instance.updateOptions(newOptions);
    return this;
  }

  unmount() {
    this.disposed = true;
    this.instance?.unmount();
    this.instance = null;
  }
}

module.exports = { VanillaPDFEditor };
module.exports.default = VanillaPDFEditor;
