import { e2 as Wt } from "./PDFEditor-CGWidoXd.js";
var Me = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function be(t, e) {
  return e = { exports: {} }, t(e, e.exports), e.exports;
}
function Xt(t) {
  return t && t.default || t;
}
var Wl = Jl, Xl = _l, Yl = tc, ft = [], Ke = [], Kl = typeof Uint8Array < "u" ? Uint8Array : Array, Fi = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
for (var mr = 0, Zl = Fi.length; mr < Zl; ++mr)
  ft[mr] = Fi[mr], Ke[Fi.charCodeAt(mr)] = mr;
Ke[45] = 62;
Ke[95] = 63;
function Gu(t) {
  var e = t.length;
  if (e % 4 > 0)
    throw new Error("Invalid string. Length must be a multiple of 4");
  var r = t.indexOf("=");
  r === -1 && (r = e);
  var n = r === e ? 0 : 4 - r % 4;
  return [r, n];
}
function Jl(t) {
  var e = Gu(t), r = e[0], n = e[1];
  return (r + n) * 3 / 4 - n;
}
function Ql(t, e, r) {
  return (e + r) * 3 / 4 - r;
}
function _l(t) {
  var e, r = Gu(t), n = r[0], a = r[1], o = new Kl(Ql(t, n, a)), s = 0, u = a > 0 ? n - 4 : n, f;
  for (f = 0; f < u; f += 4)
    e = Ke[t.charCodeAt(f)] << 18 | Ke[t.charCodeAt(f + 1)] << 12 | Ke[t.charCodeAt(f + 2)] << 6 | Ke[t.charCodeAt(f + 3)], o[s++] = e >> 16 & 255, o[s++] = e >> 8 & 255, o[s++] = e & 255;
  return a === 2 && (e = Ke[t.charCodeAt(f)] << 2 | Ke[t.charCodeAt(f + 1)] >> 4, o[s++] = e & 255), a === 1 && (e = Ke[t.charCodeAt(f)] << 10 | Ke[t.charCodeAt(f + 1)] << 4 | Ke[t.charCodeAt(f + 2)] >> 2, o[s++] = e >> 8 & 255, o[s++] = e & 255), o;
}
function $l(t) {
  return ft[t >> 18 & 63] + ft[t >> 12 & 63] + ft[t >> 6 & 63] + ft[t & 63];
}
function ec(t, e, r) {
  for (var n, a = [], o = e; o < r; o += 3)
    n = (t[o] << 16 & 16711680) + (t[o + 1] << 8 & 65280) + (t[o + 2] & 255), a.push($l(n));
  return a.join("");
}
function tc(t) {
  for (var e, r = t.length, n = r % 3, a = [], o = 16383, s = 0, u = r - n; s < u; s += o)
    a.push(ec(t, s, s + o > u ? u : s + o));
  return n === 1 ? (e = t[r - 1], a.push(ft[e >> 2] + ft[e << 4 & 63] + "==")) : n === 2 && (e = (t[r - 2] << 8) + t[r - 1], a.push(ft[e >> 10] + ft[e >> 4 & 63] + ft[e << 2 & 63] + "=")), a.join("");
}
var xi = {
  byteLength: Wl,
  toByteArray: Xl,
  fromByteArray: Yl
}, rc = function(e, r, n, a, o) {
  var s, u, f = o * 8 - a - 1, l = (1 << f) - 1, c = l >> 1, p = -7, y = n ? o - 1 : 0, v = n ? -1 : 1, m = e[r + y];
  for (y += v, s = m & (1 << -p) - 1, m >>= -p, p += f; p > 0; s = s * 256 + e[r + y], y += v, p -= 8)
    ;
  for (u = s & (1 << -p) - 1, s >>= -p, p += a; p > 0; u = u * 256 + e[r + y], y += v, p -= 8)
    ;
  if (s === 0)
    s = 1 - c;
  else {
    if (s === l)
      return u ? NaN : (m ? -1 : 1) * (1 / 0);
    u = u + Math.pow(2, a), s = s - c;
  }
  return (m ? -1 : 1) * u * Math.pow(2, s - a);
}, nc = function(e, r, n, a, o, s) {
  var u, f, l, c = s * 8 - o - 1, p = (1 << c) - 1, y = p >> 1, v = o === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0, m = a ? 0 : s - 1, w = a ? 1 : -1, F = r < 0 || r === 0 && 1 / r < 0 ? 1 : 0;
  for (r = Math.abs(r), isNaN(r) || r === 1 / 0 ? (f = isNaN(r) ? 1 : 0, u = p) : (u = Math.floor(Math.log(r) / Math.LN2), r * (l = Math.pow(2, -u)) < 1 && (u--, l *= 2), u + y >= 1 ? r += v / l : r += v * Math.pow(2, 1 - y), r * l >= 2 && (u++, l /= 2), u + y >= p ? (f = 0, u = p) : u + y >= 1 ? (f = (r * l - 1) * Math.pow(2, o), u = u + y) : (f = r * Math.pow(2, y - 1) * Math.pow(2, o), u = 0)); o >= 8; e[n + m] = f & 255, m += w, f /= 256, o -= 8)
    ;
  for (u = u << o | f, c += o; c > 0; e[n + m] = u & 255, m += w, u /= 256, c -= 8)
    ;
  e[n + m - w] |= F * 128;
}, br = {
  read: rc,
  write: nc
}, Xe = be(function(t, e) {
  var r = typeof Symbol == "function" && typeof Symbol.for == "function" ? /* @__PURE__ */ Symbol.for("nodejs.util.inspect.custom") : null;
  e.Buffer = s, e.SlowBuffer = F, e.INSPECT_MAX_BYTES = 50;
  var n = 2147483647;
  e.kMaxLength = n, s.TYPED_ARRAY_SUPPORT = a(), !s.TYPED_ARRAY_SUPPORT && typeof console < "u" && typeof console.error == "function" && console.error("This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support.");
  function a() {
    try {
      var g = new Uint8Array(1), h = {
        foo: function() {
          return 42;
        }
      };
      return Object.setPrototypeOf(h, Uint8Array.prototype), Object.setPrototypeOf(g, h), g.foo() === 42;
    } catch {
      return !1;
    }
  }
  Object.defineProperty(s.prototype, "parent", {
    enumerable: !0,
    get: function() {
      if (s.isBuffer(this))
        return this.buffer;
    }
  }), Object.defineProperty(s.prototype, "offset", {
    enumerable: !0,
    get: function() {
      if (s.isBuffer(this))
        return this.byteOffset;
    }
  });
  function o(g) {
    if (g > n)
      throw new RangeError('The value "' + g + '" is invalid for option "size"');
    var h = new Uint8Array(g);
    return Object.setPrototypeOf(h, s.prototype), h;
  }
  function s(g, h, d) {
    if (typeof g == "number") {
      if (typeof h == "string")
        throw new TypeError('The "string" argument must be of type string. Received type number');
      return c(g);
    }
    return u(g, h, d);
  }
  s.poolSize = 8192;
  function u(g, h, d) {
    if (typeof g == "string")
      return p(g, h);
    if (ArrayBuffer.isView(g))
      return y(g);
    if (g == null)
      throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof g);
    if (H(g, ArrayBuffer) || g && H(g.buffer, ArrayBuffer) || typeof SharedArrayBuffer < "u" && (H(g, SharedArrayBuffer) || g && H(g.buffer, SharedArrayBuffer)))
      return v(g, h, d);
    if (typeof g == "number")
      throw new TypeError('The "value" argument must not be of type number. Received type number');
    var b = g.valueOf && g.valueOf();
    if (b != null && b !== g)
      return s.from(b, h, d);
    var x = m(g);
    if (x) return x;
    if (typeof Symbol < "u" && Symbol.toPrimitive != null && typeof g[Symbol.toPrimitive] == "function")
      return s.from(g[Symbol.toPrimitive]("string"), h, d);
    throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof g);
  }
  s.from = function(g, h, d) {
    return u(g, h, d);
  }, Object.setPrototypeOf(s.prototype, Uint8Array.prototype), Object.setPrototypeOf(s, Uint8Array);
  function f(g) {
    if (typeof g != "number")
      throw new TypeError('"size" argument must be of type number');
    if (g < 0)
      throw new RangeError('The value "' + g + '" is invalid for option "size"');
  }
  function l(g, h, d) {
    return f(g), g <= 0 ? o(g) : h !== void 0 ? typeof d == "string" ? o(g).fill(h, d) : o(g).fill(h) : o(g);
  }
  s.alloc = function(g, h, d) {
    return l(g, h, d);
  };
  function c(g) {
    return f(g), o(g < 0 ? 0 : w(g) | 0);
  }
  s.allocUnsafe = function(g) {
    return c(g);
  }, s.allocUnsafeSlow = function(g) {
    return c(g);
  };
  function p(g, h) {
    if ((typeof h != "string" || h === "") && (h = "utf8"), !s.isEncoding(h))
      throw new TypeError("Unknown encoding: " + h);
    var d = S(g, h) | 0, b = o(d), x = b.write(g, h);
    return x !== d && (b = b.slice(0, x)), b;
  }
  function y(g) {
    for (var h = g.length < 0 ? 0 : w(g.length) | 0, d = o(h), b = 0; b < h; b += 1)
      d[b] = g[b] & 255;
    return d;
  }
  function v(g, h, d) {
    if (h < 0 || g.byteLength < h)
      throw new RangeError('"offset" is outside of buffer bounds');
    if (g.byteLength < h + (d || 0))
      throw new RangeError('"length" is outside of buffer bounds');
    var b;
    return h === void 0 && d === void 0 ? b = new Uint8Array(g) : d === void 0 ? b = new Uint8Array(g, h) : b = new Uint8Array(g, h, d), Object.setPrototypeOf(b, s.prototype), b;
  }
  function m(g) {
    if (s.isBuffer(g)) {
      var h = w(g.length) | 0, d = o(h);
      return d.length === 0 || g.copy(d, 0, 0, h), d;
    }
    if (g.length !== void 0)
      return typeof g.length != "number" || J(g.length) ? o(0) : y(g);
    if (g.type === "Buffer" && Array.isArray(g.data))
      return y(g.data);
  }
  function w(g) {
    if (g >= n)
      throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + n.toString(16) + " bytes");
    return g | 0;
  }
  function F(g) {
    return +g != g && (g = 0), s.alloc(+g);
  }
  s.isBuffer = function(h) {
    return h != null && h._isBuffer === !0 && h !== s.prototype;
  }, s.compare = function(h, d) {
    if (H(h, Uint8Array) && (h = s.from(h, h.offset, h.byteLength)), H(d, Uint8Array) && (d = s.from(d, d.offset, d.byteLength)), !s.isBuffer(h) || !s.isBuffer(d))
      throw new TypeError('The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array');
    if (h === d) return 0;
    for (var b = h.length, x = d.length, O = 0, C = Math.min(b, x); O < C; ++O)
      if (h[O] !== d[O]) {
        b = h[O], x = d[O];
        break;
      }
    return b < x ? -1 : x < b ? 1 : 0;
  }, s.isEncoding = function(h) {
    switch (String(h).toLowerCase()) {
      case "hex":
      case "utf8":
      case "utf-8":
      case "ascii":
      case "latin1":
      case "binary":
      case "base64":
      case "ucs2":
      case "ucs-2":
      case "utf16le":
      case "utf-16le":
        return !0;
      default:
        return !1;
    }
  }, s.concat = function(h, d) {
    if (!Array.isArray(h))
      throw new TypeError('"list" argument must be an Array of Buffers');
    if (h.length === 0)
      return s.alloc(0);
    var b;
    if (d === void 0)
      for (d = 0, b = 0; b < h.length; ++b)
        d += h[b].length;
    var x = s.allocUnsafe(d), O = 0;
    for (b = 0; b < h.length; ++b) {
      var C = h[b];
      if (H(C, Uint8Array) && (C = s.from(C)), !s.isBuffer(C))
        throw new TypeError('"list" argument must be an Array of Buffers');
      C.copy(x, O), O += C.length;
    }
    return x;
  };
  function S(g, h) {
    if (s.isBuffer(g))
      return g.length;
    if (ArrayBuffer.isView(g) || H(g, ArrayBuffer))
      return g.byteLength;
    if (typeof g != "string")
      throw new TypeError('The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof g);
    var d = g.length, b = arguments.length > 2 && arguments[2] === !0;
    if (!b && d === 0) return 0;
    for (var x = !1; ; )
      switch (h) {
        case "ascii":
        case "latin1":
        case "binary":
          return d;
        case "utf8":
        case "utf-8":
          return Oe(g).length;
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return d * 2;
        case "hex":
          return d >>> 1;
        case "base64":
          return V(g).length;
        default:
          if (x)
            return b ? -1 : Oe(g).length;
          h = ("" + h).toLowerCase(), x = !0;
      }
  }
  s.byteLength = S;
  function I(g, h, d) {
    var b = !1;
    if ((h === void 0 || h < 0) && (h = 0), h > this.length || ((d === void 0 || d > this.length) && (d = this.length), d <= 0) || (d >>>= 0, h >>>= 0, d <= h))
      return "";
    for (g || (g = "utf8"); ; )
      switch (g) {
        case "hex":
          return re(this, h, d);
        case "utf8":
        case "utf-8":
          return te(this, h, d);
        case "ascii":
          return le(this, h, d);
        case "latin1":
        case "binary":
          return K(this, h, d);
        case "base64":
          return Q(this, h, d);
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return de(this, h, d);
        default:
          if (b) throw new TypeError("Unknown encoding: " + g);
          g = (g + "").toLowerCase(), b = !0;
      }
  }
  s.prototype._isBuffer = !0;
  function A(g, h, d) {
    var b = g[h];
    g[h] = g[d], g[d] = b;
  }
  s.prototype.swap16 = function() {
    var h = this.length;
    if (h % 2 !== 0)
      throw new RangeError("Buffer size must be a multiple of 16-bits");
    for (var d = 0; d < h; d += 2)
      A(this, d, d + 1);
    return this;
  }, s.prototype.swap32 = function() {
    var h = this.length;
    if (h % 4 !== 0)
      throw new RangeError("Buffer size must be a multiple of 32-bits");
    for (var d = 0; d < h; d += 4)
      A(this, d, d + 3), A(this, d + 1, d + 2);
    return this;
  }, s.prototype.swap64 = function() {
    var h = this.length;
    if (h % 8 !== 0)
      throw new RangeError("Buffer size must be a multiple of 64-bits");
    for (var d = 0; d < h; d += 8)
      A(this, d, d + 7), A(this, d + 1, d + 6), A(this, d + 2, d + 5), A(this, d + 3, d + 4);
    return this;
  }, s.prototype.toString = function() {
    var h = this.length;
    return h === 0 ? "" : arguments.length === 0 ? te(this, 0, h) : I.apply(this, arguments);
  }, s.prototype.toLocaleString = s.prototype.toString, s.prototype.equals = function(h) {
    if (!s.isBuffer(h)) throw new TypeError("Argument must be a Buffer");
    return this === h ? !0 : s.compare(this, h) === 0;
  }, s.prototype.inspect = function() {
    var h = "", d = e.INSPECT_MAX_BYTES;
    return h = this.toString("hex", 0, d).replace(/(.{2})/g, "$1 ").trim(), this.length > d && (h += " ... "), "<Buffer " + h + ">";
  }, r && (s.prototype[r] = s.prototype.inspect), s.prototype.compare = function(h, d, b, x, O) {
    if (H(h, Uint8Array) && (h = s.from(h, h.offset, h.byteLength)), !s.isBuffer(h))
      throw new TypeError('The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof h);
    if (d === void 0 && (d = 0), b === void 0 && (b = h ? h.length : 0), x === void 0 && (x = 0), O === void 0 && (O = this.length), d < 0 || b > h.length || x < 0 || O > this.length)
      throw new RangeError("out of range index");
    if (x >= O && d >= b)
      return 0;
    if (x >= O)
      return -1;
    if (d >= b)
      return 1;
    if (d >>>= 0, b >>>= 0, x >>>= 0, O >>>= 0, this === h) return 0;
    for (var C = O - x, U = b - d, Y = Math.min(C, U), oe = this.slice(x, O), ge = h.slice(d, b), ue = 0; ue < Y; ++ue)
      if (oe[ue] !== ge[ue]) {
        C = oe[ue], U = ge[ue];
        break;
      }
    return C < U ? -1 : U < C ? 1 : 0;
  };
  function M(g, h, d, b, x) {
    if (g.length === 0) return -1;
    if (typeof d == "string" ? (b = d, d = 0) : d > 2147483647 ? d = 2147483647 : d < -2147483648 && (d = -2147483648), d = +d, J(d) && (d = x ? 0 : g.length - 1), d < 0 && (d = g.length + d), d >= g.length) {
      if (x) return -1;
      d = g.length - 1;
    } else if (d < 0)
      if (x) d = 0;
      else return -1;
    if (typeof h == "string" && (h = s.from(h, b)), s.isBuffer(h))
      return h.length === 0 ? -1 : L(g, h, d, b, x);
    if (typeof h == "number")
      return h = h & 255, typeof Uint8Array.prototype.indexOf == "function" ? x ? Uint8Array.prototype.indexOf.call(g, h, d) : Uint8Array.prototype.lastIndexOf.call(g, h, d) : L(g, [h], d, b, x);
    throw new TypeError("val must be string, number or Buffer");
  }
  function L(g, h, d, b, x) {
    var O = 1, C = g.length, U = h.length;
    if (b !== void 0 && (b = String(b).toLowerCase(), b === "ucs2" || b === "ucs-2" || b === "utf16le" || b === "utf-16le")) {
      if (g.length < 2 || h.length < 2)
        return -1;
      O = 2, C /= 2, U /= 2, d /= 2;
    }
    function Y(et, Ve) {
      return O === 1 ? et[Ve] : et.readUInt16BE(Ve * O);
    }
    var oe;
    if (x) {
      var ge = -1;
      for (oe = d; oe < C; oe++)
        if (Y(g, oe) === Y(h, ge === -1 ? 0 : oe - ge)) {
          if (ge === -1 && (ge = oe), oe - ge + 1 === U) return ge * O;
        } else
          ge !== -1 && (oe -= oe - ge), ge = -1;
    } else
      for (d + U > C && (d = C - U), oe = d; oe >= 0; oe--) {
        for (var ue = !0, je = 0; je < U; je++)
          if (Y(g, oe + je) !== Y(h, je)) {
            ue = !1;
            break;
          }
        if (ue) return oe;
      }
    return -1;
  }
  s.prototype.includes = function(h, d, b) {
    return this.indexOf(h, d, b) !== -1;
  }, s.prototype.indexOf = function(h, d, b) {
    return M(this, h, d, b, !0);
  }, s.prototype.lastIndexOf = function(h, d, b) {
    return M(this, h, d, b, !1);
  };
  function P(g, h, d, b) {
    d = Number(d) || 0;
    var x = g.length - d;
    b ? (b = Number(b), b > x && (b = x)) : b = x;
    var O = h.length;
    b > O / 2 && (b = O / 2);
    for (var C = 0; C < b; ++C) {
      var U = parseInt(h.substr(C * 2, 2), 16);
      if (J(U)) return C;
      g[d + C] = U;
    }
    return C;
  }
  function G(g, h, d, b) {
    return ie(Oe(h, g.length - d), g, d, b);
  }
  function W(g, h, d, b) {
    return ie(Ce(h), g, d, b);
  }
  function ne(g, h, d, b) {
    return W(g, h, d, b);
  }
  function q(g, h, d, b) {
    return ie(V(h), g, d, b);
  }
  function N(g, h, d, b) {
    return ie(_(h, g.length - d), g, d, b);
  }
  s.prototype.write = function(h, d, b, x) {
    if (d === void 0)
      x = "utf8", b = this.length, d = 0;
    else if (b === void 0 && typeof d == "string")
      x = d, b = this.length, d = 0;
    else if (isFinite(d))
      d = d >>> 0, isFinite(b) ? (b = b >>> 0, x === void 0 && (x = "utf8")) : (x = b, b = void 0);
    else
      throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
    var O = this.length - d;
    if ((b === void 0 || b > O) && (b = O), h.length > 0 && (b < 0 || d < 0) || d > this.length)
      throw new RangeError("Attempt to write outside buffer bounds");
    x || (x = "utf8");
    for (var C = !1; ; )
      switch (x) {
        case "hex":
          return P(this, h, d, b);
        case "utf8":
        case "utf-8":
          return G(this, h, d, b);
        case "ascii":
          return W(this, h, d, b);
        case "latin1":
        case "binary":
          return ne(this, h, d, b);
        case "base64":
          return q(this, h, d, b);
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return N(this, h, d, b);
        default:
          if (C) throw new TypeError("Unknown encoding: " + x);
          x = ("" + x).toLowerCase(), C = !0;
      }
  }, s.prototype.toJSON = function() {
    return {
      type: "Buffer",
      data: Array.prototype.slice.call(this._arr || this, 0)
    };
  };
  function Q(g, h, d) {
    return h === 0 && d === g.length ? xi.fromByteArray(g) : xi.fromByteArray(g.slice(h, d));
  }
  function te(g, h, d) {
    d = Math.min(g.length, d);
    for (var b = [], x = h; x < d; ) {
      var O = g[x], C = null, U = O > 239 ? 4 : O > 223 ? 3 : O > 191 ? 2 : 1;
      if (x + U <= d) {
        var Y, oe, ge, ue;
        switch (U) {
          case 1:
            O < 128 && (C = O);
            break;
          case 2:
            Y = g[x + 1], (Y & 192) === 128 && (ue = (O & 31) << 6 | Y & 63, ue > 127 && (C = ue));
            break;
          case 3:
            Y = g[x + 1], oe = g[x + 2], (Y & 192) === 128 && (oe & 192) === 128 && (ue = (O & 15) << 12 | (Y & 63) << 6 | oe & 63, ue > 2047 && (ue < 55296 || ue > 57343) && (C = ue));
            break;
          case 4:
            Y = g[x + 1], oe = g[x + 2], ge = g[x + 3], (Y & 192) === 128 && (oe & 192) === 128 && (ge & 192) === 128 && (ue = (O & 15) << 18 | (Y & 63) << 12 | (oe & 63) << 6 | ge & 63, ue > 65535 && ue < 1114112 && (C = ue));
        }
      }
      C === null ? (C = 65533, U = 1) : C > 65535 && (C -= 65536, b.push(C >>> 10 & 1023 | 55296), C = 56320 | C & 1023), b.push(C), x += U;
    }
    return j(b);
  }
  var ce = 4096;
  function j(g) {
    var h = g.length;
    if (h <= ce)
      return String.fromCharCode.apply(String, g);
    for (var d = "", b = 0; b < h; )
      d += String.fromCharCode.apply(String, g.slice(b, b += ce));
    return d;
  }
  function le(g, h, d) {
    var b = "";
    d = Math.min(g.length, d);
    for (var x = h; x < d; ++x)
      b += String.fromCharCode(g[x] & 127);
    return b;
  }
  function K(g, h, d) {
    var b = "";
    d = Math.min(g.length, d);
    for (var x = h; x < d; ++x)
      b += String.fromCharCode(g[x]);
    return b;
  }
  function re(g, h, d) {
    var b = g.length;
    (!h || h < 0) && (h = 0), (!d || d < 0 || d > b) && (d = b);
    for (var x = "", O = h; O < d; ++O)
      x += xe[g[O]];
    return x;
  }
  function de(g, h, d) {
    for (var b = g.slice(h, d), x = "", O = 0; O < b.length; O += 2)
      x += String.fromCharCode(b[O] + b[O + 1] * 256);
    return x;
  }
  s.prototype.slice = function(h, d) {
    var b = this.length;
    h = ~~h, d = d === void 0 ? b : ~~d, h < 0 ? (h += b, h < 0 && (h = 0)) : h > b && (h = b), d < 0 ? (d += b, d < 0 && (d = 0)) : d > b && (d = b), d < h && (d = h);
    var x = this.subarray(h, d);
    return Object.setPrototypeOf(x, s.prototype), x;
  };
  function X(g, h, d) {
    if (g % 1 !== 0 || g < 0) throw new RangeError("offset is not uint");
    if (g + h > d) throw new RangeError("Trying to access beyond buffer length");
  }
  s.prototype.readUIntLE = function(h, d, b) {
    h = h >>> 0, d = d >>> 0, b || X(h, d, this.length);
    for (var x = this[h], O = 1, C = 0; ++C < d && (O *= 256); )
      x += this[h + C] * O;
    return x;
  }, s.prototype.readUIntBE = function(h, d, b) {
    h = h >>> 0, d = d >>> 0, b || X(h, d, this.length);
    for (var x = this[h + --d], O = 1; d > 0 && (O *= 256); )
      x += this[h + --d] * O;
    return x;
  }, s.prototype.readUInt8 = function(h, d) {
    return h = h >>> 0, d || X(h, 1, this.length), this[h];
  }, s.prototype.readUInt16LE = function(h, d) {
    return h = h >>> 0, d || X(h, 2, this.length), this[h] | this[h + 1] << 8;
  }, s.prototype.readUInt16BE = function(h, d) {
    return h = h >>> 0, d || X(h, 2, this.length), this[h] << 8 | this[h + 1];
  }, s.prototype.readUInt32LE = function(h, d) {
    return h = h >>> 0, d || X(h, 4, this.length), (this[h] | this[h + 1] << 8 | this[h + 2] << 16) + this[h + 3] * 16777216;
  }, s.prototype.readUInt32BE = function(h, d) {
    return h = h >>> 0, d || X(h, 4, this.length), this[h] * 16777216 + (this[h + 1] << 16 | this[h + 2] << 8 | this[h + 3]);
  }, s.prototype.readIntLE = function(h, d, b) {
    h = h >>> 0, d = d >>> 0, b || X(h, d, this.length);
    for (var x = this[h], O = 1, C = 0; ++C < d && (O *= 256); )
      x += this[h + C] * O;
    return O *= 128, x >= O && (x -= Math.pow(2, 8 * d)), x;
  }, s.prototype.readIntBE = function(h, d, b) {
    h = h >>> 0, d = d >>> 0, b || X(h, d, this.length);
    for (var x = d, O = 1, C = this[h + --x]; x > 0 && (O *= 256); )
      C += this[h + --x] * O;
    return O *= 128, C >= O && (C -= Math.pow(2, 8 * d)), C;
  }, s.prototype.readInt8 = function(h, d) {
    return h = h >>> 0, d || X(h, 1, this.length), this[h] & 128 ? (255 - this[h] + 1) * -1 : this[h];
  }, s.prototype.readInt16LE = function(h, d) {
    h = h >>> 0, d || X(h, 2, this.length);
    var b = this[h] | this[h + 1] << 8;
    return b & 32768 ? b | 4294901760 : b;
  }, s.prototype.readInt16BE = function(h, d) {
    h = h >>> 0, d || X(h, 2, this.length);
    var b = this[h + 1] | this[h] << 8;
    return b & 32768 ? b | 4294901760 : b;
  }, s.prototype.readInt32LE = function(h, d) {
    return h = h >>> 0, d || X(h, 4, this.length), this[h] | this[h + 1] << 8 | this[h + 2] << 16 | this[h + 3] << 24;
  }, s.prototype.readInt32BE = function(h, d) {
    return h = h >>> 0, d || X(h, 4, this.length), this[h] << 24 | this[h + 1] << 16 | this[h + 2] << 8 | this[h + 3];
  }, s.prototype.readFloatLE = function(h, d) {
    return h = h >>> 0, d || X(h, 4, this.length), br.read(this, h, !0, 23, 4);
  }, s.prototype.readFloatBE = function(h, d) {
    return h = h >>> 0, d || X(h, 4, this.length), br.read(this, h, !1, 23, 4);
  }, s.prototype.readDoubleLE = function(h, d) {
    return h = h >>> 0, d || X(h, 8, this.length), br.read(this, h, !0, 52, 8);
  }, s.prototype.readDoubleBE = function(h, d) {
    return h = h >>> 0, d || X(h, 8, this.length), br.read(this, h, !1, 52, 8);
  };
  function ae(g, h, d, b, x, O) {
    if (!s.isBuffer(g)) throw new TypeError('"buffer" argument must be a Buffer instance');
    if (h > x || h < O) throw new RangeError('"value" argument is out of bounds');
    if (d + b > g.length) throw new RangeError("Index out of range");
  }
  s.prototype.writeUIntLE = function(h, d, b, x) {
    if (h = +h, d = d >>> 0, b = b >>> 0, !x) {
      var O = Math.pow(2, 8 * b) - 1;
      ae(this, h, d, b, O, 0);
    }
    var C = 1, U = 0;
    for (this[d] = h & 255; ++U < b && (C *= 256); )
      this[d + U] = h / C & 255;
    return d + b;
  }, s.prototype.writeUIntBE = function(h, d, b, x) {
    if (h = +h, d = d >>> 0, b = b >>> 0, !x) {
      var O = Math.pow(2, 8 * b) - 1;
      ae(this, h, d, b, O, 0);
    }
    var C = b - 1, U = 1;
    for (this[d + C] = h & 255; --C >= 0 && (U *= 256); )
      this[d + C] = h / U & 255;
    return d + b;
  }, s.prototype.writeUInt8 = function(h, d, b) {
    return h = +h, d = d >>> 0, b || ae(this, h, d, 1, 255, 0), this[d] = h & 255, d + 1;
  }, s.prototype.writeUInt16LE = function(h, d, b) {
    return h = +h, d = d >>> 0, b || ae(this, h, d, 2, 65535, 0), this[d] = h & 255, this[d + 1] = h >>> 8, d + 2;
  }, s.prototype.writeUInt16BE = function(h, d, b) {
    return h = +h, d = d >>> 0, b || ae(this, h, d, 2, 65535, 0), this[d] = h >>> 8, this[d + 1] = h & 255, d + 2;
  }, s.prototype.writeUInt32LE = function(h, d, b) {
    return h = +h, d = d >>> 0, b || ae(this, h, d, 4, 4294967295, 0), this[d + 3] = h >>> 24, this[d + 2] = h >>> 16, this[d + 1] = h >>> 8, this[d] = h & 255, d + 4;
  }, s.prototype.writeUInt32BE = function(h, d, b) {
    return h = +h, d = d >>> 0, b || ae(this, h, d, 4, 4294967295, 0), this[d] = h >>> 24, this[d + 1] = h >>> 16, this[d + 2] = h >>> 8, this[d + 3] = h & 255, d + 4;
  }, s.prototype.writeIntLE = function(h, d, b, x) {
    if (h = +h, d = d >>> 0, !x) {
      var O = Math.pow(2, 8 * b - 1);
      ae(this, h, d, b, O - 1, -O);
    }
    var C = 0, U = 1, Y = 0;
    for (this[d] = h & 255; ++C < b && (U *= 256); )
      h < 0 && Y === 0 && this[d + C - 1] !== 0 && (Y = 1), this[d + C] = (h / U >> 0) - Y & 255;
    return d + b;
  }, s.prototype.writeIntBE = function(h, d, b, x) {
    if (h = +h, d = d >>> 0, !x) {
      var O = Math.pow(2, 8 * b - 1);
      ae(this, h, d, b, O - 1, -O);
    }
    var C = b - 1, U = 1, Y = 0;
    for (this[d + C] = h & 255; --C >= 0 && (U *= 256); )
      h < 0 && Y === 0 && this[d + C + 1] !== 0 && (Y = 1), this[d + C] = (h / U >> 0) - Y & 255;
    return d + b;
  }, s.prototype.writeInt8 = function(h, d, b) {
    return h = +h, d = d >>> 0, b || ae(this, h, d, 1, 127, -128), h < 0 && (h = 255 + h + 1), this[d] = h & 255, d + 1;
  }, s.prototype.writeInt16LE = function(h, d, b) {
    return h = +h, d = d >>> 0, b || ae(this, h, d, 2, 32767, -32768), this[d] = h & 255, this[d + 1] = h >>> 8, d + 2;
  }, s.prototype.writeInt16BE = function(h, d, b) {
    return h = +h, d = d >>> 0, b || ae(this, h, d, 2, 32767, -32768), this[d] = h >>> 8, this[d + 1] = h & 255, d + 2;
  }, s.prototype.writeInt32LE = function(h, d, b) {
    return h = +h, d = d >>> 0, b || ae(this, h, d, 4, 2147483647, -2147483648), this[d] = h & 255, this[d + 1] = h >>> 8, this[d + 2] = h >>> 16, this[d + 3] = h >>> 24, d + 4;
  }, s.prototype.writeInt32BE = function(h, d, b) {
    return h = +h, d = d >>> 0, b || ae(this, h, d, 4, 2147483647, -2147483648), h < 0 && (h = 4294967295 + h + 1), this[d] = h >>> 24, this[d + 1] = h >>> 16, this[d + 2] = h >>> 8, this[d + 3] = h & 255, d + 4;
  };
  function we(g, h, d, b, x, O) {
    if (d + b > g.length) throw new RangeError("Index out of range");
    if (d < 0) throw new RangeError("Index out of range");
  }
  function Ee(g, h, d, b, x) {
    return h = +h, d = d >>> 0, x || we(g, h, d, 4), br.write(g, h, d, b, 23, 4), d + 4;
  }
  s.prototype.writeFloatLE = function(h, d, b) {
    return Ee(this, h, d, !0, b);
  }, s.prototype.writeFloatBE = function(h, d, b) {
    return Ee(this, h, d, !1, b);
  };
  function Le(g, h, d, b, x) {
    return h = +h, d = d >>> 0, x || we(g, h, d, 8), br.write(g, h, d, b, 52, 8), d + 8;
  }
  s.prototype.writeDoubleLE = function(h, d, b) {
    return Le(this, h, d, !0, b);
  }, s.prototype.writeDoubleBE = function(h, d, b) {
    return Le(this, h, d, !1, b);
  }, s.prototype.copy = function(h, d, b, x) {
    if (!s.isBuffer(h)) throw new TypeError("argument should be a Buffer");
    if (b || (b = 0), !x && x !== 0 && (x = this.length), d >= h.length && (d = h.length), d || (d = 0), x > 0 && x < b && (x = b), x === b || h.length === 0 || this.length === 0) return 0;
    if (d < 0)
      throw new RangeError("targetStart out of bounds");
    if (b < 0 || b >= this.length) throw new RangeError("Index out of range");
    if (x < 0) throw new RangeError("sourceEnd out of bounds");
    x > this.length && (x = this.length), h.length - d < x - b && (x = h.length - d + b);
    var O = x - b;
    if (this === h && typeof Uint8Array.prototype.copyWithin == "function")
      this.copyWithin(d, b, x);
    else if (this === h && b < d && d < x)
      for (var C = O - 1; C >= 0; --C)
        h[C + d] = this[C + b];
    else
      Uint8Array.prototype.set.call(h, this.subarray(b, x), d);
    return O;
  }, s.prototype.fill = function(h, d, b, x) {
    if (typeof h == "string") {
      if (typeof d == "string" ? (x = d, d = 0, b = this.length) : typeof b == "string" && (x = b, b = this.length), x !== void 0 && typeof x != "string")
        throw new TypeError("encoding must be a string");
      if (typeof x == "string" && !s.isEncoding(x))
        throw new TypeError("Unknown encoding: " + x);
      if (h.length === 1) {
        var O = h.charCodeAt(0);
        (x === "utf8" && O < 128 || x === "latin1") && (h = O);
      }
    } else typeof h == "number" ? h = h & 255 : typeof h == "boolean" && (h = Number(h));
    if (d < 0 || this.length < d || this.length < b)
      throw new RangeError("Out of range index");
    if (b <= d)
      return this;
    d = d >>> 0, b = b === void 0 ? this.length : b >>> 0, h || (h = 0);
    var C;
    if (typeof h == "number")
      for (C = d; C < b; ++C)
        this[C] = h;
    else {
      var U = s.isBuffer(h) ? h : s.from(h, x), Y = U.length;
      if (Y === 0)
        throw new TypeError('The value "' + h + '" is invalid for argument "value"');
      for (C = 0; C < b - d; ++C)
        this[C + d] = U[C % Y];
    }
    return this;
  };
  var ke = /[^+/0-9A-Za-z-_]/g;
  function ye(g) {
    if (g = g.split("=")[0], g = g.trim().replace(ke, ""), g.length < 2) return "";
    for (; g.length % 4 !== 0; )
      g = g + "=";
    return g;
  }
  function Oe(g, h) {
    h = h || 1 / 0;
    for (var d, b = g.length, x = null, O = [], C = 0; C < b; ++C) {
      if (d = g.charCodeAt(C), d > 55295 && d < 57344) {
        if (!x) {
          if (d > 56319) {
            (h -= 3) > -1 && O.push(239, 191, 189);
            continue;
          } else if (C + 1 === b) {
            (h -= 3) > -1 && O.push(239, 191, 189);
            continue;
          }
          x = d;
          continue;
        }
        if (d < 56320) {
          (h -= 3) > -1 && O.push(239, 191, 189), x = d;
          continue;
        }
        d = (x - 55296 << 10 | d - 56320) + 65536;
      } else x && (h -= 3) > -1 && O.push(239, 191, 189);
      if (x = null, d < 128) {
        if ((h -= 1) < 0) break;
        O.push(d);
      } else if (d < 2048) {
        if ((h -= 2) < 0) break;
        O.push(d >> 6 | 192, d & 63 | 128);
      } else if (d < 65536) {
        if ((h -= 3) < 0) break;
        O.push(d >> 12 | 224, d >> 6 & 63 | 128, d & 63 | 128);
      } else if (d < 1114112) {
        if ((h -= 4) < 0) break;
        O.push(d >> 18 | 240, d >> 12 & 63 | 128, d >> 6 & 63 | 128, d & 63 | 128);
      } else
        throw new Error("Invalid code point");
    }
    return O;
  }
  function Ce(g) {
    for (var h = [], d = 0; d < g.length; ++d)
      h.push(g.charCodeAt(d) & 255);
    return h;
  }
  function _(g, h) {
    for (var d, b, x, O = [], C = 0; C < g.length && !((h -= 2) < 0); ++C)
      d = g.charCodeAt(C), b = d >> 8, x = d % 256, O.push(x), O.push(b);
    return O;
  }
  function V(g) {
    return xi.toByteArray(ye(g));
  }
  function ie(g, h, d, b) {
    for (var x = 0; x < b && !(x + d >= h.length || x >= g.length); ++x)
      h[x + d] = g[x];
    return x;
  }
  function H(g, h) {
    return g instanceof h || g != null && g.constructor != null && g.constructor.name != null && g.constructor.name === h.name;
  }
  function J(g) {
    return g !== g;
  }
  var xe = (function() {
    for (var g = "0123456789abcdef", h = new Array(256), d = 0; d < 16; ++d)
      for (var b = d * 16, x = 0; x < 16; ++x)
        h[b + x] = g[d] + g[x];
    return h;
  })();
}), pe = Xe.Buffer;
Xe.SlowBuffer;
Xe.INSPECT_MAX_BYTES;
Xe.kMaxLength;
var ic;
function zt() {
}
zt.prototype = /* @__PURE__ */ Object.create(null);
function fe() {
  fe.init.call(this);
}
fe.EventEmitter = fe;
fe.usingDomains = !1;
fe.prototype.domain = void 0;
fe.prototype._events = void 0;
fe.prototype._maxListeners = void 0;
fe.defaultMaxListeners = 10;
fe.init = function() {
  this.domain = null, fe.usingDomains && ic.active, (!this._events || this._events === Object.getPrototypeOf(this)._events) && (this._events = new zt(), this._eventsCount = 0), this._maxListeners = this._maxListeners || void 0;
};
fe.prototype.setMaxListeners = function(e) {
  if (typeof e != "number" || e < 0 || isNaN(e)) throw new TypeError('"n" argument must be a positive number');
  return this._maxListeners = e, this;
};
function qu(t) {
  return t._maxListeners === void 0 ? fe.defaultMaxListeners : t._maxListeners;
}
fe.prototype.getMaxListeners = function() {
  return qu(this);
};
function ac(t, e, r) {
  if (e) t.call(r);
  else
    for (var n = t.length, a = hn(t, n), o = 0; o < n; ++o)
      a[o].call(r);
}
function oc(t, e, r, n) {
  if (e) t.call(r, n);
  else
    for (var a = t.length, o = hn(t, a), s = 0; s < a; ++s)
      o[s].call(r, n);
}
function sc(t, e, r, n, a) {
  if (e) t.call(r, n, a);
  else
    for (var o = t.length, s = hn(t, o), u = 0; u < o; ++u)
      s[u].call(r, n, a);
}
function uc(t, e, r, n, a, o) {
  if (e) t.call(r, n, a, o);
  else
    for (var s = t.length, u = hn(t, s), f = 0; f < s; ++f)
      u[f].call(r, n, a, o);
}
function fc(t, e, r, n) {
  if (e) t.apply(r, n);
  else
    for (var a = t.length, o = hn(t, a), s = 0; s < a; ++s)
      o[s].apply(r, n);
}
fe.prototype.emit = function(e) {
  var r, n, a, o, s, u, f, l = e === "error";
  if (u = this._events, u) l = l && u.error == null;
  else if (!l) return !1;
  if (f = this.domain, l) {
    if (r = arguments[1], f)
      r || (r = new Error('Uncaught, unspecified "error" event')), r.domainEmitter = this, r.domain = f, r.domainThrown = !1, f.emit("error", r);
    else {
      if (r instanceof Error)
        throw r;
      var c = new Error('Uncaught, unspecified "error" event. (' + r + ")");
      throw c.context = r, c;
    }
    return !1;
  }
  if (n = u[e], !n) return !1;
  var p = typeof n == "function";
  switch (a = arguments.length, a) {
    // fast cases
    case 1:
      ac(n, p, this);
      break;
    case 2:
      oc(n, p, this, arguments[1]);
      break;
    case 3:
      sc(n, p, this, arguments[1], arguments[2]);
      break;
    case 4:
      uc(n, p, this, arguments[1], arguments[2], arguments[3]);
      break;
    // slower
    default:
      for (o = new Array(a - 1), s = 1; s < a; s++)
        o[s - 1] = arguments[s];
      fc(n, p, this, o);
  }
  return !0;
};
function Hu(t, e, r, n) {
  var a, o, s;
  if (typeof r != "function") throw new TypeError('"listener" argument must be a function');
  if (o = t._events, o ? (o.newListener && (t.emit("newListener", e, r.listener ? r.listener : r), o = t._events), s = o[e]) : (o = t._events = new zt(), t._eventsCount = 0), !s)
    s = o[e] = r, ++t._eventsCount;
  else if (typeof s == "function" ? s = o[e] = n ? [r, s] : [s, r] : n ? s.unshift(r) : s.push(r), !s.warned && (a = qu(t), a && a > 0 && s.length > a)) {
    s.warned = !0;
    var u = new Error("Possible EventEmitter memory leak detected. " + s.length + " " + e + " listeners added. Use emitter.setMaxListeners() to increase limit");
    u.name = "MaxListenersExceededWarning", u.emitter = t, u.type = e, u.count = s.length, lc(u);
  }
  return t;
}
function lc(t) {
  typeof console.warn == "function" ? console.warn(t) : console.log(t);
}
fe.prototype.addListener = function(e, r) {
  return Hu(this, e, r, !1);
};
fe.prototype.on = fe.prototype.addListener;
fe.prototype.prependListener = function(e, r) {
  return Hu(this, e, r, !0);
};
function Wu(t, e, r) {
  var n = !1;
  function a() {
    t.removeListener(e, a), n || (n = !0, r.apply(t, arguments));
  }
  return a.listener = r, a;
}
fe.prototype.once = function(e, r) {
  if (typeof r != "function") throw new TypeError('"listener" argument must be a function');
  return this.on(e, Wu(this, e, r)), this;
};
fe.prototype.prependOnceListener = function(e, r) {
  if (typeof r != "function") throw new TypeError('"listener" argument must be a function');
  return this.prependListener(e, Wu(this, e, r)), this;
};
fe.prototype.removeListener = function(e, r) {
  var n, a, o, s, u;
  if (typeof r != "function") throw new TypeError('"listener" argument must be a function');
  if (a = this._events, !a) return this;
  if (n = a[e], !n) return this;
  if (n === r || n.listener && n.listener === r)
    --this._eventsCount === 0 ? this._events = new zt() : (delete a[e], a.removeListener && this.emit("removeListener", e, n.listener || r));
  else if (typeof n != "function") {
    for (o = -1, s = n.length; s-- > 0; )
      if (n[s] === r || n[s].listener && n[s].listener === r) {
        u = n[s].listener, o = s;
        break;
      }
    if (o < 0) return this;
    if (n.length === 1) {
      if (n[0] = void 0, --this._eventsCount === 0)
        return this._events = new zt(), this;
      delete a[e];
    } else
      cc(n, o);
    a.removeListener && this.emit("removeListener", e, u || r);
  }
  return this;
};
fe.prototype.removeAllListeners = function(e) {
  var r, n;
  if (n = this._events, !n) return this;
  if (!n.removeListener)
    return arguments.length === 0 ? (this._events = new zt(), this._eventsCount = 0) : n[e] && (--this._eventsCount === 0 ? this._events = new zt() : delete n[e]), this;
  if (arguments.length === 0) {
    for (var a = Object.keys(n), o = 0, s; o < a.length; ++o)
      s = a[o], s !== "removeListener" && this.removeAllListeners(s);
    return this.removeAllListeners("removeListener"), this._events = new zt(), this._eventsCount = 0, this;
  }
  if (r = n[e], typeof r == "function")
    this.removeListener(e, r);
  else if (r)
    do
      this.removeListener(e, r[r.length - 1]);
    while (r[0]);
  return this;
};
fe.prototype.listeners = function(e) {
  var r, n, a = this._events;
  return a ? (r = a[e], r ? typeof r == "function" ? n = [r.listener || r] : n = hc(r) : n = []) : n = [], n;
};
fe.listenerCount = function(t, e) {
  return typeof t.listenerCount == "function" ? t.listenerCount(e) : Xu.call(t, e);
};
fe.prototype.listenerCount = Xu;
function Xu(t) {
  var e = this._events;
  if (e) {
    var r = e[t];
    if (typeof r == "function")
      return 1;
    if (r)
      return r.length;
  }
  return 0;
}
fe.prototype.eventNames = function() {
  return this._eventsCount > 0 ? Reflect.ownKeys(this._events) : [];
};
function cc(t, e) {
  for (var r = e, n = r + 1, a = t.length; n < a; r += 1, n += 1)
    t[r] = t[n];
  t.pop();
}
function hn(t, e) {
  for (var r = new Array(e); e--; )
    r[e] = t[e];
  return r;
}
function hc(t) {
  for (var e = new Array(t.length), r = 0; r < e.length; ++r)
    e[r] = t[r].listener || t[r];
  return e;
}
var $n = typeof global < "u" ? global : typeof self < "u" ? self : typeof window < "u" ? window : {};
function Yu() {
  throw new Error("setTimeout has not been defined");
}
function Ku() {
  throw new Error("clearTimeout has not been defined");
}
var kt = Yu, Lt = Ku;
typeof $n.setTimeout == "function" && (kt = setTimeout);
typeof $n.clearTimeout == "function" && (Lt = clearTimeout);
function Zu(t) {
  if (kt === setTimeout)
    return setTimeout(t, 0);
  if ((kt === Yu || !kt) && setTimeout)
    return kt = setTimeout, setTimeout(t, 0);
  try {
    return kt(t, 0);
  } catch {
    try {
      return kt.call(null, t, 0);
    } catch {
      return kt.call(this, t, 0);
    }
  }
}
function pc(t) {
  if (Lt === clearTimeout)
    return clearTimeout(t);
  if ((Lt === Ku || !Lt) && clearTimeout)
    return Lt = clearTimeout, clearTimeout(t);
  try {
    return Lt(t);
  } catch {
    try {
      return Lt.call(null, t);
    } catch {
      return Lt.call(this, t);
    }
  }
}
var Ft = [], Tr = !1, ar, Bn = -1;
function dc() {
  !Tr || !ar || (Tr = !1, ar.length ? Ft = ar.concat(Ft) : Bn = -1, Ft.length && Ju());
}
function Ju() {
  if (!Tr) {
    var t = Zu(dc);
    Tr = !0;
    for (var e = Ft.length; e; ) {
      for (ar = Ft, Ft = []; ++Bn < e; )
        ar && ar[Bn].run();
      Bn = -1, e = Ft.length;
    }
    ar = null, Tr = !1, pc(t);
  }
}
function He(t) {
  var e = new Array(arguments.length - 1);
  if (arguments.length > 1)
    for (var r = 1; r < arguments.length; r++)
      e[r - 1] = arguments[r];
  Ft.push(new Qu(t, e)), Ft.length === 1 && !Tr && Zu(Ju);
}
function Qu(t, e) {
  this.fun = t, this.array = e;
}
Qu.prototype.run = function() {
  this.fun.apply(null, this.array);
};
var vc = "browser", yc = "browser", gc = !0, mc = {}, bc = [], wc = "", Fc = {}, xc = {}, Sc = {};
function dr() {
}
var Ac = dr, Ec = dr, Cc = dr, Ic = dr, Oc = dr, Dc = dr, Tc = dr;
function Pc(t) {
  throw new Error("process.binding is not supported");
}
function Bc() {
  return "/";
}
function kc(t) {
  throw new Error("process.chdir is not supported");
}
function Lc() {
  return 0;
}
var Er = $n.performance || {}, Mc = Er.now || Er.mozNow || Er.msNow || Er.oNow || Er.webkitNow || function() {
  return (/* @__PURE__ */ new Date()).getTime();
};
function Uc(t) {
  var e = Mc.call(Er) * 1e-3, r = Math.floor(e), n = Math.floor(e % 1 * 1e9);
  return t && (r = r - t[0], n = n - t[1], n < 0 && (r--, n += 1e9)), [r, n];
}
var Nc = /* @__PURE__ */ new Date();
function Rc() {
  var t = /* @__PURE__ */ new Date(), e = t - Nc;
  return e / 1e3;
}
var jt = {
  nextTick: He,
  title: vc,
  browser: gc,
  env: mc,
  argv: bc,
  version: wc,
  versions: Fc,
  on: Ac,
  addListener: Ec,
  once: Cc,
  off: Ic,
  removeListener: Oc,
  removeAllListeners: Dc,
  emit: Tc,
  binding: Pc,
  cwd: Bc,
  chdir: kc,
  umask: Lc,
  hrtime: Uc,
  platform: yc,
  release: xc,
  config: Sc,
  uptime: Rc
}, fa;
typeof Object.create == "function" ? fa = function(e, r) {
  e.super_ = r, e.prototype = Object.create(r.prototype, {
    constructor: {
      value: e,
      enumerable: !1,
      writable: !0,
      configurable: !0
    }
  });
} : fa = function(e, r) {
  e.super_ = r;
  var n = function() {
  };
  n.prototype = r.prototype, e.prototype = new n(), e.prototype.constructor = e;
};
var Gr = fa, zc = /%[sdj%]/g;
function jc(t) {
  if (!Ba(t)) {
    for (var e = [], r = 0; r < arguments.length; r++)
      e.push(xt(arguments[r]));
    return e.join(" ");
  }
  for (var r = 1, n = arguments, a = n.length, o = String(t).replace(zc, function(u) {
    if (u === "%%") return "%";
    if (r >= a) return u;
    switch (u) {
      case "%s":
        return String(n[r++]);
      case "%d":
        return Number(n[r++]);
      case "%j":
        try {
          return JSON.stringify(n[r++]);
        } catch {
          return "[Circular]";
        }
      default:
        return u;
    }
  }), s = n[r]; r < a; s = n[++r])
    Pa(s) || !pn(s) ? o += " " + s : o += " " + xt(s);
  return o;
}
function _u(t, e) {
  if (Nt($n.process))
    return function() {
      return _u(t, e).apply(this, arguments);
    };
  if (jt.noDeprecation === !0)
    return t;
  var r = !1;
  function n() {
    if (!r) {
      if (jt.throwDeprecation)
        throw new Error(e);
      jt.traceDeprecation ? console.trace(e) : console.error(e), r = !0;
    }
    return t.apply(this, arguments);
  }
  return n;
}
var bn = {}, Si;
function Vc(t) {
  if (Nt(Si) && (Si = jt.env.NODE_DEBUG || ""), t = t.toUpperCase(), !bn[t])
    if (new RegExp("\\b" + t + "\\b", "i").test(Si)) {
      var e = 0;
      bn[t] = function() {
        var r = jc.apply(null, arguments);
        console.error("%s %d: %s", t, e, r);
      };
    } else
      bn[t] = function() {
      };
  return bn[t];
}
function xt(t, e) {
  var r = {
    seen: [],
    stylize: qc
  };
  return arguments.length >= 3 && (r.depth = arguments[2]), arguments.length >= 4 && (r.colors = arguments[3]), $u(e) ? r.showHidden = e : e && Jc(r, e), Nt(r.showHidden) && (r.showHidden = !1), Nt(r.depth) && (r.depth = 2), Nt(r.colors) && (r.colors = !1), Nt(r.customInspect) && (r.customInspect = !0), r.colors && (r.stylize = Gc), Rn(r, t, r.depth);
}
xt.colors = {
  bold: [1, 22],
  italic: [3, 23],
  underline: [4, 24],
  inverse: [7, 27],
  white: [37, 39],
  grey: [90, 39],
  black: [30, 39],
  blue: [34, 39],
  cyan: [36, 39],
  green: [32, 39],
  magenta: [35, 39],
  red: [31, 39],
  yellow: [33, 39]
};
xt.styles = {
  special: "cyan",
  number: "yellow",
  boolean: "yellow",
  undefined: "grey",
  null: "bold",
  string: "green",
  date: "magenta",
  // "name": intentionally not styling
  regexp: "red"
};
function Gc(t, e) {
  var r = xt.styles[e];
  return r ? "\x1B[" + xt.colors[r][0] + "m" + t + "\x1B[" + xt.colors[r][1] + "m" : t;
}
function qc(t, e) {
  return t;
}
function Hc(t) {
  var e = {};
  return t.forEach(function(r, n) {
    e[r] = !0;
  }), e;
}
function Rn(t, e, r) {
  if (t.customInspect && e && Ii(e.inspect) && // Filter out the util module, it's inspect function is special
  e.inspect !== xt && // Also filter out any prototype objects using the circular check.
  !(e.constructor && e.constructor.prototype === e)) {
    var n = e.inspect(r, t);
    return Ba(n) || (n = Rn(t, n, r)), n;
  }
  var a = Wc(t, e);
  if (a)
    return a;
  var o = Object.keys(e), s = Hc(o);
  if (t.showHidden && (o = Object.getOwnPropertyNames(e)), Ci(e) && (o.indexOf("message") >= 0 || o.indexOf("description") >= 0))
    return Ai(e);
  if (o.length === 0) {
    if (Ii(e)) {
      var u = e.name ? ": " + e.name : "";
      return t.stylize("[Function" + u + "]", "special");
    }
    if (Ei(e))
      return t.stylize(RegExp.prototype.toString.call(e), "regexp");
    if (So(e))
      return t.stylize(Date.prototype.toString.call(e), "date");
    if (Ci(e))
      return Ai(e);
  }
  var f = "", l = !1, c = ["{", "}"];
  if (Kc(e) && (l = !0, c = ["[", "]"]), Ii(e)) {
    var p = e.name ? ": " + e.name : "";
    f = " [Function" + p + "]";
  }
  if (Ei(e) && (f = " " + RegExp.prototype.toString.call(e)), So(e) && (f = " " + Date.prototype.toUTCString.call(e)), Ci(e) && (f = " " + Ai(e)), o.length === 0 && (!l || e.length == 0))
    return c[0] + f + c[1];
  if (r < 0)
    return Ei(e) ? t.stylize(RegExp.prototype.toString.call(e), "regexp") : t.stylize("[Object]", "special");
  t.seen.push(e);
  var y;
  return l ? y = Xc(t, e, r, s, o) : y = o.map(function(v) {
    return la(t, e, r, s, v, l);
  }), t.seen.pop(), Yc(y, f, c);
}
function Wc(t, e) {
  if (Nt(e)) return t.stylize("undefined", "undefined");
  if (Ba(e)) {
    var r = "'" + JSON.stringify(e).replace(/^"|"$/g, "").replace(/'/g, "\\'").replace(/\\"/g, '"') + "'";
    return t.stylize(r, "string");
  }
  if (Zc(e)) return t.stylize("" + e, "number");
  if ($u(e)) return t.stylize("" + e, "boolean");
  if (Pa(e)) return t.stylize("null", "null");
}
function Ai(t) {
  return "[" + Error.prototype.toString.call(t) + "]";
}
function Xc(t, e, r, n, a) {
  for (var o = [], s = 0, u = e.length; s < u; ++s)
    ef(e, String(s)) ? o.push(la(t, e, r, n, String(s), !0)) : o.push("");
  return a.forEach(function(f) {
    f.match(/^\d+$/) || o.push(la(t, e, r, n, f, !0));
  }), o;
}
function la(t, e, r, n, a, o) {
  var s, u, f;
  if (f = Object.getOwnPropertyDescriptor(e, a) || {
    value: e[a]
  }, f.get ? f.set ? u = t.stylize("[Getter/Setter]", "special") : u = t.stylize("[Getter]", "special") : f.set && (u = t.stylize("[Setter]", "special")), ef(n, a) || (s = "[" + a + "]"), u || (t.seen.indexOf(f.value) < 0 ? (Pa(r) ? u = Rn(t, f.value, null) : u = Rn(t, f.value, r - 1), u.indexOf(`
`) > -1 && (o ? u = u.split(`
`).map(function(l) {
    return "  " + l;
  }).join(`
`).substr(2) : u = `
` + u.split(`
`).map(function(l) {
    return "   " + l;
  }).join(`
`))) : u = t.stylize("[Circular]", "special")), Nt(s)) {
    if (o && a.match(/^\d+$/))
      return u;
    s = JSON.stringify("" + a), s.match(/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/) ? (s = s.substr(1, s.length - 2), s = t.stylize(s, "name")) : (s = s.replace(/'/g, "\\'").replace(/\\"/g, '"').replace(/(^"|"$)/g, "'"), s = t.stylize(s, "string"));
  }
  return s + ": " + u;
}
function Yc(t, e, r) {
  var n = t.reduce(function(a, o) {
    return o.indexOf(`
`) >= 0, a + o.replace(/\u001b\[\d\d?m/g, "").length + 1;
  }, 0);
  return n > 60 ? r[0] + (e === "" ? "" : e + `
 `) + " " + t.join(`,
  `) + " " + r[1] : r[0] + e + " " + t.join(", ") + " " + r[1];
}
function Kc(t) {
  return Array.isArray(t);
}
function $u(t) {
  return typeof t == "boolean";
}
function Pa(t) {
  return t === null;
}
function Zc(t) {
  return typeof t == "number";
}
function Ba(t) {
  return typeof t == "string";
}
function Nt(t) {
  return t === void 0;
}
function Ei(t) {
  return pn(t) && ka(t) === "[object RegExp]";
}
function pn(t) {
  return typeof t == "object" && t !== null;
}
function So(t) {
  return pn(t) && ka(t) === "[object Date]";
}
function Ci(t) {
  return pn(t) && (ka(t) === "[object Error]" || t instanceof Error);
}
function Ii(t) {
  return typeof t == "function";
}
function ka(t) {
  return Object.prototype.toString.call(t);
}
function Jc(t, e) {
  if (!e || !pn(e)) return t;
  for (var r = Object.keys(e), n = r.length; n--; )
    t[r[n]] = e[r[n]];
  return t;
}
function ef(t, e) {
  return Object.prototype.hasOwnProperty.call(t, e);
}
var Qc = {
  inspect: xt
};
function vr() {
  this.head = null, this.tail = null, this.length = 0;
}
vr.prototype.push = function(t) {
  var e = {
    data: t,
    next: null
  };
  this.length > 0 ? this.tail.next = e : this.head = e, this.tail = e, ++this.length;
};
vr.prototype.unshift = function(t) {
  var e = {
    data: t,
    next: this.head
  };
  this.length === 0 && (this.tail = e), this.head = e, ++this.length;
};
vr.prototype.shift = function() {
  if (this.length !== 0) {
    var t = this.head.data;
    return this.length === 1 ? this.head = this.tail = null : this.head = this.head.next, --this.length, t;
  }
};
vr.prototype.clear = function() {
  this.head = this.tail = null, this.length = 0;
};
vr.prototype.join = function(t) {
  if (this.length === 0) return "";
  for (var e = this.head, r = "" + e.data; e = e.next; )
    r += t + e.data;
  return r;
};
vr.prototype.concat = function(t) {
  if (this.length === 0) return pe.alloc(0);
  if (this.length === 1) return this.head.data;
  for (var e = pe.allocUnsafe(t >>> 0), r = this.head, n = 0; r; )
    r.data.copy(e, n), n += r.data.length, r = r.next;
  return e;
};
var tf = be(function(t, e) {
  var r = Xe.Buffer, n = r.isEncoding || function(l) {
    switch (l && l.toLowerCase()) {
      case "hex":
      case "utf8":
      case "utf-8":
      case "ascii":
      case "binary":
      case "base64":
      case "ucs2":
      case "ucs-2":
      case "utf16le":
      case "utf-16le":
      case "raw":
        return !0;
      default:
        return !1;
    }
  };
  function a(l) {
    if (l && !n(l))
      throw new Error("Unknown encoding: " + l);
  }
  var o = e.StringDecoder = function(l) {
    switch (this.encoding = (l || "utf8").toLowerCase().replace(/[-_]/, ""), a(l), this.encoding) {
      case "utf8":
        this.surrogateSize = 3;
        break;
      case "ucs2":
      case "utf16le":
        this.surrogateSize = 2, this.detectIncompleteChar = u;
        break;
      case "base64":
        this.surrogateSize = 3, this.detectIncompleteChar = f;
        break;
      default:
        this.write = s;
        return;
    }
    this.charBuffer = new r(6), this.charReceived = 0, this.charLength = 0;
  };
  o.prototype.write = function(l) {
    for (var c = ""; this.charLength; ) {
      var p = l.length >= this.charLength - this.charReceived ? this.charLength - this.charReceived : l.length;
      if (l.copy(this.charBuffer, this.charReceived, 0, p), this.charReceived += p, this.charReceived < this.charLength)
        return "";
      l = l.slice(p, l.length), c = this.charBuffer.slice(0, this.charLength).toString(this.encoding);
      var v = c.charCodeAt(c.length - 1);
      if (v >= 55296 && v <= 56319) {
        this.charLength += this.surrogateSize, c = "";
        continue;
      }
      if (this.charReceived = this.charLength = 0, l.length === 0)
        return c;
      break;
    }
    this.detectIncompleteChar(l);
    var y = l.length;
    this.charLength && (l.copy(this.charBuffer, 0, l.length - this.charReceived, y), y -= this.charReceived), c += l.toString(this.encoding, 0, y);
    var y = c.length - 1, v = c.charCodeAt(y);
    if (v >= 55296 && v <= 56319) {
      var m = this.surrogateSize;
      return this.charLength += m, this.charReceived += m, this.charBuffer.copy(this.charBuffer, m, 0, m), l.copy(this.charBuffer, 0, 0, m), c.substring(0, y);
    }
    return c;
  }, o.prototype.detectIncompleteChar = function(l) {
    for (var c = l.length >= 3 ? 3 : l.length; c > 0; c--) {
      var p = l[l.length - c];
      if (c == 1 && p >> 5 == 6) {
        this.charLength = 2;
        break;
      }
      if (c <= 2 && p >> 4 == 14) {
        this.charLength = 3;
        break;
      }
      if (c <= 3 && p >> 3 == 30) {
        this.charLength = 4;
        break;
      }
    }
    this.charReceived = c;
  }, o.prototype.end = function(l) {
    var c = "";
    if (l && l.length && (c = this.write(l)), this.charReceived) {
      var p = this.charReceived, y = this.charBuffer, v = this.encoding;
      c += y.slice(0, p).toString(v);
    }
    return c;
  };
  function s(l) {
    return l.toString(this.encoding);
  }
  function u(l) {
    this.charReceived = l.length % 2, this.charLength = this.charReceived ? 2 : 0;
  }
  function f(l) {
    this.charReceived = l.length % 3, this.charLength = this.charReceived ? 3 : 0;
  }
}), rf = tf.StringDecoder;
Ae.ReadableState = nf;
var ve = Vc("stream");
Gr(Ae, fe);
function _c(t, e, r) {
  if (typeof t.prependListener == "function")
    return t.prependListener(e, r);
  !t._events || !t._events[e] ? t.on(e, r) : Array.isArray(t._events[e]) ? t._events[e].unshift(r) : t._events[e] = [r, t._events[e]];
}
function $c(t, e) {
  return t.listeners(e).length;
}
function nf(t, e) {
  t = t || {}, this.objectMode = !!t.objectMode, e instanceof $e && (this.objectMode = this.objectMode || !!t.readableObjectMode);
  var r = t.highWaterMark, n = this.objectMode ? 16 : 16 * 1024;
  this.highWaterMark = r || r === 0 ? r : n, this.highWaterMark = ~~this.highWaterMark, this.buffer = new vr(), this.length = 0, this.pipes = null, this.pipesCount = 0, this.flowing = null, this.ended = !1, this.endEmitted = !1, this.reading = !1, this.sync = !0, this.needReadable = !1, this.emittedReadable = !1, this.readableListening = !1, this.resumeScheduled = !1, this.defaultEncoding = t.defaultEncoding || "utf8", this.ranOut = !1, this.awaitDrain = 0, this.readingMore = !1, this.decoder = null, this.encoding = null, t.encoding && (this.decoder = new rf(t.encoding), this.encoding = t.encoding);
}
function Ae(t) {
  if (!(this instanceof Ae)) return new Ae(t);
  this._readableState = new nf(t, this), this.readable = !0, t && typeof t.read == "function" && (this._read = t.read), fe.call(this);
}
Ae.prototype.push = function(t, e) {
  var r = this._readableState;
  return !r.objectMode && typeof t == "string" && (e = e || r.defaultEncoding, e !== r.encoding && (t = pe.from(t, e), e = "")), af(this, r, t, e, !1);
};
Ae.prototype.unshift = function(t) {
  var e = this._readableState;
  return af(this, e, t, "", !0);
};
Ae.prototype.isPaused = function() {
  return this._readableState.flowing === !1;
};
function af(t, e, r, n, a) {
  var o = rh(e, r);
  if (o)
    t.emit("error", o);
  else if (r === null)
    e.reading = !1, nh(t, e);
  else if (e.objectMode || r && r.length > 0)
    if (e.ended && !a) {
      var s = new Error("stream.push() after EOF");
      t.emit("error", s);
    } else if (e.endEmitted && a) {
      var u = new Error("stream.unshift() after end event");
      t.emit("error", u);
    } else {
      var f;
      e.decoder && !a && !n && (r = e.decoder.write(r), f = !e.objectMode && r.length === 0), a || (e.reading = !1), f || (e.flowing && e.length === 0 && !e.sync ? (t.emit("data", r), t.read(0)) : (e.length += e.objectMode ? 1 : r.length, a ? e.buffer.unshift(r) : e.buffer.push(r), e.needReadable && ei(t))), ih(t, e);
    }
  else a || (e.reading = !1);
  return eh(e);
}
function eh(t) {
  return !t.ended && (t.needReadable || t.length < t.highWaterMark || t.length === 0);
}
Ae.prototype.setEncoding = function(t) {
  return this._readableState.decoder = new rf(t), this._readableState.encoding = t, this;
};
var Ao = 8388608;
function th(t) {
  return t >= Ao ? t = Ao : (t--, t |= t >>> 1, t |= t >>> 2, t |= t >>> 4, t |= t >>> 8, t |= t >>> 16, t++), t;
}
function Eo(t, e) {
  return t <= 0 || e.length === 0 && e.ended ? 0 : e.objectMode ? 1 : t !== t ? e.flowing && e.length ? e.buffer.head.data.length : e.length : (t > e.highWaterMark && (e.highWaterMark = th(t)), t <= e.length ? t : e.ended ? e.length : (e.needReadable = !0, 0));
}
Ae.prototype.read = function(t) {
  ve("read", t), t = parseInt(t, 10);
  var e = this._readableState, r = t;
  if (t !== 0 && (e.emittedReadable = !1), t === 0 && e.needReadable && (e.length >= e.highWaterMark || e.ended))
    return ve("read: emitReadable", e.length, e.ended), e.length === 0 && e.ended ? Oi(this) : ei(this), null;
  if (t = Eo(t, e), t === 0 && e.ended)
    return e.length === 0 && Oi(this), null;
  var n = e.needReadable;
  ve("need readable", n), (e.length === 0 || e.length - t < e.highWaterMark) && (n = !0, ve("length less than watermark", n)), e.ended || e.reading ? (n = !1, ve("reading or ended", n)) : n && (ve("do read"), e.reading = !0, e.sync = !0, e.length === 0 && (e.needReadable = !0), this._read(e.highWaterMark), e.sync = !1, e.reading || (t = Eo(r, e)));
  var a;
  return t > 0 ? a = of(t, e) : a = null, a === null ? (e.needReadable = !0, t = 0) : e.length -= t, e.length === 0 && (e.ended || (e.needReadable = !0), r !== t && e.ended && Oi(this)), a !== null && this.emit("data", a), a;
};
function rh(t, e) {
  var r = null;
  return !pe.isBuffer(e) && typeof e != "string" && e !== null && e !== void 0 && !t.objectMode && (r = new TypeError("Invalid non-string/buffer chunk")), r;
}
function nh(t, e) {
  if (!e.ended) {
    if (e.decoder) {
      var r = e.decoder.end();
      r && r.length && (e.buffer.push(r), e.length += e.objectMode ? 1 : r.length);
    }
    e.ended = !0, ei(t);
  }
}
function ei(t) {
  var e = t._readableState;
  e.needReadable = !1, e.emittedReadable || (ve("emitReadable", e.flowing), e.emittedReadable = !0, e.sync ? He(Co, t) : Co(t));
}
function Co(t) {
  ve("emit readable"), t.emit("readable"), La(t);
}
function ih(t, e) {
  e.readingMore || (e.readingMore = !0, He(ah, t, e));
}
function ah(t, e) {
  for (var r = e.length; !e.reading && !e.flowing && !e.ended && e.length < e.highWaterMark && (ve("maybeReadMore read 0"), t.read(0), r !== e.length); )
    r = e.length;
  e.readingMore = !1;
}
Ae.prototype._read = function(t) {
  this.emit("error", new Error("not implemented"));
};
Ae.prototype.pipe = function(t, e) {
  var r = this, n = this._readableState;
  switch (n.pipesCount) {
    case 0:
      n.pipes = t;
      break;
    case 1:
      n.pipes = [n.pipes, t];
      break;
    default:
      n.pipes.push(t);
      break;
  }
  n.pipesCount += 1, ve("pipe count=%d opts=%j", n.pipesCount, e);
  var a = !e || e.end !== !1, o = a ? u : c;
  n.endEmitted ? He(o) : r.once("end", o), t.on("unpipe", s);
  function s(S) {
    ve("onunpipe"), S === r && c();
  }
  function u() {
    ve("onend"), t.end();
  }
  var f = oh(r);
  t.on("drain", f);
  var l = !1;
  function c() {
    ve("cleanup"), t.removeListener("close", m), t.removeListener("finish", w), t.removeListener("drain", f), t.removeListener("error", v), t.removeListener("unpipe", s), r.removeListener("end", u), r.removeListener("end", c), r.removeListener("data", y), l = !0, n.awaitDrain && (!t._writableState || t._writableState.needDrain) && f();
  }
  var p = !1;
  r.on("data", y);
  function y(S) {
    ve("ondata"), p = !1;
    var I = t.write(S);
    I === !1 && !p && ((n.pipesCount === 1 && n.pipes === t || n.pipesCount > 1 && sf(n.pipes, t) !== -1) && !l && (ve("false write response, pause", r._readableState.awaitDrain), r._readableState.awaitDrain++, p = !0), r.pause());
  }
  function v(S) {
    ve("onerror", S), F(), t.removeListener("error", v), $c(t, "error") === 0 && t.emit("error", S);
  }
  _c(t, "error", v);
  function m() {
    t.removeListener("finish", w), F();
  }
  t.once("close", m);
  function w() {
    ve("onfinish"), t.removeListener("close", m), F();
  }
  t.once("finish", w);
  function F() {
    ve("unpipe"), r.unpipe(t);
  }
  return t.emit("pipe", r), n.flowing || (ve("pipe resume"), r.resume()), t;
};
function oh(t) {
  return function() {
    var e = t._readableState;
    ve("pipeOnDrain", e.awaitDrain), e.awaitDrain && e.awaitDrain--, e.awaitDrain === 0 && t.listeners("data").length && (e.flowing = !0, La(t));
  };
}
Ae.prototype.unpipe = function(t) {
  var e = this._readableState;
  if (e.pipesCount === 0) return this;
  if (e.pipesCount === 1)
    return t && t !== e.pipes ? this : (t || (t = e.pipes), e.pipes = null, e.pipesCount = 0, e.flowing = !1, t && t.emit("unpipe", this), this);
  if (!t) {
    var r = e.pipes, n = e.pipesCount;
    e.pipes = null, e.pipesCount = 0, e.flowing = !1;
    for (var a = 0; a < n; a++)
      r[a].emit("unpipe", this);
    return this;
  }
  var o = sf(e.pipes, t);
  return o === -1 ? this : (e.pipes.splice(o, 1), e.pipesCount -= 1, e.pipesCount === 1 && (e.pipes = e.pipes[0]), t.emit("unpipe", this), this);
};
Ae.prototype.on = function(t, e) {
  var r = fe.prototype.on.call(this, t, e);
  if (t === "data")
    this._readableState.flowing !== !1 && this.resume();
  else if (t === "readable") {
    var n = this._readableState;
    !n.endEmitted && !n.readableListening && (n.readableListening = n.needReadable = !0, n.emittedReadable = !1, n.reading ? n.length && ei(this) : He(sh, this));
  }
  return r;
};
Ae.prototype.addListener = Ae.prototype.on;
function sh(t) {
  ve("readable nexttick read 0"), t.read(0);
}
Ae.prototype.resume = function() {
  var t = this._readableState;
  return t.flowing || (ve("resume"), t.flowing = !0, uh(this, t)), this;
};
function uh(t, e) {
  e.resumeScheduled || (e.resumeScheduled = !0, He(fh, t, e));
}
function fh(t, e) {
  e.reading || (ve("resume read 0"), t.read(0)), e.resumeScheduled = !1, e.awaitDrain = 0, t.emit("resume"), La(t), e.flowing && !e.reading && t.read(0);
}
Ae.prototype.pause = function() {
  return ve("call pause flowing=%j", this._readableState.flowing), this._readableState.flowing !== !1 && (ve("pause"), this._readableState.flowing = !1, this.emit("pause")), this;
};
function La(t) {
  var e = t._readableState;
  for (ve("flow", e.flowing); e.flowing && t.read() !== null; )
    ;
}
Ae.prototype.wrap = function(t) {
  var e = this._readableState, r = !1, n = this;
  t.on("end", function() {
    if (ve("wrapped end"), e.decoder && !e.ended) {
      var s = e.decoder.end();
      s && s.length && n.push(s);
    }
    n.push(null);
  }), t.on("data", function(s) {
    if (ve("wrapped data"), e.decoder && (s = e.decoder.write(s)), !(e.objectMode && s == null) && !(!e.objectMode && (!s || !s.length))) {
      var u = n.push(s);
      u || (r = !0, t.pause());
    }
  });
  for (var a in t)
    this[a] === void 0 && typeof t[a] == "function" && (this[a] = /* @__PURE__ */ (function(s) {
      return function() {
        return t[s].apply(t, arguments);
      };
    })(a));
  var o = ["error", "close", "destroy", "pause", "resume"];
  return dh(o, function(s) {
    t.on(s, n.emit.bind(n, s));
  }), n._read = function(s) {
    ve("wrapped _read", s), r && (r = !1, t.resume());
  }, n;
};
Ae._fromList = of;
function of(t, e) {
  if (e.length === 0) return null;
  var r;
  return e.objectMode ? r = e.buffer.shift() : !t || t >= e.length ? (e.decoder ? r = e.buffer.join("") : e.buffer.length === 1 ? r = e.buffer.head.data : r = e.buffer.concat(e.length), e.buffer.clear()) : r = lh(t, e.buffer, e.decoder), r;
}
function lh(t, e, r) {
  var n;
  return t < e.head.data.length ? (n = e.head.data.slice(0, t), e.head.data = e.head.data.slice(t)) : t === e.head.data.length ? n = e.shift() : n = r ? ch(t, e) : hh(t, e), n;
}
function ch(t, e) {
  var r = e.head, n = 1, a = r.data;
  for (t -= a.length; r = r.next; ) {
    var o = r.data, s = t > o.length ? o.length : t;
    if (s === o.length ? a += o : a += o.slice(0, t), t -= s, t === 0) {
      s === o.length ? (++n, r.next ? e.head = r.next : e.head = e.tail = null) : (e.head = r, r.data = o.slice(s));
      break;
    }
    ++n;
  }
  return e.length -= n, a;
}
function hh(t, e) {
  var r = pe.allocUnsafe(t), n = e.head, a = 1;
  for (n.data.copy(r), t -= n.data.length; n = n.next; ) {
    var o = n.data, s = t > o.length ? o.length : t;
    if (o.copy(r, r.length - t, 0, s), t -= s, t === 0) {
      s === o.length ? (++a, n.next ? e.head = n.next : e.head = e.tail = null) : (e.head = n, n.data = o.slice(s));
      break;
    }
    ++a;
  }
  return e.length -= a, r;
}
function Oi(t) {
  var e = t._readableState;
  if (e.length > 0) throw new Error('"endReadable()" called on non-empty stream');
  e.endEmitted || (e.ended = !0, He(ph, e, t));
}
function ph(t, e) {
  !t.endEmitted && t.length === 0 && (t.endEmitted = !0, e.readable = !1, e.emit("end"));
}
function dh(t, e) {
  for (var r = 0, n = t.length; r < n; r++)
    e(t[r], r);
}
function sf(t, e) {
  for (var r = 0, n = t.length; r < n; r++)
    if (t[r] === e) return r;
  return -1;
}
Re.WritableState = Ma;
Gr(Re, fe);
function vh() {
}
function yh(t, e, r) {
  this.chunk = t, this.encoding = e, this.callback = r, this.next = null;
}
function Ma(t, e) {
  Object.defineProperty(this, "buffer", {
    get: _u(function() {
      return this.getBuffer();
    }, "_writableState.buffer is deprecated. Use _writableState.getBuffer instead.")
  }), t = t || {}, this.objectMode = !!t.objectMode, e instanceof $e && (this.objectMode = this.objectMode || !!t.writableObjectMode);
  var r = t.highWaterMark, n = this.objectMode ? 16 : 16 * 1024;
  this.highWaterMark = r || r === 0 ? r : n, this.highWaterMark = ~~this.highWaterMark, this.needDrain = !1, this.ending = !1, this.ended = !1, this.finished = !1;
  var a = t.decodeStrings === !1;
  this.decodeStrings = !a, this.defaultEncoding = t.defaultEncoding || "utf8", this.length = 0, this.writing = !1, this.corked = 0, this.sync = !0, this.bufferProcessing = !1, this.onwrite = function(o) {
    Sh(e, o);
  }, this.writecb = null, this.writelen = 0, this.bufferedRequest = null, this.lastBufferedRequest = null, this.pendingcb = 0, this.prefinished = !1, this.errorEmitted = !1, this.bufferedRequestCount = 0, this.corkedRequestsFree = new cf(this);
}
Ma.prototype.getBuffer = function() {
  for (var e = this.bufferedRequest, r = []; e; )
    r.push(e), e = e.next;
  return r;
};
function Re(t) {
  if (!(this instanceof Re) && !(this instanceof $e)) return new Re(t);
  this._writableState = new Ma(t, this), this.writable = !0, t && (typeof t.write == "function" && (this._write = t.write), typeof t.writev == "function" && (this._writev = t.writev)), fe.call(this);
}
Re.prototype.pipe = function() {
  this.emit("error", new Error("Cannot pipe, not readable"));
};
function gh(t, e) {
  var r = new Error("write after end");
  t.emit("error", r), He(e, r);
}
function mh(t, e, r, n) {
  var a = !0, o = !1;
  return r === null ? o = new TypeError("May not write null values to stream") : !pe.isBuffer(r) && typeof r != "string" && r !== void 0 && !e.objectMode && (o = new TypeError("Invalid non-string/buffer chunk")), o && (t.emit("error", o), He(n, o), a = !1), a;
}
Re.prototype.write = function(t, e, r) {
  var n = this._writableState, a = !1;
  return typeof e == "function" && (r = e, e = null), pe.isBuffer(t) ? e = "buffer" : e || (e = n.defaultEncoding), typeof r != "function" && (r = vh), n.ended ? gh(this, r) : mh(this, n, t, r) && (n.pendingcb++, a = wh(this, n, t, e, r)), a;
};
Re.prototype.cork = function() {
  var t = this._writableState;
  t.corked++;
};
Re.prototype.uncork = function() {
  var t = this._writableState;
  t.corked && (t.corked--, !t.writing && !t.corked && !t.finished && !t.bufferProcessing && t.bufferedRequest && uf(this, t));
};
Re.prototype.setDefaultEncoding = function(e) {
  if (typeof e == "string" && (e = e.toLowerCase()), !(["hex", "utf8", "utf-8", "ascii", "binary", "base64", "ucs2", "ucs-2", "utf16le", "utf-16le", "raw"].indexOf((e + "").toLowerCase()) > -1)) throw new TypeError("Unknown encoding: " + e);
  return this._writableState.defaultEncoding = e, this;
};
function bh(t, e, r) {
  return !t.objectMode && t.decodeStrings !== !1 && typeof e == "string" && (e = pe.from(e, r)), e;
}
function wh(t, e, r, n, a) {
  r = bh(e, r, n), pe.isBuffer(r) && (n = "buffer");
  var o = e.objectMode ? 1 : r.length;
  e.length += o;
  var s = e.length < e.highWaterMark;
  if (s || (e.needDrain = !0), e.writing || e.corked) {
    var u = e.lastBufferedRequest;
    e.lastBufferedRequest = new yh(r, n, a), u ? u.next = e.lastBufferedRequest : e.bufferedRequest = e.lastBufferedRequest, e.bufferedRequestCount += 1;
  } else
    ca(t, e, !1, o, r, n, a);
  return s;
}
function ca(t, e, r, n, a, o, s) {
  e.writelen = n, e.writecb = s, e.writing = !0, e.sync = !0, r ? t._writev(a, e.onwrite) : t._write(a, o, e.onwrite), e.sync = !1;
}
function Fh(t, e, r, n, a) {
  --e.pendingcb, r ? He(a, n) : a(n), t._writableState.errorEmitted = !0, t.emit("error", n);
}
function xh(t) {
  t.writing = !1, t.writecb = null, t.length -= t.writelen, t.writelen = 0;
}
function Sh(t, e) {
  var r = t._writableState, n = r.sync, a = r.writecb;
  if (xh(r), e) Fh(t, r, n, e, a);
  else {
    var o = ff(r);
    !o && !r.corked && !r.bufferProcessing && r.bufferedRequest && uf(t, r), n ? He(Io, t, r, o, a) : Io(t, r, o, a);
  }
}
function Io(t, e, r, n) {
  r || Ah(t, e), e.pendingcb--, n(), lf(t, e);
}
function Ah(t, e) {
  e.length === 0 && e.needDrain && (e.needDrain = !1, t.emit("drain"));
}
function uf(t, e) {
  e.bufferProcessing = !0;
  var r = e.bufferedRequest;
  if (t._writev && r && r.next) {
    var n = e.bufferedRequestCount, a = new Array(n), o = e.corkedRequestsFree;
    o.entry = r;
    for (var s = 0; r; )
      a[s] = r, r = r.next, s += 1;
    ca(t, e, !0, e.length, a, "", o.finish), e.pendingcb++, e.lastBufferedRequest = null, o.next ? (e.corkedRequestsFree = o.next, o.next = null) : e.corkedRequestsFree = new cf(e);
  } else {
    for (; r; ) {
      var u = r.chunk, f = r.encoding, l = r.callback, c = e.objectMode ? 1 : u.length;
      if (ca(t, e, !1, c, u, f, l), r = r.next, e.writing)
        break;
    }
    r === null && (e.lastBufferedRequest = null);
  }
  e.bufferedRequestCount = 0, e.bufferedRequest = r, e.bufferProcessing = !1;
}
Re.prototype._write = function(t, e, r) {
  r(new Error("not implemented"));
};
Re.prototype._writev = null;
Re.prototype.end = function(t, e, r) {
  var n = this._writableState;
  typeof t == "function" ? (r = t, t = null, e = null) : typeof e == "function" && (r = e, e = null), t != null && this.write(t, e), n.corked && (n.corked = 1, this.uncork()), !n.ending && !n.finished && Eh(this, n, r);
};
function ff(t) {
  return t.ending && t.length === 0 && t.bufferedRequest === null && !t.finished && !t.writing;
}
function Oo(t, e) {
  e.prefinished || (e.prefinished = !0, t.emit("prefinish"));
}
function lf(t, e) {
  var r = ff(e);
  return r && (e.pendingcb === 0 ? (Oo(t, e), e.finished = !0, t.emit("finish")) : Oo(t, e)), r;
}
function Eh(t, e, r) {
  e.ending = !0, lf(t, e), r && (e.finished ? He(r) : t.once("finish", r)), e.ended = !0, t.writable = !1;
}
function cf(t) {
  var e = this;
  this.next = null, this.entry = null, this.finish = function(r) {
    var n = e.entry;
    for (e.entry = null; n; ) {
      var a = n.callback;
      t.pendingcb--, a(r), n = n.next;
    }
    t.corkedRequestsFree ? t.corkedRequestsFree.next = e : t.corkedRequestsFree = e;
  };
}
Gr($e, Ae);
var Do = Object.keys(Re.prototype);
for (var Di = 0; Di < Do.length; Di++) {
  var Ti = Do[Di];
  $e.prototype[Ti] || ($e.prototype[Ti] = Re.prototype[Ti]);
}
function $e(t) {
  if (!(this instanceof $e)) return new $e(t);
  Ae.call(this, t), Re.call(this, t), t && t.readable === !1 && (this.readable = !1), t && t.writable === !1 && (this.writable = !1), this.allowHalfOpen = !0, t && t.allowHalfOpen === !1 && (this.allowHalfOpen = !1), this.once("end", Ch);
}
function Ch() {
  this.allowHalfOpen || this._writableState.ended || He(Ih, this);
}
function Ih(t) {
  t.end();
}
Gr(dt, $e);
function Oh(t) {
  this.afterTransform = function(e, r) {
    return Dh(t, e, r);
  }, this.needTransform = !1, this.transforming = !1, this.writecb = null, this.writechunk = null, this.writeencoding = null;
}
function Dh(t, e, r) {
  var n = t._transformState;
  n.transforming = !1;
  var a = n.writecb;
  if (!a) return t.emit("error", new Error("no writecb in Transform class"));
  n.writechunk = null, n.writecb = null, r != null && t.push(r), a(e);
  var o = t._readableState;
  o.reading = !1, (o.needReadable || o.length < o.highWaterMark) && t._read(o.highWaterMark);
}
function dt(t) {
  if (!(this instanceof dt)) return new dt(t);
  $e.call(this, t), this._transformState = new Oh(this);
  var e = this;
  this._readableState.needReadable = !0, this._readableState.sync = !1, t && (typeof t.transform == "function" && (this._transform = t.transform), typeof t.flush == "function" && (this._flush = t.flush)), this.once("prefinish", function() {
    typeof this._flush == "function" ? this._flush(function(r) {
      To(e, r);
    }) : To(e);
  });
}
dt.prototype.push = function(t, e) {
  return this._transformState.needTransform = !1, $e.prototype.push.call(this, t, e);
};
dt.prototype._transform = function(t, e, r) {
  throw new Error("Not implemented");
};
dt.prototype._write = function(t, e, r) {
  var n = this._transformState;
  if (n.writecb = r, n.writechunk = t, n.writeencoding = e, !n.transforming) {
    var a = this._readableState;
    (n.needTransform || a.needReadable || a.length < a.highWaterMark) && this._read(a.highWaterMark);
  }
};
dt.prototype._read = function(t) {
  var e = this._transformState;
  e.writechunk !== null && e.writecb && !e.transforming ? (e.transforming = !0, this._transform(e.writechunk, e.writeencoding, e.afterTransform)) : e.needTransform = !0;
};
function To(t, e) {
  if (e) return t.emit("error", e);
  var r = t._writableState, n = t._transformState;
  if (r.length) throw new Error("Calling transform done when ws.length != 0");
  if (n.transforming) throw new Error("Calling transform done when still transforming");
  return t.push(null);
}
Gr(nn, dt);
function nn(t) {
  if (!(this instanceof nn)) return new nn(t);
  dt.call(this, t);
}
nn.prototype._transform = function(t, e, r) {
  r(null, t);
};
Gr(Ye, fe);
Ye.Readable = Ae;
Ye.Writable = Re;
Ye.Duplex = $e;
Ye.Transform = dt;
Ye.PassThrough = nn;
Ye.Stream = Ye;
function Ye() {
  fe.call(this);
}
Ye.prototype.pipe = function(t, e) {
  var r = this;
  function n(c) {
    t.writable && t.write(c) === !1 && r.pause && r.pause();
  }
  r.on("data", n);
  function a() {
    r.readable && r.resume && r.resume();
  }
  t.on("drain", a), !t._isStdio && (!e || e.end !== !1) && (r.on("end", s), r.on("close", u));
  var o = !1;
  function s() {
    o || (o = !0, t.end());
  }
  function u() {
    o || (o = !0, typeof t.destroy == "function" && t.destroy());
  }
  function f(c) {
    if (l(), fe.listenerCount(this, "error") === 0)
      throw c;
  }
  r.on("error", f), t.on("error", f);
  function l() {
    r.removeListener("data", n), t.removeListener("drain", a), r.removeListener("end", s), r.removeListener("close", u), r.removeListener("error", f), t.removeListener("error", f), r.removeListener("end", l), r.removeListener("close", l), t.removeListener("close", l);
  }
  return r.on("end", l), r.on("close", l), t.on("close", l), t.emit("pipe", r), t;
};
var Pr = Xe.Buffer, Je = {}, Qe;
for (Qe in Xe)
  Xe.hasOwnProperty(Qe) && (Qe === "SlowBuffer" || Qe === "Buffer" || (Je[Qe] = Xe[Qe]));
var Br = Je.Buffer = {};
for (Qe in Pr)
  Pr.hasOwnProperty(Qe) && (Qe === "allocUnsafe" || Qe === "allocUnsafeSlow" || (Br[Qe] = Pr[Qe]));
Je.Buffer.prototype = Pr.prototype;
(!Br.from || Br.from === Uint8Array.from) && (Br.from = function(t, e, r) {
  if (typeof t == "number")
    throw new TypeError('The "value" argument must not be of type number. Received type ' + typeof t);
  if (t && typeof t.length > "u")
    throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof t);
  return Pr(t, e, r);
});
Br.alloc || (Br.alloc = function(t, e, r) {
  if (typeof t != "number")
    throw new TypeError('The "size" argument must be of type number. Received type ' + typeof t);
  if (t < 0 || t >= 2 * (1 << 30))
    throw new RangeError('The value "' + t + '" is invalid for option "size"');
  var n = Pr(t);
  return !e || e.length === 0 ? n.fill(0) : typeof r == "string" ? n.fill(e, r) : n.fill(e), n;
});
if (!Je.kStringMaxLength)
  try {
    Je.kStringMaxLength = jt.binding("buffer").kStringMaxLength;
  } catch {
  }
Je.constants || (Je.constants = {
  MAX_LENGTH: Je.kMaxLength
}, Je.kStringMaxLength && (Je.constants.MAX_STRING_LENGTH = Je.kStringMaxLength));
var qr = Je, hf = "\uFEFF", Th = Ua;
function Ua(t, e) {
  this.encoder = t, this.addBOM = !0;
}
Ua.prototype.write = function(t) {
  return this.addBOM && (t = hf + t, this.addBOM = !1), this.encoder.write(t);
};
Ua.prototype.end = function() {
  return this.encoder.end();
};
var Ph = Na;
function Na(t, e) {
  this.decoder = t, this.pass = !1, this.options = e || {};
}
Na.prototype.write = function(t) {
  var e = this.decoder.write(t);
  return this.pass || !e || (e[0] === hf && (e = e.slice(1), typeof this.options.stripBOM == "function" && this.options.stripBOM()), this.pass = !0), e;
};
Na.prototype.end = function() {
  return this.decoder.end();
};
var Po = {
  PrependBOM: Th,
  StripBOM: Ph
}, dn = qr.Buffer, Bh = {
  // Encodings
  utf8: {
    type: "_internal",
    bomAware: !0
  },
  cesu8: {
    type: "_internal",
    bomAware: !0
  },
  unicode11utf8: "utf8",
  ucs2: {
    type: "_internal",
    bomAware: !0
  },
  utf16le: "ucs2",
  binary: {
    type: "_internal"
  },
  base64: {
    type: "_internal"
  },
  hex: {
    type: "_internal"
  },
  // Codec.
  _internal: Ra
};
function Ra(t, e) {
  this.enc = t.encodingName, this.bomAware = t.bomAware, this.enc === "base64" ? this.encoder = ja : this.enc === "cesu8" && (this.enc = "utf8", this.encoder = Va, dn.from("eda0bdedb2a9", "hex").toString() !== "💩" && (this.decoder = Ga, this.defaultCharUnicode = e.defaultCharUnicode));
}
Ra.prototype.encoder = za;
Ra.prototype.decoder = pf;
var zn = tf.StringDecoder;
zn.prototype.end || (zn.prototype.end = function() {
});
function pf(t, e) {
  zn.call(this, e.enc);
}
pf.prototype = zn.prototype;
function za(t, e) {
  this.enc = e.enc;
}
za.prototype.write = function(t) {
  return dn.from(t, this.enc);
};
za.prototype.end = function() {
};
function ja(t, e) {
  this.prevStr = "";
}
ja.prototype.write = function(t) {
  t = this.prevStr + t;
  var e = t.length - t.length % 4;
  return this.prevStr = t.slice(e), t = t.slice(0, e), dn.from(t, "base64");
};
ja.prototype.end = function() {
  return dn.from(this.prevStr, "base64");
};
function Va(t, e) {
}
Va.prototype.write = function(t) {
  for (var e = dn.alloc(t.length * 3), r = 0, n = 0; n < t.length; n++) {
    var a = t.charCodeAt(n);
    a < 128 ? e[r++] = a : a < 2048 ? (e[r++] = 192 + (a >>> 6), e[r++] = 128 + (a & 63)) : (e[r++] = 224 + (a >>> 12), e[r++] = 128 + (a >>> 6 & 63), e[r++] = 128 + (a & 63));
  }
  return e.slice(0, r);
};
Va.prototype.end = function() {
};
function Ga(t, e) {
  this.acc = 0, this.contBytes = 0, this.accBytes = 0, this.defaultCharUnicode = e.defaultCharUnicode;
}
Ga.prototype.write = function(t) {
  for (var e = this.acc, r = this.contBytes, n = this.accBytes, a = "", o = 0; o < t.length; o++) {
    var s = t[o];
    (s & 192) !== 128 ? (r > 0 && (a += this.defaultCharUnicode, r = 0), s < 128 ? a += String.fromCharCode(s) : s < 224 ? (e = s & 31, r = 1, n = 1) : s < 240 ? (e = s & 15, r = 2, n = 1) : a += this.defaultCharUnicode) : r > 0 ? (e = e << 6 | s & 63, r--, n++, r === 0 && (n === 2 && e < 128 && e > 0 ? a += this.defaultCharUnicode : n === 3 && e < 2048 ? a += this.defaultCharUnicode : a += String.fromCharCode(e))) : a += this.defaultCharUnicode;
  }
  return this.acc = e, this.contBytes = r, this.accBytes = n, a;
};
Ga.prototype.end = function() {
  var t = 0;
  return this.contBytes > 0 && (t += this.defaultCharUnicode), t;
};
var ti = qr.Buffer, kh = ri;
function ri() {
}
ri.prototype.encoder = qa;
ri.prototype.decoder = Ha;
ri.prototype.bomAware = !0;
function qa() {
}
qa.prototype.write = function(t) {
  for (var e = ti.from(t, "ucs2"), r = 0; r < e.length; r += 2) {
    var n = e[r];
    e[r] = e[r + 1], e[r + 1] = n;
  }
  return e;
};
qa.prototype.end = function() {
};
function Ha() {
  this.overflowByte = -1;
}
Ha.prototype.write = function(t) {
  if (t.length == 0) return "";
  var e = ti.alloc(t.length + 1), r = 0, n = 0;
  for (this.overflowByte !== -1 && (e[0] = t[0], e[1] = this.overflowByte, r = 1, n = 2); r < t.length - 1; r += 2, n += 2)
    e[n] = t[r + 1], e[n + 1] = t[r];
  return this.overflowByte = r == t.length - 1 ? t[t.length - 1] : -1, e.slice(0, n).toString("ucs2");
};
Ha.prototype.end = function() {
};
var Lh = Wa;
function Wa(t, e) {
  this.iconv = e;
}
Wa.prototype.encoder = Xa;
Wa.prototype.decoder = Ya;
function Xa(t, e) {
  t = t || {}, t.addBOM === void 0 && (t.addBOM = !0), this.encoder = e.iconv.getEncoder("utf-16le", t);
}
Xa.prototype.write = function(t) {
  return this.encoder.write(t);
};
Xa.prototype.end = function() {
  return this.encoder.end();
};
function Ya(t, e) {
  this.decoder = null, this.initialBytes = [], this.initialBytesLen = 0, this.options = t || {}, this.iconv = e.iconv;
}
Ya.prototype.write = function(t) {
  if (!this.decoder) {
    if (this.initialBytes.push(t), this.initialBytesLen += t.length, this.initialBytesLen < 16)
      return "";
    var t = ti.concat(this.initialBytes), e = df(t, this.options.defaultEncoding);
    this.decoder = this.iconv.getDecoder(e, this.options), this.initialBytes.length = this.initialBytesLen = 0;
  }
  return this.decoder.write(t);
};
Ya.prototype.end = function() {
  if (!this.decoder) {
    var t = ti.concat(this.initialBytes), e = df(t, this.options.defaultEncoding);
    this.decoder = this.iconv.getDecoder(e, this.options);
    var r = this.decoder.write(t), n = this.decoder.end();
    return n ? r + n : r;
  }
  return this.decoder.end();
};
function df(t, e) {
  var r = e || "utf-16le";
  if (t.length >= 2)
    if (t[0] == 254 && t[1] == 255)
      r = "utf-16be";
    else if (t[0] == 255 && t[1] == 254)
      r = "utf-16le";
    else {
      for (var n = 0, a = 0, o = Math.min(t.length - t.length % 2, 64), s = 0; s < o; s += 2)
        t[s] === 0 && t[s + 1] !== 0 && a++, t[s] !== 0 && t[s + 1] === 0 && n++;
      a > n ? r = "utf-16be" : a < n && (r = "utf-16le");
    }
  return r;
}
var Mh = {
  utf16be: kh,
  utf16: Lh
}, vt = qr.Buffer, Uh = ni, Nh = "utf7";
function ni(t, e) {
  this.iconv = e;
}
ni.prototype.encoder = Ka;
ni.prototype.decoder = Za;
ni.prototype.bomAware = !0;
var Rh = /[^A-Za-z0-9'\(\),-\.\/:\? \n\r\t]+/g;
function Ka(t, e) {
  this.iconv = e.iconv;
}
Ka.prototype.write = function(t) {
  return vt.from(t.replace(Rh, (function(e) {
    return "+" + (e === "+" ? "" : this.iconv.encode(e, "utf16-be").toString("base64").replace(/=+$/, "")) + "-";
  }).bind(this)));
};
Ka.prototype.end = function() {
};
function Za(t, e) {
  this.iconv = e.iconv, this.inBase64 = !1, this.base64Accum = "";
}
var zh = /[A-Za-z0-9\/+]/, Ja = [];
for (var wn = 0; wn < 256; wn++)
  Ja[wn] = zh.test(String.fromCharCode(wn));
var jh = 43, cr = 45, ha = 38;
Za.prototype.write = function(t) {
  for (var e = "", r = 0, n = this.inBase64, a = this.base64Accum, o = 0; o < t.length; o++)
    if (!n)
      t[o] == jh && (e += this.iconv.decode(t.slice(r, o), "ascii"), r = o + 1, n = !0);
    else if (!Ja[t[o]]) {
      if (o == r && t[o] == cr)
        e += "+";
      else {
        var s = a + t.slice(r, o).toString();
        e += this.iconv.decode(vt.from(s, "base64"), "utf16-be");
      }
      t[o] != cr && o--, r = o + 1, n = !1, a = "";
    }
  if (!n)
    e += this.iconv.decode(t.slice(r), "ascii");
  else {
    var s = a + t.slice(r).toString(), u = s.length - s.length % 8;
    a = s.slice(u), s = s.slice(0, u), e += this.iconv.decode(vt.from(s, "base64"), "utf16-be");
  }
  return this.inBase64 = n, this.base64Accum = a, e;
};
Za.prototype.end = function() {
  var t = "";
  return this.inBase64 && this.base64Accum.length > 0 && (t = this.iconv.decode(vt.from(this.base64Accum, "base64"), "utf16-be")), this.inBase64 = !1, this.base64Accum = "", t;
};
var Vh = ii;
function ii(t, e) {
  this.iconv = e;
}
ii.prototype.encoder = Qa;
ii.prototype.decoder = _a;
ii.prototype.bomAware = !0;
function Qa(t, e) {
  this.iconv = e.iconv, this.inBase64 = !1, this.base64Accum = vt.alloc(6), this.base64AccumIdx = 0;
}
Qa.prototype.write = function(t) {
  for (var e = this.inBase64, r = this.base64Accum, n = this.base64AccumIdx, a = vt.alloc(t.length * 5 + 10), o = 0, s = 0; s < t.length; s++) {
    var u = t.charCodeAt(s);
    32 <= u && u <= 126 ? (e && (n > 0 && (o += a.write(r.slice(0, n).toString("base64").replace(/\//g, ",").replace(/=+$/, ""), o), n = 0), a[o++] = cr, e = !1), e || (a[o++] = u, u === ha && (a[o++] = cr))) : (e || (a[o++] = ha, e = !0), e && (r[n++] = u >> 8, r[n++] = u & 255, n == r.length && (o += a.write(r.toString("base64").replace(/\//g, ","), o), n = 0)));
  }
  return this.inBase64 = e, this.base64AccumIdx = n, a.slice(0, o);
};
Qa.prototype.end = function() {
  var t = vt.alloc(10), e = 0;
  return this.inBase64 && (this.base64AccumIdx > 0 && (e += t.write(this.base64Accum.slice(0, this.base64AccumIdx).toString("base64").replace(/\//g, ",").replace(/=+$/, ""), e), this.base64AccumIdx = 0), t[e++] = cr, this.inBase64 = !1), t.slice(0, e);
};
function _a(t, e) {
  this.iconv = e.iconv, this.inBase64 = !1, this.base64Accum = "";
}
var vf = Ja.slice();
vf[44] = !0;
_a.prototype.write = function(t) {
  for (var e = "", r = 0, n = this.inBase64, a = this.base64Accum, o = 0; o < t.length; o++)
    if (!n)
      t[o] == ha && (e += this.iconv.decode(t.slice(r, o), "ascii"), r = o + 1, n = !0);
    else if (!vf[t[o]]) {
      if (o == r && t[o] == cr)
        e += "&";
      else {
        var s = a + t.slice(r, o).toString().replace(/,/g, "/");
        e += this.iconv.decode(vt.from(s, "base64"), "utf16-be");
      }
      t[o] != cr && o--, r = o + 1, n = !1, a = "";
    }
  if (!n)
    e += this.iconv.decode(t.slice(r), "ascii");
  else {
    var s = a + t.slice(r).toString().replace(/,/g, "/"), u = s.length - s.length % 8;
    a = s.slice(u), s = s.slice(0, u), e += this.iconv.decode(vt.from(s, "base64"), "utf16-be");
  }
  return this.inBase64 = n, this.base64Accum = a, e;
};
_a.prototype.end = function() {
  var t = "";
  return this.inBase64 && this.base64Accum.length > 0 && (t = this.iconv.decode(vt.from(this.base64Accum, "base64"), "utf16-be")), this.inBase64 = !1, this.base64Accum = "", t;
};
var Gh = {
  utf7: Uh,
  unicode11utf7: Nh,
  utf7imap: Vh
}, jn = qr.Buffer, qh = $a;
function $a(t, e) {
  if (!t) throw new Error("SBCS codec is called without the data.");
  if (!t.chars || t.chars.length !== 128 && t.chars.length !== 256) throw new Error("Encoding '" + t.type + "' has incorrect 'chars' (must be of len 128 or 256)");
  if (t.chars.length === 128) {
    for (var r = "", n = 0; n < 128; n++)
      r += String.fromCharCode(n);
    t.chars = r + t.chars;
  }
  this.decodeBuf = jn.from(t.chars, "ucs2");
  for (var a = jn.alloc(65536, e.defaultCharSingleByte.charCodeAt(0)), n = 0; n < t.chars.length; n++)
    a[t.chars.charCodeAt(n)] = n;
  this.encodeBuf = a;
}
$a.prototype.encoder = eo;
$a.prototype.decoder = to;
function eo(t, e) {
  this.encodeBuf = e.encodeBuf;
}
eo.prototype.write = function(t) {
  for (var e = jn.alloc(t.length), r = 0; r < t.length; r++)
    e[r] = this.encodeBuf[t.charCodeAt(r)];
  return e;
};
eo.prototype.end = function() {
};
function to(t, e) {
  this.decodeBuf = e.decodeBuf;
}
to.prototype.write = function(t) {
  for (var e = this.decodeBuf, r = jn.alloc(t.length * 2), n = 0, a = 0, o = 0; o < t.length; o++)
    n = t[o] * 2, a = o * 2, r[a] = e[n], r[a + 1] = e[n + 1];
  return r.toString("ucs2");
};
to.prototype.end = function() {
};
var Hh = {
  _sbcs: qh
}, Wh = {
  // Not supported by iconv, not sure why.
  10029: "maccenteuro",
  maccenteuro: {
    type: "_sbcs",
    chars: "ÄĀāÉĄÖÜáąČäčĆćéŹźĎíďĒēĖóėôöõúĚěü†°Ę£§•¶ß®©™ę¨≠ģĮįĪ≤≥īĶ∂∑łĻļĽľĹĺŅņŃ¬√ńŇ∆«»… ňŐÕőŌ–—“”‘’÷◊ōŔŕŘ‹›řŖŗŠ‚„šŚśÁŤťÍŽžŪÓÔūŮÚůŰűŲųÝýķŻŁżĢˇ"
  },
  808: "cp808",
  ibm808: "cp808",
  cp808: {
    type: "_sbcs",
    chars: "АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдежзийклмноп░▒▓│┤╡╢╖╕╣║╗╝╜╛┐└┴┬├─┼╞╟╚╔╩╦╠═╬╧╨╤╥╙╘╒╓╫╪┘┌█▄▌▐▀рстуфхцчшщъыьэюяЁёЄєЇїЎў°∙·√№€■ "
  },
  mik: {
    type: "_sbcs",
    chars: "АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдежзийклмнопрстуфхцчшщъыьэюя└┴┬├─┼╣║╚╔╩╦╠═╬┐░▒▓│┤№§╗╝┘┌█▄▌▐▀αßΓπΣσµτΦΘΩδ∞φε∩≡±≥≤⌠⌡÷≈°∙·√ⁿ²■ "
  },
  // Aliases of generated encodings.
  ascii8bit: "ascii",
  usascii: "ascii",
  ansix34: "ascii",
  ansix341968: "ascii",
  ansix341986: "ascii",
  csascii: "ascii",
  cp367: "ascii",
  ibm367: "ascii",
  isoir6: "ascii",
  iso646us: "ascii",
  iso646irv: "ascii",
  us: "ascii",
  latin1: "iso88591",
  latin2: "iso88592",
  latin3: "iso88593",
  latin4: "iso88594",
  latin5: "iso88599",
  latin6: "iso885910",
  latin7: "iso885913",
  latin8: "iso885914",
  latin9: "iso885915",
  latin10: "iso885916",
  csisolatin1: "iso88591",
  csisolatin2: "iso88592",
  csisolatin3: "iso88593",
  csisolatin4: "iso88594",
  csisolatincyrillic: "iso88595",
  csisolatinarabic: "iso88596",
  csisolatingreek: "iso88597",
  csisolatinhebrew: "iso88598",
  csisolatin5: "iso88599",
  csisolatin6: "iso885910",
  l1: "iso88591",
  l2: "iso88592",
  l3: "iso88593",
  l4: "iso88594",
  l5: "iso88599",
  l6: "iso885910",
  l7: "iso885913",
  l8: "iso885914",
  l9: "iso885915",
  l10: "iso885916",
  isoir14: "iso646jp",
  isoir57: "iso646cn",
  isoir100: "iso88591",
  isoir101: "iso88592",
  isoir109: "iso88593",
  isoir110: "iso88594",
  isoir144: "iso88595",
  isoir127: "iso88596",
  isoir126: "iso88597",
  isoir138: "iso88598",
  isoir148: "iso88599",
  isoir157: "iso885910",
  isoir166: "tis620",
  isoir179: "iso885913",
  isoir199: "iso885914",
  isoir203: "iso885915",
  isoir226: "iso885916",
  cp819: "iso88591",
  ibm819: "iso88591",
  cyrillic: "iso88595",
  arabic: "iso88596",
  arabic8: "iso88596",
  ecma114: "iso88596",
  asmo708: "iso88596",
  greek: "iso88597",
  greek8: "iso88597",
  ecma118: "iso88597",
  elot928: "iso88597",
  hebrew: "iso88598",
  hebrew8: "iso88598",
  turkish: "iso88599",
  turkish8: "iso88599",
  thai: "iso885911",
  thai8: "iso885911",
  celtic: "iso885914",
  celtic8: "iso885914",
  isoceltic: "iso885914",
  tis6200: "tis620",
  tis62025291: "tis620",
  tis62025330: "tis620",
  1e4: "macroman",
  10006: "macgreek",
  10007: "maccyrillic",
  10079: "maciceland",
  10081: "macturkish",
  cspc8codepage437: "cp437",
  cspc775baltic: "cp775",
  cspc850multilingual: "cp850",
  cspcp852: "cp852",
  cspc862latinhebrew: "cp862",
  cpgr: "cp869",
  msee: "cp1250",
  mscyrl: "cp1251",
  msansi: "cp1252",
  msgreek: "cp1253",
  msturk: "cp1254",
  mshebr: "cp1255",
  msarab: "cp1256",
  winbaltrim: "cp1257",
  cp20866: "koi8r",
  20866: "koi8r",
  ibm878: "koi8r",
  cskoi8r: "koi8r",
  cp21866: "koi8u",
  21866: "koi8u",
  ibm1168: "koi8u",
  strk10482002: "rk1048",
  tcvn5712: "tcvn",
  tcvn57121: "tcvn",
  gb198880: "iso646cn",
  cn: "iso646cn",
  csiso14jisc6220ro: "iso646jp",
  jisc62201969ro: "iso646jp",
  jp: "iso646jp",
  cshproman8: "hproman8",
  r8: "hproman8",
  roman8: "hproman8",
  xroman8: "hproman8",
  ibm1051: "hproman8",
  mac: "macintosh",
  csmacintosh: "macintosh"
}, Xh = {
  437: "cp437",
  737: "cp737",
  775: "cp775",
  850: "cp850",
  852: "cp852",
  855: "cp855",
  856: "cp856",
  857: "cp857",
  858: "cp858",
  860: "cp860",
  861: "cp861",
  862: "cp862",
  863: "cp863",
  864: "cp864",
  865: "cp865",
  866: "cp866",
  869: "cp869",
  874: "windows874",
  922: "cp922",
  1046: "cp1046",
  1124: "cp1124",
  1125: "cp1125",
  1129: "cp1129",
  1133: "cp1133",
  1161: "cp1161",
  1162: "cp1162",
  1163: "cp1163",
  1250: "windows1250",
  1251: "windows1251",
  1252: "windows1252",
  1253: "windows1253",
  1254: "windows1254",
  1255: "windows1255",
  1256: "windows1256",
  1257: "windows1257",
  1258: "windows1258",
  28591: "iso88591",
  28592: "iso88592",
  28593: "iso88593",
  28594: "iso88594",
  28595: "iso88595",
  28596: "iso88596",
  28597: "iso88597",
  28598: "iso88598",
  28599: "iso88599",
  28600: "iso885910",
  28601: "iso885911",
  28603: "iso885913",
  28604: "iso885914",
  28605: "iso885915",
  28606: "iso885916",
  windows874: {
    type: "_sbcs",
    chars: "€����…�����������‘’“”•–—�������� กขฃคฅฆงจฉชซฌญฎฏฐฑฒณดตถทธนบปผฝพฟภมยรฤลฦวศษสหฬอฮฯะัาำิีึืฺุู����฿เแโใไๅๆ็่้๊๋์ํ๎๏๐๑๒๓๔๕๖๗๘๙๚๛����"
  },
  win874: "windows874",
  cp874: "windows874",
  windows1250: {
    type: "_sbcs",
    chars: "€�‚�„…†‡�‰Š‹ŚŤŽŹ�‘’“”•–—�™š›śťžź ˇ˘Ł¤Ą¦§¨©Ş«¬­®Ż°±˛ł´µ¶·¸ąş»Ľ˝ľżŔÁÂĂÄĹĆÇČÉĘËĚÍÎĎĐŃŇÓÔŐÖ×ŘŮÚŰÜÝŢßŕáâăäĺćçčéęëěíîďđńňóôőö÷řůúűüýţ˙"
  },
  win1250: "windows1250",
  cp1250: "windows1250",
  windows1251: {
    type: "_sbcs",
    chars: "ЂЃ‚ѓ„…†‡€‰Љ‹ЊЌЋЏђ‘’“”•–—�™љ›њќћџ ЎўЈ¤Ґ¦§Ё©Є«¬­®Ї°±Ііґµ¶·ё№є»јЅѕїАБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдежзийклмнопрстуфхцчшщъыьэюя"
  },
  win1251: "windows1251",
  cp1251: "windows1251",
  windows1252: {
    type: "_sbcs",
    chars: "€�‚ƒ„…†‡ˆ‰Š‹Œ�Ž��‘’“”•–—˜™š›œ�žŸ ¡¢£¤¥¦§¨©ª«¬­®¯°±²³´µ¶·¸¹º»¼½¾¿ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖ×ØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõö÷øùúûüýþÿ"
  },
  win1252: "windows1252",
  cp1252: "windows1252",
  windows1253: {
    type: "_sbcs",
    chars: "€�‚ƒ„…†‡�‰�‹�����‘’“”•–—�™�›���� ΅Ά£¤¥¦§¨©�«¬­®―°±²³΄µ¶·ΈΉΊ»Ό½ΎΏΐΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡ�ΣΤΥΦΧΨΩΪΫάέήίΰαβγδεζηθικλμνξοπρςστυφχψωϊϋόύώ�"
  },
  win1253: "windows1253",
  cp1253: "windows1253",
  windows1254: {
    type: "_sbcs",
    chars: "€�‚ƒ„…†‡ˆ‰Š‹Œ����‘’“”•–—˜™š›œ��Ÿ ¡¢£¤¥¦§¨©ª«¬­®¯°±²³´µ¶·¸¹º»¼½¾¿ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏĞÑÒÓÔÕÖ×ØÙÚÛÜİŞßàáâãäåæçèéêëìíîïğñòóôõö÷øùúûüışÿ"
  },
  win1254: "windows1254",
  cp1254: "windows1254",
  windows1255: {
    type: "_sbcs",
    chars: "€�‚ƒ„…†‡ˆ‰�‹�����‘’“”•–—˜™�›���� ¡¢£₪¥¦§¨©×«¬­®¯°±²³´µ¶·¸¹÷»¼½¾¿ְֱֲֳִֵֶַָֹֺֻּֽ־ֿ׀ׁׂ׃װױײ׳״�������אבגדהוזחטיךכלםמןנסעףפץצקרשת��‎‏�"
  },
  win1255: "windows1255",
  cp1255: "windows1255",
  windows1256: {
    type: "_sbcs",
    chars: "€پ‚ƒ„…†‡ˆ‰ٹ‹Œچژڈگ‘’“”•–—ک™ڑ›œ‌‍ں ،¢£¤¥¦§¨©ھ«¬­®¯°±²³´µ¶·¸¹؛»¼½¾؟ہءآأؤإئابةتثجحخدذرزسشصض×طظعغـفقكàلâمنهوçèéêëىيîïًٌٍَôُِ÷ّùْûü‎‏ے"
  },
  win1256: "windows1256",
  cp1256: "windows1256",
  windows1257: {
    type: "_sbcs",
    chars: "€�‚�„…†‡�‰�‹�¨ˇ¸�‘’“”•–—�™�›�¯˛� �¢£¤�¦§Ø©Ŗ«¬­®Æ°±²³´µ¶·ø¹ŗ»¼½¾æĄĮĀĆÄÅĘĒČÉŹĖĢĶĪĻŠŃŅÓŌÕÖ×ŲŁŚŪÜŻŽßąįāćäåęēčéźėģķīļšńņóōõö÷ųłśūüżž˙"
  },
  win1257: "windows1257",
  cp1257: "windows1257",
  windows1258: {
    type: "_sbcs",
    chars: "€�‚ƒ„…†‡ˆ‰�‹Œ����‘’“”•–—˜™�›œ��Ÿ ¡¢£¤¥¦§¨©ª«¬­®¯°±²³´µ¶·¸¹º»¼½¾¿ÀÁÂĂÄÅÆÇÈÉÊË̀ÍÎÏĐÑ̉ÓÔƠÖ×ØÙÚÛÜỮßàáâăäåæçèéêë́íîïđṇ̃óôơö÷øùúûüư₫ÿ"
  },
  win1258: "windows1258",
  cp1258: "windows1258",
  iso88591: {
    type: "_sbcs",
    chars: " ¡¢£¤¥¦§¨©ª«¬­®¯°±²³´µ¶·¸¹º»¼½¾¿ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖ×ØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõö÷øùúûüýþÿ"
  },
  cp28591: "iso88591",
  iso88592: {
    type: "_sbcs",
    chars: " Ą˘Ł¤ĽŚ§¨ŠŞŤŹ­ŽŻ°ą˛ł´ľśˇ¸šşťź˝žżŔÁÂĂÄĹĆÇČÉĘËĚÍÎĎĐŃŇÓÔŐÖ×ŘŮÚŰÜÝŢßŕáâăäĺćçčéęëěíîďđńňóôőö÷řůúűüýţ˙"
  },
  cp28592: "iso88592",
  iso88593: {
    type: "_sbcs",
    chars: " Ħ˘£¤�Ĥ§¨İŞĞĴ­�Ż°ħ²³´µĥ·¸ışğĵ½�żÀÁÂ�ÄĊĈÇÈÉÊËÌÍÎÏ�ÑÒÓÔĠÖ×ĜÙÚÛÜŬŜßàáâ�äċĉçèéêëìíîï�ñòóôġö÷ĝùúûüŭŝ˙"
  },
  cp28593: "iso88593",
  iso88594: {
    type: "_sbcs",
    chars: " ĄĸŖ¤ĨĻ§¨ŠĒĢŦ­Ž¯°ą˛ŗ´ĩļˇ¸šēģŧŊžŋĀÁÂÃÄÅÆĮČÉĘËĖÍÎĪĐŅŌĶÔÕÖ×ØŲÚÛÜŨŪßāáâãäåæįčéęëėíîīđņōķôõö÷øųúûüũū˙"
  },
  cp28594: "iso88594",
  iso88595: {
    type: "_sbcs",
    chars: " ЁЂЃЄЅІЇЈЉЊЋЌ­ЎЏАБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдежзийклмнопрстуфхцчшщъыьэюя№ёђѓєѕіїјљњћќ§ўџ"
  },
  cp28595: "iso88595",
  iso88596: {
    type: "_sbcs",
    chars: " ���¤�������،­�������������؛���؟�ءآأؤإئابةتثجحخدذرزسشصضطظعغ�����ـفقكلمنهوىيًٌٍَُِّْ�������������"
  },
  cp28596: "iso88596",
  iso88597: {
    type: "_sbcs",
    chars: " ‘’£€₯¦§¨©ͺ«¬­�―°±²³΄΅Ά·ΈΉΊ»Ό½ΎΏΐΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡ�ΣΤΥΦΧΨΩΪΫάέήίΰαβγδεζηθικλμνξοπρςστυφχψωϊϋόύώ�"
  },
  cp28597: "iso88597",
  iso88598: {
    type: "_sbcs",
    chars: " �¢£¤¥¦§¨©×«¬­®¯°±²³´µ¶·¸¹÷»¼½¾��������������������������������‗אבגדהוזחטיךכלםמןנסעףפץצקרשת��‎‏�"
  },
  cp28598: "iso88598",
  iso88599: {
    type: "_sbcs",
    chars: " ¡¢£¤¥¦§¨©ª«¬­®¯°±²³´µ¶·¸¹º»¼½¾¿ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏĞÑÒÓÔÕÖ×ØÙÚÛÜİŞßàáâãäåæçèéêëìíîïğñòóôõö÷øùúûüışÿ"
  },
  cp28599: "iso88599",
  iso885910: {
    type: "_sbcs",
    chars: " ĄĒĢĪĨĶ§ĻĐŠŦŽ­ŪŊ°ąēģīĩķ·ļđšŧž―ūŋĀÁÂÃÄÅÆĮČÉĘËĖÍÎÏÐŅŌÓÔÕÖŨØŲÚÛÜÝÞßāáâãäåæįčéęëėíîïðņōóôõöũøųúûüýþĸ"
  },
  cp28600: "iso885910",
  iso885911: {
    type: "_sbcs",
    chars: " กขฃคฅฆงจฉชซฌญฎฏฐฑฒณดตถทธนบปผฝพฟภมยรฤลฦวศษสหฬอฮฯะัาำิีึืฺุู����฿เแโใไๅๆ็่้๊๋์ํ๎๏๐๑๒๓๔๕๖๗๘๙๚๛����"
  },
  cp28601: "iso885911",
  iso885913: {
    type: "_sbcs",
    chars: " ”¢£¤„¦§Ø©Ŗ«¬­®Æ°±²³“µ¶·ø¹ŗ»¼½¾æĄĮĀĆÄÅĘĒČÉŹĖĢĶĪĻŠŃŅÓŌÕÖ×ŲŁŚŪÜŻŽßąįāćäåęēčéźėģķīļšńņóōõö÷ųłśūüżž’"
  },
  cp28603: "iso885913",
  iso885914: {
    type: "_sbcs",
    chars: " Ḃḃ£ĊċḊ§Ẁ©ẂḋỲ­®ŸḞḟĠġṀṁ¶ṖẁṗẃṠỳẄẅṡÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏŴÑÒÓÔÕÖṪØÙÚÛÜÝŶßàáâãäåæçèéêëìíîïŵñòóôõöṫøùúûüýŷÿ"
  },
  cp28604: "iso885914",
  iso885915: {
    type: "_sbcs",
    chars: " ¡¢£€¥Š§š©ª«¬­®¯°±²³Žµ¶·ž¹º»ŒœŸ¿ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖ×ØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõö÷øùúûüýþÿ"
  },
  cp28605: "iso885915",
  iso885916: {
    type: "_sbcs",
    chars: " ĄąŁ€„Š§š©Ș«Ź­źŻ°±ČłŽ”¶·žčș»ŒœŸżÀÁÂĂÄĆÆÇÈÉÊËÌÍÎÏĐŃÒÓÔŐÖŚŰÙÚÛÜĘȚßàáâăäćæçèéêëìíîïđńòóôőöśűùúûüęțÿ"
  },
  cp28606: "iso885916",
  cp437: {
    type: "_sbcs",
    chars: "ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜ¢£¥₧ƒáíóúñÑªº¿⌐¬½¼¡«»░▒▓│┤╡╢╖╕╣║╗╝╜╛┐└┴┬├─┼╞╟╚╔╩╦╠═╬╧╨╤╥╙╘╒╓╫╪┘┌█▄▌▐▀αßΓπΣσµτΦΘΩδ∞φε∩≡±≥≤⌠⌡÷≈°∙·√ⁿ²■ "
  },
  ibm437: "cp437",
  csibm437: "cp437",
  cp737: {
    type: "_sbcs",
    chars: "ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρσςτυφχψ░▒▓│┤╡╢╖╕╣║╗╝╜╛┐└┴┬├─┼╞╟╚╔╩╦╠═╬╧╨╤╥╙╘╒╓╫╪┘┌█▄▌▐▀ωάέήϊίόύϋώΆΈΉΊΌΎΏ±≥≤ΪΫ÷≈°∙·√ⁿ²■ "
  },
  ibm737: "cp737",
  csibm737: "cp737",
  cp775: {
    type: "_sbcs",
    chars: "ĆüéāäģåćłēŖŗīŹÄÅÉæÆōöĢ¢ŚśÖÜø£Ø×¤ĀĪóŻżź”¦©®¬½¼Ł«»░▒▓│┤ĄČĘĖ╣║╗╝ĮŠ┐└┴┬├─┼ŲŪ╚╔╩╦╠═╬Žąčęėįšųūž┘┌█▄▌▐▀ÓßŌŃõÕµńĶķĻļņĒŅ’­±“¾¶§÷„°∙·¹³²■ "
  },
  ibm775: "cp775",
  csibm775: "cp775",
  cp850: {
    type: "_sbcs",
    chars: "ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜø£Ø×ƒáíóúñÑªº¿®¬½¼¡«»░▒▓│┤ÁÂÀ©╣║╗╝¢¥┐└┴┬├─┼ãÃ╚╔╩╦╠═╬¤ðÐÊËÈıÍÎÏ┘┌█▄¦Ì▀ÓßÔÒõÕµþÞÚÛÙýÝ¯´­±‗¾¶§÷¸°¨·¹³²■ "
  },
  ibm850: "cp850",
  csibm850: "cp850",
  cp852: {
    type: "_sbcs",
    chars: "ÇüéâäůćçłëŐőîŹÄĆÉĹĺôöĽľŚśÖÜŤťŁ×čáíóúĄąŽžĘę¬źČş«»░▒▓│┤ÁÂĚŞ╣║╗╝Żż┐└┴┬├─┼Ăă╚╔╩╦╠═╬¤đĐĎËďŇÍÎě┘┌█▄ŢŮ▀ÓßÔŃńňŠšŔÚŕŰýÝţ´­˝˛ˇ˘§÷¸°¨˙űŘř■ "
  },
  ibm852: "cp852",
  csibm852: "cp852",
  cp855: {
    type: "_sbcs",
    chars: "ђЂѓЃёЁєЄѕЅіІїЇјЈљЉњЊћЋќЌўЎџЏюЮъЪаАбБцЦдДеЕфФгГ«»░▒▓│┤хХиИ╣║╗╝йЙ┐└┴┬├─┼кК╚╔╩╦╠═╬¤лЛмМнНоОп┘┌█▄Пя▀ЯрРсСтТуУжЖвВьЬ№­ыЫзЗшШэЭщЩчЧ§■ "
  },
  ibm855: "cp855",
  csibm855: "cp855",
  cp856: {
    type: "_sbcs",
    chars: "אבגדהוזחטיךכלםמןנסעףפץצקרשת�£�×����������®¬½¼�«»░▒▓│┤���©╣║╗╝¢¥┐└┴┬├─┼��╚╔╩╦╠═╬¤���������┘┌█▄¦�▀������µ�������¯´­±‗¾¶§÷¸°¨·¹³²■ "
  },
  ibm856: "cp856",
  csibm856: "cp856",
  cp857: {
    type: "_sbcs",
    chars: "ÇüéâäàåçêëèïîıÄÅÉæÆôöòûùİÖÜø£ØŞşáíóúñÑĞğ¿®¬½¼¡«»░▒▓│┤ÁÂÀ©╣║╗╝¢¥┐└┴┬├─┼ãÃ╚╔╩╦╠═╬¤ºªÊËÈ�ÍÎÏ┘┌█▄¦Ì▀ÓßÔÒõÕµ�×ÚÛÙìÿ¯´­±�¾¶§÷¸°¨·¹³²■ "
  },
  ibm857: "cp857",
  csibm857: "cp857",
  cp858: {
    type: "_sbcs",
    chars: "ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜø£Ø×ƒáíóúñÑªº¿®¬½¼¡«»░▒▓│┤ÁÂÀ©╣║╗╝¢¥┐└┴┬├─┼ãÃ╚╔╩╦╠═╬¤ðÐÊËÈ€ÍÎÏ┘┌█▄¦Ì▀ÓßÔÒõÕµþÞÚÛÙýÝ¯´­±‗¾¶§÷¸°¨·¹³²■ "
  },
  ibm858: "cp858",
  csibm858: "cp858",
  cp860: {
    type: "_sbcs",
    chars: "ÇüéâãàÁçêÊèÍÔìÃÂÉÀÈôõòÚùÌÕÜ¢£Ù₧ÓáíóúñÑªº¿Ò¬½¼¡«»░▒▓│┤╡╢╖╕╣║╗╝╜╛┐└┴┬├─┼╞╟╚╔╩╦╠═╬╧╨╤╥╙╘╒╓╫╪┘┌█▄▌▐▀αßΓπΣσµτΦΘΩδ∞φε∩≡±≥≤⌠⌡÷≈°∙·√ⁿ²■ "
  },
  ibm860: "cp860",
  csibm860: "cp860",
  cp861: {
    type: "_sbcs",
    chars: "ÇüéâäàåçêëèÐðÞÄÅÉæÆôöþûÝýÖÜø£Ø₧ƒáíóúÁÍÓÚ¿⌐¬½¼¡«»░▒▓│┤╡╢╖╕╣║╗╝╜╛┐└┴┬├─┼╞╟╚╔╩╦╠═╬╧╨╤╥╙╘╒╓╫╪┘┌█▄▌▐▀αßΓπΣσµτΦΘΩδ∞φε∩≡±≥≤⌠⌡÷≈°∙·√ⁿ²■ "
  },
  ibm861: "cp861",
  csibm861: "cp861",
  cp862: {
    type: "_sbcs",
    chars: "אבגדהוזחטיךכלםמןנסעףפץצקרשת¢£¥₧ƒáíóúñÑªº¿⌐¬½¼¡«»░▒▓│┤╡╢╖╕╣║╗╝╜╛┐└┴┬├─┼╞╟╚╔╩╦╠═╬╧╨╤╥╙╘╒╓╫╪┘┌█▄▌▐▀αßΓπΣσµτΦΘΩδ∞φε∩≡±≥≤⌠⌡÷≈°∙·√ⁿ²■ "
  },
  ibm862: "cp862",
  csibm862: "cp862",
  cp863: {
    type: "_sbcs",
    chars: "ÇüéâÂà¶çêëèïî‗À§ÉÈÊôËÏûù¤ÔÜ¢£ÙÛƒ¦´óú¨¸³¯Î⌐¬½¼¾«»░▒▓│┤╡╢╖╕╣║╗╝╜╛┐└┴┬├─┼╞╟╚╔╩╦╠═╬╧╨╤╥╙╘╒╓╫╪┘┌█▄▌▐▀αßΓπΣσµτΦΘΩδ∞φε∩≡±≥≤⌠⌡÷≈°∙·√ⁿ²■ "
  },
  ibm863: "cp863",
  csibm863: "cp863",
  cp864: {
    type: "_sbcs",
    chars: `\0\x07\b	
\v\f\r\x1B !"#$٪&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_\`abcdefghijklmnopqrstuvwxyz{|}~°·∙√▒─│┼┤┬├┴┐┌└┘β∞φ±½¼≈«»ﻷﻸ��ﻻﻼ� ­ﺂ£¤ﺄ��ﺎﺏﺕﺙ،ﺝﺡﺥ٠١٢٣٤٥٦٧٨٩ﻑ؛ﺱﺵﺹ؟¢ﺀﺁﺃﺅﻊﺋﺍﺑﺓﺗﺛﺟﺣﺧﺩﺫﺭﺯﺳﺷﺻﺿﻁﻅﻋﻏ¦¬÷×ﻉـﻓﻗﻛﻟﻣﻧﻫﻭﻯﻳﺽﻌﻎﻍﻡﹽّﻥﻩﻬﻰﻲﻐﻕﻵﻶﻝﻙﻱ■�`
  },
  ibm864: "cp864",
  csibm864: "cp864",
  cp865: {
    type: "_sbcs",
    chars: "ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜø£Ø₧ƒáíóúñÑªº¿⌐¬½¼¡«¤░▒▓│┤╡╢╖╕╣║╗╝╜╛┐└┴┬├─┼╞╟╚╔╩╦╠═╬╧╨╤╥╙╘╒╓╫╪┘┌█▄▌▐▀αßΓπΣσµτΦΘΩδ∞φε∩≡±≥≤⌠⌡÷≈°∙·√ⁿ²■ "
  },
  ibm865: "cp865",
  csibm865: "cp865",
  cp866: {
    type: "_sbcs",
    chars: "АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдежзийклмноп░▒▓│┤╡╢╖╕╣║╗╝╜╛┐└┴┬├─┼╞╟╚╔╩╦╠═╬╧╨╤╥╙╘╒╓╫╪┘┌█▄▌▐▀рстуфхцчшщъыьэюяЁёЄєЇїЎў°∙·√№¤■ "
  },
  ibm866: "cp866",
  csibm866: "cp866",
  cp869: {
    type: "_sbcs",
    chars: "������Ά�·¬¦‘’Έ―ΉΊΪΌ��ΎΫ©Ώ²³ά£έήίϊΐόύΑΒΓΔΕΖΗ½ΘΙ«»░▒▓│┤ΚΛΜΝ╣║╗╝ΞΟ┐└┴┬├─┼ΠΡ╚╔╩╦╠═╬ΣΤΥΦΧΨΩαβγ┘┌█▄δε▀ζηθικλμνξοπρσςτ΄­±υφχ§ψ΅°¨ωϋΰώ■ "
  },
  ibm869: "cp869",
  csibm869: "cp869",
  cp922: {
    type: "_sbcs",
    chars: " ¡¢£¤¥¦§¨©ª«¬­®‾°±²³´µ¶·¸¹º»¼½¾¿ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏŠÑÒÓÔÕÖ×ØÙÚÛÜÝŽßàáâãäåæçèéêëìíîïšñòóôõö÷øùúûüýžÿ"
  },
  ibm922: "cp922",
  csibm922: "cp922",
  cp1046: {
    type: "_sbcs",
    chars: "ﺈ×÷ﹱ■│─┐┌└┘ﹹﹻﹽﹿﹷﺊﻰﻳﻲﻎﻏﻐﻶﻸﻺﻼ ¤ﺋﺑﺗﺛﺟﺣ،­ﺧﺳ٠١٢٣٤٥٦٧٨٩ﺷ؛ﺻﺿﻊ؟ﻋءآأؤإئابةتثجحخدذرزسشصضطﻇعغﻌﺂﺄﺎﻓـفقكلمنهوىيًٌٍَُِّْﻗﻛﻟﻵﻷﻹﻻﻣﻧﻬﻩ�"
  },
  ibm1046: "cp1046",
  csibm1046: "cp1046",
  cp1124: {
    type: "_sbcs",
    chars: " ЁЂҐЄЅІЇЈЉЊЋЌ­ЎЏАБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдежзийклмнопрстуфхцчшщъыьэюя№ёђґєѕіїјљњћќ§ўџ"
  },
  ibm1124: "cp1124",
  csibm1124: "cp1124",
  cp1125: {
    type: "_sbcs",
    chars: "АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдежзийклмноп░▒▓│┤╡╢╖╕╣║╗╝╜╛┐└┴┬├─┼╞╟╚╔╩╦╠═╬╧╨╤╥╙╘╒╓╫╪┘┌█▄▌▐▀рстуфхцчшщъыьэюяЁёҐґЄєІіЇї·√№¤■ "
  },
  ibm1125: "cp1125",
  csibm1125: "cp1125",
  cp1129: {
    type: "_sbcs",
    chars: " ¡¢£¤¥¦§œ©ª«¬­®¯°±²³Ÿµ¶·Œ¹º»¼½¾¿ÀÁÂĂÄÅÆÇÈÉÊË̀ÍÎÏĐÑ̉ÓÔƠÖ×ØÙÚÛÜỮßàáâăäåæçèéêë́íîïđṇ̃óôơö÷øùúûüư₫ÿ"
  },
  ibm1129: "cp1129",
  csibm1129: "cp1129",
  cp1133: {
    type: "_sbcs",
    chars: " ກຂຄງຈສຊຍດຕຖທນບປຜຝພຟມຢຣລວຫອຮ���ຯະາຳິີຶືຸູຼັົຽ���ເແໂໃໄ່້໊໋໌ໍໆ�ໜໝ₭����������������໐໑໒໓໔໕໖໗໘໙��¢¬¦�"
  },
  ibm1133: "cp1133",
  csibm1133: "cp1133",
  cp1161: {
    type: "_sbcs",
    chars: "��������������������������������่กขฃคฅฆงจฉชซฌญฎฏฐฑฒณดตถทธนบปผฝพฟภมยรฤลฦวศษสหฬอฮฯะัาำิีึืฺุู้๊๋€฿เแโใไๅๆ็่้๊๋์ํ๎๏๐๑๒๓๔๕๖๗๘๙๚๛¢¬¦ "
  },
  ibm1161: "cp1161",
  csibm1161: "cp1161",
  cp1162: {
    type: "_sbcs",
    chars: "€…‘’“”•–— กขฃคฅฆงจฉชซฌญฎฏฐฑฒณดตถทธนบปผฝพฟภมยรฤลฦวศษสหฬอฮฯะัาำิีึืฺุู����฿เแโใไๅๆ็่้๊๋์ํ๎๏๐๑๒๓๔๕๖๗๘๙๚๛����"
  },
  ibm1162: "cp1162",
  csibm1162: "cp1162",
  cp1163: {
    type: "_sbcs",
    chars: " ¡¢£€¥¦§œ©ª«¬­®¯°±²³Ÿµ¶·Œ¹º»¼½¾¿ÀÁÂĂÄÅÆÇÈÉÊË̀ÍÎÏĐÑ̉ÓÔƠÖ×ØÙÚÛÜỮßàáâăäåæçèéêë́íîïđṇ̃óôơö÷øùúûüư₫ÿ"
  },
  ibm1163: "cp1163",
  csibm1163: "cp1163",
  maccroatian: {
    type: "_sbcs",
    chars: "ÄÅÇÉÑÖÜáàâäãåçéèêëíìîïñóòôöõúùûü†°¢£§•¶ß®Š™´¨≠ŽØ∞±≤≥∆µ∂∑∏š∫ªºΩžø¿¡¬√ƒ≈Ć«Č… ÀÃÕŒœĐ—“”‘’÷◊�©⁄¤‹›Æ»–·‚„‰ÂćÁčÈÍÎÏÌÓÔđÒÚÛÙıˆ˜¯πË˚¸Êæˇ"
  },
  maccyrillic: {
    type: "_sbcs",
    chars: "АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ†°¢£§•¶І®©™Ђђ≠Ѓѓ∞±≤≥іµ∂ЈЄєЇїЉљЊњјЅ¬√ƒ≈∆«»… ЋћЌќѕ–—“”‘’÷„ЎўЏџ№Ёёяабвгдежзийклмнопрстуфхцчшщъыьэю¤"
  },
  macgreek: {
    type: "_sbcs",
    chars: "Ä¹²É³ÖÜ΅àâä΄¨çéèêë£™îï•½‰ôö¦­ùûü†ΓΔΘΛΞΠß®©ΣΪ§≠°·Α±≤≥¥ΒΕΖΗΙΚΜΦΫΨΩάΝ¬ΟΡ≈Τ«»… ΥΧΆΈœ–―“”‘’÷ΉΊΌΎέήίόΏύαβψδεφγηιξκλμνοπώρστθωςχυζϊϋΐΰ�"
  },
  maciceland: {
    type: "_sbcs",
    chars: "ÄÅÇÉÑÖÜáàâäãåçéèêëíìîïñóòôöõúùûüÝ°¢£§•¶ß®©™´¨≠ÆØ∞±≤≥¥µ∂∑∏π∫ªºΩæø¿¡¬√ƒ≈∆«»… ÀÃÕŒœ–—“”‘’÷◊ÿŸ⁄¤ÐðÞþý·‚„‰ÂÊÁËÈÍÎÏÌÓÔ�ÒÚÛÙıˆ˜¯˘˙˚¸˝˛ˇ"
  },
  macroman: {
    type: "_sbcs",
    chars: "ÄÅÇÉÑÖÜáàâäãåçéèêëíìîïñóòôöõúùûü†°¢£§•¶ß®©™´¨≠ÆØ∞±≤≥¥µ∂∑∏π∫ªºΩæø¿¡¬√ƒ≈∆«»… ÀÃÕŒœ–—“”‘’÷◊ÿŸ⁄¤‹›ﬁﬂ‡·‚„‰ÂÊÁËÈÍÎÏÌÓÔ�ÒÚÛÙıˆ˜¯˘˙˚¸˝˛ˇ"
  },
  macromania: {
    type: "_sbcs",
    chars: "ÄÅÇÉÑÖÜáàâäãåçéèêëíìîïñóòôöõúùûü†°¢£§•¶ß®©™´¨≠ĂŞ∞±≤≥¥µ∂∑∏π∫ªºΩăş¿¡¬√ƒ≈∆«»… ÀÃÕŒœ–—“”‘’÷◊ÿŸ⁄¤‹›Ţţ‡·‚„‰ÂÊÁËÈÍÎÏÌÓÔ�ÒÚÛÙıˆ˜¯˘˙˚¸˝˛ˇ"
  },
  macthai: {
    type: "_sbcs",
    chars: "«»…“”�•‘’� กขฃคฅฆงจฉชซฌญฎฏฐฑฒณดตถทธนบปผฝพฟภมยรฤลฦวศษสหฬอฮฯะัาำิีึืฺุู\uFEFF​–—฿เแโใไๅๆ็่้๊๋์ํ™๏๐๑๒๓๔๕๖๗๘๙®©����"
  },
  macturkish: {
    type: "_sbcs",
    chars: "ÄÅÇÉÑÖÜáàâäãåçéèêëíìîïñóòôöõúùûü†°¢£§•¶ß®©™´¨≠ÆØ∞±≤≥¥µ∂∑∏π∫ªºΩæø¿¡¬√ƒ≈∆«»… ÀÃÕŒœ–—“”‘’÷◊ÿŸĞğİıŞş‡·‚„‰ÂÊÁËÈÍÎÏÌÓÔ�ÒÚÛÙ�ˆ˜¯˘˙˚¸˝˛ˇ"
  },
  macukraine: {
    type: "_sbcs",
    chars: "АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ†°Ґ£§•¶І®©™Ђђ≠Ѓѓ∞±≤≥іµґЈЄєЇїЉљЊњјЅ¬√ƒ≈∆«»… ЋћЌќѕ–—“”‘’÷„ЎўЏџ№Ёёяабвгдежзийклмнопрстуфхцчшщъыьэю¤"
  },
  koi8r: {
    type: "_sbcs",
    chars: "─│┌┐└┘├┤┬┴┼▀▄█▌▐░▒▓⌠■∙√≈≤≥ ⌡°²·÷═║╒ё╓╔╕╖╗╘╙╚╛╜╝╞╟╠╡Ё╢╣╤╥╦╧╨╩╪╫╬©юабцдефгхийклмнопярстужвьызшэщчъЮАБЦДЕФГХИЙКЛМНОПЯРСТУЖВЬЫЗШЭЩЧЪ"
  },
  koi8u: {
    type: "_sbcs",
    chars: "─│┌┐└┘├┤┬┴┼▀▄█▌▐░▒▓⌠■∙√≈≤≥ ⌡°²·÷═║╒ёє╔ії╗╘╙╚╛ґ╝╞╟╠╡ЁЄ╣ІЇ╦╧╨╩╪Ґ╬©юабцдефгхийклмнопярстужвьызшэщчъЮАБЦДЕФГХИЙКЛМНОПЯРСТУЖВЬЫЗШЭЩЧЪ"
  },
  koi8ru: {
    type: "_sbcs",
    chars: "─│┌┐└┘├┤┬┴┼▀▄█▌▐░▒▓⌠■∙√≈≤≥ ⌡°²·÷═║╒ёє╔ії╗╘╙╚╛ґў╞╟╠╡ЁЄ╣ІЇ╦╧╨╩╪ҐЎ©юабцдефгхийклмнопярстужвьызшэщчъЮАБЦДЕФГХИЙКЛМНОПЯРСТУЖВЬЫЗШЭЩЧЪ"
  },
  koi8t: {
    type: "_sbcs",
    chars: "қғ‚Ғ„…†‡�‰ҳ‹ҲҷҶ�Қ‘’“”•–—�™�›�����ӯӮё¤ӣ¦§���«¬­®�°±²Ё�Ӣ¶·�№�»���©юабцдефгхийклмнопярстужвьызшэщчъЮАБЦДЕФГХИЙКЛМНОПЯРСТУЖВЬЫЗШЭЩЧЪ"
  },
  armscii8: {
    type: "_sbcs",
    chars: " �և։)(»«—.՝,-֊…՜՛՞ԱաԲբԳգԴդԵեԶզԷէԸըԹթԺժԻիԼլԽխԾծԿկՀհՁձՂղՃճՄմՅյՆնՇշՈոՉչՊպՋջՌռՍսՎվՏտՐրՑցՒւՓփՔքՕօՖֆ՚�"
  },
  rk1048: {
    type: "_sbcs",
    chars: "ЂЃ‚ѓ„…†‡€‰Љ‹ЊҚҺЏђ‘’“”•–—�™љ›њқһџ ҰұӘ¤Ө¦§Ё©Ғ«¬­®Ү°±Ііөµ¶·ё№ғ»әҢңүАБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдежзийклмнопрстуфхцчшщъыьэюя"
  },
  tcvn: {
    type: "_sbcs",
    chars: `\0ÚỤỪỬỮ\x07\b	
\v\f\rỨỰỲỶỸÝỴ\x1B !"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_\`abcdefghijklmnopqrstuvwxyz{|}~ÀẢÃÁẠẶẬÈẺẼÉẸỆÌỈĨÍỊÒỎÕÓỌỘỜỞỠỚỢÙỦŨ ĂÂÊÔƠƯĐăâêôơưđẶ̀̀̉̃́àảãáạẲằẳẵắẴẮẦẨẪẤỀặầẩẫấậèỂẻẽéẹềểễếệìỉỄẾỒĩíịòỔỏõóọồổỗốộờởỡớợùỖủũúụừửữứựỳỷỹýỵỐ`
  },
  georgianacademy: {
    type: "_sbcs",
    chars: "‚ƒ„…†‡ˆ‰Š‹Œ‘’“”•–—˜™š›œŸ ¡¢£¤¥¦§¨©ª«¬­®¯°±²³´µ¶·¸¹º»¼½¾¿აბგდევზთიკლმნოპჟრსტუფქღყშჩცძწჭხჯჰჱჲჳჴჵჶçèéêëìíîïðñòóôõö÷øùúûüýþÿ"
  },
  georgianps: {
    type: "_sbcs",
    chars: "‚ƒ„…†‡ˆ‰Š‹Œ‘’“”•–—˜™š›œŸ ¡¢£¤¥¦§¨©ª«¬­®¯°±²³´µ¶·¸¹º»¼½¾¿აბგდევზჱთიკლმნჲოპჟრსტჳუფქღყშჩცძწჭხჴჯჰჵæçèéêëìíîïðñòóôõö÷øùúûüýþÿ"
  },
  pt154: {
    type: "_sbcs",
    chars: "ҖҒӮғ„…ҶҮҲүҠӢҢҚҺҸҗ‘’“”•–—ҳҷҡӣңқһҹ ЎўЈӨҘҰ§Ё©Ә«¬ӯ®Ҝ°ұІіҙө¶·ё№ә»јҪҫҝАБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдежзийклмнопрстуфхцчшщъыьэюя"
  },
  viscii: {
    type: "_sbcs",
    chars: `\0ẲẴẪ\x07\b	
\v\f\rỶỸ\x1BỴ !"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_\`abcdefghijklmnopqrstuvwxyz{|}~ẠẮẰẶẤẦẨẬẼẸẾỀỂỄỆỐỒỔỖỘỢỚỜỞỊỎỌỈỦŨỤỲÕắằặấầẩậẽẹếềểễệốồổỗỠƠộờởịỰỨỪỬơớƯÀÁÂÃẢĂẳẵÈÉÊẺÌÍĨỳĐứÒÓÔạỷừửÙÚỹỵÝỡưàáâãảăữẫèéêẻìíĩỉđựòóôõỏọụùúũủýợỮ`
  },
  iso646cn: {
    type: "_sbcs",
    chars: `\0\x07\b	
\v\f\r\x1B !"#¥%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_\`abcdefghijklmnopqrstuvwxyz{|}‾��������������������������������������������������������������������������������������������������������������������������������`
  },
  iso646jp: {
    type: "_sbcs",
    chars: `\0\x07\b	
\v\f\r\x1B !"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[¥]^_\`abcdefghijklmnopqrstuvwxyz{|}‾��������������������������������������������������������������������������������������������������������������������������������`
  },
  hproman8: {
    type: "_sbcs",
    chars: " ÀÂÈÊËÎÏ´ˋˆ¨˜ÙÛ₤¯Ýý°ÇçÑñ¡¿¤£¥§ƒ¢âêôûáéóúàèòùäëöüÅîØÆåíøæÄìÖÜÉïßÔÁÃãÐðÍÌÓÒÕõŠšÚŸÿÞþ·µ¶¾—¼½ªº«■»±�"
  },
  macintosh: {
    type: "_sbcs",
    chars: "ÄÅÇÉÑÖÜáàâäãåçéèêëíìîïñóòôöõúùûü†°¢£§•¶ß®©™´¨≠ÆØ∞±≤≥¥µ∂∑∏π∫ªºΩæø¿¡¬√ƒ≈∆«»… ÀÃÕŒœ–—“”‘’÷◊ÿŸ⁄¤‹›ﬁﬂ‡·‚„‰ÂÊÁËÈÍÎÏÌÓÔ�ÒÚÛÙıˆ˜¯˘˙˚¸˝˛ˇ"
  },
  ascii: {
    type: "_sbcs",
    chars: "��������������������������������������������������������������������������������������������������������������������������������"
  },
  tis620: {
    type: "_sbcs",
    chars: "���������������������������������กขฃคฅฆงจฉชซฌญฎฏฐฑฒณดตถทธนบปผฝพฟภมยรฤลฦวศษสหฬอฮฯะัาำิีึืฺุู����฿เแโใไๅๆ็่้๊๋์ํ๎๏๐๑๒๓๔๕๖๗๘๙๚๛����"
  }
}, Ur = qr.Buffer, Yh = Et, qe = -1, yf = -2, _e = -10, pt = -1e3, kr = new Array(256), an = -1;
for (var Pi = 0; Pi < 256; Pi++)
  kr[Pi] = qe;
function Et(t, e) {
  if (this.encodingName = t.encodingName, !t) throw new Error("DBCS codec is called without the data.");
  if (!t.table) throw new Error("Encoding '" + this.encodingName + "' has no data.");
  var r = t.table();
  this.decodeTables = [], this.decodeTables[0] = kr.slice(0), this.decodeTableSeq = [];
  for (var n = 0; n < r.length; n++)
    this._addDecodeChunk(r[n]);
  this.defaultCharUnicode = e.defaultCharUnicode, this.encodeTable = [], this.encodeTableSeq = [];
  var a = {};
  if (t.encodeSkipVals) for (var n = 0; n < t.encodeSkipVals.length; n++) {
    var o = t.encodeSkipVals[n];
    if (typeof o == "number") a[o] = !0;
    else for (var s = o.from; s <= o.to; s++)
      a[s] = !0;
  }
  if (this._fillEncodeTable(0, 0, a), t.encodeAdd)
    for (var u in t.encodeAdd)
      Object.prototype.hasOwnProperty.call(t.encodeAdd, u) && this._setEncodeChar(u.charCodeAt(0), t.encodeAdd[u]);
  if (this.defCharSB = this.encodeTable[0][e.defaultCharSingleByte.charCodeAt(0)], this.defCharSB === qe && (this.defCharSB = this.encodeTable[0]["?"]), this.defCharSB === qe && (this.defCharSB = 63), typeof t.gb18030 == "function") {
    this.gb18030 = t.gb18030();
    for (var f = this.decodeTables.length, l = this.decodeTables[f] = kr.slice(0), c = this.decodeTables.length, p = this.decodeTables[c] = kr.slice(0), n = 129; n <= 254; n++)
      for (var y = pt - this.decodeTables[0][n], v = this.decodeTables[y], s = 48; s <= 57; s++)
        v[s] = pt - f;
    for (var n = 129; n <= 254; n++)
      l[n] = pt - c;
    for (var n = 48; n <= 57; n++)
      p[n] = yf;
  }
}
Et.prototype.encoder = ai;
Et.prototype.decoder = ro;
Et.prototype._getDecodeTrieNode = function(t) {
  for (var e = []; t > 0; t >>= 8)
    e.push(t & 255);
  e.length == 0 && e.push(0);
  for (var r = this.decodeTables[0], n = e.length - 1; n > 0; n--) {
    var a = r[e[n]];
    if (a == qe)
      r[e[n]] = pt - this.decodeTables.length, this.decodeTables.push(r = kr.slice(0));
    else if (a <= pt)
      r = this.decodeTables[pt - a];
    else throw new Error("Overwrite byte in " + this.encodingName + ", addr: " + t.toString(16));
  }
  return r;
};
Et.prototype._addDecodeChunk = function(t) {
  var e = parseInt(t[0], 16), r = this._getDecodeTrieNode(e);
  e = e & 255;
  for (var n = 1; n < t.length; n++) {
    var a = t[n];
    if (typeof a == "string")
      for (var o = 0; o < a.length; ) {
        var s = a.charCodeAt(o++);
        if (55296 <= s && s < 56320) {
          var u = a.charCodeAt(o++);
          if (56320 <= u && u < 57344) r[e++] = 65536 + (s - 55296) * 1024 + (u - 56320);
          else throw new Error("Incorrect surrogate pair in " + this.encodingName + " at chunk " + t[0]);
        } else if (4080 < s && s <= 4095) {
          for (var f = 4095 - s + 2, l = [], c = 0; c < f; c++)
            l.push(a.charCodeAt(o++));
          r[e++] = _e - this.decodeTableSeq.length, this.decodeTableSeq.push(l);
        } else r[e++] = s;
      }
    else if (typeof a == "number")
      for (var p = r[e - 1] + 1, o = 0; o < a; o++)
        r[e++] = p++;
    else throw new Error("Incorrect type '" + typeof a + "' given in " + this.encodingName + " at chunk " + t[0]);
  }
  if (e > 255) throw new Error("Incorrect chunk in " + this.encodingName + " at addr " + t[0] + ": too long" + e);
};
Et.prototype._getEncodeBucket = function(t) {
  var e = t >> 8;
  return this.encodeTable[e] === void 0 && (this.encodeTable[e] = kr.slice(0)), this.encodeTable[e];
};
Et.prototype._setEncodeChar = function(t, e) {
  var r = this._getEncodeBucket(t), n = t & 255;
  r[n] <= _e ? this.encodeTableSeq[_e - r[n]][an] = e : r[n] == qe && (r[n] = e);
};
Et.prototype._setEncodeSequence = function(t, e) {
  var r = t[0], n = this._getEncodeBucket(r), a = r & 255, o;
  n[a] <= _e ? o = this.encodeTableSeq[_e - n[a]] : (o = {}, n[a] !== qe && (o[an] = n[a]), n[a] = _e - this.encodeTableSeq.length, this.encodeTableSeq.push(o));
  for (var s = 1; s < t.length - 1; s++) {
    var u = o[r];
    typeof u == "object" ? o = u : (o = o[r] = {}, u !== void 0 && (o[an] = u));
  }
  r = t[t.length - 1], o[r] = e;
};
Et.prototype._fillEncodeTable = function(t, e, r) {
  for (var n = this.decodeTables[t], a = 0; a < 256; a++) {
    var o = n[a], s = e + a;
    r[s] || (o >= 0 ? this._setEncodeChar(o, s) : o <= pt ? this._fillEncodeTable(pt - o, s << 8, r) : o <= _e && this._setEncodeSequence(this.decodeTableSeq[_e - o], s));
  }
};
function ai(t, e) {
  this.leadSurrogate = -1, this.seqObj = void 0, this.encodeTable = e.encodeTable, this.encodeTableSeq = e.encodeTableSeq, this.defaultCharSingleByte = e.defCharSB, this.gb18030 = e.gb18030;
}
ai.prototype.write = function(t) {
  for (var e = Ur.alloc(t.length * (this.gb18030 ? 4 : 3)), r = this.leadSurrogate, n = this.seqObj, a = -1, o = 0, s = 0; ; ) {
    if (a === -1) {
      if (o == t.length) break;
      var u = t.charCodeAt(o++);
    } else {
      var u = a;
      a = -1;
    }
    if (55296 <= u && u < 57344)
      if (u < 56320)
        if (r === -1) {
          r = u;
          continue;
        } else
          r = u, u = qe;
      else
        r !== -1 ? (u = 65536 + (r - 55296) * 1024 + (u - 56320), r = -1) : u = qe;
    else r !== -1 && (a = u, u = qe, r = -1);
    var f = qe;
    if (n !== void 0 && u != qe) {
      var l = n[u];
      if (typeof l == "object") {
        n = l;
        continue;
      } else typeof l == "number" ? f = l : l == null && (l = n[an], l !== void 0 && (f = l, a = u));
      n = void 0;
    } else if (u >= 0) {
      var c = this.encodeTable[u >> 8];
      if (c !== void 0 && (f = c[u & 255]), f <= _e) {
        n = this.encodeTableSeq[_e - f];
        continue;
      }
      if (f == qe && this.gb18030) {
        var p = no(this.gb18030.uChars, u);
        if (p != -1) {
          var f = this.gb18030.gbChars[p] + (u - this.gb18030.uChars[p]);
          e[s++] = 129 + Math.floor(f / 12600), f = f % 12600, e[s++] = 48 + Math.floor(f / 1260), f = f % 1260, e[s++] = 129 + Math.floor(f / 10), f = f % 10, e[s++] = 48 + f;
          continue;
        }
      }
    }
    f === qe && (f = this.defaultCharSingleByte), f < 256 ? e[s++] = f : f < 65536 ? (e[s++] = f >> 8, e[s++] = f & 255) : (e[s++] = f >> 16, e[s++] = f >> 8 & 255, e[s++] = f & 255);
  }
  return this.seqObj = n, this.leadSurrogate = r, e.slice(0, s);
};
ai.prototype.end = function() {
  if (!(this.leadSurrogate === -1 && this.seqObj === void 0)) {
    var t = Ur.alloc(10), e = 0;
    if (this.seqObj) {
      var r = this.seqObj[an];
      r !== void 0 && (r < 256 ? t[e++] = r : (t[e++] = r >> 8, t[e++] = r & 255)), this.seqObj = void 0;
    }
    return this.leadSurrogate !== -1 && (t[e++] = this.defaultCharSingleByte, this.leadSurrogate = -1), t.slice(0, e);
  }
};
ai.prototype.findIdx = no;
function ro(t, e) {
  this.nodeIdx = 0, this.prevBuf = Ur.alloc(0), this.decodeTables = e.decodeTables, this.decodeTableSeq = e.decodeTableSeq, this.defaultCharUnicode = e.defaultCharUnicode, this.gb18030 = e.gb18030;
}
ro.prototype.write = function(t) {
  var e = Ur.alloc(t.length * 2), r = this.nodeIdx, n = this.prevBuf, a = this.prevBuf.length, o = -this.prevBuf.length, s;
  a > 0 && (n = Ur.concat([n, t.slice(0, 10)]));
  for (var u = 0, f = 0; u < t.length; u++) {
    var l = u >= 0 ? t[u] : n[u + a], s = this.decodeTables[r][l];
    if (!(s >= 0)) if (s === qe)
      u = o, s = this.defaultCharUnicode.charCodeAt(0);
    else if (s === yf) {
      var c = o >= 0 ? t.slice(o, u + 1) : n.slice(o + a, u + 1 + a), p = (c[0] - 129) * 12600 + (c[1] - 48) * 1260 + (c[2] - 129) * 10 + (c[3] - 48), y = no(this.gb18030.gbChars, p);
      s = this.gb18030.uChars[y] + p - this.gb18030.gbChars[y];
    } else if (s <= pt) {
      r = pt - s;
      continue;
    } else if (s <= _e) {
      for (var v = this.decodeTableSeq[_e - s], m = 0; m < v.length - 1; m++)
        s = v[m], e[f++] = s & 255, e[f++] = s >> 8;
      s = v[v.length - 1];
    } else throw new Error("iconv-lite internal error: invalid decoding table value " + s + " at " + r + "/" + l);
    if (s > 65535) {
      s -= 65536;
      var w = 55296 + Math.floor(s / 1024);
      e[f++] = w & 255, e[f++] = w >> 8, s = 56320 + s % 1024;
    }
    e[f++] = s & 255, e[f++] = s >> 8, r = 0, o = u + 1;
  }
  return this.nodeIdx = r, this.prevBuf = o >= 0 ? t.slice(o) : n.slice(o + a), e.slice(0, f).toString("ucs2");
};
ro.prototype.end = function() {
  for (var t = ""; this.prevBuf.length > 0; ) {
    t += this.defaultCharUnicode;
    var e = this.prevBuf.slice(1);
    this.prevBuf = Ur.alloc(0), this.nodeIdx = 0, e.length > 0 && (t += this.write(e));
  }
  return this.nodeIdx = 0, t;
};
function no(t, e) {
  if (t[0] > e) return -1;
  for (var r = 0, n = t.length; r < n - 1; ) {
    var a = r + Math.floor((n - r + 1) / 2);
    t[a] <= e ? r = a : n = a;
  }
  return r;
}
var Kh = {
  _dbcs: Yh
}, Zh = [
  [
    "0",
    "\0",
    128
  ],
  [
    "a1",
    "｡",
    62
  ],
  [
    "8140",
    "　、。，．・：；？！゛゜´｀¨＾￣＿ヽヾゝゞ〃仝々〆〇ー―‐／＼～∥｜…‥‘’“”（）〔〕［］｛｝〈",
    9,
    "＋－±×"
  ],
  [
    "8180",
    "÷＝≠＜＞≦≧∞∴♂♀°′″℃￥＄￠￡％＃＆＊＠§☆★○●◎◇◆□■△▲▽▼※〒→←↑↓〓"
  ],
  [
    "81b8",
    "∈∋⊆⊇⊂⊃∪∩"
  ],
  [
    "81c8",
    "∧∨￢⇒⇔∀∃"
  ],
  [
    "81da",
    "∠⊥⌒∂∇≡≒≪≫√∽∝∵∫∬"
  ],
  [
    "81f0",
    "Å‰♯♭♪†‡¶"
  ],
  [
    "81fc",
    "◯"
  ],
  [
    "824f",
    "０",
    9
  ],
  [
    "8260",
    "Ａ",
    25
  ],
  [
    "8281",
    "ａ",
    25
  ],
  [
    "829f",
    "ぁ",
    82
  ],
  [
    "8340",
    "ァ",
    62
  ],
  [
    "8380",
    "ム",
    22
  ],
  [
    "839f",
    "Α",
    16,
    "Σ",
    6
  ],
  [
    "83bf",
    "α",
    16,
    "σ",
    6
  ],
  [
    "8440",
    "А",
    5,
    "ЁЖ",
    25
  ],
  [
    "8470",
    "а",
    5,
    "ёж",
    7
  ],
  [
    "8480",
    "о",
    17
  ],
  [
    "849f",
    "─│┌┐┘└├┬┤┴┼━┃┏┓┛┗┣┳┫┻╋┠┯┨┷┿┝┰┥┸╂"
  ],
  [
    "8740",
    "①",
    19,
    "Ⅰ",
    9
  ],
  [
    "875f",
    "㍉㌔㌢㍍㌘㌧㌃㌶㍑㍗㌍㌦㌣㌫㍊㌻㎜㎝㎞㎎㎏㏄㎡"
  ],
  [
    "877e",
    "㍻"
  ],
  [
    "8780",
    "〝〟№㏍℡㊤",
    4,
    "㈱㈲㈹㍾㍽㍼≒≡∫∮∑√⊥∠∟⊿∵∩∪"
  ],
  [
    "889f",
    "亜唖娃阿哀愛挨姶逢葵茜穐悪握渥旭葦芦鯵梓圧斡扱宛姐虻飴絢綾鮎或粟袷安庵按暗案闇鞍杏以伊位依偉囲夷委威尉惟意慰易椅為畏異移維緯胃萎衣謂違遺医井亥域育郁磯一壱溢逸稲茨芋鰯允印咽員因姻引飲淫胤蔭"
  ],
  [
    "8940",
    "院陰隠韻吋右宇烏羽迂雨卯鵜窺丑碓臼渦嘘唄欝蔚鰻姥厩浦瓜閏噂云運雲荏餌叡営嬰影映曳栄永泳洩瑛盈穎頴英衛詠鋭液疫益駅悦謁越閲榎厭円"
  ],
  [
    "8980",
    "園堰奄宴延怨掩援沿演炎焔煙燕猿縁艶苑薗遠鉛鴛塩於汚甥凹央奥往応押旺横欧殴王翁襖鴬鴎黄岡沖荻億屋憶臆桶牡乙俺卸恩温穏音下化仮何伽価佳加可嘉夏嫁家寡科暇果架歌河火珂禍禾稼箇花苛茄荷華菓蝦課嘩貨迦過霞蚊俄峨我牙画臥芽蛾賀雅餓駕介会解回塊壊廻快怪悔恢懐戒拐改"
  ],
  [
    "8a40",
    "魁晦械海灰界皆絵芥蟹開階貝凱劾外咳害崖慨概涯碍蓋街該鎧骸浬馨蛙垣柿蛎鈎劃嚇各廓拡撹格核殻獲確穫覚角赫較郭閣隔革学岳楽額顎掛笠樫"
  ],
  [
    "8a80",
    "橿梶鰍潟割喝恰括活渇滑葛褐轄且鰹叶椛樺鞄株兜竃蒲釜鎌噛鴨栢茅萱粥刈苅瓦乾侃冠寒刊勘勧巻喚堪姦完官寛干幹患感慣憾換敢柑桓棺款歓汗漢澗潅環甘監看竿管簡緩缶翰肝艦莞観諌貫還鑑間閑関陥韓館舘丸含岸巌玩癌眼岩翫贋雁頑顔願企伎危喜器基奇嬉寄岐希幾忌揮机旗既期棋棄"
  ],
  [
    "8b40",
    "機帰毅気汽畿祈季稀紀徽規記貴起軌輝飢騎鬼亀偽儀妓宜戯技擬欺犠疑祇義蟻誼議掬菊鞠吉吃喫桔橘詰砧杵黍却客脚虐逆丘久仇休及吸宮弓急救"
  ],
  [
    "8b80",
    "朽求汲泣灸球究窮笈級糾給旧牛去居巨拒拠挙渠虚許距鋸漁禦魚亨享京供侠僑兇競共凶協匡卿叫喬境峡強彊怯恐恭挟教橋況狂狭矯胸脅興蕎郷鏡響饗驚仰凝尭暁業局曲極玉桐粁僅勤均巾錦斤欣欽琴禁禽筋緊芹菌衿襟謹近金吟銀九倶句区狗玖矩苦躯駆駈駒具愚虞喰空偶寓遇隅串櫛釧屑屈"
  ],
  [
    "8c40",
    "掘窟沓靴轡窪熊隈粂栗繰桑鍬勲君薫訓群軍郡卦袈祁係傾刑兄啓圭珪型契形径恵慶慧憩掲携敬景桂渓畦稽系経継繋罫茎荊蛍計詣警軽頚鶏芸迎鯨"
  ],
  [
    "8c80",
    "劇戟撃激隙桁傑欠決潔穴結血訣月件倹倦健兼券剣喧圏堅嫌建憲懸拳捲検権牽犬献研硯絹県肩見謙賢軒遣鍵険顕験鹸元原厳幻弦減源玄現絃舷言諺限乎個古呼固姑孤己庫弧戸故枯湖狐糊袴股胡菰虎誇跨鈷雇顧鼓五互伍午呉吾娯後御悟梧檎瑚碁語誤護醐乞鯉交佼侯候倖光公功効勾厚口向"
  ],
  [
    "8d40",
    "后喉坑垢好孔孝宏工巧巷幸広庚康弘恒慌抗拘控攻昂晃更杭校梗構江洪浩港溝甲皇硬稿糠紅紘絞綱耕考肯肱腔膏航荒行衡講貢購郊酵鉱砿鋼閤降"
  ],
  [
    "8d80",
    "項香高鴻剛劫号合壕拷濠豪轟麹克刻告国穀酷鵠黒獄漉腰甑忽惚骨狛込此頃今困坤墾婚恨懇昏昆根梱混痕紺艮魂些佐叉唆嵯左差査沙瑳砂詐鎖裟坐座挫債催再最哉塞妻宰彩才採栽歳済災采犀砕砦祭斎細菜裁載際剤在材罪財冴坂阪堺榊肴咲崎埼碕鷺作削咋搾昨朔柵窄策索錯桜鮭笹匙冊刷"
  ],
  [
    "8e40",
    "察拶撮擦札殺薩雑皐鯖捌錆鮫皿晒三傘参山惨撒散桟燦珊産算纂蚕讃賛酸餐斬暫残仕仔伺使刺司史嗣四士始姉姿子屍市師志思指支孜斯施旨枝止"
  ],
  [
    "8e80",
    "死氏獅祉私糸紙紫肢脂至視詞詩試誌諮資賜雌飼歯事似侍児字寺慈持時次滋治爾璽痔磁示而耳自蒔辞汐鹿式識鴫竺軸宍雫七叱執失嫉室悉湿漆疾質実蔀篠偲柴芝屡蕊縞舎写射捨赦斜煮社紗者謝車遮蛇邪借勺尺杓灼爵酌釈錫若寂弱惹主取守手朱殊狩珠種腫趣酒首儒受呪寿授樹綬需囚収周"
  ],
  [
    "8f40",
    "宗就州修愁拾洲秀秋終繍習臭舟蒐衆襲讐蹴輯週酋酬集醜什住充十従戎柔汁渋獣縦重銃叔夙宿淑祝縮粛塾熟出術述俊峻春瞬竣舜駿准循旬楯殉淳"
  ],
  [
    "8f80",
    "準潤盾純巡遵醇順処初所暑曙渚庶緒署書薯藷諸助叙女序徐恕鋤除傷償勝匠升召哨商唱嘗奨妾娼宵将小少尚庄床廠彰承抄招掌捷昇昌昭晶松梢樟樵沼消渉湘焼焦照症省硝礁祥称章笑粧紹肖菖蒋蕉衝裳訟証詔詳象賞醤鉦鍾鐘障鞘上丈丞乗冗剰城場壌嬢常情擾条杖浄状畳穣蒸譲醸錠嘱埴飾"
  ],
  [
    "9040",
    "拭植殖燭織職色触食蝕辱尻伸信侵唇娠寝審心慎振新晋森榛浸深申疹真神秦紳臣芯薪親診身辛進針震人仁刃塵壬尋甚尽腎訊迅陣靭笥諏須酢図厨"
  ],
  [
    "9080",
    "逗吹垂帥推水炊睡粋翠衰遂酔錐錘随瑞髄崇嵩数枢趨雛据杉椙菅頗雀裾澄摺寸世瀬畝是凄制勢姓征性成政整星晴棲栖正清牲生盛精聖声製西誠誓請逝醒青静斉税脆隻席惜戚斥昔析石積籍績脊責赤跡蹟碩切拙接摂折設窃節説雪絶舌蝉仙先千占宣専尖川戦扇撰栓栴泉浅洗染潜煎煽旋穿箭線"
  ],
  [
    "9140",
    "繊羨腺舛船薦詮賎践選遷銭銑閃鮮前善漸然全禅繕膳糎噌塑岨措曾曽楚狙疏疎礎祖租粗素組蘇訴阻遡鼠僧創双叢倉喪壮奏爽宋層匝惣想捜掃挿掻"
  ],
  [
    "9180",
    "操早曹巣槍槽漕燥争痩相窓糟総綜聡草荘葬蒼藻装走送遭鎗霜騒像増憎臓蔵贈造促側則即息捉束測足速俗属賊族続卒袖其揃存孫尊損村遜他多太汰詑唾堕妥惰打柁舵楕陀駄騨体堆対耐岱帯待怠態戴替泰滞胎腿苔袋貸退逮隊黛鯛代台大第醍題鷹滝瀧卓啄宅托択拓沢濯琢託鐸濁諾茸凧蛸只"
  ],
  [
    "9240",
    "叩但達辰奪脱巽竪辿棚谷狸鱈樽誰丹単嘆坦担探旦歎淡湛炭短端箪綻耽胆蛋誕鍛団壇弾断暖檀段男談値知地弛恥智池痴稚置致蜘遅馳築畜竹筑蓄"
  ],
  [
    "9280",
    "逐秩窒茶嫡着中仲宙忠抽昼柱注虫衷註酎鋳駐樗瀦猪苧著貯丁兆凋喋寵帖帳庁弔張彫徴懲挑暢朝潮牒町眺聴脹腸蝶調諜超跳銚長頂鳥勅捗直朕沈珍賃鎮陳津墜椎槌追鎚痛通塚栂掴槻佃漬柘辻蔦綴鍔椿潰坪壷嬬紬爪吊釣鶴亭低停偵剃貞呈堤定帝底庭廷弟悌抵挺提梯汀碇禎程締艇訂諦蹄逓"
  ],
  [
    "9340",
    "邸鄭釘鼎泥摘擢敵滴的笛適鏑溺哲徹撤轍迭鉄典填天展店添纏甜貼転顛点伝殿澱田電兎吐堵塗妬屠徒斗杜渡登菟賭途都鍍砥砺努度土奴怒倒党冬"
  ],
  [
    "9380",
    "凍刀唐塔塘套宕島嶋悼投搭東桃梼棟盗淘湯涛灯燈当痘祷等答筒糖統到董蕩藤討謄豆踏逃透鐙陶頭騰闘働動同堂導憧撞洞瞳童胴萄道銅峠鴇匿得徳涜特督禿篤毒独読栃橡凸突椴届鳶苫寅酉瀞噸屯惇敦沌豚遁頓呑曇鈍奈那内乍凪薙謎灘捺鍋楢馴縄畷南楠軟難汝二尼弐迩匂賑肉虹廿日乳入"
  ],
  [
    "9440",
    "如尿韮任妊忍認濡禰祢寧葱猫熱年念捻撚燃粘乃廼之埜嚢悩濃納能脳膿農覗蚤巴把播覇杷波派琶破婆罵芭馬俳廃拝排敗杯盃牌背肺輩配倍培媒梅"
  ],
  [
    "9480",
    "楳煤狽買売賠陪這蝿秤矧萩伯剥博拍柏泊白箔粕舶薄迫曝漠爆縛莫駁麦函箱硲箸肇筈櫨幡肌畑畠八鉢溌発醗髪伐罰抜筏閥鳩噺塙蛤隼伴判半反叛帆搬斑板氾汎版犯班畔繁般藩販範釆煩頒飯挽晩番盤磐蕃蛮匪卑否妃庇彼悲扉批披斐比泌疲皮碑秘緋罷肥被誹費避非飛樋簸備尾微枇毘琵眉美"
  ],
  [
    "9540",
    "鼻柊稗匹疋髭彦膝菱肘弼必畢筆逼桧姫媛紐百謬俵彪標氷漂瓢票表評豹廟描病秒苗錨鋲蒜蛭鰭品彬斌浜瀕貧賓頻敏瓶不付埠夫婦富冨布府怖扶敷"
  ],
  [
    "9580",
    "斧普浮父符腐膚芙譜負賦赴阜附侮撫武舞葡蕪部封楓風葺蕗伏副復幅服福腹複覆淵弗払沸仏物鮒分吻噴墳憤扮焚奮粉糞紛雰文聞丙併兵塀幣平弊柄並蔽閉陛米頁僻壁癖碧別瞥蔑箆偏変片篇編辺返遍便勉娩弁鞭保舗鋪圃捕歩甫補輔穂募墓慕戊暮母簿菩倣俸包呆報奉宝峰峯崩庖抱捧放方朋"
  ],
  [
    "9640",
    "法泡烹砲縫胞芳萌蓬蜂褒訪豊邦鋒飽鳳鵬乏亡傍剖坊妨帽忘忙房暴望某棒冒紡肪膨謀貌貿鉾防吠頬北僕卜墨撲朴牧睦穆釦勃没殆堀幌奔本翻凡盆"
  ],
  [
    "9680",
    "摩磨魔麻埋妹昧枚毎哩槙幕膜枕鮪柾鱒桝亦俣又抹末沫迄侭繭麿万慢満漫蔓味未魅巳箕岬密蜜湊蓑稔脈妙粍民眠務夢無牟矛霧鵡椋婿娘冥名命明盟迷銘鳴姪牝滅免棉綿緬面麺摸模茂妄孟毛猛盲網耗蒙儲木黙目杢勿餅尤戻籾貰問悶紋門匁也冶夜爺耶野弥矢厄役約薬訳躍靖柳薮鑓愉愈油癒"
  ],
  [
    "9740",
    "諭輸唯佑優勇友宥幽悠憂揖有柚湧涌猶猷由祐裕誘遊邑郵雄融夕予余与誉輿預傭幼妖容庸揚揺擁曜楊様洋溶熔用窯羊耀葉蓉要謡踊遥陽養慾抑欲"
  ],
  [
    "9780",
    "沃浴翌翼淀羅螺裸来莱頼雷洛絡落酪乱卵嵐欄濫藍蘭覧利吏履李梨理璃痢裏裡里離陸律率立葎掠略劉流溜琉留硫粒隆竜龍侶慮旅虜了亮僚両凌寮料梁涼猟療瞭稜糧良諒遼量陵領力緑倫厘林淋燐琳臨輪隣鱗麟瑠塁涙累類令伶例冷励嶺怜玲礼苓鈴隷零霊麗齢暦歴列劣烈裂廉恋憐漣煉簾練聯"
  ],
  [
    "9840",
    "蓮連錬呂魯櫓炉賂路露労婁廊弄朗楼榔浪漏牢狼篭老聾蝋郎六麓禄肋録論倭和話歪賄脇惑枠鷲亙亘鰐詫藁蕨椀湾碗腕"
  ],
  [
    "989f",
    "弌丐丕个丱丶丼丿乂乖乘亂亅豫亊舒弍于亞亟亠亢亰亳亶从仍仄仆仂仗仞仭仟价伉佚估佛佝佗佇佶侈侏侘佻佩佰侑佯來侖儘俔俟俎俘俛俑俚俐俤俥倚倨倔倪倥倅伜俶倡倩倬俾俯們倆偃假會偕偐偈做偖偬偸傀傚傅傴傲"
  ],
  [
    "9940",
    "僉僊傳僂僖僞僥僭僣僮價僵儉儁儂儖儕儔儚儡儺儷儼儻儿兀兒兌兔兢竸兩兪兮冀冂囘册冉冏冑冓冕冖冤冦冢冩冪冫决冱冲冰况冽凅凉凛几處凩凭"
  ],
  [
    "9980",
    "凰凵凾刄刋刔刎刧刪刮刳刹剏剄剋剌剞剔剪剴剩剳剿剽劍劔劒剱劈劑辨辧劬劭劼劵勁勍勗勞勣勦飭勠勳勵勸勹匆匈甸匍匐匏匕匚匣匯匱匳匸區卆卅丗卉卍凖卞卩卮夘卻卷厂厖厠厦厥厮厰厶參簒雙叟曼燮叮叨叭叺吁吽呀听吭吼吮吶吩吝呎咏呵咎呟呱呷呰咒呻咀呶咄咐咆哇咢咸咥咬哄哈咨"
  ],
  [
    "9a40",
    "咫哂咤咾咼哘哥哦唏唔哽哮哭哺哢唹啀啣啌售啜啅啖啗唸唳啝喙喀咯喊喟啻啾喘喞單啼喃喩喇喨嗚嗅嗟嗄嗜嗤嗔嘔嗷嘖嗾嗽嘛嗹噎噐營嘴嘶嘲嘸"
  ],
  [
    "9a80",
    "噫噤嘯噬噪嚆嚀嚊嚠嚔嚏嚥嚮嚶嚴囂嚼囁囃囀囈囎囑囓囗囮囹圀囿圄圉圈國圍圓團圖嗇圜圦圷圸坎圻址坏坩埀垈坡坿垉垓垠垳垤垪垰埃埆埔埒埓堊埖埣堋堙堝塲堡塢塋塰毀塒堽塹墅墹墟墫墺壞墻墸墮壅壓壑壗壙壘壥壜壤壟壯壺壹壻壼壽夂夊夐夛梦夥夬夭夲夸夾竒奕奐奎奚奘奢奠奧奬奩"
  ],
  [
    "9b40",
    "奸妁妝佞侫妣妲姆姨姜妍姙姚娥娟娑娜娉娚婀婬婉娵娶婢婪媚媼媾嫋嫂媽嫣嫗嫦嫩嫖嫺嫻嬌嬋嬖嬲嫐嬪嬶嬾孃孅孀孑孕孚孛孥孩孰孳孵學斈孺宀"
  ],
  [
    "9b80",
    "它宦宸寃寇寉寔寐寤實寢寞寥寫寰寶寳尅將專對尓尠尢尨尸尹屁屆屎屓屐屏孱屬屮乢屶屹岌岑岔妛岫岻岶岼岷峅岾峇峙峩峽峺峭嶌峪崋崕崗嵜崟崛崑崔崢崚崙崘嵌嵒嵎嵋嵬嵳嵶嶇嶄嶂嶢嶝嶬嶮嶽嶐嶷嶼巉巍巓巒巖巛巫已巵帋帚帙帑帛帶帷幄幃幀幎幗幔幟幢幤幇幵并幺麼广庠廁廂廈廐廏"
  ],
  [
    "9c40",
    "廖廣廝廚廛廢廡廨廩廬廱廳廰廴廸廾弃弉彝彜弋弑弖弩弭弸彁彈彌彎弯彑彖彗彙彡彭彳彷徃徂彿徊很徑徇從徙徘徠徨徭徼忖忻忤忸忱忝悳忿怡恠"
  ],
  [
    "9c80",
    "怙怐怩怎怱怛怕怫怦怏怺恚恁恪恷恟恊恆恍恣恃恤恂恬恫恙悁悍惧悃悚悄悛悖悗悒悧悋惡悸惠惓悴忰悽惆悵惘慍愕愆惶惷愀惴惺愃愡惻惱愍愎慇愾愨愧慊愿愼愬愴愽慂慄慳慷慘慙慚慫慴慯慥慱慟慝慓慵憙憖憇憬憔憚憊憑憫憮懌懊應懷懈懃懆憺懋罹懍懦懣懶懺懴懿懽懼懾戀戈戉戍戌戔戛"
  ],
  [
    "9d40",
    "戞戡截戮戰戲戳扁扎扞扣扛扠扨扼抂抉找抒抓抖拔抃抔拗拑抻拏拿拆擔拈拜拌拊拂拇抛拉挌拮拱挧挂挈拯拵捐挾捍搜捏掖掎掀掫捶掣掏掉掟掵捫"
  ],
  [
    "9d80",
    "捩掾揩揀揆揣揉插揶揄搖搴搆搓搦搶攝搗搨搏摧摯摶摎攪撕撓撥撩撈撼據擒擅擇撻擘擂擱擧舉擠擡抬擣擯攬擶擴擲擺攀擽攘攜攅攤攣攫攴攵攷收攸畋效敖敕敍敘敞敝敲數斂斃變斛斟斫斷旃旆旁旄旌旒旛旙无旡旱杲昊昃旻杳昵昶昴昜晏晄晉晁晞晝晤晧晨晟晢晰暃暈暎暉暄暘暝曁暹曉暾暼"
  ],
  [
    "9e40",
    "曄暸曖曚曠昿曦曩曰曵曷朏朖朞朦朧霸朮朿朶杁朸朷杆杞杠杙杣杤枉杰枩杼杪枌枋枦枡枅枷柯枴柬枳柩枸柤柞柝柢柮枹柎柆柧檜栞框栩桀桍栲桎"
  ],
  [
    "9e80",
    "梳栫桙档桷桿梟梏梭梔條梛梃檮梹桴梵梠梺椏梍桾椁棊椈棘椢椦棡椌棍棔棧棕椶椒椄棗棣椥棹棠棯椨椪椚椣椡棆楹楷楜楸楫楔楾楮椹楴椽楙椰楡楞楝榁楪榲榮槐榿槁槓榾槎寨槊槝榻槃榧樮榑榠榜榕榴槞槨樂樛槿權槹槲槧樅榱樞槭樔槫樊樒櫁樣樓橄樌橲樶橸橇橢橙橦橈樸樢檐檍檠檄檢檣"
  ],
  [
    "9f40",
    "檗蘗檻櫃櫂檸檳檬櫞櫑櫟檪櫚櫪櫻欅蘖櫺欒欖鬱欟欸欷盜欹飮歇歃歉歐歙歔歛歟歡歸歹歿殀殄殃殍殘殕殞殤殪殫殯殲殱殳殷殼毆毋毓毟毬毫毳毯"
  ],
  [
    "9f80",
    "麾氈氓气氛氤氣汞汕汢汪沂沍沚沁沛汾汨汳沒沐泄泱泓沽泗泅泝沮沱沾沺泛泯泙泪洟衍洶洫洽洸洙洵洳洒洌浣涓浤浚浹浙涎涕濤涅淹渕渊涵淇淦涸淆淬淞淌淨淒淅淺淙淤淕淪淮渭湮渮渙湲湟渾渣湫渫湶湍渟湃渺湎渤滿渝游溂溪溘滉溷滓溽溯滄溲滔滕溏溥滂溟潁漑灌滬滸滾漿滲漱滯漲滌"
  ],
  [
    "e040",
    "漾漓滷澆潺潸澁澀潯潛濳潭澂潼潘澎澑濂潦澳澣澡澤澹濆澪濟濕濬濔濘濱濮濛瀉瀋濺瀑瀁瀏濾瀛瀚潴瀝瀘瀟瀰瀾瀲灑灣炙炒炯烱炬炸炳炮烟烋烝"
  ],
  [
    "e080",
    "烙焉烽焜焙煥煕熈煦煢煌煖煬熏燻熄熕熨熬燗熹熾燒燉燔燎燠燬燧燵燼燹燿爍爐爛爨爭爬爰爲爻爼爿牀牆牋牘牴牾犂犁犇犒犖犢犧犹犲狃狆狄狎狒狢狠狡狹狷倏猗猊猜猖猝猴猯猩猥猾獎獏默獗獪獨獰獸獵獻獺珈玳珎玻珀珥珮珞璢琅瑯琥珸琲琺瑕琿瑟瑙瑁瑜瑩瑰瑣瑪瑶瑾璋璞璧瓊瓏瓔珱"
  ],
  [
    "e140",
    "瓠瓣瓧瓩瓮瓲瓰瓱瓸瓷甄甃甅甌甎甍甕甓甞甦甬甼畄畍畊畉畛畆畚畩畤畧畫畭畸當疆疇畴疊疉疂疔疚疝疥疣痂疳痃疵疽疸疼疱痍痊痒痙痣痞痾痿"
  ],
  [
    "e180",
    "痼瘁痰痺痲痳瘋瘍瘉瘟瘧瘠瘡瘢瘤瘴瘰瘻癇癈癆癜癘癡癢癨癩癪癧癬癰癲癶癸發皀皃皈皋皎皖皓皙皚皰皴皸皹皺盂盍盖盒盞盡盥盧盪蘯盻眈眇眄眩眤眞眥眦眛眷眸睇睚睨睫睛睥睿睾睹瞎瞋瞑瞠瞞瞰瞶瞹瞿瞼瞽瞻矇矍矗矚矜矣矮矼砌砒礦砠礪硅碎硴碆硼碚碌碣碵碪碯磑磆磋磔碾碼磅磊磬"
  ],
  [
    "e240",
    "磧磚磽磴礇礒礑礙礬礫祀祠祗祟祚祕祓祺祿禊禝禧齋禪禮禳禹禺秉秕秧秬秡秣稈稍稘稙稠稟禀稱稻稾稷穃穗穉穡穢穩龝穰穹穽窈窗窕窘窖窩竈窰"
  ],
  [
    "e280",
    "窶竅竄窿邃竇竊竍竏竕竓站竚竝竡竢竦竭竰笂笏笊笆笳笘笙笞笵笨笶筐筺笄筍笋筌筅筵筥筴筧筰筱筬筮箝箘箟箍箜箚箋箒箏筝箙篋篁篌篏箴篆篝篩簑簔篦篥籠簀簇簓篳篷簗簍篶簣簧簪簟簷簫簽籌籃籔籏籀籐籘籟籤籖籥籬籵粃粐粤粭粢粫粡粨粳粲粱粮粹粽糀糅糂糘糒糜糢鬻糯糲糴糶糺紆"
  ],
  [
    "e340",
    "紂紜紕紊絅絋紮紲紿紵絆絳絖絎絲絨絮絏絣經綉絛綏絽綛綺綮綣綵緇綽綫總綢綯緜綸綟綰緘緝緤緞緻緲緡縅縊縣縡縒縱縟縉縋縢繆繦縻縵縹繃縷"
  ],
  [
    "e380",
    "縲縺繧繝繖繞繙繚繹繪繩繼繻纃緕繽辮繿纈纉續纒纐纓纔纖纎纛纜缸缺罅罌罍罎罐网罕罔罘罟罠罨罩罧罸羂羆羃羈羇羌羔羞羝羚羣羯羲羹羮羶羸譱翅翆翊翕翔翡翦翩翳翹飜耆耄耋耒耘耙耜耡耨耿耻聊聆聒聘聚聟聢聨聳聲聰聶聹聽聿肄肆肅肛肓肚肭冐肬胛胥胙胝胄胚胖脉胯胱脛脩脣脯腋"
  ],
  [
    "e440",
    "隋腆脾腓腑胼腱腮腥腦腴膃膈膊膀膂膠膕膤膣腟膓膩膰膵膾膸膽臀臂膺臉臍臑臙臘臈臚臟臠臧臺臻臾舁舂舅與舊舍舐舖舩舫舸舳艀艙艘艝艚艟艤"
  ],
  [
    "e480",
    "艢艨艪艫舮艱艷艸艾芍芒芫芟芻芬苡苣苟苒苴苳苺莓范苻苹苞茆苜茉苙茵茴茖茲茱荀茹荐荅茯茫茗茘莅莚莪莟莢莖茣莎莇莊荼莵荳荵莠莉莨菴萓菫菎菽萃菘萋菁菷萇菠菲萍萢萠莽萸蔆菻葭萪萼蕚蒄葷葫蒭葮蒂葩葆萬葯葹萵蓊葢蒹蒿蒟蓙蓍蒻蓚蓐蓁蓆蓖蒡蔡蓿蓴蔗蔘蔬蔟蔕蔔蓼蕀蕣蕘蕈"
  ],
  [
    "e540",
    "蕁蘂蕋蕕薀薤薈薑薊薨蕭薔薛藪薇薜蕷蕾薐藉薺藏薹藐藕藝藥藜藹蘊蘓蘋藾藺蘆蘢蘚蘰蘿虍乕虔號虧虱蚓蚣蚩蚪蚋蚌蚶蚯蛄蛆蚰蛉蠣蚫蛔蛞蛩蛬"
  ],
  [
    "e580",
    "蛟蛛蛯蜒蜆蜈蜀蜃蛻蜑蜉蜍蛹蜊蜴蜿蜷蜻蜥蜩蜚蝠蝟蝸蝌蝎蝴蝗蝨蝮蝙蝓蝣蝪蠅螢螟螂螯蟋螽蟀蟐雖螫蟄螳蟇蟆螻蟯蟲蟠蠏蠍蟾蟶蟷蠎蟒蠑蠖蠕蠢蠡蠱蠶蠹蠧蠻衄衂衒衙衞衢衫袁衾袞衵衽袵衲袂袗袒袮袙袢袍袤袰袿袱裃裄裔裘裙裝裹褂裼裴裨裲褄褌褊褓襃褞褥褪褫襁襄褻褶褸襌褝襠襞"
  ],
  [
    "e640",
    "襦襤襭襪襯襴襷襾覃覈覊覓覘覡覩覦覬覯覲覺覽覿觀觚觜觝觧觴觸訃訖訐訌訛訝訥訶詁詛詒詆詈詼詭詬詢誅誂誄誨誡誑誥誦誚誣諄諍諂諚諫諳諧"
  ],
  [
    "e680",
    "諤諱謔諠諢諷諞諛謌謇謚諡謖謐謗謠謳鞫謦謫謾謨譁譌譏譎證譖譛譚譫譟譬譯譴譽讀讌讎讒讓讖讙讚谺豁谿豈豌豎豐豕豢豬豸豺貂貉貅貊貍貎貔豼貘戝貭貪貽貲貳貮貶賈賁賤賣賚賽賺賻贄贅贊贇贏贍贐齎贓賍贔贖赧赭赱赳趁趙跂趾趺跏跚跖跌跛跋跪跫跟跣跼踈踉跿踝踞踐踟蹂踵踰踴蹊"
  ],
  [
    "e740",
    "蹇蹉蹌蹐蹈蹙蹤蹠踪蹣蹕蹶蹲蹼躁躇躅躄躋躊躓躑躔躙躪躡躬躰軆躱躾軅軈軋軛軣軼軻軫軾輊輅輕輒輙輓輜輟輛輌輦輳輻輹轅轂輾轌轉轆轎轗轜"
  ],
  [
    "e780",
    "轢轣轤辜辟辣辭辯辷迚迥迢迪迯邇迴逅迹迺逑逕逡逍逞逖逋逧逶逵逹迸遏遐遑遒逎遉逾遖遘遞遨遯遶隨遲邂遽邁邀邊邉邏邨邯邱邵郢郤扈郛鄂鄒鄙鄲鄰酊酖酘酣酥酩酳酲醋醉醂醢醫醯醪醵醴醺釀釁釉釋釐釖釟釡釛釼釵釶鈞釿鈔鈬鈕鈑鉞鉗鉅鉉鉤鉈銕鈿鉋鉐銜銖銓銛鉚鋏銹銷鋩錏鋺鍄錮"
  ],
  [
    "e840",
    "錙錢錚錣錺錵錻鍜鍠鍼鍮鍖鎰鎬鎭鎔鎹鏖鏗鏨鏥鏘鏃鏝鏐鏈鏤鐚鐔鐓鐃鐇鐐鐶鐫鐵鐡鐺鑁鑒鑄鑛鑠鑢鑞鑪鈩鑰鑵鑷鑽鑚鑼鑾钁鑿閂閇閊閔閖閘閙"
  ],
  [
    "e880",
    "閠閨閧閭閼閻閹閾闊濶闃闍闌闕闔闖關闡闥闢阡阨阮阯陂陌陏陋陷陜陞陝陟陦陲陬隍隘隕隗險隧隱隲隰隴隶隸隹雎雋雉雍襍雜霍雕雹霄霆霈霓霎霑霏霖霙霤霪霰霹霽霾靄靆靈靂靉靜靠靤靦靨勒靫靱靹鞅靼鞁靺鞆鞋鞏鞐鞜鞨鞦鞣鞳鞴韃韆韈韋韜韭齏韲竟韶韵頏頌頸頤頡頷頽顆顏顋顫顯顰"
  ],
  [
    "e940",
    "顱顴顳颪颯颱颶飄飃飆飩飫餃餉餒餔餘餡餝餞餤餠餬餮餽餾饂饉饅饐饋饑饒饌饕馗馘馥馭馮馼駟駛駝駘駑駭駮駱駲駻駸騁騏騅駢騙騫騷驅驂驀驃"
  ],
  [
    "e980",
    "騾驕驍驛驗驟驢驥驤驩驫驪骭骰骼髀髏髑髓體髞髟髢髣髦髯髫髮髴髱髷髻鬆鬘鬚鬟鬢鬣鬥鬧鬨鬩鬪鬮鬯鬲魄魃魏魍魎魑魘魴鮓鮃鮑鮖鮗鮟鮠鮨鮴鯀鯊鮹鯆鯏鯑鯒鯣鯢鯤鯔鯡鰺鯲鯱鯰鰕鰔鰉鰓鰌鰆鰈鰒鰊鰄鰮鰛鰥鰤鰡鰰鱇鰲鱆鰾鱚鱠鱧鱶鱸鳧鳬鳰鴉鴈鳫鴃鴆鴪鴦鶯鴣鴟鵄鴕鴒鵁鴿鴾鵆鵈"
  ],
  [
    "ea40",
    "鵝鵞鵤鵑鵐鵙鵲鶉鶇鶫鵯鵺鶚鶤鶩鶲鷄鷁鶻鶸鶺鷆鷏鷂鷙鷓鷸鷦鷭鷯鷽鸚鸛鸞鹵鹹鹽麁麈麋麌麒麕麑麝麥麩麸麪麭靡黌黎黏黐黔黜點黝黠黥黨黯"
  ],
  [
    "ea80",
    "黴黶黷黹黻黼黽鼇鼈皷鼕鼡鼬鼾齊齒齔齣齟齠齡齦齧齬齪齷齲齶龕龜龠堯槇遙瑤凜熙"
  ],
  [
    "ed40",
    "纊褜鍈銈蓜俉炻昱棈鋹曻彅丨仡仼伀伃伹佖侒侊侚侔俍偀倢俿倞偆偰偂傔僴僘兊兤冝冾凬刕劜劦勀勛匀匇匤卲厓厲叝﨎咜咊咩哿喆坙坥垬埈埇﨏"
  ],
  [
    "ed80",
    "塚增墲夋奓奛奝奣妤妺孖寀甯寘寬尞岦岺峵崧嵓﨑嵂嵭嶸嶹巐弡弴彧德忞恝悅悊惞惕愠惲愑愷愰憘戓抦揵摠撝擎敎昀昕昻昉昮昞昤晥晗晙晴晳暙暠暲暿曺朎朗杦枻桒柀栁桄棏﨓楨﨔榘槢樰橫橆橳橾櫢櫤毖氿汜沆汯泚洄涇浯涖涬淏淸淲淼渹湜渧渼溿澈澵濵瀅瀇瀨炅炫焏焄煜煆煇凞燁燾犱"
  ],
  [
    "ee40",
    "犾猤猪獷玽珉珖珣珒琇珵琦琪琩琮瑢璉璟甁畯皂皜皞皛皦益睆劯砡硎硤硺礰礼神祥禔福禛竑竧靖竫箞精絈絜綷綠緖繒罇羡羽茁荢荿菇菶葈蒴蕓蕙"
  ],
  [
    "ee80",
    "蕫﨟薰蘒﨡蠇裵訒訷詹誧誾諟諸諶譓譿賰賴贒赶﨣軏﨤逸遧郞都鄕鄧釚釗釞釭釮釤釥鈆鈐鈊鈺鉀鈼鉎鉙鉑鈹鉧銧鉷鉸鋧鋗鋙鋐﨧鋕鋠鋓錥錡鋻﨨錞鋿錝錂鍰鍗鎤鏆鏞鏸鐱鑅鑈閒隆﨩隝隯霳霻靃靍靏靑靕顗顥飯飼餧館馞驎髙髜魵魲鮏鮱鮻鰀鵰鵫鶴鸙黑"
  ],
  [
    "eeef",
    "ⅰ",
    9,
    "￢￤＇＂"
  ],
  [
    "f040",
    "",
    62
  ],
  [
    "f080",
    "",
    124
  ],
  [
    "f140",
    "",
    62
  ],
  [
    "f180",
    "",
    124
  ],
  [
    "f240",
    "",
    62
  ],
  [
    "f280",
    "",
    124
  ],
  [
    "f340",
    "",
    62
  ],
  [
    "f380",
    "",
    124
  ],
  [
    "f440",
    "",
    62
  ],
  [
    "f480",
    "",
    124
  ],
  [
    "f540",
    "",
    62
  ],
  [
    "f580",
    "",
    124
  ],
  [
    "f640",
    "",
    62
  ],
  [
    "f680",
    "",
    124
  ],
  [
    "f740",
    "",
    62
  ],
  [
    "f780",
    "",
    124
  ],
  [
    "f840",
    "",
    62
  ],
  [
    "f880",
    "",
    124
  ],
  [
    "f940",
    ""
  ],
  [
    "fa40",
    "ⅰ",
    9,
    "Ⅰ",
    9,
    "￢￤＇＂㈱№℡∵纊褜鍈銈蓜俉炻昱棈鋹曻彅丨仡仼伀伃伹佖侒侊侚侔俍偀倢俿倞偆偰偂傔僴僘兊"
  ],
  [
    "fa80",
    "兤冝冾凬刕劜劦勀勛匀匇匤卲厓厲叝﨎咜咊咩哿喆坙坥垬埈埇﨏塚增墲夋奓奛奝奣妤妺孖寀甯寘寬尞岦岺峵崧嵓﨑嵂嵭嶸嶹巐弡弴彧德忞恝悅悊惞惕愠惲愑愷愰憘戓抦揵摠撝擎敎昀昕昻昉昮昞昤晥晗晙晴晳暙暠暲暿曺朎朗杦枻桒柀栁桄棏﨓楨﨔榘槢樰橫橆橳橾櫢櫤毖氿汜沆汯泚洄涇浯"
  ],
  [
    "fb40",
    "涖涬淏淸淲淼渹湜渧渼溿澈澵濵瀅瀇瀨炅炫焏焄煜煆煇凞燁燾犱犾猤猪獷玽珉珖珣珒琇珵琦琪琩琮瑢璉璟甁畯皂皜皞皛皦益睆劯砡硎硤硺礰礼神"
  ],
  [
    "fb80",
    "祥禔福禛竑竧靖竫箞精絈絜綷綠緖繒罇羡羽茁荢荿菇菶葈蒴蕓蕙蕫﨟薰蘒﨡蠇裵訒訷詹誧誾諟諸諶譓譿賰賴贒赶﨣軏﨤逸遧郞都鄕鄧釚釗釞釭釮釤釥鈆鈐鈊鈺鉀鈼鉎鉙鉑鈹鉧銧鉷鉸鋧鋗鋙鋐﨧鋕鋠鋓錥錡鋻﨨錞鋿錝錂鍰鍗鎤鏆鏞鏸鐱鑅鑈閒隆﨩隝隯霳霻靃靍靏靑靕顗顥飯飼餧館馞驎髙"
  ],
  [
    "fc40",
    "髜魵魲鮏鮱鮻鰀鵰鵫鶴鸙黑"
  ]
], Jh = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  default: Zh
}), Qh = [
  [
    "0",
    "\0",
    127
  ],
  [
    "8ea1",
    "｡",
    62
  ],
  [
    "a1a1",
    "　、。，．・：；？！゛゜´｀¨＾￣＿ヽヾゝゞ〃仝々〆〇ー―‐／＼～∥｜…‥‘’“”（）〔〕［］｛｝〈",
    9,
    "＋－±×÷＝≠＜＞≦≧∞∴♂♀°′″℃￥＄￠￡％＃＆＊＠§☆★○●◎◇"
  ],
  [
    "a2a1",
    "◆□■△▲▽▼※〒→←↑↓〓"
  ],
  [
    "a2ba",
    "∈∋⊆⊇⊂⊃∪∩"
  ],
  [
    "a2ca",
    "∧∨￢⇒⇔∀∃"
  ],
  [
    "a2dc",
    "∠⊥⌒∂∇≡≒≪≫√∽∝∵∫∬"
  ],
  [
    "a2f2",
    "Å‰♯♭♪†‡¶"
  ],
  [
    "a2fe",
    "◯"
  ],
  [
    "a3b0",
    "０",
    9
  ],
  [
    "a3c1",
    "Ａ",
    25
  ],
  [
    "a3e1",
    "ａ",
    25
  ],
  [
    "a4a1",
    "ぁ",
    82
  ],
  [
    "a5a1",
    "ァ",
    85
  ],
  [
    "a6a1",
    "Α",
    16,
    "Σ",
    6
  ],
  [
    "a6c1",
    "α",
    16,
    "σ",
    6
  ],
  [
    "a7a1",
    "А",
    5,
    "ЁЖ",
    25
  ],
  [
    "a7d1",
    "а",
    5,
    "ёж",
    25
  ],
  [
    "a8a1",
    "─│┌┐┘└├┬┤┴┼━┃┏┓┛┗┣┳┫┻╋┠┯┨┷┿┝┰┥┸╂"
  ],
  [
    "ada1",
    "①",
    19,
    "Ⅰ",
    9
  ],
  [
    "adc0",
    "㍉㌔㌢㍍㌘㌧㌃㌶㍑㍗㌍㌦㌣㌫㍊㌻㎜㎝㎞㎎㎏㏄㎡"
  ],
  [
    "addf",
    "㍻〝〟№㏍℡㊤",
    4,
    "㈱㈲㈹㍾㍽㍼≒≡∫∮∑√⊥∠∟⊿∵∩∪"
  ],
  [
    "b0a1",
    "亜唖娃阿哀愛挨姶逢葵茜穐悪握渥旭葦芦鯵梓圧斡扱宛姐虻飴絢綾鮎或粟袷安庵按暗案闇鞍杏以伊位依偉囲夷委威尉惟意慰易椅為畏異移維緯胃萎衣謂違遺医井亥域育郁磯一壱溢逸稲茨芋鰯允印咽員因姻引飲淫胤蔭"
  ],
  [
    "b1a1",
    "院陰隠韻吋右宇烏羽迂雨卯鵜窺丑碓臼渦嘘唄欝蔚鰻姥厩浦瓜閏噂云運雲荏餌叡営嬰影映曳栄永泳洩瑛盈穎頴英衛詠鋭液疫益駅悦謁越閲榎厭円園堰奄宴延怨掩援沿演炎焔煙燕猿縁艶苑薗遠鉛鴛塩於汚甥凹央奥往応"
  ],
  [
    "b2a1",
    "押旺横欧殴王翁襖鴬鴎黄岡沖荻億屋憶臆桶牡乙俺卸恩温穏音下化仮何伽価佳加可嘉夏嫁家寡科暇果架歌河火珂禍禾稼箇花苛茄荷華菓蝦課嘩貨迦過霞蚊俄峨我牙画臥芽蛾賀雅餓駕介会解回塊壊廻快怪悔恢懐戒拐改"
  ],
  [
    "b3a1",
    "魁晦械海灰界皆絵芥蟹開階貝凱劾外咳害崖慨概涯碍蓋街該鎧骸浬馨蛙垣柿蛎鈎劃嚇各廓拡撹格核殻獲確穫覚角赫較郭閣隔革学岳楽額顎掛笠樫橿梶鰍潟割喝恰括活渇滑葛褐轄且鰹叶椛樺鞄株兜竃蒲釜鎌噛鴨栢茅萱"
  ],
  [
    "b4a1",
    "粥刈苅瓦乾侃冠寒刊勘勧巻喚堪姦完官寛干幹患感慣憾換敢柑桓棺款歓汗漢澗潅環甘監看竿管簡緩缶翰肝艦莞観諌貫還鑑間閑関陥韓館舘丸含岸巌玩癌眼岩翫贋雁頑顔願企伎危喜器基奇嬉寄岐希幾忌揮机旗既期棋棄"
  ],
  [
    "b5a1",
    "機帰毅気汽畿祈季稀紀徽規記貴起軌輝飢騎鬼亀偽儀妓宜戯技擬欺犠疑祇義蟻誼議掬菊鞠吉吃喫桔橘詰砧杵黍却客脚虐逆丘久仇休及吸宮弓急救朽求汲泣灸球究窮笈級糾給旧牛去居巨拒拠挙渠虚許距鋸漁禦魚亨享京"
  ],
  [
    "b6a1",
    "供侠僑兇競共凶協匡卿叫喬境峡強彊怯恐恭挟教橋況狂狭矯胸脅興蕎郷鏡響饗驚仰凝尭暁業局曲極玉桐粁僅勤均巾錦斤欣欽琴禁禽筋緊芹菌衿襟謹近金吟銀九倶句区狗玖矩苦躯駆駈駒具愚虞喰空偶寓遇隅串櫛釧屑屈"
  ],
  [
    "b7a1",
    "掘窟沓靴轡窪熊隈粂栗繰桑鍬勲君薫訓群軍郡卦袈祁係傾刑兄啓圭珪型契形径恵慶慧憩掲携敬景桂渓畦稽系経継繋罫茎荊蛍計詣警軽頚鶏芸迎鯨劇戟撃激隙桁傑欠決潔穴結血訣月件倹倦健兼券剣喧圏堅嫌建憲懸拳捲"
  ],
  [
    "b8a1",
    "検権牽犬献研硯絹県肩見謙賢軒遣鍵険顕験鹸元原厳幻弦減源玄現絃舷言諺限乎個古呼固姑孤己庫弧戸故枯湖狐糊袴股胡菰虎誇跨鈷雇顧鼓五互伍午呉吾娯後御悟梧檎瑚碁語誤護醐乞鯉交佼侯候倖光公功効勾厚口向"
  ],
  [
    "b9a1",
    "后喉坑垢好孔孝宏工巧巷幸広庚康弘恒慌抗拘控攻昂晃更杭校梗構江洪浩港溝甲皇硬稿糠紅紘絞綱耕考肯肱腔膏航荒行衡講貢購郊酵鉱砿鋼閤降項香高鴻剛劫号合壕拷濠豪轟麹克刻告国穀酷鵠黒獄漉腰甑忽惚骨狛込"
  ],
  [
    "baa1",
    "此頃今困坤墾婚恨懇昏昆根梱混痕紺艮魂些佐叉唆嵯左差査沙瑳砂詐鎖裟坐座挫債催再最哉塞妻宰彩才採栽歳済災采犀砕砦祭斎細菜裁載際剤在材罪財冴坂阪堺榊肴咲崎埼碕鷺作削咋搾昨朔柵窄策索錯桜鮭笹匙冊刷"
  ],
  [
    "bba1",
    "察拶撮擦札殺薩雑皐鯖捌錆鮫皿晒三傘参山惨撒散桟燦珊産算纂蚕讃賛酸餐斬暫残仕仔伺使刺司史嗣四士始姉姿子屍市師志思指支孜斯施旨枝止死氏獅祉私糸紙紫肢脂至視詞詩試誌諮資賜雌飼歯事似侍児字寺慈持時"
  ],
  [
    "bca1",
    "次滋治爾璽痔磁示而耳自蒔辞汐鹿式識鴫竺軸宍雫七叱執失嫉室悉湿漆疾質実蔀篠偲柴芝屡蕊縞舎写射捨赦斜煮社紗者謝車遮蛇邪借勺尺杓灼爵酌釈錫若寂弱惹主取守手朱殊狩珠種腫趣酒首儒受呪寿授樹綬需囚収周"
  ],
  [
    "bda1",
    "宗就州修愁拾洲秀秋終繍習臭舟蒐衆襲讐蹴輯週酋酬集醜什住充十従戎柔汁渋獣縦重銃叔夙宿淑祝縮粛塾熟出術述俊峻春瞬竣舜駿准循旬楯殉淳準潤盾純巡遵醇順処初所暑曙渚庶緒署書薯藷諸助叙女序徐恕鋤除傷償"
  ],
  [
    "bea1",
    "勝匠升召哨商唱嘗奨妾娼宵将小少尚庄床廠彰承抄招掌捷昇昌昭晶松梢樟樵沼消渉湘焼焦照症省硝礁祥称章笑粧紹肖菖蒋蕉衝裳訟証詔詳象賞醤鉦鍾鐘障鞘上丈丞乗冗剰城場壌嬢常情擾条杖浄状畳穣蒸譲醸錠嘱埴飾"
  ],
  [
    "bfa1",
    "拭植殖燭織職色触食蝕辱尻伸信侵唇娠寝審心慎振新晋森榛浸深申疹真神秦紳臣芯薪親診身辛進針震人仁刃塵壬尋甚尽腎訊迅陣靭笥諏須酢図厨逗吹垂帥推水炊睡粋翠衰遂酔錐錘随瑞髄崇嵩数枢趨雛据杉椙菅頗雀裾"
  ],
  [
    "c0a1",
    "澄摺寸世瀬畝是凄制勢姓征性成政整星晴棲栖正清牲生盛精聖声製西誠誓請逝醒青静斉税脆隻席惜戚斥昔析石積籍績脊責赤跡蹟碩切拙接摂折設窃節説雪絶舌蝉仙先千占宣専尖川戦扇撰栓栴泉浅洗染潜煎煽旋穿箭線"
  ],
  [
    "c1a1",
    "繊羨腺舛船薦詮賎践選遷銭銑閃鮮前善漸然全禅繕膳糎噌塑岨措曾曽楚狙疏疎礎祖租粗素組蘇訴阻遡鼠僧創双叢倉喪壮奏爽宋層匝惣想捜掃挿掻操早曹巣槍槽漕燥争痩相窓糟総綜聡草荘葬蒼藻装走送遭鎗霜騒像増憎"
  ],
  [
    "c2a1",
    "臓蔵贈造促側則即息捉束測足速俗属賊族続卒袖其揃存孫尊損村遜他多太汰詑唾堕妥惰打柁舵楕陀駄騨体堆対耐岱帯待怠態戴替泰滞胎腿苔袋貸退逮隊黛鯛代台大第醍題鷹滝瀧卓啄宅托択拓沢濯琢託鐸濁諾茸凧蛸只"
  ],
  [
    "c3a1",
    "叩但達辰奪脱巽竪辿棚谷狸鱈樽誰丹単嘆坦担探旦歎淡湛炭短端箪綻耽胆蛋誕鍛団壇弾断暖檀段男談値知地弛恥智池痴稚置致蜘遅馳築畜竹筑蓄逐秩窒茶嫡着中仲宙忠抽昼柱注虫衷註酎鋳駐樗瀦猪苧著貯丁兆凋喋寵"
  ],
  [
    "c4a1",
    "帖帳庁弔張彫徴懲挑暢朝潮牒町眺聴脹腸蝶調諜超跳銚長頂鳥勅捗直朕沈珍賃鎮陳津墜椎槌追鎚痛通塚栂掴槻佃漬柘辻蔦綴鍔椿潰坪壷嬬紬爪吊釣鶴亭低停偵剃貞呈堤定帝底庭廷弟悌抵挺提梯汀碇禎程締艇訂諦蹄逓"
  ],
  [
    "c5a1",
    "邸鄭釘鼎泥摘擢敵滴的笛適鏑溺哲徹撤轍迭鉄典填天展店添纏甜貼転顛点伝殿澱田電兎吐堵塗妬屠徒斗杜渡登菟賭途都鍍砥砺努度土奴怒倒党冬凍刀唐塔塘套宕島嶋悼投搭東桃梼棟盗淘湯涛灯燈当痘祷等答筒糖統到"
  ],
  [
    "c6a1",
    "董蕩藤討謄豆踏逃透鐙陶頭騰闘働動同堂導憧撞洞瞳童胴萄道銅峠鴇匿得徳涜特督禿篤毒独読栃橡凸突椴届鳶苫寅酉瀞噸屯惇敦沌豚遁頓呑曇鈍奈那内乍凪薙謎灘捺鍋楢馴縄畷南楠軟難汝二尼弐迩匂賑肉虹廿日乳入"
  ],
  [
    "c7a1",
    "如尿韮任妊忍認濡禰祢寧葱猫熱年念捻撚燃粘乃廼之埜嚢悩濃納能脳膿農覗蚤巴把播覇杷波派琶破婆罵芭馬俳廃拝排敗杯盃牌背肺輩配倍培媒梅楳煤狽買売賠陪這蝿秤矧萩伯剥博拍柏泊白箔粕舶薄迫曝漠爆縛莫駁麦"
  ],
  [
    "c8a1",
    "函箱硲箸肇筈櫨幡肌畑畠八鉢溌発醗髪伐罰抜筏閥鳩噺塙蛤隼伴判半反叛帆搬斑板氾汎版犯班畔繁般藩販範釆煩頒飯挽晩番盤磐蕃蛮匪卑否妃庇彼悲扉批披斐比泌疲皮碑秘緋罷肥被誹費避非飛樋簸備尾微枇毘琵眉美"
  ],
  [
    "c9a1",
    "鼻柊稗匹疋髭彦膝菱肘弼必畢筆逼桧姫媛紐百謬俵彪標氷漂瓢票表評豹廟描病秒苗錨鋲蒜蛭鰭品彬斌浜瀕貧賓頻敏瓶不付埠夫婦富冨布府怖扶敷斧普浮父符腐膚芙譜負賦赴阜附侮撫武舞葡蕪部封楓風葺蕗伏副復幅服"
  ],
  [
    "caa1",
    "福腹複覆淵弗払沸仏物鮒分吻噴墳憤扮焚奮粉糞紛雰文聞丙併兵塀幣平弊柄並蔽閉陛米頁僻壁癖碧別瞥蔑箆偏変片篇編辺返遍便勉娩弁鞭保舗鋪圃捕歩甫補輔穂募墓慕戊暮母簿菩倣俸包呆報奉宝峰峯崩庖抱捧放方朋"
  ],
  [
    "cba1",
    "法泡烹砲縫胞芳萌蓬蜂褒訪豊邦鋒飽鳳鵬乏亡傍剖坊妨帽忘忙房暴望某棒冒紡肪膨謀貌貿鉾防吠頬北僕卜墨撲朴牧睦穆釦勃没殆堀幌奔本翻凡盆摩磨魔麻埋妹昧枚毎哩槙幕膜枕鮪柾鱒桝亦俣又抹末沫迄侭繭麿万慢満"
  ],
  [
    "cca1",
    "漫蔓味未魅巳箕岬密蜜湊蓑稔脈妙粍民眠務夢無牟矛霧鵡椋婿娘冥名命明盟迷銘鳴姪牝滅免棉綿緬面麺摸模茂妄孟毛猛盲網耗蒙儲木黙目杢勿餅尤戻籾貰問悶紋門匁也冶夜爺耶野弥矢厄役約薬訳躍靖柳薮鑓愉愈油癒"
  ],
  [
    "cda1",
    "諭輸唯佑優勇友宥幽悠憂揖有柚湧涌猶猷由祐裕誘遊邑郵雄融夕予余与誉輿預傭幼妖容庸揚揺擁曜楊様洋溶熔用窯羊耀葉蓉要謡踊遥陽養慾抑欲沃浴翌翼淀羅螺裸来莱頼雷洛絡落酪乱卵嵐欄濫藍蘭覧利吏履李梨理璃"
  ],
  [
    "cea1",
    "痢裏裡里離陸律率立葎掠略劉流溜琉留硫粒隆竜龍侶慮旅虜了亮僚両凌寮料梁涼猟療瞭稜糧良諒遼量陵領力緑倫厘林淋燐琳臨輪隣鱗麟瑠塁涙累類令伶例冷励嶺怜玲礼苓鈴隷零霊麗齢暦歴列劣烈裂廉恋憐漣煉簾練聯"
  ],
  [
    "cfa1",
    "蓮連錬呂魯櫓炉賂路露労婁廊弄朗楼榔浪漏牢狼篭老聾蝋郎六麓禄肋録論倭和話歪賄脇惑枠鷲亙亘鰐詫藁蕨椀湾碗腕"
  ],
  [
    "d0a1",
    "弌丐丕个丱丶丼丿乂乖乘亂亅豫亊舒弍于亞亟亠亢亰亳亶从仍仄仆仂仗仞仭仟价伉佚估佛佝佗佇佶侈侏侘佻佩佰侑佯來侖儘俔俟俎俘俛俑俚俐俤俥倚倨倔倪倥倅伜俶倡倩倬俾俯們倆偃假會偕偐偈做偖偬偸傀傚傅傴傲"
  ],
  [
    "d1a1",
    "僉僊傳僂僖僞僥僭僣僮價僵儉儁儂儖儕儔儚儡儺儷儼儻儿兀兒兌兔兢竸兩兪兮冀冂囘册冉冏冑冓冕冖冤冦冢冩冪冫决冱冲冰况冽凅凉凛几處凩凭凰凵凾刄刋刔刎刧刪刮刳刹剏剄剋剌剞剔剪剴剩剳剿剽劍劔劒剱劈劑辨"
  ],
  [
    "d2a1",
    "辧劬劭劼劵勁勍勗勞勣勦飭勠勳勵勸勹匆匈甸匍匐匏匕匚匣匯匱匳匸區卆卅丗卉卍凖卞卩卮夘卻卷厂厖厠厦厥厮厰厶參簒雙叟曼燮叮叨叭叺吁吽呀听吭吼吮吶吩吝呎咏呵咎呟呱呷呰咒呻咀呶咄咐咆哇咢咸咥咬哄哈咨"
  ],
  [
    "d3a1",
    "咫哂咤咾咼哘哥哦唏唔哽哮哭哺哢唹啀啣啌售啜啅啖啗唸唳啝喙喀咯喊喟啻啾喘喞單啼喃喩喇喨嗚嗅嗟嗄嗜嗤嗔嘔嗷嘖嗾嗽嘛嗹噎噐營嘴嘶嘲嘸噫噤嘯噬噪嚆嚀嚊嚠嚔嚏嚥嚮嚶嚴囂嚼囁囃囀囈囎囑囓囗囮囹圀囿圄圉"
  ],
  [
    "d4a1",
    "圈國圍圓團圖嗇圜圦圷圸坎圻址坏坩埀垈坡坿垉垓垠垳垤垪垰埃埆埔埒埓堊埖埣堋堙堝塲堡塢塋塰毀塒堽塹墅墹墟墫墺壞墻墸墮壅壓壑壗壙壘壥壜壤壟壯壺壹壻壼壽夂夊夐夛梦夥夬夭夲夸夾竒奕奐奎奚奘奢奠奧奬奩"
  ],
  [
    "d5a1",
    "奸妁妝佞侫妣妲姆姨姜妍姙姚娥娟娑娜娉娚婀婬婉娵娶婢婪媚媼媾嫋嫂媽嫣嫗嫦嫩嫖嫺嫻嬌嬋嬖嬲嫐嬪嬶嬾孃孅孀孑孕孚孛孥孩孰孳孵學斈孺宀它宦宸寃寇寉寔寐寤實寢寞寥寫寰寶寳尅將專對尓尠尢尨尸尹屁屆屎屓"
  ],
  [
    "d6a1",
    "屐屏孱屬屮乢屶屹岌岑岔妛岫岻岶岼岷峅岾峇峙峩峽峺峭嶌峪崋崕崗嵜崟崛崑崔崢崚崙崘嵌嵒嵎嵋嵬嵳嵶嶇嶄嶂嶢嶝嶬嶮嶽嶐嶷嶼巉巍巓巒巖巛巫已巵帋帚帙帑帛帶帷幄幃幀幎幗幔幟幢幤幇幵并幺麼广庠廁廂廈廐廏"
  ],
  [
    "d7a1",
    "廖廣廝廚廛廢廡廨廩廬廱廳廰廴廸廾弃弉彝彜弋弑弖弩弭弸彁彈彌彎弯彑彖彗彙彡彭彳彷徃徂彿徊很徑徇從徙徘徠徨徭徼忖忻忤忸忱忝悳忿怡恠怙怐怩怎怱怛怕怫怦怏怺恚恁恪恷恟恊恆恍恣恃恤恂恬恫恙悁悍惧悃悚"
  ],
  [
    "d8a1",
    "悄悛悖悗悒悧悋惡悸惠惓悴忰悽惆悵惘慍愕愆惶惷愀惴惺愃愡惻惱愍愎慇愾愨愧慊愿愼愬愴愽慂慄慳慷慘慙慚慫慴慯慥慱慟慝慓慵憙憖憇憬憔憚憊憑憫憮懌懊應懷懈懃懆憺懋罹懍懦懣懶懺懴懿懽懼懾戀戈戉戍戌戔戛"
  ],
  [
    "d9a1",
    "戞戡截戮戰戲戳扁扎扞扣扛扠扨扼抂抉找抒抓抖拔抃抔拗拑抻拏拿拆擔拈拜拌拊拂拇抛拉挌拮拱挧挂挈拯拵捐挾捍搜捏掖掎掀掫捶掣掏掉掟掵捫捩掾揩揀揆揣揉插揶揄搖搴搆搓搦搶攝搗搨搏摧摯摶摎攪撕撓撥撩撈撼"
  ],
  [
    "daa1",
    "據擒擅擇撻擘擂擱擧舉擠擡抬擣擯攬擶擴擲擺攀擽攘攜攅攤攣攫攴攵攷收攸畋效敖敕敍敘敞敝敲數斂斃變斛斟斫斷旃旆旁旄旌旒旛旙无旡旱杲昊昃旻杳昵昶昴昜晏晄晉晁晞晝晤晧晨晟晢晰暃暈暎暉暄暘暝曁暹曉暾暼"
  ],
  [
    "dba1",
    "曄暸曖曚曠昿曦曩曰曵曷朏朖朞朦朧霸朮朿朶杁朸朷杆杞杠杙杣杤枉杰枩杼杪枌枋枦枡枅枷柯枴柬枳柩枸柤柞柝柢柮枹柎柆柧檜栞框栩桀桍栲桎梳栫桙档桷桿梟梏梭梔條梛梃檮梹桴梵梠梺椏梍桾椁棊椈棘椢椦棡椌棍"
  ],
  [
    "dca1",
    "棔棧棕椶椒椄棗棣椥棹棠棯椨椪椚椣椡棆楹楷楜楸楫楔楾楮椹楴椽楙椰楡楞楝榁楪榲榮槐榿槁槓榾槎寨槊槝榻槃榧樮榑榠榜榕榴槞槨樂樛槿權槹槲槧樅榱樞槭樔槫樊樒櫁樣樓橄樌橲樶橸橇橢橙橦橈樸樢檐檍檠檄檢檣"
  ],
  [
    "dda1",
    "檗蘗檻櫃櫂檸檳檬櫞櫑櫟檪櫚櫪櫻欅蘖櫺欒欖鬱欟欸欷盜欹飮歇歃歉歐歙歔歛歟歡歸歹歿殀殄殃殍殘殕殞殤殪殫殯殲殱殳殷殼毆毋毓毟毬毫毳毯麾氈氓气氛氤氣汞汕汢汪沂沍沚沁沛汾汨汳沒沐泄泱泓沽泗泅泝沮沱沾"
  ],
  [
    "dea1",
    "沺泛泯泙泪洟衍洶洫洽洸洙洵洳洒洌浣涓浤浚浹浙涎涕濤涅淹渕渊涵淇淦涸淆淬淞淌淨淒淅淺淙淤淕淪淮渭湮渮渙湲湟渾渣湫渫湶湍渟湃渺湎渤滿渝游溂溪溘滉溷滓溽溯滄溲滔滕溏溥滂溟潁漑灌滬滸滾漿滲漱滯漲滌"
  ],
  [
    "dfa1",
    "漾漓滷澆潺潸澁澀潯潛濳潭澂潼潘澎澑濂潦澳澣澡澤澹濆澪濟濕濬濔濘濱濮濛瀉瀋濺瀑瀁瀏濾瀛瀚潴瀝瀘瀟瀰瀾瀲灑灣炙炒炯烱炬炸炳炮烟烋烝烙焉烽焜焙煥煕熈煦煢煌煖煬熏燻熄熕熨熬燗熹熾燒燉燔燎燠燬燧燵燼"
  ],
  [
    "e0a1",
    "燹燿爍爐爛爨爭爬爰爲爻爼爿牀牆牋牘牴牾犂犁犇犒犖犢犧犹犲狃狆狄狎狒狢狠狡狹狷倏猗猊猜猖猝猴猯猩猥猾獎獏默獗獪獨獰獸獵獻獺珈玳珎玻珀珥珮珞璢琅瑯琥珸琲琺瑕琿瑟瑙瑁瑜瑩瑰瑣瑪瑶瑾璋璞璧瓊瓏瓔珱"
  ],
  [
    "e1a1",
    "瓠瓣瓧瓩瓮瓲瓰瓱瓸瓷甄甃甅甌甎甍甕甓甞甦甬甼畄畍畊畉畛畆畚畩畤畧畫畭畸當疆疇畴疊疉疂疔疚疝疥疣痂疳痃疵疽疸疼疱痍痊痒痙痣痞痾痿痼瘁痰痺痲痳瘋瘍瘉瘟瘧瘠瘡瘢瘤瘴瘰瘻癇癈癆癜癘癡癢癨癩癪癧癬癰"
  ],
  [
    "e2a1",
    "癲癶癸發皀皃皈皋皎皖皓皙皚皰皴皸皹皺盂盍盖盒盞盡盥盧盪蘯盻眈眇眄眩眤眞眥眦眛眷眸睇睚睨睫睛睥睿睾睹瞎瞋瞑瞠瞞瞰瞶瞹瞿瞼瞽瞻矇矍矗矚矜矣矮矼砌砒礦砠礪硅碎硴碆硼碚碌碣碵碪碯磑磆磋磔碾碼磅磊磬"
  ],
  [
    "e3a1",
    "磧磚磽磴礇礒礑礙礬礫祀祠祗祟祚祕祓祺祿禊禝禧齋禪禮禳禹禺秉秕秧秬秡秣稈稍稘稙稠稟禀稱稻稾稷穃穗穉穡穢穩龝穰穹穽窈窗窕窘窖窩竈窰窶竅竄窿邃竇竊竍竏竕竓站竚竝竡竢竦竭竰笂笏笊笆笳笘笙笞笵笨笶筐"
  ],
  [
    "e4a1",
    "筺笄筍笋筌筅筵筥筴筧筰筱筬筮箝箘箟箍箜箚箋箒箏筝箙篋篁篌篏箴篆篝篩簑簔篦篥籠簀簇簓篳篷簗簍篶簣簧簪簟簷簫簽籌籃籔籏籀籐籘籟籤籖籥籬籵粃粐粤粭粢粫粡粨粳粲粱粮粹粽糀糅糂糘糒糜糢鬻糯糲糴糶糺紆"
  ],
  [
    "e5a1",
    "紂紜紕紊絅絋紮紲紿紵絆絳絖絎絲絨絮絏絣經綉絛綏絽綛綺綮綣綵緇綽綫總綢綯緜綸綟綰緘緝緤緞緻緲緡縅縊縣縡縒縱縟縉縋縢繆繦縻縵縹繃縷縲縺繧繝繖繞繙繚繹繪繩繼繻纃緕繽辮繿纈纉續纒纐纓纔纖纎纛纜缸缺"
  ],
  [
    "e6a1",
    "罅罌罍罎罐网罕罔罘罟罠罨罩罧罸羂羆羃羈羇羌羔羞羝羚羣羯羲羹羮羶羸譱翅翆翊翕翔翡翦翩翳翹飜耆耄耋耒耘耙耜耡耨耿耻聊聆聒聘聚聟聢聨聳聲聰聶聹聽聿肄肆肅肛肓肚肭冐肬胛胥胙胝胄胚胖脉胯胱脛脩脣脯腋"
  ],
  [
    "e7a1",
    "隋腆脾腓腑胼腱腮腥腦腴膃膈膊膀膂膠膕膤膣腟膓膩膰膵膾膸膽臀臂膺臉臍臑臙臘臈臚臟臠臧臺臻臾舁舂舅與舊舍舐舖舩舫舸舳艀艙艘艝艚艟艤艢艨艪艫舮艱艷艸艾芍芒芫芟芻芬苡苣苟苒苴苳苺莓范苻苹苞茆苜茉苙"
  ],
  [
    "e8a1",
    "茵茴茖茲茱荀茹荐荅茯茫茗茘莅莚莪莟莢莖茣莎莇莊荼莵荳荵莠莉莨菴萓菫菎菽萃菘萋菁菷萇菠菲萍萢萠莽萸蔆菻葭萪萼蕚蒄葷葫蒭葮蒂葩葆萬葯葹萵蓊葢蒹蒿蒟蓙蓍蒻蓚蓐蓁蓆蓖蒡蔡蓿蓴蔗蔘蔬蔟蔕蔔蓼蕀蕣蕘蕈"
  ],
  [
    "e9a1",
    "蕁蘂蕋蕕薀薤薈薑薊薨蕭薔薛藪薇薜蕷蕾薐藉薺藏薹藐藕藝藥藜藹蘊蘓蘋藾藺蘆蘢蘚蘰蘿虍乕虔號虧虱蚓蚣蚩蚪蚋蚌蚶蚯蛄蛆蚰蛉蠣蚫蛔蛞蛩蛬蛟蛛蛯蜒蜆蜈蜀蜃蛻蜑蜉蜍蛹蜊蜴蜿蜷蜻蜥蜩蜚蝠蝟蝸蝌蝎蝴蝗蝨蝮蝙"
  ],
  [
    "eaa1",
    "蝓蝣蝪蠅螢螟螂螯蟋螽蟀蟐雖螫蟄螳蟇蟆螻蟯蟲蟠蠏蠍蟾蟶蟷蠎蟒蠑蠖蠕蠢蠡蠱蠶蠹蠧蠻衄衂衒衙衞衢衫袁衾袞衵衽袵衲袂袗袒袮袙袢袍袤袰袿袱裃裄裔裘裙裝裹褂裼裴裨裲褄褌褊褓襃褞褥褪褫襁襄褻褶褸襌褝襠襞"
  ],
  [
    "eba1",
    "襦襤襭襪襯襴襷襾覃覈覊覓覘覡覩覦覬覯覲覺覽覿觀觚觜觝觧觴觸訃訖訐訌訛訝訥訶詁詛詒詆詈詼詭詬詢誅誂誄誨誡誑誥誦誚誣諄諍諂諚諫諳諧諤諱謔諠諢諷諞諛謌謇謚諡謖謐謗謠謳鞫謦謫謾謨譁譌譏譎證譖譛譚譫"
  ],
  [
    "eca1",
    "譟譬譯譴譽讀讌讎讒讓讖讙讚谺豁谿豈豌豎豐豕豢豬豸豺貂貉貅貊貍貎貔豼貘戝貭貪貽貲貳貮貶賈賁賤賣賚賽賺賻贄贅贊贇贏贍贐齎贓賍贔贖赧赭赱赳趁趙跂趾趺跏跚跖跌跛跋跪跫跟跣跼踈踉跿踝踞踐踟蹂踵踰踴蹊"
  ],
  [
    "eda1",
    "蹇蹉蹌蹐蹈蹙蹤蹠踪蹣蹕蹶蹲蹼躁躇躅躄躋躊躓躑躔躙躪躡躬躰軆躱躾軅軈軋軛軣軼軻軫軾輊輅輕輒輙輓輜輟輛輌輦輳輻輹轅轂輾轌轉轆轎轗轜轢轣轤辜辟辣辭辯辷迚迥迢迪迯邇迴逅迹迺逑逕逡逍逞逖逋逧逶逵逹迸"
  ],
  [
    "eea1",
    "遏遐遑遒逎遉逾遖遘遞遨遯遶隨遲邂遽邁邀邊邉邏邨邯邱邵郢郤扈郛鄂鄒鄙鄲鄰酊酖酘酣酥酩酳酲醋醉醂醢醫醯醪醵醴醺釀釁釉釋釐釖釟釡釛釼釵釶鈞釿鈔鈬鈕鈑鉞鉗鉅鉉鉤鉈銕鈿鉋鉐銜銖銓銛鉚鋏銹銷鋩錏鋺鍄錮"
  ],
  [
    "efa1",
    "錙錢錚錣錺錵錻鍜鍠鍼鍮鍖鎰鎬鎭鎔鎹鏖鏗鏨鏥鏘鏃鏝鏐鏈鏤鐚鐔鐓鐃鐇鐐鐶鐫鐵鐡鐺鑁鑒鑄鑛鑠鑢鑞鑪鈩鑰鑵鑷鑽鑚鑼鑾钁鑿閂閇閊閔閖閘閙閠閨閧閭閼閻閹閾闊濶闃闍闌闕闔闖關闡闥闢阡阨阮阯陂陌陏陋陷陜陞"
  ],
  [
    "f0a1",
    "陝陟陦陲陬隍隘隕隗險隧隱隲隰隴隶隸隹雎雋雉雍襍雜霍雕雹霄霆霈霓霎霑霏霖霙霤霪霰霹霽霾靄靆靈靂靉靜靠靤靦靨勒靫靱靹鞅靼鞁靺鞆鞋鞏鞐鞜鞨鞦鞣鞳鞴韃韆韈韋韜韭齏韲竟韶韵頏頌頸頤頡頷頽顆顏顋顫顯顰"
  ],
  [
    "f1a1",
    "顱顴顳颪颯颱颶飄飃飆飩飫餃餉餒餔餘餡餝餞餤餠餬餮餽餾饂饉饅饐饋饑饒饌饕馗馘馥馭馮馼駟駛駝駘駑駭駮駱駲駻駸騁騏騅駢騙騫騷驅驂驀驃騾驕驍驛驗驟驢驥驤驩驫驪骭骰骼髀髏髑髓體髞髟髢髣髦髯髫髮髴髱髷"
  ],
  [
    "f2a1",
    "髻鬆鬘鬚鬟鬢鬣鬥鬧鬨鬩鬪鬮鬯鬲魄魃魏魍魎魑魘魴鮓鮃鮑鮖鮗鮟鮠鮨鮴鯀鯊鮹鯆鯏鯑鯒鯣鯢鯤鯔鯡鰺鯲鯱鯰鰕鰔鰉鰓鰌鰆鰈鰒鰊鰄鰮鰛鰥鰤鰡鰰鱇鰲鱆鰾鱚鱠鱧鱶鱸鳧鳬鳰鴉鴈鳫鴃鴆鴪鴦鶯鴣鴟鵄鴕鴒鵁鴿鴾鵆鵈"
  ],
  [
    "f3a1",
    "鵝鵞鵤鵑鵐鵙鵲鶉鶇鶫鵯鵺鶚鶤鶩鶲鷄鷁鶻鶸鶺鷆鷏鷂鷙鷓鷸鷦鷭鷯鷽鸚鸛鸞鹵鹹鹽麁麈麋麌麒麕麑麝麥麩麸麪麭靡黌黎黏黐黔黜點黝黠黥黨黯黴黶黷黹黻黼黽鼇鼈皷鼕鼡鼬鼾齊齒齔齣齟齠齡齦齧齬齪齷齲齶龕龜龠"
  ],
  [
    "f4a1",
    "堯槇遙瑤凜熙"
  ],
  [
    "f9a1",
    "纊褜鍈銈蓜俉炻昱棈鋹曻彅丨仡仼伀伃伹佖侒侊侚侔俍偀倢俿倞偆偰偂傔僴僘兊兤冝冾凬刕劜劦勀勛匀匇匤卲厓厲叝﨎咜咊咩哿喆坙坥垬埈埇﨏塚增墲夋奓奛奝奣妤妺孖寀甯寘寬尞岦岺峵崧嵓﨑嵂嵭嶸嶹巐弡弴彧德"
  ],
  [
    "faa1",
    "忞恝悅悊惞惕愠惲愑愷愰憘戓抦揵摠撝擎敎昀昕昻昉昮昞昤晥晗晙晴晳暙暠暲暿曺朎朗杦枻桒柀栁桄棏﨓楨﨔榘槢樰橫橆橳橾櫢櫤毖氿汜沆汯泚洄涇浯涖涬淏淸淲淼渹湜渧渼溿澈澵濵瀅瀇瀨炅炫焏焄煜煆煇凞燁燾犱"
  ],
  [
    "fba1",
    "犾猤猪獷玽珉珖珣珒琇珵琦琪琩琮瑢璉璟甁畯皂皜皞皛皦益睆劯砡硎硤硺礰礼神祥禔福禛竑竧靖竫箞精絈絜綷綠緖繒罇羡羽茁荢荿菇菶葈蒴蕓蕙蕫﨟薰蘒﨡蠇裵訒訷詹誧誾諟諸諶譓譿賰賴贒赶﨣軏﨤逸遧郞都鄕鄧釚"
  ],
  [
    "fca1",
    "釗釞釭釮釤釥鈆鈐鈊鈺鉀鈼鉎鉙鉑鈹鉧銧鉷鉸鋧鋗鋙鋐﨧鋕鋠鋓錥錡鋻﨨錞鋿錝錂鍰鍗鎤鏆鏞鏸鐱鑅鑈閒隆﨩隝隯霳霻靃靍靏靑靕顗顥飯飼餧館馞驎髙髜魵魲鮏鮱鮻鰀鵰鵫鶴鸙黑"
  ],
  [
    "fcf1",
    "ⅰ",
    9,
    "￢￤＇＂"
  ],
  [
    "8fa2af",
    "˘ˇ¸˙˝¯˛˚～΄΅"
  ],
  [
    "8fa2c2",
    "¡¦¿"
  ],
  [
    "8fa2eb",
    "ºª©®™¤№"
  ],
  [
    "8fa6e1",
    "ΆΈΉΊΪ"
  ],
  [
    "8fa6e7",
    "Ό"
  ],
  [
    "8fa6e9",
    "ΎΫ"
  ],
  [
    "8fa6ec",
    "Ώ"
  ],
  [
    "8fa6f1",
    "άέήίϊΐόςύϋΰώ"
  ],
  [
    "8fa7c2",
    "Ђ",
    10,
    "ЎЏ"
  ],
  [
    "8fa7f2",
    "ђ",
    10,
    "ўџ"
  ],
  [
    "8fa9a1",
    "ÆĐ"
  ],
  [
    "8fa9a4",
    "Ħ"
  ],
  [
    "8fa9a6",
    "Ĳ"
  ],
  [
    "8fa9a8",
    "ŁĿ"
  ],
  [
    "8fa9ab",
    "ŊØŒ"
  ],
  [
    "8fa9af",
    "ŦÞ"
  ],
  [
    "8fa9c1",
    "æđðħıĳĸłŀŉŋøœßŧþ"
  ],
  [
    "8faaa1",
    "ÁÀÄÂĂǍĀĄÅÃĆĈČÇĊĎÉÈËÊĚĖĒĘ"
  ],
  [
    "8faaba",
    "ĜĞĢĠĤÍÌÏÎǏİĪĮĨĴĶĹĽĻŃŇŅÑÓÒÖÔǑŐŌÕŔŘŖŚŜŠŞŤŢÚÙÜÛŬǓŰŪŲŮŨǗǛǙǕŴÝŸŶŹŽŻ"
  ],
  [
    "8faba1",
    "áàäâăǎāąåãćĉčçċďéèëêěėēęǵĝğ"
  ],
  [
    "8fabbd",
    "ġĥíìïîǐ"
  ],
  [
    "8fabc5",
    "īįĩĵķĺľļńňņñóòöôǒőōõŕřŗśŝšşťţúùüûŭǔűūųůũǘǜǚǖŵýÿŷźžż"
  ],
  [
    "8fb0a1",
    "丂丄丅丌丒丟丣两丨丫丮丯丰丵乀乁乄乇乑乚乜乣乨乩乴乵乹乿亍亖亗亝亯亹仃仐仚仛仠仡仢仨仯仱仳仵份仾仿伀伂伃伈伋伌伒伕伖众伙伮伱你伳伵伷伹伻伾佀佂佈佉佋佌佒佔佖佘佟佣佪佬佮佱佷佸佹佺佽佾侁侂侄"
  ],
  [
    "8fb1a1",
    "侅侉侊侌侎侐侒侓侔侗侙侚侞侟侲侷侹侻侼侽侾俀俁俅俆俈俉俋俌俍俏俒俜俠俢俰俲俼俽俿倀倁倄倇倊倌倎倐倓倗倘倛倜倝倞倢倧倮倰倲倳倵偀偁偂偅偆偊偌偎偑偒偓偗偙偟偠偢偣偦偧偪偭偰偱倻傁傃傄傆傊傎傏傐"
  ],
  [
    "8fb2a1",
    "傒傓傔傖傛傜傞",
    4,
    "傪傯傰傹傺傽僀僃僄僇僌僎僐僓僔僘僜僝僟僢僤僦僨僩僯僱僶僺僾儃儆儇儈儋儌儍儎僲儐儗儙儛儜儝儞儣儧儨儬儭儯儱儳儴儵儸儹兂兊兏兓兕兗兘兟兤兦兾冃冄冋冎冘冝冡冣冭冸冺冼冾冿凂"
  ],
  [
    "8fb3a1",
    "凈减凑凒凓凕凘凞凢凥凮凲凳凴凷刁刂刅划刓刕刖刘刢刨刱刲刵刼剅剉剕剗剘剚剜剟剠剡剦剮剷剸剹劀劂劅劊劌劓劕劖劗劘劚劜劤劥劦劧劯劰劶劷劸劺劻劽勀勄勆勈勌勏勑勔勖勛勜勡勥勨勩勪勬勰勱勴勶勷匀匃匊匋"
  ],
  [
    "8fb4a1",
    "匌匑匓匘匛匜匞匟匥匧匨匩匫匬匭匰匲匵匼匽匾卂卌卋卙卛卡卣卥卬卭卲卹卾厃厇厈厎厓厔厙厝厡厤厪厫厯厲厴厵厷厸厺厽叀叅叏叒叓叕叚叝叞叠另叧叵吂吓吚吡吧吨吪启吱吴吵呃呄呇呍呏呞呢呤呦呧呩呫呭呮呴呿"
  ],
  [
    "8fb5a1",
    "咁咃咅咈咉咍咑咕咖咜咟咡咦咧咩咪咭咮咱咷咹咺咻咿哆哊响哎哠哪哬哯哶哼哾哿唀唁唅唈唉唌唍唎唕唪唫唲唵唶唻唼唽啁啇啉啊啍啐啑啘啚啛啞啠啡啤啦啿喁喂喆喈喎喏喑喒喓喔喗喣喤喭喲喿嗁嗃嗆嗉嗋嗌嗎嗑嗒"
  ],
  [
    "8fb6a1",
    "嗓嗗嗘嗛嗞嗢嗩嗶嗿嘅嘈嘊嘍",
    5,
    "嘙嘬嘰嘳嘵嘷嘹嘻嘼嘽嘿噀噁噃噄噆噉噋噍噏噔噞噠噡噢噣噦噩噭噯噱噲噵嚄嚅嚈嚋嚌嚕嚙嚚嚝嚞嚟嚦嚧嚨嚩嚫嚬嚭嚱嚳嚷嚾囅囉囊囋囏囐囌囍囙囜囝囟囡囤",
    4,
    "囱囫园"
  ],
  [
    "8fb7a1",
    "囶囷圁圂圇圊圌圑圕圚圛圝圠圢圣圤圥圩圪圬圮圯圳圴圽圾圿坅坆坌坍坒坢坥坧坨坫坭",
    4,
    "坳坴坵坷坹坺坻坼坾垁垃垌垔垗垙垚垜垝垞垟垡垕垧垨垩垬垸垽埇埈埌埏埕埝埞埤埦埧埩埭埰埵埶埸埽埾埿堃堄堈堉埡"
  ],
  [
    "8fb8a1",
    "堌堍堛堞堟堠堦堧堭堲堹堿塉塌塍塏塐塕塟塡塤塧塨塸塼塿墀墁墇墈墉墊墌墍墏墐墔墖墝墠墡墢墦墩墱墲壄墼壂壈壍壎壐壒壔壖壚壝壡壢壩壳夅夆夋夌夒夓夔虁夝夡夣夤夨夯夰夳夵夶夿奃奆奒奓奙奛奝奞奟奡奣奫奭"
  ],
  [
    "8fb9a1",
    "奯奲奵奶她奻奼妋妌妎妒妕妗妟妤妧妭妮妯妰妳妷妺妼姁姃姄姈姊姍姒姝姞姟姣姤姧姮姯姱姲姴姷娀娄娌娍娎娒娓娞娣娤娧娨娪娭娰婄婅婇婈婌婐婕婞婣婥婧婭婷婺婻婾媋媐媓媖媙媜媞媟媠媢媧媬媱媲媳媵媸媺媻媿"
  ],
  [
    "8fbaa1",
    "嫄嫆嫈嫏嫚嫜嫠嫥嫪嫮嫵嫶嫽嬀嬁嬈嬗嬴嬙嬛嬝嬡嬥嬭嬸孁孋孌孒孖孞孨孮孯孼孽孾孿宁宄宆宊宎宐宑宓宔宖宨宩宬宭宯宱宲宷宺宼寀寁寍寏寖",
    4,
    "寠寯寱寴寽尌尗尞尟尣尦尩尫尬尮尰尲尵尶屙屚屜屢屣屧屨屩"
  ],
  [
    "8fbba1",
    "屭屰屴屵屺屻屼屽岇岈岊岏岒岝岟岠岢岣岦岪岲岴岵岺峉峋峒峝峗峮峱峲峴崁崆崍崒崫崣崤崦崧崱崴崹崽崿嵂嵃嵆嵈嵕嵑嵙嵊嵟嵠嵡嵢嵤嵪嵭嵰嵹嵺嵾嵿嶁嶃嶈嶊嶒嶓嶔嶕嶙嶛嶟嶠嶧嶫嶰嶴嶸嶹巃巇巋巐巎巘巙巠巤"
  ],
  [
    "8fbca1",
    "巩巸巹帀帇帍帒帔帕帘帟帠帮帨帲帵帾幋幐幉幑幖幘幛幜幞幨幪",
    4,
    "幰庀庋庎庢庤庥庨庪庬庱庳庽庾庿廆廌廋廎廑廒廔廕廜廞廥廫异弆弇弈弎弙弜弝弡弢弣弤弨弫弬弮弰弴弶弻弽弿彀彄彅彇彍彐彔彘彛彠彣彤彧"
  ],
  [
    "8fbda1",
    "彯彲彴彵彸彺彽彾徉徍徏徖徜徝徢徧徫徤徬徯徰徱徸忄忇忈忉忋忐",
    4,
    "忞忡忢忨忩忪忬忭忮忯忲忳忶忺忼怇怊怍怓怔怗怘怚怟怤怭怳怵恀恇恈恉恌恑恔恖恗恝恡恧恱恾恿悂悆悈悊悎悑悓悕悘悝悞悢悤悥您悰悱悷"
  ],
  [
    "8fbea1",
    "悻悾惂惄惈惉惊惋惎惏惔惕惙惛惝惞惢惥惲惵惸惼惽愂愇愊愌愐",
    4,
    "愖愗愙愜愞愢愪愫愰愱愵愶愷愹慁慅慆慉慞慠慬慲慸慻慼慿憀憁憃憄憋憍憒憓憗憘憜憝憟憠憥憨憪憭憸憹憼懀懁懂懎懏懕懜懝懞懟懡懢懧懩懥"
  ],
  [
    "8fbfa1",
    "懬懭懯戁戃戄戇戓戕戜戠戢戣戧戩戫戹戽扂扃扄扆扌扐扑扒扔扖扚扜扤扭扯扳扺扽抍抎抏抐抦抨抳抶抷抺抾抿拄拎拕拖拚拪拲拴拼拽挃挄挊挋挍挐挓挖挘挩挪挭挵挶挹挼捁捂捃捄捆捊捋捎捒捓捔捘捛捥捦捬捭捱捴捵"
  ],
  [
    "8fc0a1",
    "捸捼捽捿掂掄掇掊掐掔掕掙掚掞掤掦掭掮掯掽揁揅揈揎揑揓揔揕揜揠揥揪揬揲揳揵揸揹搉搊搐搒搔搘搞搠搢搤搥搩搪搯搰搵搽搿摋摏摑摒摓摔摚摛摜摝摟摠摡摣摭摳摴摻摽撅撇撏撐撑撘撙撛撝撟撡撣撦撨撬撳撽撾撿"
  ],
  [
    "8fc1a1",
    "擄擉擊擋擌擎擐擑擕擗擤擥擩擪擭擰擵擷擻擿攁攄攈攉攊攏攓攔攖攙攛攞攟攢攦攩攮攱攺攼攽敃敇敉敐敒敔敟敠敧敫敺敽斁斅斊斒斕斘斝斠斣斦斮斲斳斴斿旂旈旉旎旐旔旖旘旟旰旲旴旵旹旾旿昀昄昈昉昍昑昒昕昖昝"
  ],
  [
    "8fc2a1",
    "昞昡昢昣昤昦昩昪昫昬昮昰昱昳昹昷晀晅晆晊晌晑晎晗晘晙晛晜晠晡曻晪晫晬晾晳晵晿晷晸晹晻暀晼暋暌暍暐暒暙暚暛暜暟暠暤暭暱暲暵暻暿曀曂曃曈曌曎曏曔曛曟曨曫曬曮曺朅朇朎朓朙朜朠朢朳朾杅杇杈杌杔杕杝"
  ],
  [
    "8fc3a1",
    "杦杬杮杴杶杻极构枎枏枑枓枖枘枙枛枰枱枲枵枻枼枽柹柀柂柃柅柈柉柒柗柙柜柡柦柰柲柶柷桒栔栙栝栟栨栧栬栭栯栰栱栳栻栿桄桅桊桌桕桗桘桛桫桮",
    4,
    "桵桹桺桻桼梂梄梆梈梖梘梚梜梡梣梥梩梪梮梲梻棅棈棌棏"
  ],
  [
    "8fc4a1",
    "棐棑棓棖棙棜棝棥棨棪棫棬棭棰棱棵棶棻棼棽椆椉椊椐椑椓椖椗椱椳椵椸椻楂楅楉楎楗楛楣楤楥楦楨楩楬楰楱楲楺楻楿榀榍榒榖榘榡榥榦榨榫榭榯榷榸榺榼槅槈槑槖槗槢槥槮槯槱槳槵槾樀樁樃樏樑樕樚樝樠樤樨樰樲"
  ],
  [
    "8fc5a1",
    "樴樷樻樾樿橅橆橉橊橎橐橑橒橕橖橛橤橧橪橱橳橾檁檃檆檇檉檋檑檛檝檞檟檥檫檯檰檱檴檽檾檿櫆櫉櫈櫌櫐櫔櫕櫖櫜櫝櫤櫧櫬櫰櫱櫲櫼櫽欂欃欆欇欉欏欐欑欗欛欞欤欨欫欬欯欵欶欻欿歆歊歍歒歖歘歝歠歧歫歮歰歵歽"
  ],
  [
    "8fc6a1",
    "歾殂殅殗殛殟殠殢殣殨殩殬殭殮殰殸殹殽殾毃毄毉毌毖毚毡毣毦毧毮毱毷毹毿氂氄氅氉氍氎氐氒氙氟氦氧氨氬氮氳氵氶氺氻氿汊汋汍汏汒汔汙汛汜汫汭汯汴汶汸汹汻沅沆沇沉沔沕沗沘沜沟沰沲沴泂泆泍泏泐泑泒泔泖"
  ],
  [
    "8fc7a1",
    "泚泜泠泧泩泫泬泮泲泴洄洇洊洎洏洑洓洚洦洧洨汧洮洯洱洹洼洿浗浞浟浡浥浧浯浰浼涂涇涑涒涔涖涗涘涪涬涴涷涹涽涿淄淈淊淎淏淖淛淝淟淠淢淥淩淯淰淴淶淼渀渄渞渢渧渲渶渹渻渼湄湅湈湉湋湏湑湒湓湔湗湜湝湞"
  ],
  [
    "8fc8a1",
    "湢湣湨湳湻湽溍溓溙溠溧溭溮溱溳溻溿滀滁滃滇滈滊滍滎滏滫滭滮滹滻滽漄漈漊漌漍漖漘漚漛漦漩漪漯漰漳漶漻漼漭潏潑潒潓潗潙潚潝潞潡潢潨潬潽潾澃澇澈澋澌澍澐澒澓澔澖澚澟澠澥澦澧澨澮澯澰澵澶澼濅濇濈濊"
  ],
  [
    "8fc9a1",
    "濚濞濨濩濰濵濹濼濽瀀瀅瀆瀇瀍瀗瀠瀣瀯瀴瀷瀹瀼灃灄灈灉灊灋灔灕灝灞灎灤灥灬灮灵灶灾炁炅炆炔",
    4,
    "炛炤炫炰炱炴炷烊烑烓烔烕烖烘烜烤烺焃",
    4,
    "焋焌焏焞焠焫焭焯焰焱焸煁煅煆煇煊煋煐煒煗煚煜煞煠"
  ],
  [
    "8fcaa1",
    "煨煹熀熅熇熌熒熚熛熠熢熯熰熲熳熺熿燀燁燄燋燌燓燖燙燚燜燸燾爀爇爈爉爓爗爚爝爟爤爫爯爴爸爹牁牂牃牅牎牏牐牓牕牖牚牜牞牠牣牨牫牮牯牱牷牸牻牼牿犄犉犍犎犓犛犨犭犮犱犴犾狁狇狉狌狕狖狘狟狥狳狴狺狻"
  ],
  [
    "8fcba1",
    "狾猂猄猅猇猋猍猒猓猘猙猞猢猤猧猨猬猱猲猵猺猻猽獃獍獐獒獖獘獝獞獟獠獦獧獩獫獬獮獯獱獷獹獼玀玁玃玅玆玎玐玓玕玗玘玜玞玟玠玢玥玦玪玫玭玵玷玹玼玽玿珅珆珉珋珌珏珒珓珖珙珝珡珣珦珧珩珴珵珷珹珺珻珽"
  ],
  [
    "8fcca1",
    "珿琀琁琄琇琊琑琚琛琤琦琨",
    9,
    "琹瑀瑃瑄瑆瑇瑋瑍瑑瑒瑗瑝瑢瑦瑧瑨瑫瑭瑮瑱瑲璀璁璅璆璇璉璏璐璑璒璘璙璚璜璟璠璡璣璦璨璩璪璫璮璯璱璲璵璹璻璿瓈瓉瓌瓐瓓瓘瓚瓛瓞瓟瓤瓨瓪瓫瓯瓴瓺瓻瓼瓿甆"
  ],
  [
    "8fcda1",
    "甒甖甗甠甡甤甧甩甪甯甶甹甽甾甿畀畃畇畈畎畐畒畗畞畟畡畯畱畹",
    5,
    "疁疅疐疒疓疕疙疜疢疤疴疺疿痀痁痄痆痌痎痏痗痜痟痠痡痤痧痬痮痯痱痹瘀瘂瘃瘄瘇瘈瘊瘌瘏瘒瘓瘕瘖瘙瘛瘜瘝瘞瘣瘥瘦瘩瘭瘲瘳瘵瘸瘹"
  ],
  [
    "8fcea1",
    "瘺瘼癊癀癁癃癄癅癉癋癕癙癟癤癥癭癮癯癱癴皁皅皌皍皕皛皜皝皟皠皢",
    6,
    "皪皭皽盁盅盉盋盌盎盔盙盠盦盨盬盰盱盶盹盼眀眆眊眎眒眔眕眗眙眚眜眢眨眭眮眯眴眵眶眹眽眾睂睅睆睊睍睎睏睒睖睗睜睞睟睠睢"
  ],
  [
    "8fcfa1",
    "睤睧睪睬睰睲睳睴睺睽瞀瞄瞌瞍瞔瞕瞖瞚瞟瞢瞧瞪瞮瞯瞱瞵瞾矃矉矑矒矕矙矞矟矠矤矦矪矬矰矱矴矸矻砅砆砉砍砎砑砝砡砢砣砭砮砰砵砷硃硄硇硈硌硎硒硜硞硠硡硣硤硨硪确硺硾碊碏碔碘碡碝碞碟碤碨碬碭碰碱碲碳"
  ],
  [
    "8fd0a1",
    "碻碽碿磇磈磉磌磎磒磓磕磖磤磛磟磠磡磦磪磲磳礀磶磷磺磻磿礆礌礐礚礜礞礟礠礥礧礩礭礱礴礵礻礽礿祄祅祆祊祋祏祑祔祘祛祜祧祩祫祲祹祻祼祾禋禌禑禓禔禕禖禘禛禜禡禨禩禫禯禱禴禸离秂秄秇秈秊秏秔秖秚秝秞"
  ],
  [
    "8fd1a1",
    "秠秢秥秪秫秭秱秸秼稂稃稇稉稊稌稑稕稛稞稡稧稫稭稯稰稴稵稸稹稺穄穅穇穈穌穕穖穙穜穝穟穠穥穧穪穭穵穸穾窀窂窅窆窊窋窐窑窔窞窠窣窬窳窵窹窻窼竆竉竌竎竑竛竨竩竫竬竱竴竻竽竾笇笔笟笣笧笩笪笫笭笮笯笰"
  ],
  [
    "8fd2a1",
    "笱笴笽笿筀筁筇筎筕筠筤筦筩筪筭筯筲筳筷箄箉箎箐箑箖箛箞箠箥箬箯箰箲箵箶箺箻箼箽篂篅篈篊篔篖篗篙篚篛篨篪篲篴篵篸篹篺篼篾簁簂簃簄簆簉簋簌簎簏簙簛簠簥簦簨簬簱簳簴簶簹簺籆籊籕籑籒籓籙",
    5
  ],
  [
    "8fd3a1",
    "籡籣籧籩籭籮籰籲籹籼籽粆粇粏粔粞粠粦粰粶粷粺粻粼粿糄糇糈糉糍糏糓糔糕糗糙糚糝糦糩糫糵紃紇紈紉紏紑紒紓紖紝紞紣紦紪紭紱紼紽紾絀絁絇絈絍絑絓絗絙絚絜絝絥絧絪絰絸絺絻絿綁綂綃綅綆綈綋綌綍綑綖綗綝"
  ],
  [
    "8fd4a1",
    "綞綦綧綪綳綶綷綹緂",
    4,
    "緌緍緎緗緙縀緢緥緦緪緫緭緱緵緶緹緺縈縐縑縕縗縜縝縠縧縨縬縭縯縳縶縿繄繅繇繎繐繒繘繟繡繢繥繫繮繯繳繸繾纁纆纇纊纍纑纕纘纚纝纞缼缻缽缾缿罃罄罇罏罒罓罛罜罝罡罣罤罥罦罭"
  ],
  [
    "8fd5a1",
    "罱罽罾罿羀羋羍羏羐羑羖羗羜羡羢羦羪羭羴羼羿翀翃翈翎翏翛翟翣翥翨翬翮翯翲翺翽翾翿耇耈耊耍耎耏耑耓耔耖耝耞耟耠耤耦耬耮耰耴耵耷耹耺耼耾聀聄聠聤聦聭聱聵肁肈肎肜肞肦肧肫肸肹胈胍胏胒胔胕胗胘胠胭胮"
  ],
  [
    "8fd6a1",
    "胰胲胳胶胹胺胾脃脋脖脗脘脜脞脠脤脧脬脰脵脺脼腅腇腊腌腒腗腠腡腧腨腩腭腯腷膁膐膄膅膆膋膎膖膘膛膞膢膮膲膴膻臋臃臅臊臎臏臕臗臛臝臞臡臤臫臬臰臱臲臵臶臸臹臽臿舀舃舏舓舔舙舚舝舡舢舨舲舴舺艃艄艅艆"
  ],
  [
    "8fd7a1",
    "艋艎艏艑艖艜艠艣艧艭艴艻艽艿芀芁芃芄芇芉芊芎芑芔芖芘芚芛芠芡芣芤芧芨芩芪芮芰芲芴芷芺芼芾芿苆苐苕苚苠苢苤苨苪苭苯苶苷苽苾茀茁茇茈茊茋荔茛茝茞茟茡茢茬茭茮茰茳茷茺茼茽荂荃荄荇荍荎荑荕荖荗荰荸"
  ],
  [
    "8fd8a1",
    "荽荿莀莂莄莆莍莒莔莕莘莙莛莜莝莦莧莩莬莾莿菀菇菉菏菐菑菔菝荓菨菪菶菸菹菼萁萆萊萏萑萕萙莭萯萹葅葇葈葊葍葏葑葒葖葘葙葚葜葠葤葥葧葪葰葳葴葶葸葼葽蒁蒅蒒蒓蒕蒞蒦蒨蒩蒪蒯蒱蒴蒺蒽蒾蓀蓂蓇蓈蓌蓏蓓"
  ],
  [
    "8fd9a1",
    "蓜蓧蓪蓯蓰蓱蓲蓷蔲蓺蓻蓽蔂蔃蔇蔌蔎蔐蔜蔞蔢蔣蔤蔥蔧蔪蔫蔯蔳蔴蔶蔿蕆蕏",
    4,
    "蕖蕙蕜",
    6,
    "蕤蕫蕯蕹蕺蕻蕽蕿薁薅薆薉薋薌薏薓薘薝薟薠薢薥薧薴薶薷薸薼薽薾薿藂藇藊藋藎薭藘藚藟藠藦藨藭藳藶藼"
  ],
  [
    "8fdaa1",
    "藿蘀蘄蘅蘍蘎蘐蘑蘒蘘蘙蘛蘞蘡蘧蘩蘶蘸蘺蘼蘽虀虂虆虒虓虖虗虘虙虝虠",
    4,
    "虩虬虯虵虶虷虺蚍蚑蚖蚘蚚蚜蚡蚦蚧蚨蚭蚱蚳蚴蚵蚷蚸蚹蚿蛀蛁蛃蛅蛑蛒蛕蛗蛚蛜蛠蛣蛥蛧蚈蛺蛼蛽蜄蜅蜇蜋蜎蜏蜐蜓蜔蜙蜞蜟蜡蜣"
  ],
  [
    "8fdba1",
    "蜨蜮蜯蜱蜲蜹蜺蜼蜽蜾蝀蝃蝅蝍蝘蝝蝡蝤蝥蝯蝱蝲蝻螃",
    6,
    "螋螌螐螓螕螗螘螙螞螠螣螧螬螭螮螱螵螾螿蟁蟈蟉蟊蟎蟕蟖蟙蟚蟜蟟蟢蟣蟤蟪蟫蟭蟱蟳蟸蟺蟿蠁蠃蠆蠉蠊蠋蠐蠙蠒蠓蠔蠘蠚蠛蠜蠞蠟蠨蠭蠮蠰蠲蠵"
  ],
  [
    "8fdca1",
    "蠺蠼衁衃衅衈衉衊衋衎衑衕衖衘衚衜衟衠衤衩衱衹衻袀袘袚袛袜袟袠袨袪袺袽袾裀裊",
    4,
    "裑裒裓裛裞裧裯裰裱裵裷褁褆褍褎褏褕褖褘褙褚褜褠褦褧褨褰褱褲褵褹褺褾襀襂襅襆襉襏襒襗襚襛襜襡襢襣襫襮襰襳襵襺"
  ],
  [
    "8fdda1",
    "襻襼襽覉覍覐覔覕覛覜覟覠覥覰覴覵覶覷覼觔",
    4,
    "觥觩觫觭觱觳觶觹觽觿訄訅訇訏訑訒訔訕訞訠訢訤訦訫訬訯訵訷訽訾詀詃詅詇詉詍詎詓詖詗詘詜詝詡詥詧詵詶詷詹詺詻詾詿誀誃誆誋誏誐誒誖誗誙誟誧誩誮誯誳"
  ],
  [
    "8fdea1",
    "誶誷誻誾諃諆諈諉諊諑諓諔諕諗諝諟諬諰諴諵諶諼諿謅謆謋謑謜謞謟謊謭謰謷謼譂",
    4,
    "譈譒譓譔譙譍譞譣譭譶譸譹譼譾讁讄讅讋讍讏讔讕讜讞讟谸谹谽谾豅豇豉豋豏豑豓豔豗豘豛豝豙豣豤豦豨豩豭豳豵豶豻豾貆"
  ],
  [
    "8fdfa1",
    "貇貋貐貒貓貙貛貜貤貹貺賅賆賉賋賏賖賕賙賝賡賨賬賯賰賲賵賷賸賾賿贁贃贉贒贗贛赥赩赬赮赿趂趄趈趍趐趑趕趞趟趠趦趫趬趯趲趵趷趹趻跀跅跆跇跈跊跎跑跔跕跗跙跤跥跧跬跰趼跱跲跴跽踁踄踅踆踋踑踔踖踠踡踢"
  ],
  [
    "8fe0a1",
    "踣踦踧踱踳踶踷踸踹踽蹀蹁蹋蹍蹎蹏蹔蹛蹜蹝蹞蹡蹢蹩蹬蹭蹯蹰蹱蹹蹺蹻躂躃躉躐躒躕躚躛躝躞躢躧躩躭躮躳躵躺躻軀軁軃軄軇軏軑軔軜軨軮軰軱軷軹軺軭輀輂輇輈輏輐輖輗輘輞輠輡輣輥輧輨輬輭輮輴輵輶輷輺轀轁"
  ],
  [
    "8fe1a1",
    "轃轇轏轑",
    4,
    "轘轝轞轥辝辠辡辤辥辦辵辶辸达迀迁迆迊迋迍运迒迓迕迠迣迤迨迮迱迵迶迻迾适逄逈逌逘逛逨逩逯逪逬逭逳逴逷逿遃遄遌遛遝遢遦遧遬遰遴遹邅邈邋邌邎邐邕邗邘邙邛邠邡邢邥邰邲邳邴邶邽郌邾郃"
  ],
  [
    "8fe2a1",
    "郄郅郇郈郕郗郘郙郜郝郟郥郒郶郫郯郰郴郾郿鄀鄄鄅鄆鄈鄍鄐鄔鄖鄗鄘鄚鄜鄞鄠鄥鄢鄣鄧鄩鄮鄯鄱鄴鄶鄷鄹鄺鄼鄽酃酇酈酏酓酗酙酚酛酡酤酧酭酴酹酺酻醁醃醅醆醊醎醑醓醔醕醘醞醡醦醨醬醭醮醰醱醲醳醶醻醼醽醿"
  ],
  [
    "8fe3a1",
    "釂釃釅釓釔釗釙釚釞釤釥釩釪釬",
    5,
    "釷釹釻釽鈀鈁鈄鈅鈆鈇鈉鈊鈌鈐鈒鈓鈖鈘鈜鈝鈣鈤鈥鈦鈨鈮鈯鈰鈳鈵鈶鈸鈹鈺鈼鈾鉀鉂鉃鉆鉇鉊鉍鉎鉏鉑鉘鉙鉜鉝鉠鉡鉥鉧鉨鉩鉮鉯鉰鉵",
    4,
    "鉻鉼鉽鉿銈銉銊銍銎銒銗"
  ],
  [
    "8fe4a1",
    "銙銟銠銤銥銧銨銫銯銲銶銸銺銻銼銽銿",
    4,
    "鋅鋆鋇鋈鋋鋌鋍鋎鋐鋓鋕鋗鋘鋙鋜鋝鋟鋠鋡鋣鋥鋧鋨鋬鋮鋰鋹鋻鋿錀錂錈錍錑錔錕錜錝錞錟錡錤錥錧錩錪錳錴錶錷鍇鍈鍉鍐鍑鍒鍕鍗鍘鍚鍞鍤鍥鍧鍩鍪鍭鍯鍰鍱鍳鍴鍶"
  ],
  [
    "8fe5a1",
    "鍺鍽鍿鎀鎁鎂鎈鎊鎋鎍鎏鎒鎕鎘鎛鎞鎡鎣鎤鎦鎨鎫鎴鎵鎶鎺鎩鏁鏄鏅鏆鏇鏉",
    4,
    "鏓鏙鏜鏞鏟鏢鏦鏧鏹鏷鏸鏺鏻鏽鐁鐂鐄鐈鐉鐍鐎鐏鐕鐖鐗鐟鐮鐯鐱鐲鐳鐴鐻鐿鐽鑃鑅鑈鑊鑌鑕鑙鑜鑟鑡鑣鑨鑫鑭鑮鑯鑱鑲钄钃镸镹"
  ],
  [
    "8fe6a1",
    "镾閄閈閌閍閎閝閞閟閡閦閩閫閬閴閶閺閽閿闆闈闉闋闐闑闒闓闙闚闝闞闟闠闤闦阝阞阢阤阥阦阬阱阳阷阸阹阺阼阽陁陒陔陖陗陘陡陮陴陻陼陾陿隁隂隃隄隉隑隖隚隝隟隤隥隦隩隮隯隳隺雊雒嶲雘雚雝雞雟雩雯雱雺霂"
  ],
  [
    "8fe7a1",
    "霃霅霉霚霛霝霡霢霣霨霱霳靁靃靊靎靏靕靗靘靚靛靣靧靪靮靳靶靷靸靻靽靿鞀鞉鞕鞖鞗鞙鞚鞞鞟鞢鞬鞮鞱鞲鞵鞶鞸鞹鞺鞼鞾鞿韁韄韅韇韉韊韌韍韎韐韑韔韗韘韙韝韞韠韛韡韤韯韱韴韷韸韺頇頊頙頍頎頔頖頜頞頠頣頦"
  ],
  [
    "8fe8a1",
    "頫頮頯頰頲頳頵頥頾顄顇顊顑顒顓顖顗顙顚顢顣顥顦顪顬颫颭颮颰颴颷颸颺颻颿飂飅飈飌飡飣飥飦飧飪飳飶餂餇餈餑餕餖餗餚餛餜餟餢餦餧餫餱",
    4,
    "餹餺餻餼饀饁饆饇饈饍饎饔饘饙饛饜饞饟饠馛馝馟馦馰馱馲馵"
  ],
  [
    "8fe9a1",
    "馹馺馽馿駃駉駓駔駙駚駜駞駧駪駫駬駰駴駵駹駽駾騂騃騄騋騌騐騑騖騞騠騢騣騤騧騭騮騳騵騶騸驇驁驄驊驋驌驎驑驔驖驝骪骬骮骯骲骴骵骶骹骻骾骿髁髃髆髈髎髐髒髕髖髗髛髜髠髤髥髧髩髬髲髳髵髹髺髽髿",
    4
  ],
  [
    "8feaa1",
    "鬄鬅鬈鬉鬋鬌鬍鬎鬐鬒鬖鬙鬛鬜鬠鬦鬫鬭鬳鬴鬵鬷鬹鬺鬽魈魋魌魕魖魗魛魞魡魣魥魦魨魪",
    4,
    "魳魵魷魸魹魿鮀鮄鮅鮆鮇鮉鮊鮋鮍鮏鮐鮔鮚鮝鮞鮦鮧鮩鮬鮰鮱鮲鮷鮸鮻鮼鮾鮿鯁鯇鯈鯎鯐鯗鯘鯝鯟鯥鯧鯪鯫鯯鯳鯷鯸"
  ],
  [
    "8feba1",
    "鯹鯺鯽鯿鰀鰂鰋鰏鰑鰖鰘鰙鰚鰜鰞鰢鰣鰦",
    4,
    "鰱鰵鰶鰷鰽鱁鱃鱄鱅鱉鱊鱎鱏鱐鱓鱔鱖鱘鱛鱝鱞鱟鱣鱩鱪鱜鱫鱨鱮鱰鱲鱵鱷鱻鳦鳲鳷鳹鴋鴂鴑鴗鴘鴜鴝鴞鴯鴰鴲鴳鴴鴺鴼鵅鴽鵂鵃鵇鵊鵓鵔鵟鵣鵢鵥鵩鵪鵫鵰鵶鵷鵻"
  ],
  [
    "8feca1",
    "鵼鵾鶃鶄鶆鶊鶍鶎鶒鶓鶕鶖鶗鶘鶡鶪鶬鶮鶱鶵鶹鶼鶿鷃鷇鷉鷊鷔鷕鷖鷗鷚鷞鷟鷠鷥鷧鷩鷫鷮鷰鷳鷴鷾鸊鸂鸇鸎鸐鸑鸒鸕鸖鸙鸜鸝鹺鹻鹼麀麂麃麄麅麇麎麏麖麘麛麞麤麨麬麮麯麰麳麴麵黆黈黋黕黟黤黧黬黭黮黰黱黲黵"
  ],
  [
    "8feda1",
    "黸黿鼂鼃鼉鼏鼐鼑鼒鼔鼖鼗鼙鼚鼛鼟鼢鼦鼪鼫鼯鼱鼲鼴鼷鼹鼺鼼鼽鼿齁齃",
    4,
    "齓齕齖齗齘齚齝齞齨齩齭",
    4,
    "齳齵齺齽龏龐龑龒龔龖龗龞龡龢龣龥"
  ]
], _h = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  default: Qh
}), $h = [
  [
    "0",
    "\0",
    127,
    "€"
  ],
  [
    "8140",
    "丂丄丅丆丏丒丗丟丠両丣並丩丮丯丱丳丵丷丼乀乁乂乄乆乊乑乕乗乚乛乢乣乤乥乧乨乪",
    5,
    "乲乴",
    9,
    "乿",
    6,
    "亇亊"
  ],
  [
    "8180",
    "亐亖亗亙亜亝亞亣亪亯亰亱亴亶亷亸亹亼亽亾仈仌仏仐仒仚仛仜仠仢仦仧仩仭仮仯仱仴仸仹仺仼仾伀伂",
    6,
    "伋伌伒",
    4,
    "伜伝伡伣伨伩伬伭伮伱伳伵伷伹伻伾",
    4,
    "佄佅佇",
    5,
    "佒佔佖佡佢佦佨佪佫佭佮佱佲併佷佸佹佺佽侀侁侂侅來侇侊侌侎侐侒侓侕侖侘侙侚侜侞侟価侢"
  ],
  [
    "8240",
    "侤侫侭侰",
    4,
    "侶",
    8,
    "俀俁係俆俇俈俉俋俌俍俒",
    4,
    "俙俛俠俢俤俥俧俫俬俰俲俴俵俶俷俹俻俼俽俿",
    11
  ],
  [
    "8280",
    "個倎倐們倓倕倖倗倛倝倞倠倢倣値倧倫倯",
    10,
    "倻倽倿偀偁偂偄偅偆偉偊偋偍偐",
    4,
    "偖偗偘偙偛偝",
    7,
    "偦",
    5,
    "偭",
    8,
    "偸偹偺偼偽傁傂傃傄傆傇傉傊傋傌傎",
    20,
    "傤傦傪傫傭",
    4,
    "傳",
    6,
    "傼"
  ],
  [
    "8340",
    "傽",
    17,
    "僐",
    5,
    "僗僘僙僛",
    10,
    "僨僩僪僫僯僰僱僲僴僶",
    4,
    "僼",
    9,
    "儈"
  ],
  [
    "8380",
    "儉儊儌",
    5,
    "儓",
    13,
    "儢",
    28,
    "兂兇兊兌兎兏児兒兓兗兘兙兛兝",
    4,
    "兣兤兦內兩兪兯兲兺兾兿冃冄円冇冊冋冎冏冐冑冓冔冘冚冝冞冟冡冣冦",
    4,
    "冭冮冴冸冹冺冾冿凁凂凃凅凈凊凍凎凐凒",
    5
  ],
  [
    "8440",
    "凘凙凚凜凞凟凢凣凥",
    5,
    "凬凮凱凲凴凷凾刄刅刉刋刌刏刐刓刔刕刜刞刟刡刢刣別刦刧刪刬刯刱刲刴刵刼刾剄",
    5,
    "剋剎剏剒剓剕剗剘"
  ],
  [
    "8480",
    "剙剚剛剝剟剠剢剣剤剦剨剫剬剭剮剰剱剳",
    9,
    "剾劀劃",
    4,
    "劉",
    6,
    "劑劒劔",
    6,
    "劜劤劥劦劧劮劯劰労",
    9,
    "勀勁勂勄勅勆勈勊勌勍勎勏勑勓勔動勗務",
    5,
    "勠勡勢勣勥",
    10,
    "勱",
    7,
    "勻勼勽匁匂匃匄匇匉匊匋匌匎"
  ],
  [
    "8540",
    "匑匒匓匔匘匛匜匞匟匢匤匥匧匨匩匫匬匭匯",
    9,
    "匼匽區卂卄卆卋卌卍卐協単卙卛卝卥卨卪卬卭卲卶卹卻卼卽卾厀厁厃厇厈厊厎厏"
  ],
  [
    "8580",
    "厐",
    4,
    "厖厗厙厛厜厞厠厡厤厧厪厫厬厭厯",
    6,
    "厷厸厹厺厼厽厾叀參",
    4,
    "収叏叐叒叓叕叚叜叝叞叡叢叧叴叺叾叿吀吂吅吇吋吔吘吙吚吜吢吤吥吪吰吳吶吷吺吽吿呁呂呄呅呇呉呌呍呎呏呑呚呝",
    4,
    "呣呥呧呩",
    7,
    "呴呹呺呾呿咁咃咅咇咈咉咊咍咑咓咗咘咜咞咟咠咡"
  ],
  [
    "8640",
    "咢咥咮咰咲咵咶咷咹咺咼咾哃哅哊哋哖哘哛哠",
    4,
    "哫哬哯哰哱哴",
    5,
    "哻哾唀唂唃唄唅唈唊",
    4,
    "唒唓唕",
    5,
    "唜唝唞唟唡唥唦"
  ],
  [
    "8680",
    "唨唩唫唭唲唴唵唶唸唹唺唻唽啀啂啅啇啈啋",
    4,
    "啑啒啓啔啗",
    4,
    "啝啞啟啠啢啣啨啩啫啯",
    5,
    "啹啺啽啿喅喆喌喍喎喐喒喓喕喖喗喚喛喞喠",
    6,
    "喨",
    8,
    "喲喴営喸喺喼喿",
    4,
    "嗆嗇嗈嗊嗋嗎嗏嗐嗕嗗",
    4,
    "嗞嗠嗢嗧嗩嗭嗮嗰嗱嗴嗶嗸",
    4,
    "嗿嘂嘃嘄嘅"
  ],
  [
    "8740",
    "嘆嘇嘊嘋嘍嘐",
    7,
    "嘙嘚嘜嘝嘠嘡嘢嘥嘦嘨嘩嘪嘫嘮嘯嘰嘳嘵嘷嘸嘺嘼嘽嘾噀",
    11,
    "噏",
    4,
    "噕噖噚噛噝",
    4
  ],
  [
    "8780",
    "噣噥噦噧噭噮噯噰噲噳噴噵噷噸噹噺噽",
    7,
    "嚇",
    6,
    "嚐嚑嚒嚔",
    14,
    "嚤",
    10,
    "嚰",
    6,
    "嚸嚹嚺嚻嚽",
    12,
    "囋",
    8,
    "囕囖囘囙囜団囥",
    5,
    "囬囮囯囲図囶囷囸囻囼圀圁圂圅圇國",
    6
  ],
  [
    "8840",
    "園",
    9,
    "圝圞圠圡圢圤圥圦圧圫圱圲圴",
    4,
    "圼圽圿坁坃坄坅坆坈坉坋坒",
    4,
    "坘坙坢坣坥坧坬坮坰坱坲坴坵坸坹坺坽坾坿垀"
  ],
  [
    "8880",
    "垁垇垈垉垊垍",
    4,
    "垔",
    6,
    "垜垝垞垟垥垨垪垬垯垰垱垳垵垶垷垹",
    8,
    "埄",
    6,
    "埌埍埐埑埓埖埗埛埜埞埡埢埣埥",
    7,
    "埮埰埱埲埳埵埶執埻埼埾埿堁堃堄堅堈堉堊堌堎堏堐堒堓堔堖堗堘堚堛堜堝堟堢堣堥",
    4,
    "堫",
    4,
    "報堲堳場堶",
    7
  ],
  [
    "8940",
    "堾",
    5,
    "塅",
    6,
    "塎塏塐塒塓塕塖塗塙",
    4,
    "塟",
    5,
    "塦",
    4,
    "塭",
    16,
    "塿墂墄墆墇墈墊墋墌"
  ],
  [
    "8980",
    "墍",
    4,
    "墔",
    4,
    "墛墜墝墠",
    7,
    "墪",
    17,
    "墽墾墿壀壂壃壄壆",
    10,
    "壒壓壔壖",
    13,
    "壥",
    5,
    "壭壯壱売壴壵壷壸壺",
    7,
    "夃夅夆夈",
    4,
    "夎夐夑夒夓夗夘夛夝夞夠夡夢夣夦夨夬夰夲夳夵夶夻"
  ],
  [
    "8a40",
    "夽夾夿奀奃奅奆奊奌奍奐奒奓奙奛",
    4,
    "奡奣奤奦",
    12,
    "奵奷奺奻奼奾奿妀妅妉妋妌妎妏妐妑妔妕妘妚妛妜妝妟妠妡妢妦"
  ],
  [
    "8a80",
    "妧妬妭妰妱妳",
    5,
    "妺妼妽妿",
    6,
    "姇姈姉姌姍姎姏姕姖姙姛姞",
    4,
    "姤姦姧姩姪姫姭",
    11,
    "姺姼姽姾娀娂娊娋娍娎娏娐娒娔娕娖娗娙娚娛娝娞娡娢娤娦娧娨娪",
    6,
    "娳娵娷",
    4,
    "娽娾娿婁",
    4,
    "婇婈婋",
    9,
    "婖婗婘婙婛",
    5
  ],
  [
    "8b40",
    "婡婣婤婥婦婨婩婫",
    8,
    "婸婹婻婼婽婾媀",
    17,
    "媓",
    6,
    "媜",
    13,
    "媫媬"
  ],
  [
    "8b80",
    "媭",
    4,
    "媴媶媷媹",
    4,
    "媿嫀嫃",
    5,
    "嫊嫋嫍",
    4,
    "嫓嫕嫗嫙嫚嫛嫝嫞嫟嫢嫤嫥嫧嫨嫪嫬",
    4,
    "嫲",
    22,
    "嬊",
    11,
    "嬘",
    25,
    "嬳嬵嬶嬸",
    7,
    "孁",
    6
  ],
  [
    "8c40",
    "孈",
    7,
    "孒孖孞孠孡孧孨孫孭孮孯孲孴孶孷學孹孻孼孾孿宂宆宊宍宎宐宑宒宔宖実宧宨宩宬宭宮宯宱宲宷宺宻宼寀寁寃寈寉寊寋寍寎寏"
  ],
  [
    "8c80",
    "寑寔",
    8,
    "寠寢寣實寧審",
    4,
    "寯寱",
    6,
    "寽対尀専尃尅將專尋尌對導尐尒尓尗尙尛尞尟尠尡尣尦尨尩尪尫尭尮尯尰尲尳尵尶尷屃屄屆屇屌屍屒屓屔屖屗屘屚屛屜屝屟屢層屧",
    6,
    "屰屲",
    6,
    "屻屼屽屾岀岃",
    4,
    "岉岊岋岎岏岒岓岕岝",
    4,
    "岤",
    4
  ],
  [
    "8d40",
    "岪岮岯岰岲岴岶岹岺岻岼岾峀峂峃峅",
    5,
    "峌",
    5,
    "峓",
    5,
    "峚",
    6,
    "峢峣峧峩峫峬峮峯峱",
    9,
    "峼",
    4
  ],
  [
    "8d80",
    "崁崄崅崈",
    5,
    "崏",
    4,
    "崕崗崘崙崚崜崝崟",
    4,
    "崥崨崪崫崬崯",
    4,
    "崵",
    7,
    "崿",
    7,
    "嵈嵉嵍",
    10,
    "嵙嵚嵜嵞",
    10,
    "嵪嵭嵮嵰嵱嵲嵳嵵",
    12,
    "嶃",
    21,
    "嶚嶛嶜嶞嶟嶠"
  ],
  [
    "8e40",
    "嶡",
    21,
    "嶸",
    12,
    "巆",
    6,
    "巎",
    12,
    "巜巟巠巣巤巪巬巭"
  ],
  [
    "8e80",
    "巰巵巶巸",
    4,
    "巿帀帄帇帉帊帋帍帎帒帓帗帞",
    7,
    "帨",
    4,
    "帯帰帲",
    4,
    "帹帺帾帿幀幁幃幆",
    5,
    "幍",
    6,
    "幖",
    4,
    "幜幝幟幠幣",
    14,
    "幵幷幹幾庁庂広庅庈庉庌庍庎庒庘庛庝庡庢庣庤庨",
    4,
    "庮",
    4,
    "庴庺庻庼庽庿",
    6
  ],
  [
    "8f40",
    "廆廇廈廋",
    5,
    "廔廕廗廘廙廚廜",
    11,
    "廩廫",
    8,
    "廵廸廹廻廼廽弅弆弇弉弌弍弎弐弒弔弖弙弚弜弝弞弡弢弣弤"
  ],
  [
    "8f80",
    "弨弫弬弮弰弲",
    6,
    "弻弽弾弿彁",
    14,
    "彑彔彙彚彛彜彞彟彠彣彥彧彨彫彮彯彲彴彵彶彸彺彽彾彿徃徆徍徎徏徑従徔徖徚徛徝從徟徠徢",
    5,
    "復徫徬徯",
    5,
    "徶徸徹徺徻徾",
    4,
    "忇忈忊忋忎忓忔忕忚忛応忞忟忢忣忥忦忨忩忬忯忰忲忳忴忶忷忹忺忼怇"
  ],
  [
    "9040",
    "怈怉怋怌怐怑怓怗怘怚怞怟怢怣怤怬怭怮怰",
    4,
    "怶",
    4,
    "怽怾恀恄",
    6,
    "恌恎恏恑恓恔恖恗恘恛恜恞恟恠恡恥恦恮恱恲恴恵恷恾悀"
  ],
  [
    "9080",
    "悁悂悅悆悇悈悊悋悎悏悐悑悓悕悗悘悙悜悞悡悢悤悥悧悩悪悮悰悳悵悶悷悹悺悽",
    7,
    "惇惈惉惌",
    4,
    "惒惓惔惖惗惙惛惞惡",
    4,
    "惪惱惲惵惷惸惻",
    4,
    "愂愃愄愅愇愊愋愌愐",
    4,
    "愖愗愘愙愛愜愝愞愡愢愥愨愩愪愬",
    18,
    "慀",
    6
  ],
  [
    "9140",
    "慇慉態慍慏慐慒慓慔慖",
    6,
    "慞慟慠慡慣慤慥慦慩",
    6,
    "慱慲慳慴慶慸",
    18,
    "憌憍憏",
    4,
    "憕"
  ],
  [
    "9180",
    "憖",
    6,
    "憞",
    8,
    "憪憫憭",
    9,
    "憸",
    5,
    "憿懀懁懃",
    4,
    "應懌",
    4,
    "懓懕",
    16,
    "懧",
    13,
    "懶",
    8,
    "戀",
    5,
    "戇戉戓戔戙戜戝戞戠戣戦戧戨戩戫戭戯戰戱戲戵戶戸",
    4,
    "扂扄扅扆扊"
  ],
  [
    "9240",
    "扏扐払扖扗扙扚扜",
    6,
    "扤扥扨扱扲扴扵扷扸扺扻扽抁抂抃抅抆抇抈抋",
    5,
    "抔抙抜抝択抣抦抧抩抪抭抮抯抰抲抳抴抶抷抸抺抾拀拁"
  ],
  [
    "9280",
    "拃拋拏拑拕拝拞拠拡拤拪拫拰拲拵拸拹拺拻挀挃挄挅挆挊挋挌挍挏挐挒挓挔挕挗挘挙挜挦挧挩挬挭挮挰挱挳",
    5,
    "挻挼挾挿捀捁捄捇捈捊捑捒捓捔捖",
    7,
    "捠捤捥捦捨捪捫捬捯捰捲捳捴捵捸捹捼捽捾捿掁掃掄掅掆掋掍掑掓掔掕掗掙",
    6,
    "採掤掦掫掯掱掲掵掶掹掻掽掿揀"
  ],
  [
    "9340",
    "揁揂揃揅揇揈揊揋揌揑揓揔揕揗",
    6,
    "揟揢揤",
    4,
    "揫揬揮揯揰揱揳揵揷揹揺揻揼揾搃搄搆",
    4,
    "損搎搑搒搕",
    5,
    "搝搟搢搣搤"
  ],
  [
    "9380",
    "搥搧搨搩搫搮",
    5,
    "搵",
    4,
    "搻搼搾摀摂摃摉摋",
    6,
    "摓摕摖摗摙",
    4,
    "摟",
    7,
    "摨摪摫摬摮",
    9,
    "摻",
    6,
    "撃撆撈",
    8,
    "撓撔撗撘撚撛撜撝撟",
    4,
    "撥撦撧撨撪撫撯撱撲撳撴撶撹撻撽撾撿擁擃擄擆",
    6,
    "擏擑擓擔擕擖擙據"
  ],
  [
    "9440",
    "擛擜擝擟擠擡擣擥擧",
    24,
    "攁",
    7,
    "攊",
    7,
    "攓",
    4,
    "攙",
    8
  ],
  [
    "9480",
    "攢攣攤攦",
    4,
    "攬攭攰攱攲攳攷攺攼攽敀",
    4,
    "敆敇敊敋敍敎敐敒敓敔敗敘敚敜敟敠敡敤敥敧敨敩敪敭敮敯敱敳敵敶數",
    14,
    "斈斉斊斍斎斏斒斔斕斖斘斚斝斞斠斢斣斦斨斪斬斮斱",
    7,
    "斺斻斾斿旀旂旇旈旉旊旍旐旑旓旔旕旘",
    7,
    "旡旣旤旪旫"
  ],
  [
    "9540",
    "旲旳旴旵旸旹旻",
    4,
    "昁昄昅昇昈昉昋昍昐昑昒昖昗昘昚昛昜昞昡昢昣昤昦昩昪昫昬昮昰昲昳昷",
    4,
    "昽昿晀時晄",
    6,
    "晍晎晐晑晘"
  ],
  [
    "9580",
    "晙晛晜晝晞晠晢晣晥晧晩",
    4,
    "晱晲晳晵晸晹晻晼晽晿暀暁暃暅暆暈暉暊暋暍暎暏暐暒暓暔暕暘",
    4,
    "暞",
    8,
    "暩",
    4,
    "暯",
    4,
    "暵暶暷暸暺暻暼暽暿",
    25,
    "曚曞",
    7,
    "曧曨曪",
    5,
    "曱曵曶書曺曻曽朁朂會"
  ],
  [
    "9640",
    "朄朅朆朇朌朎朏朑朒朓朖朘朙朚朜朞朠",
    5,
    "朧朩朮朰朲朳朶朷朸朹朻朼朾朿杁杄杅杇杊杋杍杒杔杕杗",
    4,
    "杝杢杣杤杦杧杫杬杮東杴杶"
  ],
  [
    "9680",
    "杸杹杺杻杽枀枂枃枅枆枈枊枌枍枎枏枑枒枓枔枖枙枛枟枠枡枤枦枩枬枮枱枲枴枹",
    7,
    "柂柅",
    9,
    "柕柖柗柛柟柡柣柤柦柧柨柪柫柭柮柲柵",
    7,
    "柾栁栂栃栄栆栍栐栒栔栕栘",
    4,
    "栞栟栠栢",
    6,
    "栫",
    6,
    "栴栵栶栺栻栿桇桋桍桏桒桖",
    5
  ],
  [
    "9740",
    "桜桝桞桟桪桬",
    7,
    "桵桸",
    8,
    "梂梄梇",
    7,
    "梐梑梒梔梕梖梘",
    9,
    "梣梤梥梩梪梫梬梮梱梲梴梶梷梸"
  ],
  [
    "9780",
    "梹",
    6,
    "棁棃",
    5,
    "棊棌棎棏棐棑棓棔棖棗棙棛",
    4,
    "棡棢棤",
    9,
    "棯棲棳棴棶棷棸棻棽棾棿椀椂椃椄椆",
    4,
    "椌椏椑椓",
    11,
    "椡椢椣椥",
    7,
    "椮椯椱椲椳椵椶椷椸椺椻椼椾楀楁楃",
    16,
    "楕楖楘楙楛楜楟"
  ],
  [
    "9840",
    "楡楢楤楥楧楨楩楪楬業楯楰楲",
    4,
    "楺楻楽楾楿榁榃榅榊榋榌榎",
    5,
    "榖榗榙榚榝",
    9,
    "榩榪榬榮榯榰榲榳榵榶榸榹榺榼榽"
  ],
  [
    "9880",
    "榾榿槀槂",
    7,
    "構槍槏槑槒槓槕",
    5,
    "槜槝槞槡",
    11,
    "槮槯槰槱槳",
    9,
    "槾樀",
    9,
    "樋",
    11,
    "標",
    5,
    "樠樢",
    5,
    "権樫樬樭樮樰樲樳樴樶",
    6,
    "樿",
    4,
    "橅橆橈",
    7,
    "橑",
    6,
    "橚"
  ],
  [
    "9940",
    "橜",
    4,
    "橢橣橤橦",
    10,
    "橲",
    6,
    "橺橻橽橾橿檁檂檃檅",
    8,
    "檏檒",
    4,
    "檘",
    7,
    "檡",
    5
  ],
  [
    "9980",
    "檧檨檪檭",
    114,
    "欥欦欨",
    6
  ],
  [
    "9a40",
    "欯欰欱欳欴欵欶欸欻欼欽欿歀歁歂歄歅歈歊歋歍",
    11,
    "歚",
    7,
    "歨歩歫",
    13,
    "歺歽歾歿殀殅殈"
  ],
  [
    "9a80",
    "殌殎殏殐殑殔殕殗殘殙殜",
    4,
    "殢",
    7,
    "殫",
    7,
    "殶殸",
    6,
    "毀毃毄毆",
    4,
    "毌毎毐毑毘毚毜",
    4,
    "毢",
    7,
    "毬毭毮毰毱毲毴毶毷毸毺毻毼毾",
    6,
    "氈",
    4,
    "氎氒気氜氝氞氠氣氥氫氬氭氱氳氶氷氹氺氻氼氾氿汃汄汅汈汋",
    4,
    "汑汒汓汖汘"
  ],
  [
    "9b40",
    "汙汚汢汣汥汦汧汫",
    4,
    "汱汳汵汷汸決汻汼汿沀沄沇沊沋沍沎沑沒沕沖沗沘沚沜沝沞沠沢沨沬沯沰沴沵沶沷沺泀況泂泃泆泇泈泋泍泎泏泑泒泘"
  ],
  [
    "9b80",
    "泙泚泜泝泟泤泦泧泩泬泭泲泴泹泿洀洂洃洅洆洈洉洊洍洏洐洑洓洔洕洖洘洜洝洟",
    5,
    "洦洨洩洬洭洯洰洴洶洷洸洺洿浀浂浄浉浌浐浕浖浗浘浛浝浟浡浢浤浥浧浨浫浬浭浰浱浲浳浵浶浹浺浻浽",
    4,
    "涃涄涆涇涊涋涍涏涐涒涖",
    4,
    "涜涢涥涬涭涰涱涳涴涶涷涹",
    5,
    "淁淂淃淈淉淊"
  ],
  [
    "9c40",
    "淍淎淏淐淒淓淔淕淗淚淛淜淟淢淣淥淧淨淩淪淭淯淰淲淴淵淶淸淺淽",
    7,
    "渆渇済渉渋渏渒渓渕渘渙減渜渞渟渢渦渧渨渪測渮渰渱渳渵"
  ],
  [
    "9c80",
    "渶渷渹渻",
    7,
    "湅",
    7,
    "湏湐湑湒湕湗湙湚湜湝湞湠",
    10,
    "湬湭湯",
    14,
    "満溁溂溄溇溈溊",
    4,
    "溑",
    6,
    "溙溚溛溝溞溠溡溣溤溦溨溩溫溬溭溮溰溳溵溸溹溼溾溿滀滃滄滅滆滈滉滊滌滍滎滐滒滖滘滙滛滜滝滣滧滪",
    5
  ],
  [
    "9d40",
    "滰滱滲滳滵滶滷滸滺",
    7,
    "漃漄漅漇漈漊",
    4,
    "漐漑漒漖",
    9,
    "漡漢漣漥漦漧漨漬漮漰漲漴漵漷",
    6,
    "漿潀潁潂"
  ],
  [
    "9d80",
    "潃潄潅潈潉潊潌潎",
    9,
    "潙潚潛潝潟潠潡潣潤潥潧",
    5,
    "潯潰潱潳潵潶潷潹潻潽",
    6,
    "澅澆澇澊澋澏",
    12,
    "澝澞澟澠澢",
    4,
    "澨",
    10,
    "澴澵澷澸澺",
    5,
    "濁濃",
    5,
    "濊",
    6,
    "濓",
    10,
    "濟濢濣濤濥"
  ],
  [
    "9e40",
    "濦",
    7,
    "濰",
    32,
    "瀒",
    7,
    "瀜",
    6,
    "瀤",
    6
  ],
  [
    "9e80",
    "瀫",
    9,
    "瀶瀷瀸瀺",
    17,
    "灍灎灐",
    13,
    "灟",
    11,
    "灮灱灲灳灴灷灹灺灻災炁炂炃炄炆炇炈炋炌炍炏炐炑炓炗炘炚炛炞",
    12,
    "炰炲炴炵炶為炾炿烄烅烆烇烉烋",
    12,
    "烚"
  ],
  [
    "9f40",
    "烜烝烞烠烡烢烣烥烪烮烰",
    6,
    "烸烺烻烼烾",
    10,
    "焋",
    4,
    "焑焒焔焗焛",
    10,
    "焧",
    7,
    "焲焳焴"
  ],
  [
    "9f80",
    "焵焷",
    13,
    "煆煇煈煉煋煍煏",
    12,
    "煝煟",
    4,
    "煥煩",
    4,
    "煯煰煱煴煵煶煷煹煻煼煾",
    5,
    "熅",
    4,
    "熋熌熍熎熐熑熒熓熕熖熗熚",
    4,
    "熡",
    6,
    "熩熪熫熭",
    5,
    "熴熶熷熸熺",
    8,
    "燄",
    9,
    "燏",
    4
  ],
  [
    "a040",
    "燖",
    9,
    "燡燢燣燤燦燨",
    5,
    "燯",
    9,
    "燺",
    11,
    "爇",
    19
  ],
  [
    "a080",
    "爛爜爞",
    9,
    "爩爫爭爮爯爲爳爴爺爼爾牀",
    6,
    "牉牊牋牎牏牐牑牓牔牕牗牘牚牜牞牠牣牤牥牨牪牫牬牭牰牱牳牴牶牷牸牻牼牽犂犃犅",
    4,
    "犌犎犐犑犓",
    11,
    "犠",
    11,
    "犮犱犲犳犵犺",
    6,
    "狅狆狇狉狊狋狌狏狑狓狔狕狖狘狚狛"
  ],
  [
    "a1a1",
    "　、。·ˉˇ¨〃々—～‖…‘’“”〔〕〈",
    7,
    "〖〗【】±×÷∶∧∨∑∏∪∩∈∷√⊥∥∠⌒⊙∫∮≡≌≈∽∝≠≮≯≤≥∞∵∴♂♀°′″℃＄¤￠￡‰§№☆★○●◎◇◆□■△▲※→←↑↓〓"
  ],
  [
    "a2a1",
    "ⅰ",
    9
  ],
  [
    "a2b1",
    "⒈",
    19,
    "⑴",
    19,
    "①",
    9
  ],
  [
    "a2e5",
    "㈠",
    9
  ],
  [
    "a2f1",
    "Ⅰ",
    11
  ],
  [
    "a3a1",
    "！＂＃￥％",
    88,
    "￣"
  ],
  [
    "a4a1",
    "ぁ",
    82
  ],
  [
    "a5a1",
    "ァ",
    85
  ],
  [
    "a6a1",
    "Α",
    16,
    "Σ",
    6
  ],
  [
    "a6c1",
    "α",
    16,
    "σ",
    6
  ],
  [
    "a6e0",
    "︵︶︹︺︿﹀︽︾﹁﹂﹃﹄"
  ],
  [
    "a6ee",
    "︻︼︷︸︱"
  ],
  [
    "a6f4",
    "︳︴"
  ],
  [
    "a7a1",
    "А",
    5,
    "ЁЖ",
    25
  ],
  [
    "a7d1",
    "а",
    5,
    "ёж",
    25
  ],
  [
    "a840",
    "ˊˋ˙–―‥‵℅℉↖↗↘↙∕∟∣≒≦≧⊿═",
    35,
    "▁",
    6
  ],
  [
    "a880",
    "█",
    7,
    "▓▔▕▼▽◢◣◤◥☉⊕〒〝〞"
  ],
  [
    "a8a1",
    "āáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜüêɑ"
  ],
  [
    "a8bd",
    "ńň"
  ],
  [
    "a8c0",
    "ɡ"
  ],
  [
    "a8c5",
    "ㄅ",
    36
  ],
  [
    "a940",
    "〡",
    8,
    "㊣㎎㎏㎜㎝㎞㎡㏄㏎㏑㏒㏕︰￢￤"
  ],
  [
    "a959",
    "℡㈱"
  ],
  [
    "a95c",
    "‐"
  ],
  [
    "a960",
    "ー゛゜ヽヾ〆ゝゞ﹉",
    9,
    "﹔﹕﹖﹗﹙",
    8
  ],
  [
    "a980",
    "﹢",
    4,
    "﹨﹩﹪﹫"
  ],
  [
    "a996",
    "〇"
  ],
  [
    "a9a4",
    "─",
    75
  ],
  [
    "aa40",
    "狜狝狟狢",
    5,
    "狪狫狵狶狹狽狾狿猀猂猄",
    5,
    "猋猌猍猏猐猑猒猔猘猙猚猟猠猣猤猦猧猨猭猯猰猲猳猵猶猺猻猼猽獀",
    8
  ],
  [
    "aa80",
    "獉獊獋獌獎獏獑獓獔獕獖獘",
    7,
    "獡",
    10,
    "獮獰獱"
  ],
  [
    "ab40",
    "獲",
    11,
    "獿",
    4,
    "玅玆玈玊玌玍玏玐玒玓玔玕玗玘玙玚玜玝玞玠玡玣",
    5,
    "玪玬玭玱玴玵玶玸玹玼玽玾玿珁珃",
    4
  ],
  [
    "ab80",
    "珋珌珎珒",
    6,
    "珚珛珜珝珟珡珢珣珤珦珨珪珫珬珮珯珰珱珳",
    4
  ],
  [
    "ac40",
    "珸",
    10,
    "琄琇琈琋琌琍琎琑",
    8,
    "琜",
    5,
    "琣琤琧琩琫琭琯琱琲琷",
    4,
    "琽琾琿瑀瑂",
    11
  ],
  [
    "ac80",
    "瑎",
    6,
    "瑖瑘瑝瑠",
    12,
    "瑮瑯瑱",
    4,
    "瑸瑹瑺"
  ],
  [
    "ad40",
    "瑻瑼瑽瑿璂璄璅璆璈璉璊璌璍璏璑",
    10,
    "璝璟",
    7,
    "璪",
    15,
    "璻",
    12
  ],
  [
    "ad80",
    "瓈",
    9,
    "瓓",
    8,
    "瓝瓟瓡瓥瓧",
    6,
    "瓰瓱瓲"
  ],
  [
    "ae40",
    "瓳瓵瓸",
    6,
    "甀甁甂甃甅",
    7,
    "甎甐甒甔甕甖甗甛甝甞甠",
    4,
    "甦甧甪甮甴甶甹甼甽甿畁畂畃畄畆畇畉畊畍畐畑畒畓畕畖畗畘"
  ],
  [
    "ae80",
    "畝",
    7,
    "畧畨畩畫",
    6,
    "畳畵當畷畺",
    4,
    "疀疁疂疄疅疇"
  ],
  [
    "af40",
    "疈疉疊疌疍疎疐疓疕疘疛疜疞疢疦",
    4,
    "疭疶疷疺疻疿痀痁痆痋痌痎痏痐痑痓痗痙痚痜痝痟痠痡痥痩痬痭痮痯痲痳痵痶痷痸痺痻痽痾瘂瘄瘆瘇"
  ],
  [
    "af80",
    "瘈瘉瘋瘍瘎瘏瘑瘒瘓瘔瘖瘚瘜瘝瘞瘡瘣瘧瘨瘬瘮瘯瘱瘲瘶瘷瘹瘺瘻瘽癁療癄"
  ],
  [
    "b040",
    "癅",
    6,
    "癎",
    5,
    "癕癗",
    4,
    "癝癟癠癡癢癤",
    6,
    "癬癭癮癰",
    7,
    "癹発發癿皀皁皃皅皉皊皌皍皏皐皒皔皕皗皘皚皛"
  ],
  [
    "b080",
    "皜",
    7,
    "皥",
    8,
    "皯皰皳皵",
    9,
    "盀盁盃啊阿埃挨哎唉哀皑癌蔼矮艾碍爱隘鞍氨安俺按暗岸胺案肮昂盎凹敖熬翱袄傲奥懊澳芭捌扒叭吧笆八疤巴拔跋靶把耙坝霸罢爸白柏百摆佰败拜稗斑班搬扳般颁板版扮拌伴瓣半办绊邦帮梆榜膀绑棒磅蚌镑傍谤苞胞包褒剥"
  ],
  [
    "b140",
    "盄盇盉盋盌盓盕盙盚盜盝盞盠",
    4,
    "盦",
    7,
    "盰盳盵盶盷盺盻盽盿眀眂眃眅眆眊県眎",
    10,
    "眛眜眝眞眡眣眤眥眧眪眫"
  ],
  [
    "b180",
    "眬眮眰",
    4,
    "眹眻眽眾眿睂睄睅睆睈",
    7,
    "睒",
    7,
    "睜薄雹保堡饱宝抱报暴豹鲍爆杯碑悲卑北辈背贝钡倍狈备惫焙被奔苯本笨崩绷甭泵蹦迸逼鼻比鄙笔彼碧蓖蔽毕毙毖币庇痹闭敝弊必辟壁臂避陛鞭边编贬扁便变卞辨辩辫遍标彪膘表鳖憋别瘪彬斌濒滨宾摈兵冰柄丙秉饼炳"
  ],
  [
    "b240",
    "睝睞睟睠睤睧睩睪睭",
    11,
    "睺睻睼瞁瞂瞃瞆",
    5,
    "瞏瞐瞓",
    11,
    "瞡瞣瞤瞦瞨瞫瞭瞮瞯瞱瞲瞴瞶",
    4
  ],
  [
    "b280",
    "瞼瞾矀",
    12,
    "矎",
    8,
    "矘矙矚矝",
    4,
    "矤病并玻菠播拨钵波博勃搏铂箔伯帛舶脖膊渤泊驳捕卜哺补埠不布步簿部怖擦猜裁材才财睬踩采彩菜蔡餐参蚕残惭惨灿苍舱仓沧藏操糙槽曹草厕策侧册测层蹭插叉茬茶查碴搽察岔差诧拆柴豺搀掺蝉馋谗缠铲产阐颤昌猖"
  ],
  [
    "b340",
    "矦矨矪矯矰矱矲矴矵矷矹矺矻矼砃",
    5,
    "砊砋砎砏砐砓砕砙砛砞砠砡砢砤砨砪砫砮砯砱砲砳砵砶砽砿硁硂硃硄硆硈硉硊硋硍硏硑硓硔硘硙硚"
  ],
  [
    "b380",
    "硛硜硞",
    11,
    "硯",
    7,
    "硸硹硺硻硽",
    6,
    "场尝常长偿肠厂敞畅唱倡超抄钞朝嘲潮巢吵炒车扯撤掣彻澈郴臣辰尘晨忱沉陈趁衬撑称城橙成呈乘程惩澄诚承逞骋秤吃痴持匙池迟弛驰耻齿侈尺赤翅斥炽充冲虫崇宠抽酬畴踌稠愁筹仇绸瞅丑臭初出橱厨躇锄雏滁除楚"
  ],
  [
    "b440",
    "碄碅碆碈碊碋碏碐碒碔碕碖碙碝碞碠碢碤碦碨",
    7,
    "碵碶碷碸確碻碼碽碿磀磂磃磄磆磇磈磌磍磎磏磑磒磓磖磗磘磚",
    9
  ],
  [
    "b480",
    "磤磥磦磧磩磪磫磭",
    4,
    "磳磵磶磸磹磻",
    5,
    "礂礃礄礆",
    6,
    "础储矗搐触处揣川穿椽传船喘串疮窗幢床闯创吹炊捶锤垂春椿醇唇淳纯蠢戳绰疵茨磁雌辞慈瓷词此刺赐次聪葱囱匆从丛凑粗醋簇促蹿篡窜摧崔催脆瘁粹淬翠村存寸磋撮搓措挫错搭达答瘩打大呆歹傣戴带殆代贷袋待逮"
  ],
  [
    "b540",
    "礍",
    5,
    "礔",
    9,
    "礟",
    4,
    "礥",
    14,
    "礵",
    4,
    "礽礿祂祃祄祅祇祊",
    8,
    "祔祕祘祙祡祣"
  ],
  [
    "b580",
    "祤祦祩祪祫祬祮祰",
    6,
    "祹祻",
    4,
    "禂禃禆禇禈禉禋禌禍禎禐禑禒怠耽担丹单郸掸胆旦氮但惮淡诞弹蛋当挡党荡档刀捣蹈倒岛祷导到稻悼道盗德得的蹬灯登等瞪凳邓堤低滴迪敌笛狄涤翟嫡抵底地蒂第帝弟递缔颠掂滇碘点典靛垫电佃甸店惦奠淀殿碉叼雕凋刁掉吊钓调跌爹碟蝶迭谍叠"
  ],
  [
    "b640",
    "禓",
    6,
    "禛",
    11,
    "禨",
    10,
    "禴",
    4,
    "禼禿秂秄秅秇秈秊秌秎秏秐秓秔秖秗秙",
    5,
    "秠秡秢秥秨秪"
  ],
  [
    "b680",
    "秬秮秱",
    6,
    "秹秺秼秾秿稁稄稅稇稈稉稊稌稏",
    4,
    "稕稖稘稙稛稜丁盯叮钉顶鼎锭定订丢东冬董懂动栋侗恫冻洞兜抖斗陡豆逗痘都督毒犊独读堵睹赌杜镀肚度渡妒端短锻段断缎堆兑队对墩吨蹲敦顿囤钝盾遁掇哆多夺垛躲朵跺舵剁惰堕蛾峨鹅俄额讹娥恶厄扼遏鄂饿恩而儿耳尔饵洱二"
  ],
  [
    "b740",
    "稝稟稡稢稤",
    14,
    "稴稵稶稸稺稾穀",
    5,
    "穇",
    9,
    "穒",
    4,
    "穘",
    16
  ],
  [
    "b780",
    "穩",
    6,
    "穱穲穳穵穻穼穽穾窂窅窇窉窊窋窌窎窏窐窓窔窙窚窛窞窡窢贰发罚筏伐乏阀法珐藩帆番翻樊矾钒繁凡烦反返范贩犯饭泛坊芳方肪房防妨仿访纺放菲非啡飞肥匪诽吠肺废沸费芬酚吩氛分纷坟焚汾粉奋份忿愤粪丰封枫蜂峰锋风疯烽逢冯缝讽奉凤佛否夫敷肤孵扶拂辐幅氟符伏俘服"
  ],
  [
    "b840",
    "窣窤窧窩窪窫窮",
    4,
    "窴",
    10,
    "竀",
    10,
    "竌",
    9,
    "竗竘竚竛竜竝竡竢竤竧",
    5,
    "竮竰竱竲竳"
  ],
  [
    "b880",
    "竴",
    4,
    "竻竼竾笀笁笂笅笇笉笌笍笎笐笒笓笖笗笘笚笜笝笟笡笢笣笧笩笭浮涪福袱弗甫抚辅俯釜斧脯腑府腐赴副覆赋复傅付阜父腹负富讣附妇缚咐噶嘎该改概钙盖溉干甘杆柑竿肝赶感秆敢赣冈刚钢缸肛纲岗港杠篙皋高膏羔糕搞镐稿告哥歌搁戈鸽胳疙割革葛格蛤阁隔铬个各给根跟耕更庚羹"
  ],
  [
    "b940",
    "笯笰笲笴笵笶笷笹笻笽笿",
    5,
    "筆筈筊筍筎筓筕筗筙筜筞筟筡筣",
    10,
    "筯筰筳筴筶筸筺筼筽筿箁箂箃箄箆",
    6,
    "箎箏"
  ],
  [
    "b980",
    "箑箒箓箖箘箙箚箛箞箟箠箣箤箥箮箯箰箲箳箵箶箷箹",
    7,
    "篂篃範埂耿梗工攻功恭龚供躬公宫弓巩汞拱贡共钩勾沟苟狗垢构购够辜菇咕箍估沽孤姑鼓古蛊骨谷股故顾固雇刮瓜剐寡挂褂乖拐怪棺关官冠观管馆罐惯灌贯光广逛瑰规圭硅归龟闺轨鬼诡癸桂柜跪贵刽辊滚棍锅郭国果裹过哈"
  ],
  [
    "ba40",
    "篅篈築篊篋篍篎篏篐篒篔",
    4,
    "篛篜篞篟篠篢篣篤篧篨篩篫篬篭篯篰篲",
    4,
    "篸篹篺篻篽篿",
    7,
    "簈簉簊簍簎簐",
    5,
    "簗簘簙"
  ],
  [
    "ba80",
    "簚",
    4,
    "簠",
    5,
    "簨簩簫",
    12,
    "簹",
    5,
    "籂骸孩海氦亥害骇酣憨邯韩含涵寒函喊罕翰撼捍旱憾悍焊汗汉夯杭航壕嚎豪毫郝好耗号浩呵喝荷菏核禾和何合盒貉阂河涸赫褐鹤贺嘿黑痕很狠恨哼亨横衡恒轰哄烘虹鸿洪宏弘红喉侯猴吼厚候后呼乎忽瑚壶葫胡蝴狐糊湖"
  ],
  [
    "bb40",
    "籃",
    9,
    "籎",
    36,
    "籵",
    5,
    "籾",
    9
  ],
  [
    "bb80",
    "粈粊",
    6,
    "粓粔粖粙粚粛粠粡粣粦粧粨粩粫粬粭粯粰粴",
    4,
    "粺粻弧虎唬护互沪户花哗华猾滑画划化话槐徊怀淮坏欢环桓还缓换患唤痪豢焕涣宦幻荒慌黄磺蝗簧皇凰惶煌晃幌恍谎灰挥辉徽恢蛔回毁悔慧卉惠晦贿秽会烩汇讳诲绘荤昏婚魂浑混豁活伙火获或惑霍货祸击圾基机畸稽积箕"
  ],
  [
    "bc40",
    "粿糀糂糃糄糆糉糋糎",
    6,
    "糘糚糛糝糞糡",
    6,
    "糩",
    5,
    "糰",
    7,
    "糹糺糼",
    13,
    "紋",
    5
  ],
  [
    "bc80",
    "紑",
    14,
    "紡紣紤紥紦紨紩紪紬紭紮細",
    6,
    "肌饥迹激讥鸡姬绩缉吉极棘辑籍集及急疾汲即嫉级挤几脊己蓟技冀季伎祭剂悸济寄寂计记既忌际妓继纪嘉枷夹佳家加荚颊贾甲钾假稼价架驾嫁歼监坚尖笺间煎兼肩艰奸缄茧检柬碱硷拣捡简俭剪减荐槛鉴践贱见键箭件"
  ],
  [
    "bd40",
    "紷",
    54,
    "絯",
    7
  ],
  [
    "bd80",
    "絸",
    32,
    "健舰剑饯渐溅涧建僵姜将浆江疆蒋桨奖讲匠酱降蕉椒礁焦胶交郊浇骄娇嚼搅铰矫侥脚狡角饺缴绞剿教酵轿较叫窖揭接皆秸街阶截劫节桔杰捷睫竭洁结解姐戒藉芥界借介疥诫届巾筋斤金今津襟紧锦仅谨进靳晋禁近烬浸"
  ],
  [
    "be40",
    "継",
    12,
    "綧",
    6,
    "綯",
    42
  ],
  [
    "be80",
    "線",
    32,
    "尽劲荆兢茎睛晶鲸京惊精粳经井警景颈静境敬镜径痉靖竟竞净炯窘揪究纠玖韭久灸九酒厩救旧臼舅咎就疚鞠拘狙疽居驹菊局咀矩举沮聚拒据巨具距踞锯俱句惧炬剧捐鹃娟倦眷卷绢撅攫抉掘倔爵觉决诀绝均菌钧军君峻"
  ],
  [
    "bf40",
    "緻",
    62
  ],
  [
    "bf80",
    "縺縼",
    4,
    "繂",
    4,
    "繈",
    21,
    "俊竣浚郡骏喀咖卡咯开揩楷凯慨刊堪勘坎砍看康慷糠扛抗亢炕考拷烤靠坷苛柯棵磕颗科壳咳可渴克刻客课肯啃垦恳坑吭空恐孔控抠口扣寇枯哭窟苦酷库裤夸垮挎跨胯块筷侩快宽款匡筐狂框矿眶旷况亏盔岿窥葵奎魁傀"
  ],
  [
    "c040",
    "繞",
    35,
    "纃",
    23,
    "纜纝纞"
  ],
  [
    "c080",
    "纮纴纻纼绖绤绬绹缊缐缞缷缹缻",
    6,
    "罃罆",
    9,
    "罒罓馈愧溃坤昆捆困括扩廓阔垃拉喇蜡腊辣啦莱来赖蓝婪栏拦篮阑兰澜谰揽览懒缆烂滥琅榔狼廊郎朗浪捞劳牢老佬姥酪烙涝勒乐雷镭蕾磊累儡垒擂肋类泪棱楞冷厘梨犁黎篱狸离漓理李里鲤礼莉荔吏栗丽厉励砾历利傈例俐"
  ],
  [
    "c140",
    "罖罙罛罜罝罞罠罣",
    4,
    "罫罬罭罯罰罳罵罶罷罸罺罻罼罽罿羀羂",
    7,
    "羋羍羏",
    4,
    "羕",
    4,
    "羛羜羠羢羣羥羦羨",
    6,
    "羱"
  ],
  [
    "c180",
    "羳",
    4,
    "羺羻羾翀翂翃翄翆翇翈翉翋翍翏",
    4,
    "翖翗翙",
    5,
    "翢翣痢立粒沥隶力璃哩俩联莲连镰廉怜涟帘敛脸链恋炼练粮凉梁粱良两辆量晾亮谅撩聊僚疗燎寥辽潦了撂镣廖料列裂烈劣猎琳林磷霖临邻鳞淋凛赁吝拎玲菱零龄铃伶羚凌灵陵岭领另令溜琉榴硫馏留刘瘤流柳六龙聋咙笼窿"
  ],
  [
    "c240",
    "翤翧翨翪翫翬翭翯翲翴",
    6,
    "翽翾翿耂耇耈耉耊耎耏耑耓耚耛耝耞耟耡耣耤耫",
    5,
    "耲耴耹耺耼耾聀聁聄聅聇聈聉聎聏聐聑聓聕聖聗"
  ],
  [
    "c280",
    "聙聛",
    13,
    "聫",
    5,
    "聲",
    11,
    "隆垄拢陇楼娄搂篓漏陋芦卢颅庐炉掳卤虏鲁麓碌露路赂鹿潞禄录陆戮驴吕铝侣旅履屡缕虑氯律率滤绿峦挛孪滦卵乱掠略抡轮伦仑沦纶论萝螺罗逻锣箩骡裸落洛骆络妈麻玛码蚂马骂嘛吗埋买麦卖迈脉瞒馒蛮满蔓曼慢漫"
  ],
  [
    "c340",
    "聾肁肂肅肈肊肍",
    5,
    "肔肕肗肙肞肣肦肧肨肬肰肳肵肶肸肹肻胅胇",
    4,
    "胏",
    6,
    "胘胟胠胢胣胦胮胵胷胹胻胾胿脀脁脃脄脅脇脈脋"
  ],
  [
    "c380",
    "脌脕脗脙脛脜脝脟",
    12,
    "脭脮脰脳脴脵脷脹",
    4,
    "脿谩芒茫盲氓忙莽猫茅锚毛矛铆卯茂冒帽貌贸么玫枚梅酶霉煤没眉媒镁每美昧寐妹媚门闷们萌蒙檬盟锰猛梦孟眯醚靡糜迷谜弥米秘觅泌蜜密幂棉眠绵冕免勉娩缅面苗描瞄藐秒渺庙妙蔑灭民抿皿敏悯闽明螟鸣铭名命谬摸"
  ],
  [
    "c440",
    "腀",
    5,
    "腇腉腍腎腏腒腖腗腘腛",
    4,
    "腡腢腣腤腦腨腪腫腬腯腲腳腵腶腷腸膁膃",
    4,
    "膉膋膌膍膎膐膒",
    5,
    "膙膚膞",
    4,
    "膤膥"
  ],
  [
    "c480",
    "膧膩膫",
    7,
    "膴",
    5,
    "膼膽膾膿臄臅臇臈臉臋臍",
    6,
    "摹蘑模膜磨摩魔抹末莫墨默沫漠寞陌谋牟某拇牡亩姆母墓暮幕募慕木目睦牧穆拿哪呐钠那娜纳氖乃奶耐奈南男难囊挠脑恼闹淖呢馁内嫩能妮霓倪泥尼拟你匿腻逆溺蔫拈年碾撵捻念娘酿鸟尿捏聂孽啮镊镍涅您柠狞凝宁"
  ],
  [
    "c540",
    "臔",
    14,
    "臤臥臦臨臩臫臮",
    4,
    "臵",
    5,
    "臽臿舃與",
    4,
    "舎舏舑舓舕",
    5,
    "舝舠舤舥舦舧舩舮舲舺舼舽舿"
  ],
  [
    "c580",
    "艀艁艂艃艅艆艈艊艌艍艎艐",
    7,
    "艙艛艜艝艞艠",
    7,
    "艩拧泞牛扭钮纽脓浓农弄奴努怒女暖虐疟挪懦糯诺哦欧鸥殴藕呕偶沤啪趴爬帕怕琶拍排牌徘湃派攀潘盘磐盼畔判叛乓庞旁耪胖抛咆刨炮袍跑泡呸胚培裴赔陪配佩沛喷盆砰抨烹澎彭蓬棚硼篷膨朋鹏捧碰坯砒霹批披劈琵毗"
  ],
  [
    "c640",
    "艪艫艬艭艱艵艶艷艸艻艼芀芁芃芅芆芇芉芌芐芓芔芕芖芚芛芞芠芢芣芧芲芵芶芺芻芼芿苀苂苃苅苆苉苐苖苙苚苝苢苧苨苩苪苬苭苮苰苲苳苵苶苸"
  ],
  [
    "c680",
    "苺苼",
    4,
    "茊茋茍茐茒茓茖茘茙茝",
    9,
    "茩茪茮茰茲茷茻茽啤脾疲皮匹痞僻屁譬篇偏片骗飘漂瓢票撇瞥拼频贫品聘乒坪苹萍平凭瓶评屏坡泼颇婆破魄迫粕剖扑铺仆莆葡菩蒲埔朴圃普浦谱曝瀑期欺栖戚妻七凄漆柒沏其棋奇歧畦崎脐齐旗祈祁骑起岂乞企启契砌器气迄弃汽泣讫掐"
  ],
  [
    "c740",
    "茾茿荁荂荄荅荈荊",
    4,
    "荓荕",
    4,
    "荝荢荰",
    6,
    "荹荺荾",
    6,
    "莇莈莊莋莌莍莏莐莑莔莕莖莗莙莚莝莟莡",
    6,
    "莬莭莮"
  ],
  [
    "c780",
    "莯莵莻莾莿菂菃菄菆菈菉菋菍菎菐菑菒菓菕菗菙菚菛菞菢菣菤菦菧菨菫菬菭恰洽牵扦钎铅千迁签仟谦乾黔钱钳前潜遣浅谴堑嵌欠歉枪呛腔羌墙蔷强抢橇锹敲悄桥瞧乔侨巧鞘撬翘峭俏窍切茄且怯窃钦侵亲秦琴勤芹擒禽寝沁青轻氢倾卿清擎晴氰情顷请庆琼穷秋丘邱球求囚酋泅趋区蛆曲躯屈驱渠"
  ],
  [
    "c840",
    "菮華菳",
    4,
    "菺菻菼菾菿萀萂萅萇萈萉萊萐萒",
    5,
    "萙萚萛萞",
    5,
    "萩",
    7,
    "萲",
    5,
    "萹萺萻萾",
    7,
    "葇葈葉"
  ],
  [
    "c880",
    "葊",
    6,
    "葒",
    4,
    "葘葝葞葟葠葢葤",
    4,
    "葪葮葯葰葲葴葷葹葻葼取娶龋趣去圈颧权醛泉全痊拳犬券劝缺炔瘸却鹊榷确雀裙群然燃冉染瓤壤攘嚷让饶扰绕惹热壬仁人忍韧任认刃妊纫扔仍日戎茸蓉荣融熔溶容绒冗揉柔肉茹蠕儒孺如辱乳汝入褥软阮蕊瑞锐闰润若弱撒洒萨腮鳃塞赛三叁"
  ],
  [
    "c940",
    "葽",
    4,
    "蒃蒄蒅蒆蒊蒍蒏",
    7,
    "蒘蒚蒛蒝蒞蒟蒠蒢",
    12,
    "蒰蒱蒳蒵蒶蒷蒻蒼蒾蓀蓂蓃蓅蓆蓇蓈蓋蓌蓎蓏蓒蓔蓕蓗"
  ],
  [
    "c980",
    "蓘",
    4,
    "蓞蓡蓢蓤蓧",
    4,
    "蓭蓮蓯蓱",
    10,
    "蓽蓾蔀蔁蔂伞散桑嗓丧搔骚扫嫂瑟色涩森僧莎砂杀刹沙纱傻啥煞筛晒珊苫杉山删煽衫闪陕擅赡膳善汕扇缮墒伤商赏晌上尚裳梢捎稍烧芍勺韶少哨邵绍奢赊蛇舌舍赦摄射慑涉社设砷申呻伸身深娠绅神沈审婶甚肾慎渗声生甥牲升绳"
  ],
  [
    "ca40",
    "蔃",
    8,
    "蔍蔎蔏蔐蔒蔔蔕蔖蔘蔙蔛蔜蔝蔞蔠蔢",
    8,
    "蔭",
    9,
    "蔾",
    4,
    "蕄蕅蕆蕇蕋",
    10
  ],
  [
    "ca80",
    "蕗蕘蕚蕛蕜蕝蕟",
    4,
    "蕥蕦蕧蕩",
    8,
    "蕳蕵蕶蕷蕸蕼蕽蕿薀薁省盛剩胜圣师失狮施湿诗尸虱十石拾时什食蚀实识史矢使屎驶始式示士世柿事拭誓逝势是嗜噬适仕侍释饰氏市恃室视试收手首守寿授售受瘦兽蔬枢梳殊抒输叔舒淑疏书赎孰熟薯暑曙署蜀黍鼠属术述树束戍竖墅庶数漱"
  ],
  [
    "cb40",
    "薂薃薆薈",
    6,
    "薐",
    10,
    "薝",
    6,
    "薥薦薧薩薫薬薭薱",
    5,
    "薸薺",
    6,
    "藂",
    6,
    "藊",
    4,
    "藑藒"
  ],
  [
    "cb80",
    "藔藖",
    5,
    "藝",
    6,
    "藥藦藧藨藪",
    14,
    "恕刷耍摔衰甩帅栓拴霜双爽谁水睡税吮瞬顺舜说硕朔烁斯撕嘶思私司丝死肆寺嗣四伺似饲巳松耸怂颂送宋讼诵搜艘擞嗽苏酥俗素速粟僳塑溯宿诉肃酸蒜算虽隋随绥髓碎岁穗遂隧祟孙损笋蓑梭唆缩琐索锁所塌他它她塔"
  ],
  [
    "cc40",
    "藹藺藼藽藾蘀",
    4,
    "蘆",
    10,
    "蘒蘓蘔蘕蘗",
    15,
    "蘨蘪",
    13,
    "蘹蘺蘻蘽蘾蘿虀"
  ],
  [
    "cc80",
    "虁",
    11,
    "虒虓處",
    4,
    "虛虜虝號虠虡虣",
    7,
    "獭挞蹋踏胎苔抬台泰酞太态汰坍摊贪瘫滩坛檀痰潭谭谈坦毯袒碳探叹炭汤塘搪堂棠膛唐糖倘躺淌趟烫掏涛滔绦萄桃逃淘陶讨套特藤腾疼誊梯剔踢锑提题蹄啼体替嚏惕涕剃屉天添填田甜恬舔腆挑条迢眺跳贴铁帖厅听烃"
  ],
  [
    "cd40",
    "虭虯虰虲",
    6,
    "蚃",
    6,
    "蚎",
    4,
    "蚔蚖",
    5,
    "蚞",
    4,
    "蚥蚦蚫蚭蚮蚲蚳蚷蚸蚹蚻",
    4,
    "蛁蛂蛃蛅蛈蛌蛍蛒蛓蛕蛖蛗蛚蛜"
  ],
  [
    "cd80",
    "蛝蛠蛡蛢蛣蛥蛦蛧蛨蛪蛫蛬蛯蛵蛶蛷蛺蛻蛼蛽蛿蜁蜄蜅蜆蜋蜌蜎蜏蜐蜑蜔蜖汀廷停亭庭挺艇通桐酮瞳同铜彤童桶捅筒统痛偷投头透凸秃突图徒途涂屠土吐兔湍团推颓腿蜕褪退吞屯臀拖托脱鸵陀驮驼椭妥拓唾挖哇蛙洼娃瓦袜歪外豌弯湾玩顽丸烷完碗挽晚皖惋宛婉万腕汪王亡枉网往旺望忘妄威"
  ],
  [
    "ce40",
    "蜙蜛蜝蜟蜠蜤蜦蜧蜨蜪蜫蜬蜭蜯蜰蜲蜳蜵蜶蜸蜹蜺蜼蜽蝀",
    6,
    "蝊蝋蝍蝏蝐蝑蝒蝔蝕蝖蝘蝚",
    5,
    "蝡蝢蝦",
    7,
    "蝯蝱蝲蝳蝵"
  ],
  [
    "ce80",
    "蝷蝸蝹蝺蝿螀螁螄螆螇螉螊螌螎",
    4,
    "螔螕螖螘",
    6,
    "螠",
    4,
    "巍微危韦违桅围唯惟为潍维苇萎委伟伪尾纬未蔚味畏胃喂魏位渭谓尉慰卫瘟温蚊文闻纹吻稳紊问嗡翁瓮挝蜗涡窝我斡卧握沃巫呜钨乌污诬屋无芜梧吾吴毋武五捂午舞伍侮坞戊雾晤物勿务悟误昔熙析西硒矽晰嘻吸锡牺"
  ],
  [
    "cf40",
    "螥螦螧螩螪螮螰螱螲螴螶螷螸螹螻螼螾螿蟁",
    4,
    "蟇蟈蟉蟌",
    4,
    "蟔",
    6,
    "蟜蟝蟞蟟蟡蟢蟣蟤蟦蟧蟨蟩蟫蟬蟭蟯",
    9
  ],
  [
    "cf80",
    "蟺蟻蟼蟽蟿蠀蠁蠂蠄",
    5,
    "蠋",
    7,
    "蠔蠗蠘蠙蠚蠜",
    4,
    "蠣稀息希悉膝夕惜熄烯溪汐犀檄袭席习媳喜铣洗系隙戏细瞎虾匣霞辖暇峡侠狭下厦夏吓掀锨先仙鲜纤咸贤衔舷闲涎弦嫌显险现献县腺馅羡宪陷限线相厢镶香箱襄湘乡翔祥详想响享项巷橡像向象萧硝霄削哮嚣销消宵淆晓"
  ],
  [
    "d040",
    "蠤",
    13,
    "蠳",
    5,
    "蠺蠻蠽蠾蠿衁衂衃衆",
    5,
    "衎",
    5,
    "衕衖衘衚",
    6,
    "衦衧衪衭衯衱衳衴衵衶衸衹衺"
  ],
  [
    "d080",
    "衻衼袀袃袆袇袉袊袌袎袏袐袑袓袔袕袗",
    4,
    "袝",
    4,
    "袣袥",
    5,
    "小孝校肖啸笑效楔些歇蝎鞋协挟携邪斜胁谐写械卸蟹懈泄泻谢屑薪芯锌欣辛新忻心信衅星腥猩惺兴刑型形邢行醒幸杏性姓兄凶胸匈汹雄熊休修羞朽嗅锈秀袖绣墟戌需虚嘘须徐许蓄酗叙旭序畜恤絮婿绪续轩喧宣悬旋玄"
  ],
  [
    "d140",
    "袬袮袯袰袲",
    4,
    "袸袹袺袻袽袾袿裀裃裄裇裈裊裋裌裍裏裐裑裓裖裗裚",
    4,
    "裠裡裦裧裩",
    6,
    "裲裵裶裷裺裻製裿褀褁褃",
    5
  ],
  [
    "d180",
    "褉褋",
    4,
    "褑褔",
    4,
    "褜",
    4,
    "褢褣褤褦褧褨褩褬褭褮褯褱褲褳褵褷选癣眩绚靴薛学穴雪血勋熏循旬询寻驯巡殉汛训讯逊迅压押鸦鸭呀丫芽牙蚜崖衙涯雅哑亚讶焉咽阉烟淹盐严研蜒岩延言颜阎炎沿奄掩眼衍演艳堰燕厌砚雁唁彦焰宴谚验殃央鸯秧杨扬佯疡羊洋阳氧仰痒养样漾邀腰妖瑶"
  ],
  [
    "d240",
    "褸",
    8,
    "襂襃襅",
    24,
    "襠",
    5,
    "襧",
    19,
    "襼"
  ],
  [
    "d280",
    "襽襾覀覂覄覅覇",
    26,
    "摇尧遥窑谣姚咬舀药要耀椰噎耶爷野冶也页掖业叶曳腋夜液一壹医揖铱依伊衣颐夷遗移仪胰疑沂宜姨彝椅蚁倚已乙矣以艺抑易邑屹亿役臆逸肄疫亦裔意毅忆义益溢诣议谊译异翼翌绎茵荫因殷音阴姻吟银淫寅饮尹引隐"
  ],
  [
    "d340",
    "覢",
    30,
    "觃觍觓觔觕觗觘觙觛觝觟觠觡觢觤觧觨觩觪觬觭觮觰觱觲觴",
    6
  ],
  [
    "d380",
    "觻",
    4,
    "訁",
    5,
    "計",
    21,
    "印英樱婴鹰应缨莹萤营荧蝇迎赢盈影颖硬映哟拥佣臃痈庸雍踊蛹咏泳涌永恿勇用幽优悠忧尤由邮铀犹油游酉有友右佑釉诱又幼迂淤于盂榆虞愚舆余俞逾鱼愉渝渔隅予娱雨与屿禹宇语羽玉域芋郁吁遇喻峪御愈欲狱育誉"
  ],
  [
    "d440",
    "訞",
    31,
    "訿",
    8,
    "詉",
    21
  ],
  [
    "d480",
    "詟",
    25,
    "詺",
    6,
    "浴寓裕预豫驭鸳渊冤元垣袁原援辕园员圆猿源缘远苑愿怨院曰约越跃钥岳粤月悦阅耘云郧匀陨允运蕴酝晕韵孕匝砸杂栽哉灾宰载再在咱攒暂赞赃脏葬遭糟凿藻枣早澡蚤躁噪造皂灶燥责择则泽贼怎增憎曾赠扎喳渣札轧"
  ],
  [
    "d540",
    "誁",
    7,
    "誋",
    7,
    "誔",
    46
  ],
  [
    "d580",
    "諃",
    32,
    "铡闸眨栅榨咋乍炸诈摘斋宅窄债寨瞻毡詹粘沾盏斩辗崭展蘸栈占战站湛绽樟章彰漳张掌涨杖丈帐账仗胀瘴障招昭找沼赵照罩兆肇召遮折哲蛰辙者锗蔗这浙珍斟真甄砧臻贞针侦枕疹诊震振镇阵蒸挣睁征狰争怔整拯正政"
  ],
  [
    "d640",
    "諤",
    34,
    "謈",
    27
  ],
  [
    "d680",
    "謤謥謧",
    30,
    "帧症郑证芝枝支吱蜘知肢脂汁之织职直植殖执值侄址指止趾只旨纸志挚掷至致置帜峙制智秩稚质炙痔滞治窒中盅忠钟衷终种肿重仲众舟周州洲诌粥轴肘帚咒皱宙昼骤珠株蛛朱猪诸诛逐竹烛煮拄瞩嘱主著柱助蛀贮铸筑"
  ],
  [
    "d740",
    "譆",
    31,
    "譧",
    4,
    "譭",
    25
  ],
  [
    "d780",
    "讇",
    24,
    "讬讱讻诇诐诪谉谞住注祝驻抓爪拽专砖转撰赚篆桩庄装妆撞壮状椎锥追赘坠缀谆准捉拙卓桌琢茁酌啄着灼浊兹咨资姿滋淄孜紫仔籽滓子自渍字鬃棕踪宗综总纵邹走奏揍租足卒族祖诅阻组钻纂嘴醉最罪尊遵昨左佐柞做作坐座"
  ],
  [
    "d840",
    "谸",
    8,
    "豂豃豄豅豈豊豋豍",
    7,
    "豖豗豘豙豛",
    5,
    "豣",
    6,
    "豬",
    6,
    "豴豵豶豷豻",
    6,
    "貃貄貆貇"
  ],
  [
    "d880",
    "貈貋貍",
    6,
    "貕貖貗貙",
    20,
    "亍丌兀丐廿卅丕亘丞鬲孬噩丨禺丿匕乇夭爻卮氐囟胤馗毓睾鼗丶亟鼐乜乩亓芈孛啬嘏仄厍厝厣厥厮靥赝匚叵匦匮匾赜卦卣刂刈刎刭刳刿剀剌剞剡剜蒯剽劂劁劐劓冂罔亻仃仉仂仨仡仫仞伛仳伢佤仵伥伧伉伫佞佧攸佚佝"
  ],
  [
    "d940",
    "貮",
    62
  ],
  [
    "d980",
    "賭",
    32,
    "佟佗伲伽佶佴侑侉侃侏佾佻侪佼侬侔俦俨俪俅俚俣俜俑俟俸倩偌俳倬倏倮倭俾倜倌倥倨偾偃偕偈偎偬偻傥傧傩傺僖儆僭僬僦僮儇儋仝氽佘佥俎龠汆籴兮巽黉馘冁夔勹匍訇匐凫夙兕亠兖亳衮袤亵脔裒禀嬴蠃羸冫冱冽冼"
  ],
  [
    "da40",
    "贎",
    14,
    "贠赑赒赗赟赥赨赩赪赬赮赯赱赲赸",
    8,
    "趂趃趆趇趈趉趌",
    4,
    "趒趓趕",
    9,
    "趠趡"
  ],
  [
    "da80",
    "趢趤",
    12,
    "趲趶趷趹趻趽跀跁跂跅跇跈跉跊跍跐跒跓跔凇冖冢冥讠讦讧讪讴讵讷诂诃诋诏诎诒诓诔诖诘诙诜诟诠诤诨诩诮诰诳诶诹诼诿谀谂谄谇谌谏谑谒谔谕谖谙谛谘谝谟谠谡谥谧谪谫谮谯谲谳谵谶卩卺阝阢阡阱阪阽阼陂陉陔陟陧陬陲陴隈隍隗隰邗邛邝邙邬邡邴邳邶邺"
  ],
  [
    "db40",
    "跕跘跙跜跠跡跢跥跦跧跩跭跮跰跱跲跴跶跼跾",
    6,
    "踆踇踈踋踍踎踐踑踒踓踕",
    7,
    "踠踡踤",
    4,
    "踫踭踰踲踳踴踶踷踸踻踼踾"
  ],
  [
    "db80",
    "踿蹃蹅蹆蹌",
    4,
    "蹓",
    5,
    "蹚",
    11,
    "蹧蹨蹪蹫蹮蹱邸邰郏郅邾郐郄郇郓郦郢郜郗郛郫郯郾鄄鄢鄞鄣鄱鄯鄹酃酆刍奂劢劬劭劾哿勐勖勰叟燮矍廴凵凼鬯厶弁畚巯坌垩垡塾墼壅壑圩圬圪圳圹圮圯坜圻坂坩垅坫垆坼坻坨坭坶坳垭垤垌垲埏垧垴垓垠埕埘埚埙埒垸埴埯埸埤埝"
  ],
  [
    "dc40",
    "蹳蹵蹷",
    4,
    "蹽蹾躀躂躃躄躆躈",
    6,
    "躑躒躓躕",
    6,
    "躝躟",
    11,
    "躭躮躰躱躳",
    6,
    "躻",
    7
  ],
  [
    "dc80",
    "軃",
    10,
    "軏",
    21,
    "堋堍埽埭堀堞堙塄堠塥塬墁墉墚墀馨鼙懿艹艽艿芏芊芨芄芎芑芗芙芫芸芾芰苈苊苣芘芷芮苋苌苁芩芴芡芪芟苄苎芤苡茉苷苤茏茇苜苴苒苘茌苻苓茑茚茆茔茕苠苕茜荑荛荜茈莒茼茴茱莛荞茯荏荇荃荟荀茗荠茭茺茳荦荥"
  ],
  [
    "dd40",
    "軥",
    62
  ],
  [
    "dd80",
    "輤",
    32,
    "荨茛荩荬荪荭荮莰荸莳莴莠莪莓莜莅荼莶莩荽莸荻莘莞莨莺莼菁萁菥菘堇萘萋菝菽菖萜萸萑萆菔菟萏萃菸菹菪菅菀萦菰菡葜葑葚葙葳蒇蒈葺蒉葸萼葆葩葶蒌蒎萱葭蓁蓍蓐蓦蒽蓓蓊蒿蒺蓠蒡蒹蒴蒗蓥蓣蔌甍蔸蓰蔹蔟蔺"
  ],
  [
    "de40",
    "轅",
    32,
    "轪辀辌辒辝辠辡辢辤辥辦辧辪辬辭辮辯農辳辴辵辷辸辺辻込辿迀迃迆"
  ],
  [
    "de80",
    "迉",
    4,
    "迏迒迖迗迚迠迡迣迧迬迯迱迲迴迵迶迺迻迼迾迿逇逈逌逎逓逕逘蕖蔻蓿蓼蕙蕈蕨蕤蕞蕺瞢蕃蕲蕻薤薨薇薏蕹薮薜薅薹薷薰藓藁藜藿蘧蘅蘩蘖蘼廾弈夼奁耷奕奚奘匏尢尥尬尴扌扪抟抻拊拚拗拮挢拶挹捋捃掭揶捱捺掎掴捭掬掊捩掮掼揲揸揠揿揄揞揎摒揆掾摅摁搋搛搠搌搦搡摞撄摭撖"
  ],
  [
    "df40",
    "這逜連逤逥逧",
    5,
    "逰",
    4,
    "逷逹逺逽逿遀遃遅遆遈",
    4,
    "過達違遖遙遚遜",
    5,
    "遤遦遧適遪遫遬遯",
    4,
    "遶",
    6,
    "遾邁"
  ],
  [
    "df80",
    "還邅邆邇邉邊邌",
    4,
    "邒邔邖邘邚邜邞邟邠邤邥邧邨邩邫邭邲邷邼邽邿郀摺撷撸撙撺擀擐擗擤擢攉攥攮弋忒甙弑卟叱叽叩叨叻吒吖吆呋呒呓呔呖呃吡呗呙吣吲咂咔呷呱呤咚咛咄呶呦咝哐咭哂咴哒咧咦哓哔呲咣哕咻咿哌哙哚哜咩咪咤哝哏哞唛哧唠哽唔哳唢唣唏唑唧唪啧喏喵啉啭啁啕唿啐唼"
  ],
  [
    "e040",
    "郂郃郆郈郉郋郌郍郒郔郕郖郘郙郚郞郟郠郣郤郥郩郪郬郮郰郱郲郳郵郶郷郹郺郻郼郿鄀鄁鄃鄅",
    19,
    "鄚鄛鄜"
  ],
  [
    "e080",
    "鄝鄟鄠鄡鄤",
    10,
    "鄰鄲",
    6,
    "鄺",
    8,
    "酄唷啖啵啶啷唳唰啜喋嗒喃喱喹喈喁喟啾嗖喑啻嗟喽喾喔喙嗪嗷嗉嘟嗑嗫嗬嗔嗦嗝嗄嗯嗥嗲嗳嗌嗍嗨嗵嗤辔嘞嘈嘌嘁嘤嘣嗾嘀嘧嘭噘嘹噗嘬噍噢噙噜噌噔嚆噤噱噫噻噼嚅嚓嚯囔囗囝囡囵囫囹囿圄圊圉圜帏帙帔帑帱帻帼"
  ],
  [
    "e140",
    "酅酇酈酑酓酔酕酖酘酙酛酜酟酠酦酧酨酫酭酳酺酻酼醀",
    4,
    "醆醈醊醎醏醓",
    6,
    "醜",
    5,
    "醤",
    5,
    "醫醬醰醱醲醳醶醷醸醹醻"
  ],
  [
    "e180",
    "醼",
    10,
    "釈釋釐釒",
    9,
    "針",
    8,
    "帷幄幔幛幞幡岌屺岍岐岖岈岘岙岑岚岜岵岢岽岬岫岱岣峁岷峄峒峤峋峥崂崃崧崦崮崤崞崆崛嵘崾崴崽嵬嵛嵯嵝嵫嵋嵊嵩嵴嶂嶙嶝豳嶷巅彳彷徂徇徉後徕徙徜徨徭徵徼衢彡犭犰犴犷犸狃狁狎狍狒狨狯狩狲狴狷猁狳猃狺"
  ],
  [
    "e240",
    "釦",
    62
  ],
  [
    "e280",
    "鈥",
    32,
    "狻猗猓猡猊猞猝猕猢猹猥猬猸猱獐獍獗獠獬獯獾舛夥飧夤夂饣饧",
    5,
    "饴饷饽馀馄馇馊馍馐馑馓馔馕庀庑庋庖庥庠庹庵庾庳赓廒廑廛廨廪膺忄忉忖忏怃忮怄忡忤忾怅怆忪忭忸怙怵怦怛怏怍怩怫怊怿怡恸恹恻恺恂"
  ],
  [
    "e340",
    "鉆",
    45,
    "鉵",
    16
  ],
  [
    "e380",
    "銆",
    7,
    "銏",
    24,
    "恪恽悖悚悭悝悃悒悌悛惬悻悱惝惘惆惚悴愠愦愕愣惴愀愎愫慊慵憬憔憧憷懔懵忝隳闩闫闱闳闵闶闼闾阃阄阆阈阊阋阌阍阏阒阕阖阗阙阚丬爿戕氵汔汜汊沣沅沐沔沌汨汩汴汶沆沩泐泔沭泷泸泱泗沲泠泖泺泫泮沱泓泯泾"
  ],
  [
    "e440",
    "銨",
    5,
    "銯",
    24,
    "鋉",
    31
  ],
  [
    "e480",
    "鋩",
    32,
    "洹洧洌浃浈洇洄洙洎洫浍洮洵洚浏浒浔洳涑浯涞涠浞涓涔浜浠浼浣渚淇淅淞渎涿淠渑淦淝淙渖涫渌涮渫湮湎湫溲湟溆湓湔渲渥湄滟溱溘滠漭滢溥溧溽溻溷滗溴滏溏滂溟潢潆潇漤漕滹漯漶潋潴漪漉漩澉澍澌潸潲潼潺濑"
  ],
  [
    "e540",
    "錊",
    51,
    "錿",
    10
  ],
  [
    "e580",
    "鍊",
    31,
    "鍫濉澧澹澶濂濡濮濞濠濯瀚瀣瀛瀹瀵灏灞宀宄宕宓宥宸甯骞搴寤寮褰寰蹇謇辶迓迕迥迮迤迩迦迳迨逅逄逋逦逑逍逖逡逵逶逭逯遄遑遒遐遨遘遢遛暹遴遽邂邈邃邋彐彗彖彘尻咫屐屙孱屣屦羼弪弩弭艴弼鬻屮妁妃妍妩妪妣"
  ],
  [
    "e640",
    "鍬",
    34,
    "鎐",
    27
  ],
  [
    "e680",
    "鎬",
    29,
    "鏋鏌鏍妗姊妫妞妤姒妲妯姗妾娅娆姝娈姣姘姹娌娉娲娴娑娣娓婀婧婊婕娼婢婵胬媪媛婷婺媾嫫媲嫒嫔媸嫠嫣嫱嫖嫦嫘嫜嬉嬗嬖嬲嬷孀尕尜孚孥孳孑孓孢驵驷驸驺驿驽骀骁骅骈骊骐骒骓骖骘骛骜骝骟骠骢骣骥骧纟纡纣纥纨纩"
  ],
  [
    "e740",
    "鏎",
    7,
    "鏗",
    54
  ],
  [
    "e780",
    "鐎",
    32,
    "纭纰纾绀绁绂绉绋绌绐绔绗绛绠绡绨绫绮绯绱绲缍绶绺绻绾缁缂缃缇缈缋缌缏缑缒缗缙缜缛缟缡",
    6,
    "缪缫缬缭缯",
    4,
    "缵幺畿巛甾邕玎玑玮玢玟珏珂珑玷玳珀珉珈珥珙顼琊珩珧珞玺珲琏琪瑛琦琥琨琰琮琬"
  ],
  [
    "e840",
    "鐯",
    14,
    "鐿",
    43,
    "鑬鑭鑮鑯"
  ],
  [
    "e880",
    "鑰",
    20,
    "钑钖钘铇铏铓铔铚铦铻锜锠琛琚瑁瑜瑗瑕瑙瑷瑭瑾璜璎璀璁璇璋璞璨璩璐璧瓒璺韪韫韬杌杓杞杈杩枥枇杪杳枘枧杵枨枞枭枋杷杼柰栉柘栊柩枰栌柙枵柚枳柝栀柃枸柢栎柁柽栲栳桠桡桎桢桄桤梃栝桕桦桁桧桀栾桊桉栩梵梏桴桷梓桫棂楮棼椟椠棹"
  ],
  [
    "e940",
    "锧锳锽镃镈镋镕镚镠镮镴镵長",
    7,
    "門",
    42
  ],
  [
    "e980",
    "閫",
    32,
    "椤棰椋椁楗棣椐楱椹楠楂楝榄楫榀榘楸椴槌榇榈槎榉楦楣楹榛榧榻榫榭槔榱槁槊槟榕槠榍槿樯槭樗樘橥槲橄樾檠橐橛樵檎橹樽樨橘橼檑檐檩檗檫猷獒殁殂殇殄殒殓殍殚殛殡殪轫轭轱轲轳轵轶轸轷轹轺轼轾辁辂辄辇辋"
  ],
  [
    "ea40",
    "闌",
    27,
    "闬闿阇阓阘阛阞阠阣",
    6,
    "阫阬阭阯阰阷阸阹阺阾陁陃陊陎陏陑陒陓陖陗"
  ],
  [
    "ea80",
    "陘陙陚陜陝陞陠陣陥陦陫陭",
    4,
    "陳陸",
    12,
    "隇隉隊辍辎辏辘辚軎戋戗戛戟戢戡戥戤戬臧瓯瓴瓿甏甑甓攴旮旯旰昊昙杲昃昕昀炅曷昝昴昱昶昵耆晟晔晁晏晖晡晗晷暄暌暧暝暾曛曜曦曩贲贳贶贻贽赀赅赆赈赉赇赍赕赙觇觊觋觌觎觏觐觑牮犟牝牦牯牾牿犄犋犍犏犒挈挲掰"
  ],
  [
    "eb40",
    "隌階隑隒隓隕隖隚際隝",
    9,
    "隨",
    7,
    "隱隲隴隵隷隸隺隻隿雂雃雈雊雋雐雑雓雔雖",
    9,
    "雡",
    6,
    "雫"
  ],
  [
    "eb80",
    "雬雭雮雰雱雲雴雵雸雺電雼雽雿霂霃霅霊霋霌霐霑霒霔霕霗",
    4,
    "霝霟霠搿擘耄毪毳毽毵毹氅氇氆氍氕氘氙氚氡氩氤氪氲攵敕敫牍牒牖爰虢刖肟肜肓肼朊肽肱肫肭肴肷胧胨胩胪胛胂胄胙胍胗朐胝胫胱胴胭脍脎胲胼朕脒豚脶脞脬脘脲腈腌腓腴腙腚腱腠腩腼腽腭腧塍媵膈膂膑滕膣膪臌朦臊膻"
  ],
  [
    "ec40",
    "霡",
    8,
    "霫霬霮霯霱霳",
    4,
    "霺霻霼霽霿",
    18,
    "靔靕靗靘靚靜靝靟靣靤靦靧靨靪",
    7
  ],
  [
    "ec80",
    "靲靵靷",
    4,
    "靽",
    7,
    "鞆",
    4,
    "鞌鞎鞏鞐鞓鞕鞖鞗鞙",
    4,
    "臁膦欤欷欹歃歆歙飑飒飓飕飙飚殳彀毂觳斐齑斓於旆旄旃旌旎旒旖炀炜炖炝炻烀炷炫炱烨烊焐焓焖焯焱煳煜煨煅煲煊煸煺熘熳熵熨熠燠燔燧燹爝爨灬焘煦熹戾戽扃扈扉礻祀祆祉祛祜祓祚祢祗祠祯祧祺禅禊禚禧禳忑忐"
  ],
  [
    "ed40",
    "鞞鞟鞡鞢鞤",
    6,
    "鞬鞮鞰鞱鞳鞵",
    46
  ],
  [
    "ed80",
    "韤韥韨韮",
    4,
    "韴韷",
    23,
    "怼恝恚恧恁恙恣悫愆愍慝憩憝懋懑戆肀聿沓泶淼矶矸砀砉砗砘砑斫砭砜砝砹砺砻砟砼砥砬砣砩硎硭硖硗砦硐硇硌硪碛碓碚碇碜碡碣碲碹碥磔磙磉磬磲礅磴礓礤礞礴龛黹黻黼盱眄眍盹眇眈眚眢眙眭眦眵眸睐睑睇睃睚睨"
  ],
  [
    "ee40",
    "頏",
    62
  ],
  [
    "ee80",
    "顎",
    32,
    "睢睥睿瞍睽瞀瞌瞑瞟瞠瞰瞵瞽町畀畎畋畈畛畲畹疃罘罡罟詈罨罴罱罹羁罾盍盥蠲钅钆钇钋钊钌钍钏钐钔钗钕钚钛钜钣钤钫钪钭钬钯钰钲钴钶",
    4,
    "钼钽钿铄铈",
    6,
    "铐铑铒铕铖铗铙铘铛铞铟铠铢铤铥铧铨铪"
  ],
  [
    "ef40",
    "顯",
    5,
    "颋颎颒颕颙颣風",
    37,
    "飏飐飔飖飗飛飜飝飠",
    4
  ],
  [
    "ef80",
    "飥飦飩",
    30,
    "铩铫铮铯铳铴铵铷铹铼铽铿锃锂锆锇锉锊锍锎锏锒",
    4,
    "锘锛锝锞锟锢锪锫锩锬锱锲锴锶锷锸锼锾锿镂锵镄镅镆镉镌镎镏镒镓镔镖镗镘镙镛镞镟镝镡镢镤",
    8,
    "镯镱镲镳锺矧矬雉秕秭秣秫稆嵇稃稂稞稔"
  ],
  [
    "f040",
    "餈",
    4,
    "餎餏餑",
    28,
    "餯",
    26
  ],
  [
    "f080",
    "饊",
    9,
    "饖",
    12,
    "饤饦饳饸饹饻饾馂馃馉稹稷穑黏馥穰皈皎皓皙皤瓞瓠甬鸠鸢鸨",
    4,
    "鸲鸱鸶鸸鸷鸹鸺鸾鹁鹂鹄鹆鹇鹈鹉鹋鹌鹎鹑鹕鹗鹚鹛鹜鹞鹣鹦",
    6,
    "鹱鹭鹳疒疔疖疠疝疬疣疳疴疸痄疱疰痃痂痖痍痣痨痦痤痫痧瘃痱痼痿瘐瘀瘅瘌瘗瘊瘥瘘瘕瘙"
  ],
  [
    "f140",
    "馌馎馚",
    10,
    "馦馧馩",
    47
  ],
  [
    "f180",
    "駙",
    32,
    "瘛瘼瘢瘠癀瘭瘰瘿瘵癃瘾瘳癍癞癔癜癖癫癯翊竦穸穹窀窆窈窕窦窠窬窨窭窳衤衩衲衽衿袂袢裆袷袼裉裢裎裣裥裱褚裼裨裾裰褡褙褓褛褊褴褫褶襁襦襻疋胥皲皴矜耒耔耖耜耠耢耥耦耧耩耨耱耋耵聃聆聍聒聩聱覃顸颀颃"
  ],
  [
    "f240",
    "駺",
    62
  ],
  [
    "f280",
    "騹",
    32,
    "颉颌颍颏颔颚颛颞颟颡颢颥颦虍虔虬虮虿虺虼虻蚨蚍蚋蚬蚝蚧蚣蚪蚓蚩蚶蛄蚵蛎蚰蚺蚱蚯蛉蛏蚴蛩蛱蛲蛭蛳蛐蜓蛞蛴蛟蛘蛑蜃蜇蛸蜈蜊蜍蜉蜣蜻蜞蜥蜮蜚蜾蝈蜴蜱蜩蜷蜿螂蜢蝽蝾蝻蝠蝰蝌蝮螋蝓蝣蝼蝤蝙蝥螓螯螨蟒"
  ],
  [
    "f340",
    "驚",
    17,
    "驲骃骉骍骎骔骕骙骦骩",
    6,
    "骲骳骴骵骹骻骽骾骿髃髄髆",
    4,
    "髍髎髏髐髒體髕髖髗髙髚髛髜"
  ],
  [
    "f380",
    "髝髞髠髢髣髤髥髧髨髩髪髬髮髰",
    8,
    "髺髼",
    6,
    "鬄鬅鬆蟆螈螅螭螗螃螫蟥螬螵螳蟋蟓螽蟑蟀蟊蟛蟪蟠蟮蠖蠓蟾蠊蠛蠡蠹蠼缶罂罄罅舐竺竽笈笃笄笕笊笫笏筇笸笪笙笮笱笠笥笤笳笾笞筘筚筅筵筌筝筠筮筻筢筲筱箐箦箧箸箬箝箨箅箪箜箢箫箴篑篁篌篝篚篥篦篪簌篾篼簏簖簋"
  ],
  [
    "f440",
    "鬇鬉",
    5,
    "鬐鬑鬒鬔",
    10,
    "鬠鬡鬢鬤",
    10,
    "鬰鬱鬳",
    7,
    "鬽鬾鬿魀魆魊魋魌魎魐魒魓魕",
    5
  ],
  [
    "f480",
    "魛",
    32,
    "簟簪簦簸籁籀臾舁舂舄臬衄舡舢舣舭舯舨舫舸舻舳舴舾艄艉艋艏艚艟艨衾袅袈裘裟襞羝羟羧羯羰羲籼敉粑粝粜粞粢粲粼粽糁糇糌糍糈糅糗糨艮暨羿翎翕翥翡翦翩翮翳糸絷綦綮繇纛麸麴赳趄趔趑趱赧赭豇豉酊酐酎酏酤"
  ],
  [
    "f540",
    "魼",
    62
  ],
  [
    "f580",
    "鮻",
    32,
    "酢酡酰酩酯酽酾酲酴酹醌醅醐醍醑醢醣醪醭醮醯醵醴醺豕鹾趸跫踅蹙蹩趵趿趼趺跄跖跗跚跞跎跏跛跆跬跷跸跣跹跻跤踉跽踔踝踟踬踮踣踯踺蹀踹踵踽踱蹉蹁蹂蹑蹒蹊蹰蹶蹼蹯蹴躅躏躔躐躜躞豸貂貊貅貘貔斛觖觞觚觜"
  ],
  [
    "f640",
    "鯜",
    62
  ],
  [
    "f680",
    "鰛",
    32,
    "觥觫觯訾謦靓雩雳雯霆霁霈霏霎霪霭霰霾龀龃龅",
    5,
    "龌黾鼋鼍隹隼隽雎雒瞿雠銎銮鋈錾鍪鏊鎏鐾鑫鱿鲂鲅鲆鲇鲈稣鲋鲎鲐鲑鲒鲔鲕鲚鲛鲞",
    5,
    "鲥",
    4,
    "鲫鲭鲮鲰",
    7,
    "鲺鲻鲼鲽鳄鳅鳆鳇鳊鳋"
  ],
  [
    "f740",
    "鰼",
    62
  ],
  [
    "f780",
    "鱻鱽鱾鲀鲃鲄鲉鲊鲌鲏鲓鲖鲗鲘鲙鲝鲪鲬鲯鲹鲾",
    4,
    "鳈鳉鳑鳒鳚鳛鳠鳡鳌",
    4,
    "鳓鳔鳕鳗鳘鳙鳜鳝鳟鳢靼鞅鞑鞒鞔鞯鞫鞣鞲鞴骱骰骷鹘骶骺骼髁髀髅髂髋髌髑魅魃魇魉魈魍魑飨餍餮饕饔髟髡髦髯髫髻髭髹鬈鬏鬓鬟鬣麽麾縻麂麇麈麋麒鏖麝麟黛黜黝黠黟黢黩黧黥黪黯鼢鼬鼯鼹鼷鼽鼾齄"
  ],
  [
    "f840",
    "鳣",
    62
  ],
  [
    "f880",
    "鴢",
    32
  ],
  [
    "f940",
    "鵃",
    62
  ],
  [
    "f980",
    "鶂",
    32
  ],
  [
    "fa40",
    "鶣",
    62
  ],
  [
    "fa80",
    "鷢",
    32
  ],
  [
    "fb40",
    "鸃",
    27,
    "鸤鸧鸮鸰鸴鸻鸼鹀鹍鹐鹒鹓鹔鹖鹙鹝鹟鹠鹡鹢鹥鹮鹯鹲鹴",
    9,
    "麀"
  ],
  [
    "fb80",
    "麁麃麄麅麆麉麊麌",
    5,
    "麔",
    8,
    "麞麠",
    5,
    "麧麨麩麪"
  ],
  [
    "fc40",
    "麫",
    8,
    "麵麶麷麹麺麼麿",
    4,
    "黅黆黇黈黊黋黌黐黒黓黕黖黗黙黚點黡黣黤黦黨黫黬黭黮黰",
    8,
    "黺黽黿",
    6
  ],
  [
    "fc80",
    "鼆",
    4,
    "鼌鼏鼑鼒鼔鼕鼖鼘鼚",
    5,
    "鼡鼣",
    8,
    "鼭鼮鼰鼱"
  ],
  [
    "fd40",
    "鼲",
    4,
    "鼸鼺鼼鼿",
    4,
    "齅",
    10,
    "齒",
    38
  ],
  [
    "fd80",
    "齹",
    5,
    "龁龂龍",
    11,
    "龜龝龞龡",
    4,
    "郎凉秊裏隣"
  ],
  [
    "fe40",
    "兀嗀﨎﨏﨑﨓﨔礼﨟蘒﨡﨣﨤﨧﨨﨩"
  ]
], e1 = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  default: $h
}), t1 = [
  [
    "a140",
    "",
    62
  ],
  [
    "a180",
    "",
    32
  ],
  [
    "a240",
    "",
    62
  ],
  [
    "a280",
    "",
    32
  ],
  [
    "a2ab",
    "",
    5
  ],
  [
    "a2e3",
    "€"
  ],
  [
    "a2ef",
    ""
  ],
  [
    "a2fd",
    ""
  ],
  [
    "a340",
    "",
    62
  ],
  [
    "a380",
    "",
    31,
    "　"
  ],
  [
    "a440",
    "",
    62
  ],
  [
    "a480",
    "",
    32
  ],
  [
    "a4f4",
    "",
    10
  ],
  [
    "a540",
    "",
    62
  ],
  [
    "a580",
    "",
    32
  ],
  [
    "a5f7",
    "",
    7
  ],
  [
    "a640",
    "",
    62
  ],
  [
    "a680",
    "",
    32
  ],
  [
    "a6b9",
    "",
    7
  ],
  [
    "a6d9",
    "",
    6
  ],
  [
    "a6ec",
    ""
  ],
  [
    "a6f3",
    ""
  ],
  [
    "a6f6",
    "",
    8
  ],
  [
    "a740",
    "",
    62
  ],
  [
    "a780",
    "",
    32
  ],
  [
    "a7c2",
    "",
    14
  ],
  [
    "a7f2",
    "",
    12
  ],
  [
    "a896",
    "",
    10
  ],
  [
    "a8bc",
    ""
  ],
  [
    "a8bf",
    "ǹ"
  ],
  [
    "a8c1",
    ""
  ],
  [
    "a8ea",
    "",
    20
  ],
  [
    "a958",
    ""
  ],
  [
    "a95b",
    ""
  ],
  [
    "a95d",
    ""
  ],
  [
    "a989",
    "〾⿰",
    11
  ],
  [
    "a997",
    "",
    12
  ],
  [
    "a9f0",
    "",
    14
  ],
  [
    "aaa1",
    "",
    93
  ],
  [
    "aba1",
    "",
    93
  ],
  [
    "aca1",
    "",
    93
  ],
  [
    "ada1",
    "",
    93
  ],
  [
    "aea1",
    "",
    93
  ],
  [
    "afa1",
    "",
    93
  ],
  [
    "d7fa",
    "",
    4
  ],
  [
    "f8a1",
    "",
    93
  ],
  [
    "f9a1",
    "",
    93
  ],
  [
    "faa1",
    "",
    93
  ],
  [
    "fba1",
    "",
    93
  ],
  [
    "fca1",
    "",
    93
  ],
  [
    "fda1",
    "",
    93
  ],
  [
    "fe50",
    "⺁⺄㑳㑇⺈⺋㖞㘚㘎⺌⺗㥮㤘㧏㧟㩳㧐㭎㱮㳠⺧⺪䁖䅟⺮䌷⺳⺶⺷䎱䎬⺻䏝䓖䙡䙌"
  ],
  [
    "fe80",
    "䜣䜩䝼䞍⻊䥇䥺䥽䦂䦃䦅䦆䦟䦛䦷䦶䲣䲟䲠䲡䱷䲢䴓",
    6,
    "䶮",
    93
  ]
], r1 = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  default: t1
}), gf = [
  128,
  165,
  169,
  178,
  184,
  216,
  226,
  235,
  238,
  244,
  248,
  251,
  253,
  258,
  276,
  284,
  300,
  325,
  329,
  334,
  364,
  463,
  465,
  467,
  469,
  471,
  473,
  475,
  477,
  506,
  594,
  610,
  712,
  716,
  730,
  930,
  938,
  962,
  970,
  1026,
  1104,
  1106,
  8209,
  8215,
  8218,
  8222,
  8231,
  8241,
  8244,
  8246,
  8252,
  8365,
  8452,
  8454,
  8458,
  8471,
  8482,
  8556,
  8570,
  8596,
  8602,
  8713,
  8720,
  8722,
  8726,
  8731,
  8737,
  8740,
  8742,
  8748,
  8751,
  8760,
  8766,
  8777,
  8781,
  8787,
  8802,
  8808,
  8816,
  8854,
  8858,
  8870,
  8896,
  8979,
  9322,
  9372,
  9548,
  9588,
  9616,
  9622,
  9634,
  9652,
  9662,
  9672,
  9676,
  9680,
  9702,
  9735,
  9738,
  9793,
  9795,
  11906,
  11909,
  11913,
  11917,
  11928,
  11944,
  11947,
  11951,
  11956,
  11960,
  11964,
  11979,
  12284,
  12292,
  12312,
  12319,
  12330,
  12351,
  12436,
  12447,
  12535,
  12543,
  12586,
  12842,
  12850,
  12964,
  13200,
  13215,
  13218,
  13253,
  13263,
  13267,
  13270,
  13384,
  13428,
  13727,
  13839,
  13851,
  14617,
  14703,
  14801,
  14816,
  14964,
  15183,
  15471,
  15585,
  16471,
  16736,
  17208,
  17325,
  17330,
  17374,
  17623,
  17997,
  18018,
  18212,
  18218,
  18301,
  18318,
  18760,
  18811,
  18814,
  18820,
  18823,
  18844,
  18848,
  18872,
  19576,
  19620,
  19738,
  19887,
  40870,
  59244,
  59336,
  59367,
  59413,
  59417,
  59423,
  59431,
  59437,
  59443,
  59452,
  59460,
  59478,
  59493,
  63789,
  63866,
  63894,
  63976,
  63986,
  64016,
  64018,
  64021,
  64025,
  64034,
  64037,
  64042,
  65074,
  65093,
  65107,
  65112,
  65127,
  65132,
  65375,
  65510,
  65536
], mf = [
  0,
  36,
  38,
  45,
  50,
  81,
  89,
  95,
  96,
  100,
  103,
  104,
  105,
  109,
  126,
  133,
  148,
  172,
  175,
  179,
  208,
  306,
  307,
  308,
  309,
  310,
  311,
  312,
  313,
  341,
  428,
  443,
  544,
  545,
  558,
  741,
  742,
  749,
  750,
  805,
  819,
  820,
  7922,
  7924,
  7925,
  7927,
  7934,
  7943,
  7944,
  7945,
  7950,
  8062,
  8148,
  8149,
  8152,
  8164,
  8174,
  8236,
  8240,
  8262,
  8264,
  8374,
  8380,
  8381,
  8384,
  8388,
  8390,
  8392,
  8393,
  8394,
  8396,
  8401,
  8406,
  8416,
  8419,
  8424,
  8437,
  8439,
  8445,
  8482,
  8485,
  8496,
  8521,
  8603,
  8936,
  8946,
  9046,
  9050,
  9063,
  9066,
  9076,
  9092,
  9100,
  9108,
  9111,
  9113,
  9131,
  9162,
  9164,
  9218,
  9219,
  11329,
  11331,
  11334,
  11336,
  11346,
  11361,
  11363,
  11366,
  11370,
  11372,
  11375,
  11389,
  11682,
  11686,
  11687,
  11692,
  11694,
  11714,
  11716,
  11723,
  11725,
  11730,
  11736,
  11982,
  11989,
  12102,
  12336,
  12348,
  12350,
  12384,
  12393,
  12395,
  12397,
  12510,
  12553,
  12851,
  12962,
  12973,
  13738,
  13823,
  13919,
  13933,
  14080,
  14298,
  14585,
  14698,
  15583,
  15847,
  16318,
  16434,
  16438,
  16481,
  16729,
  17102,
  17122,
  17315,
  17320,
  17402,
  17418,
  17859,
  17909,
  17911,
  17915,
  17916,
  17936,
  17939,
  17961,
  18664,
  18703,
  18814,
  18962,
  19043,
  33469,
  33470,
  33471,
  33484,
  33485,
  33490,
  33497,
  33501,
  33505,
  33513,
  33520,
  33536,
  33550,
  37845,
  37921,
  37948,
  38029,
  38038,
  38064,
  38065,
  38066,
  38069,
  38075,
  38076,
  38078,
  39108,
  39109,
  39113,
  39114,
  39115,
  39116,
  39265,
  39394,
  189e3
], n1 = {
  uChars: gf,
  gbChars: mf
}, i1 = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  uChars: gf,
  gbChars: mf,
  default: n1
}), a1 = [
  [
    "0",
    "\0",
    127
  ],
  [
    "8141",
    "갂갃갅갆갋",
    4,
    "갘갞갟갡갢갣갥",
    6,
    "갮갲갳갴"
  ],
  [
    "8161",
    "갵갶갷갺갻갽갾갿걁",
    9,
    "걌걎",
    5,
    "걕"
  ],
  [
    "8181",
    "걖걗걙걚걛걝",
    18,
    "걲걳걵걶걹걻",
    4,
    "겂겇겈겍겎겏겑겒겓겕",
    6,
    "겞겢",
    5,
    "겫겭겮겱",
    6,
    "겺겾겿곀곂곃곅곆곇곉곊곋곍",
    7,
    "곖곘",
    7,
    "곢곣곥곦곩곫곭곮곲곴곷",
    4,
    "곾곿괁괂괃괅괇",
    4,
    "괎괐괒괓"
  ],
  [
    "8241",
    "괔괕괖괗괙괚괛괝괞괟괡",
    7,
    "괪괫괮",
    5
  ],
  [
    "8261",
    "괶괷괹괺괻괽",
    6,
    "굆굈굊",
    5,
    "굑굒굓굕굖굗"
  ],
  [
    "8281",
    "굙",
    7,
    "굢굤",
    7,
    "굮굯굱굲굷굸굹굺굾궀궃",
    4,
    "궊궋궍궎궏궑",
    10,
    "궞",
    5,
    "궥",
    17,
    "궸",
    7,
    "귂귃귅귆귇귉",
    6,
    "귒귔",
    7,
    "귝귞귟귡귢귣귥",
    18
  ],
  [
    "8341",
    "귺귻귽귾긂",
    5,
    "긊긌긎",
    5,
    "긕",
    7
  ],
  [
    "8361",
    "긝",
    18,
    "긲긳긵긶긹긻긼"
  ],
  [
    "8381",
    "긽긾긿깂깄깇깈깉깋깏깑깒깓깕깗",
    4,
    "깞깢깣깤깦깧깪깫깭깮깯깱",
    6,
    "깺깾",
    5,
    "꺆",
    5,
    "꺍",
    46,
    "꺿껁껂껃껅",
    6,
    "껎껒",
    5,
    "껚껛껝",
    8
  ],
  [
    "8441",
    "껦껧껩껪껬껮",
    5,
    "껵껶껷껹껺껻껽",
    8
  ],
  [
    "8461",
    "꼆꼉꼊꼋꼌꼎꼏꼑",
    18
  ],
  [
    "8481",
    "꼤",
    7,
    "꼮꼯꼱꼳꼵",
    6,
    "꼾꽀꽄꽅꽆꽇꽊",
    5,
    "꽑",
    10,
    "꽞",
    5,
    "꽦",
    18,
    "꽺",
    5,
    "꾁꾂꾃꾅꾆꾇꾉",
    6,
    "꾒꾓꾔꾖",
    5,
    "꾝",
    26,
    "꾺꾻꾽꾾"
  ],
  [
    "8541",
    "꾿꿁",
    5,
    "꿊꿌꿏",
    4,
    "꿕",
    6,
    "꿝",
    4
  ],
  [
    "8561",
    "꿢",
    5,
    "꿪",
    5,
    "꿲꿳꿵꿶꿷꿹",
    6,
    "뀂뀃"
  ],
  [
    "8581",
    "뀅",
    6,
    "뀍뀎뀏뀑뀒뀓뀕",
    6,
    "뀞",
    9,
    "뀩",
    26,
    "끆끇끉끋끍끏끐끑끒끖끘끚끛끜끞",
    29,
    "끾끿낁낂낃낅",
    6,
    "낎낐낒",
    5,
    "낛낝낞낣낤"
  ],
  [
    "8641",
    "낥낦낧낪낰낲낶낷낹낺낻낽",
    6,
    "냆냊",
    5,
    "냒"
  ],
  [
    "8661",
    "냓냕냖냗냙",
    6,
    "냡냢냣냤냦",
    10
  ],
  [
    "8681",
    "냱",
    22,
    "넊넍넎넏넑넔넕넖넗넚넞",
    4,
    "넦넧넩넪넫넭",
    6,
    "넶넺",
    5,
    "녂녃녅녆녇녉",
    6,
    "녒녓녖녗녙녚녛녝녞녟녡",
    22,
    "녺녻녽녾녿놁놃",
    4,
    "놊놌놎놏놐놑놕놖놗놙놚놛놝"
  ],
  [
    "8741",
    "놞",
    9,
    "놩",
    15
  ],
  [
    "8761",
    "놹",
    18,
    "뇍뇎뇏뇑뇒뇓뇕"
  ],
  [
    "8781",
    "뇖",
    5,
    "뇞뇠",
    7,
    "뇪뇫뇭뇮뇯뇱",
    7,
    "뇺뇼뇾",
    5,
    "눆눇눉눊눍",
    6,
    "눖눘눚",
    5,
    "눡",
    18,
    "눵",
    6,
    "눽",
    26,
    "뉙뉚뉛뉝뉞뉟뉡",
    6,
    "뉪",
    4
  ],
  [
    "8841",
    "뉯",
    4,
    "뉶",
    5,
    "뉽",
    6,
    "늆늇늈늊",
    4
  ],
  [
    "8861",
    "늏늒늓늕늖늗늛",
    4,
    "늢늤늧늨늩늫늭늮늯늱늲늳늵늶늷"
  ],
  [
    "8881",
    "늸",
    15,
    "닊닋닍닎닏닑닓",
    4,
    "닚닜닞닟닠닡닣닧닩닪닰닱닲닶닼닽닾댂댃댅댆댇댉",
    6,
    "댒댖",
    5,
    "댝",
    54,
    "덗덙덚덝덠덡덢덣"
  ],
  [
    "8941",
    "덦덨덪덬덭덯덲덳덵덶덷덹",
    6,
    "뎂뎆",
    5,
    "뎍"
  ],
  [
    "8961",
    "뎎뎏뎑뎒뎓뎕",
    10,
    "뎢",
    5,
    "뎩뎪뎫뎭"
  ],
  [
    "8981",
    "뎮",
    21,
    "돆돇돉돊돍돏돑돒돓돖돘돚돜돞돟돡돢돣돥돦돧돩",
    18,
    "돽",
    18,
    "됑",
    6,
    "됙됚됛됝됞됟됡",
    6,
    "됪됬",
    7,
    "됵",
    15
  ],
  [
    "8a41",
    "둅",
    10,
    "둒둓둕둖둗둙",
    6,
    "둢둤둦"
  ],
  [
    "8a61",
    "둧",
    4,
    "둭",
    18,
    "뒁뒂"
  ],
  [
    "8a81",
    "뒃",
    4,
    "뒉",
    19,
    "뒞",
    5,
    "뒥뒦뒧뒩뒪뒫뒭",
    7,
    "뒶뒸뒺",
    5,
    "듁듂듃듅듆듇듉",
    6,
    "듑듒듓듔듖",
    5,
    "듞듟듡듢듥듧",
    4,
    "듮듰듲",
    5,
    "듹",
    26,
    "딖딗딙딚딝"
  ],
  [
    "8b41",
    "딞",
    5,
    "딦딫",
    4,
    "딲딳딵딶딷딹",
    6,
    "땂땆"
  ],
  [
    "8b61",
    "땇땈땉땊땎땏땑땒땓땕",
    6,
    "땞땢",
    8
  ],
  [
    "8b81",
    "땫",
    52,
    "떢떣떥떦떧떩떬떭떮떯떲떶",
    4,
    "떾떿뗁뗂뗃뗅",
    6,
    "뗎뗒",
    5,
    "뗙",
    18,
    "뗭",
    18
  ],
  [
    "8c41",
    "똀",
    15,
    "똒똓똕똖똗똙",
    4
  ],
  [
    "8c61",
    "똞",
    6,
    "똦",
    5,
    "똭",
    6,
    "똵",
    5
  ],
  [
    "8c81",
    "똻",
    12,
    "뙉",
    26,
    "뙥뙦뙧뙩",
    50,
    "뚞뚟뚡뚢뚣뚥",
    5,
    "뚭뚮뚯뚰뚲",
    16
  ],
  [
    "8d41",
    "뛃",
    16,
    "뛕",
    8
  ],
  [
    "8d61",
    "뛞",
    17,
    "뛱뛲뛳뛵뛶뛷뛹뛺"
  ],
  [
    "8d81",
    "뛻",
    4,
    "뜂뜃뜄뜆",
    33,
    "뜪뜫뜭뜮뜱",
    6,
    "뜺뜼",
    7,
    "띅띆띇띉띊띋띍",
    6,
    "띖",
    9,
    "띡띢띣띥띦띧띩",
    6,
    "띲띴띶",
    5,
    "띾띿랁랂랃랅",
    6,
    "랎랓랔랕랚랛랝랞"
  ],
  [
    "8e41",
    "랟랡",
    6,
    "랪랮",
    5,
    "랶랷랹",
    8
  ],
  [
    "8e61",
    "럂",
    4,
    "럈럊",
    19
  ],
  [
    "8e81",
    "럞",
    13,
    "럮럯럱럲럳럵",
    6,
    "럾렂",
    4,
    "렊렋렍렎렏렑",
    6,
    "렚렜렞",
    5,
    "렦렧렩렪렫렭",
    6,
    "렶렺",
    5,
    "롁롂롃롅",
    11,
    "롒롔",
    7,
    "롞롟롡롢롣롥",
    6,
    "롮롰롲",
    5,
    "롹롺롻롽",
    7
  ],
  [
    "8f41",
    "뢅",
    7,
    "뢎",
    17
  ],
  [
    "8f61",
    "뢠",
    7,
    "뢩",
    6,
    "뢱뢲뢳뢵뢶뢷뢹",
    4
  ],
  [
    "8f81",
    "뢾뢿룂룄룆",
    5,
    "룍룎룏룑룒룓룕",
    7,
    "룞룠룢",
    5,
    "룪룫룭룮룯룱",
    6,
    "룺룼룾",
    5,
    "뤅",
    18,
    "뤙",
    6,
    "뤡",
    26,
    "뤾뤿륁륂륃륅",
    6,
    "륍륎륐륒",
    5
  ],
  [
    "9041",
    "륚륛륝륞륟륡",
    6,
    "륪륬륮",
    5,
    "륶륷륹륺륻륽"
  ],
  [
    "9061",
    "륾",
    5,
    "릆릈릋릌릏",
    15
  ],
  [
    "9081",
    "릟",
    12,
    "릮릯릱릲릳릵",
    6,
    "릾맀맂",
    5,
    "맊맋맍맓",
    4,
    "맚맜맟맠맢맦맧맩맪맫맭",
    6,
    "맶맻",
    4,
    "먂",
    5,
    "먉",
    11,
    "먖",
    33,
    "먺먻먽먾먿멁멃멄멅멆"
  ],
  [
    "9141",
    "멇멊멌멏멐멑멒멖멗멙멚멛멝",
    6,
    "멦멪",
    5
  ],
  [
    "9161",
    "멲멳멵멶멷멹",
    9,
    "몆몈몉몊몋몍",
    5
  ],
  [
    "9181",
    "몓",
    20,
    "몪몭몮몯몱몳",
    4,
    "몺몼몾",
    5,
    "뫅뫆뫇뫉",
    14,
    "뫚",
    33,
    "뫽뫾뫿묁묂묃묅",
    7,
    "묎묐묒",
    5,
    "묙묚묛묝묞묟묡",
    6
  ],
  [
    "9241",
    "묨묪묬",
    7,
    "묷묹묺묿",
    4,
    "뭆뭈뭊뭋뭌뭎뭑뭒"
  ],
  [
    "9261",
    "뭓뭕뭖뭗뭙",
    7,
    "뭢뭤",
    7,
    "뭭",
    4
  ],
  [
    "9281",
    "뭲",
    21,
    "뮉뮊뮋뮍뮎뮏뮑",
    18,
    "뮥뮦뮧뮩뮪뮫뮭",
    6,
    "뮵뮶뮸",
    7,
    "믁믂믃믅믆믇믉",
    6,
    "믑믒믔",
    35,
    "믺믻믽믾밁"
  ],
  [
    "9341",
    "밃",
    4,
    "밊밎밐밒밓밙밚밠밡밢밣밦밨밪밫밬밮밯밲밳밵"
  ],
  [
    "9361",
    "밶밷밹",
    6,
    "뱂뱆뱇뱈뱊뱋뱎뱏뱑",
    8
  ],
  [
    "9381",
    "뱚뱛뱜뱞",
    37,
    "벆벇벉벊벍벏",
    4,
    "벖벘벛",
    4,
    "벢벣벥벦벩",
    6,
    "벲벶",
    5,
    "벾벿볁볂볃볅",
    7,
    "볎볒볓볔볖볗볙볚볛볝",
    22,
    "볷볹볺볻볽"
  ],
  [
    "9441",
    "볾",
    5,
    "봆봈봊",
    5,
    "봑봒봓봕",
    8
  ],
  [
    "9461",
    "봞",
    5,
    "봥",
    6,
    "봭",
    12
  ],
  [
    "9481",
    "봺",
    5,
    "뵁",
    6,
    "뵊뵋뵍뵎뵏뵑",
    6,
    "뵚",
    9,
    "뵥뵦뵧뵩",
    22,
    "붂붃붅붆붋",
    4,
    "붒붔붖붗붘붛붝",
    6,
    "붥",
    10,
    "붱",
    6,
    "붹",
    24
  ],
  [
    "9541",
    "뷒뷓뷖뷗뷙뷚뷛뷝",
    11,
    "뷪",
    5,
    "뷱"
  ],
  [
    "9561",
    "뷲뷳뷵뷶뷷뷹",
    6,
    "븁븂븄븆",
    5,
    "븎븏븑븒븓"
  ],
  [
    "9581",
    "븕",
    6,
    "븞븠",
    35,
    "빆빇빉빊빋빍빏",
    4,
    "빖빘빜빝빞빟빢빣빥빦빧빩빫",
    4,
    "빲빶",
    4,
    "빾빿뺁뺂뺃뺅",
    6,
    "뺎뺒",
    5,
    "뺚",
    13,
    "뺩",
    14
  ],
  [
    "9641",
    "뺸",
    23,
    "뻒뻓"
  ],
  [
    "9661",
    "뻕뻖뻙",
    6,
    "뻡뻢뻦",
    5,
    "뻭",
    8
  ],
  [
    "9681",
    "뻶",
    10,
    "뼂",
    5,
    "뼊",
    13,
    "뼚뼞",
    33,
    "뽂뽃뽅뽆뽇뽉",
    6,
    "뽒뽓뽔뽖",
    44
  ],
  [
    "9741",
    "뾃",
    16,
    "뾕",
    8
  ],
  [
    "9761",
    "뾞",
    17,
    "뾱",
    7
  ],
  [
    "9781",
    "뾹",
    11,
    "뿆",
    5,
    "뿎뿏뿑뿒뿓뿕",
    6,
    "뿝뿞뿠뿢",
    89,
    "쀽쀾쀿"
  ],
  [
    "9841",
    "쁀",
    16,
    "쁒",
    5,
    "쁙쁚쁛"
  ],
  [
    "9861",
    "쁝쁞쁟쁡",
    6,
    "쁪",
    15
  ],
  [
    "9881",
    "쁺",
    21,
    "삒삓삕삖삗삙",
    6,
    "삢삤삦",
    5,
    "삮삱삲삷",
    4,
    "삾샂샃샄샆샇샊샋샍샎샏샑",
    6,
    "샚샞",
    5,
    "샦샧샩샪샫샭",
    6,
    "샶샸샺",
    5,
    "섁섂섃섅섆섇섉",
    6,
    "섑섒섓섔섖",
    5,
    "섡섢섥섨섩섪섫섮"
  ],
  [
    "9941",
    "섲섳섴섵섷섺섻섽섾섿셁",
    6,
    "셊셎",
    5,
    "셖셗"
  ],
  [
    "9961",
    "셙셚셛셝",
    6,
    "셦셪",
    5,
    "셱셲셳셵셶셷셹셺셻"
  ],
  [
    "9981",
    "셼",
    8,
    "솆",
    5,
    "솏솑솒솓솕솗",
    4,
    "솞솠솢솣솤솦솧솪솫솭솮솯솱",
    11,
    "솾",
    5,
    "쇅쇆쇇쇉쇊쇋쇍",
    6,
    "쇕쇖쇙",
    6,
    "쇡쇢쇣쇥쇦쇧쇩",
    6,
    "쇲쇴",
    7,
    "쇾쇿숁숂숃숅",
    6,
    "숎숐숒",
    5,
    "숚숛숝숞숡숢숣"
  ],
  [
    "9a41",
    "숤숥숦숧숪숬숮숰숳숵",
    16
  ],
  [
    "9a61",
    "쉆쉇쉉",
    6,
    "쉒쉓쉕쉖쉗쉙",
    6,
    "쉡쉢쉣쉤쉦"
  ],
  [
    "9a81",
    "쉧",
    4,
    "쉮쉯쉱쉲쉳쉵",
    6,
    "쉾슀슂",
    5,
    "슊",
    5,
    "슑",
    6,
    "슙슚슜슞",
    5,
    "슦슧슩슪슫슮",
    5,
    "슶슸슺",
    33,
    "싞싟싡싢싥",
    5,
    "싮싰싲싳싴싵싷싺싽싾싿쌁",
    6,
    "쌊쌋쌎쌏"
  ],
  [
    "9b41",
    "쌐쌑쌒쌖쌗쌙쌚쌛쌝",
    6,
    "쌦쌧쌪",
    8
  ],
  [
    "9b61",
    "쌳",
    17,
    "썆",
    7
  ],
  [
    "9b81",
    "썎",
    25,
    "썪썫썭썮썯썱썳",
    4,
    "썺썻썾",
    5,
    "쎅쎆쎇쎉쎊쎋쎍",
    50,
    "쏁",
    22,
    "쏚"
  ],
  [
    "9c41",
    "쏛쏝쏞쏡쏣",
    4,
    "쏪쏫쏬쏮",
    5,
    "쏶쏷쏹",
    5
  ],
  [
    "9c61",
    "쏿",
    8,
    "쐉",
    6,
    "쐑",
    9
  ],
  [
    "9c81",
    "쐛",
    8,
    "쐥",
    6,
    "쐭쐮쐯쐱쐲쐳쐵",
    6,
    "쐾",
    9,
    "쑉",
    26,
    "쑦쑧쑩쑪쑫쑭",
    6,
    "쑶쑷쑸쑺",
    5,
    "쒁",
    18,
    "쒕",
    6,
    "쒝",
    12
  ],
  [
    "9d41",
    "쒪",
    13,
    "쒹쒺쒻쒽",
    8
  ],
  [
    "9d61",
    "쓆",
    25
  ],
  [
    "9d81",
    "쓠",
    8,
    "쓪",
    5,
    "쓲쓳쓵쓶쓷쓹쓻쓼쓽쓾씂",
    9,
    "씍씎씏씑씒씓씕",
    6,
    "씝",
    10,
    "씪씫씭씮씯씱",
    6,
    "씺씼씾",
    5,
    "앆앇앋앏앐앑앒앖앚앛앜앟앢앣앥앦앧앩",
    6,
    "앲앶",
    5,
    "앾앿얁얂얃얅얆얈얉얊얋얎얐얒얓얔"
  ],
  [
    "9e41",
    "얖얙얚얛얝얞얟얡",
    7,
    "얪",
    9,
    "얶"
  ],
  [
    "9e61",
    "얷얺얿",
    4,
    "엋엍엏엒엓엕엖엗엙",
    6,
    "엢엤엦엧"
  ],
  [
    "9e81",
    "엨엩엪엫엯엱엲엳엵엸엹엺엻옂옃옄옉옊옋옍옎옏옑",
    6,
    "옚옝",
    6,
    "옦옧옩옪옫옯옱옲옶옸옺옼옽옾옿왂왃왅왆왇왉",
    6,
    "왒왖",
    5,
    "왞왟왡",
    10,
    "왭왮왰왲",
    5,
    "왺왻왽왾왿욁",
    6,
    "욊욌욎",
    5,
    "욖욗욙욚욛욝",
    6,
    "욦"
  ],
  [
    "9f41",
    "욨욪",
    5,
    "욲욳욵욶욷욻",
    4,
    "웂웄웆",
    5,
    "웎"
  ],
  [
    "9f61",
    "웏웑웒웓웕",
    6,
    "웞웟웢",
    5,
    "웪웫웭웮웯웱웲"
  ],
  [
    "9f81",
    "웳",
    4,
    "웺웻웼웾",
    5,
    "윆윇윉윊윋윍",
    6,
    "윖윘윚",
    5,
    "윢윣윥윦윧윩",
    6,
    "윲윴윶윸윹윺윻윾윿읁읂읃읅",
    4,
    "읋읎읐읙읚읛읝읞읟읡",
    6,
    "읩읪읬",
    7,
    "읶읷읹읺읻읿잀잁잂잆잋잌잍잏잒잓잕잙잛",
    4,
    "잢잧",
    4,
    "잮잯잱잲잳잵잶잷"
  ],
  [
    "a041",
    "잸잹잺잻잾쟂",
    5,
    "쟊쟋쟍쟏쟑",
    6,
    "쟙쟚쟛쟜"
  ],
  [
    "a061",
    "쟞",
    5,
    "쟥쟦쟧쟩쟪쟫쟭",
    13
  ],
  [
    "a081",
    "쟻",
    4,
    "젂젃젅젆젇젉젋",
    4,
    "젒젔젗",
    4,
    "젞젟젡젢젣젥",
    6,
    "젮젰젲",
    5,
    "젹젺젻젽젾젿졁",
    6,
    "졊졋졎",
    5,
    "졕",
    26,
    "졲졳졵졶졷졹졻",
    4,
    "좂좄좈좉좊좎",
    5,
    "좕",
    7,
    "좞좠좢좣좤"
  ],
  [
    "a141",
    "좥좦좧좩",
    18,
    "좾좿죀죁"
  ],
  [
    "a161",
    "죂죃죅죆죇죉죊죋죍",
    6,
    "죖죘죚",
    5,
    "죢죣죥"
  ],
  [
    "a181",
    "죦",
    14,
    "죶",
    5,
    "죾죿줁줂줃줇",
    4,
    "줎　、。·‥…¨〃­―∥＼∼‘’“”〔〕〈",
    9,
    "±×÷≠≤≥∞∴°′″℃Å￠￡￥♂♀∠⊥⌒∂∇≡≒§※☆★○●◎◇◆□■△▲▽▼→←↑↓↔〓≪≫√∽∝∵∫∬∈∋⊆⊇⊂⊃∪∩∧∨￢"
  ],
  [
    "a241",
    "줐줒",
    5,
    "줙",
    18
  ],
  [
    "a261",
    "줭",
    6,
    "줵",
    18
  ],
  [
    "a281",
    "쥈",
    7,
    "쥒쥓쥕쥖쥗쥙",
    6,
    "쥢쥤",
    7,
    "쥭쥮쥯⇒⇔∀∃´～ˇ˘˝˚˙¸˛¡¿ː∮∑∏¤℉‰◁◀▷▶♤♠♡♥♧♣⊙◈▣◐◑▒▤▥▨▧▦▩♨☏☎☜☞¶†‡↕↗↙↖↘♭♩♪♬㉿㈜№㏇™㏂㏘℡€®"
  ],
  [
    "a341",
    "쥱쥲쥳쥵",
    6,
    "쥽",
    10,
    "즊즋즍즎즏"
  ],
  [
    "a361",
    "즑",
    6,
    "즚즜즞",
    16
  ],
  [
    "a381",
    "즯",
    16,
    "짂짃짅짆짉짋",
    4,
    "짒짔짗짘짛！",
    58,
    "￦］",
    32,
    "￣"
  ],
  [
    "a441",
    "짞짟짡짣짥짦짨짩짪짫짮짲",
    5,
    "짺짻짽짾짿쨁쨂쨃쨄"
  ],
  [
    "a461",
    "쨅쨆쨇쨊쨎",
    5,
    "쨕쨖쨗쨙",
    12
  ],
  [
    "a481",
    "쨦쨧쨨쨪",
    28,
    "ㄱ",
    93
  ],
  [
    "a541",
    "쩇",
    4,
    "쩎쩏쩑쩒쩓쩕",
    6,
    "쩞쩢",
    5,
    "쩩쩪"
  ],
  [
    "a561",
    "쩫",
    17,
    "쩾",
    5,
    "쪅쪆"
  ],
  [
    "a581",
    "쪇",
    16,
    "쪙",
    14,
    "ⅰ",
    9
  ],
  [
    "a5b0",
    "Ⅰ",
    9
  ],
  [
    "a5c1",
    "Α",
    16,
    "Σ",
    6
  ],
  [
    "a5e1",
    "α",
    16,
    "σ",
    6
  ],
  [
    "a641",
    "쪨",
    19,
    "쪾쪿쫁쫂쫃쫅"
  ],
  [
    "a661",
    "쫆",
    5,
    "쫎쫐쫒쫔쫕쫖쫗쫚",
    5,
    "쫡",
    6
  ],
  [
    "a681",
    "쫨쫩쫪쫫쫭",
    6,
    "쫵",
    18,
    "쬉쬊─│┌┐┘└├┬┤┴┼━┃┏┓┛┗┣┳┫┻╋┠┯┨┷┿┝┰┥┸╂┒┑┚┙┖┕┎┍┞┟┡┢┦┧┩┪┭┮┱┲┵┶┹┺┽┾╀╁╃",
    7
  ],
  [
    "a741",
    "쬋",
    4,
    "쬑쬒쬓쬕쬖쬗쬙",
    6,
    "쬢",
    7
  ],
  [
    "a761",
    "쬪",
    22,
    "쭂쭃쭄"
  ],
  [
    "a781",
    "쭅쭆쭇쭊쭋쭍쭎쭏쭑",
    6,
    "쭚쭛쭜쭞",
    5,
    "쭥",
    7,
    "㎕㎖㎗ℓ㎘㏄㎣㎤㎥㎦㎙",
    9,
    "㏊㎍㎎㎏㏏㎈㎉㏈㎧㎨㎰",
    9,
    "㎀",
    4,
    "㎺",
    5,
    "㎐",
    4,
    "Ω㏀㏁㎊㎋㎌㏖㏅㎭㎮㎯㏛㎩㎪㎫㎬㏝㏐㏓㏃㏉㏜㏆"
  ],
  [
    "a841",
    "쭭",
    10,
    "쭺",
    14
  ],
  [
    "a861",
    "쮉",
    18,
    "쮝",
    6
  ],
  [
    "a881",
    "쮤",
    19,
    "쮹",
    11,
    "ÆÐªĦ"
  ],
  [
    "a8a6",
    "Ĳ"
  ],
  [
    "a8a8",
    "ĿŁØŒºÞŦŊ"
  ],
  [
    "a8b1",
    "㉠",
    27,
    "ⓐ",
    25,
    "①",
    14,
    "½⅓⅔¼¾⅛⅜⅝⅞"
  ],
  [
    "a941",
    "쯅",
    14,
    "쯕",
    10
  ],
  [
    "a961",
    "쯠쯡쯢쯣쯥쯦쯨쯪",
    18
  ],
  [
    "a981",
    "쯽",
    14,
    "찎찏찑찒찓찕",
    6,
    "찞찟찠찣찤æđðħıĳĸŀłøœßþŧŋŉ㈀",
    27,
    "⒜",
    25,
    "⑴",
    14,
    "¹²³⁴ⁿ₁₂₃₄"
  ],
  [
    "aa41",
    "찥찦찪찫찭찯찱",
    6,
    "찺찿",
    4,
    "챆챇챉챊챋챍챎"
  ],
  [
    "aa61",
    "챏",
    4,
    "챖챚",
    5,
    "챡챢챣챥챧챩",
    6,
    "챱챲"
  ],
  [
    "aa81",
    "챳챴챶",
    29,
    "ぁ",
    82
  ],
  [
    "ab41",
    "첔첕첖첗첚첛첝첞첟첡",
    6,
    "첪첮",
    5,
    "첶첷첹"
  ],
  [
    "ab61",
    "첺첻첽",
    6,
    "쳆쳈쳊",
    5,
    "쳑쳒쳓쳕",
    5
  ],
  [
    "ab81",
    "쳛",
    8,
    "쳥",
    6,
    "쳭쳮쳯쳱",
    12,
    "ァ",
    85
  ],
  [
    "ac41",
    "쳾쳿촀촂",
    5,
    "촊촋촍촎촏촑",
    6,
    "촚촜촞촟촠"
  ],
  [
    "ac61",
    "촡촢촣촥촦촧촩촪촫촭",
    11,
    "촺",
    4
  ],
  [
    "ac81",
    "촿",
    28,
    "쵝쵞쵟А",
    5,
    "ЁЖ",
    25
  ],
  [
    "acd1",
    "а",
    5,
    "ёж",
    25
  ],
  [
    "ad41",
    "쵡쵢쵣쵥",
    6,
    "쵮쵰쵲",
    5,
    "쵹",
    7
  ],
  [
    "ad61",
    "춁",
    6,
    "춉",
    10,
    "춖춗춙춚춛춝춞춟"
  ],
  [
    "ad81",
    "춠춡춢춣춦춨춪",
    5,
    "춱",
    18,
    "췅"
  ],
  [
    "ae41",
    "췆",
    5,
    "췍췎췏췑",
    16
  ],
  [
    "ae61",
    "췢",
    5,
    "췩췪췫췭췮췯췱",
    6,
    "췺췼췾",
    4
  ],
  [
    "ae81",
    "츃츅츆츇츉츊츋츍",
    6,
    "츕츖츗츘츚",
    5,
    "츢츣츥츦츧츩츪츫"
  ],
  [
    "af41",
    "츬츭츮츯츲츴츶",
    19
  ],
  [
    "af61",
    "칊",
    13,
    "칚칛칝칞칢",
    5,
    "칪칬"
  ],
  [
    "af81",
    "칮",
    5,
    "칶칷칹칺칻칽",
    6,
    "캆캈캊",
    5,
    "캒캓캕캖캗캙"
  ],
  [
    "b041",
    "캚",
    5,
    "캢캦",
    5,
    "캮",
    12
  ],
  [
    "b061",
    "캻",
    5,
    "컂",
    19
  ],
  [
    "b081",
    "컖",
    13,
    "컦컧컩컪컭",
    6,
    "컶컺",
    5,
    "가각간갇갈갉갊감",
    7,
    "같",
    4,
    "갠갤갬갭갯갰갱갸갹갼걀걋걍걔걘걜거걱건걷걸걺검겁것겄겅겆겉겊겋게겐겔겜겝겟겠겡겨격겪견겯결겸겹겻겼경곁계곈곌곕곗고곡곤곧골곪곬곯곰곱곳공곶과곽관괄괆"
  ],
  [
    "b141",
    "켂켃켅켆켇켉",
    6,
    "켒켔켖",
    5,
    "켝켞켟켡켢켣"
  ],
  [
    "b161",
    "켥",
    6,
    "켮켲",
    5,
    "켹",
    11
  ],
  [
    "b181",
    "콅",
    14,
    "콖콗콙콚콛콝",
    6,
    "콦콨콪콫콬괌괍괏광괘괜괠괩괬괭괴괵괸괼굄굅굇굉교굔굘굡굣구국군굳굴굵굶굻굼굽굿궁궂궈궉권궐궜궝궤궷귀귁귄귈귐귑귓규균귤그극근귿글긁금급긋긍긔기긱긴긷길긺김깁깃깅깆깊까깍깎깐깔깖깜깝깟깠깡깥깨깩깬깰깸"
  ],
  [
    "b241",
    "콭콮콯콲콳콵콶콷콹",
    6,
    "쾁쾂쾃쾄쾆",
    5,
    "쾍"
  ],
  [
    "b261",
    "쾎",
    18,
    "쾢",
    5,
    "쾩"
  ],
  [
    "b281",
    "쾪",
    5,
    "쾱",
    18,
    "쿅",
    6,
    "깹깻깼깽꺄꺅꺌꺼꺽꺾껀껄껌껍껏껐껑께껙껜껨껫껭껴껸껼꼇꼈꼍꼐꼬꼭꼰꼲꼴꼼꼽꼿꽁꽂꽃꽈꽉꽐꽜꽝꽤꽥꽹꾀꾄꾈꾐꾑꾕꾜꾸꾹꾼꿀꿇꿈꿉꿋꿍꿎꿔꿜꿨꿩꿰꿱꿴꿸뀀뀁뀄뀌뀐뀔뀜뀝뀨끄끅끈끊끌끎끓끔끕끗끙"
  ],
  [
    "b341",
    "쿌",
    19,
    "쿢쿣쿥쿦쿧쿩"
  ],
  [
    "b361",
    "쿪",
    5,
    "쿲쿴쿶",
    5,
    "쿽쿾쿿퀁퀂퀃퀅",
    5
  ],
  [
    "b381",
    "퀋",
    5,
    "퀒",
    5,
    "퀙",
    19,
    "끝끼끽낀낄낌낍낏낑나낙낚난낟날낡낢남납낫",
    4,
    "낱낳내낵낸낼냄냅냇냈냉냐냑냔냘냠냥너넉넋넌널넒넓넘넙넛넜넝넣네넥넨넬넴넵넷넸넹녀녁년녈념녑녔녕녘녜녠노녹논놀놂놈놉놋농높놓놔놘놜놨뇌뇐뇔뇜뇝"
  ],
  [
    "b441",
    "퀮",
    5,
    "퀶퀷퀹퀺퀻퀽",
    6,
    "큆큈큊",
    5
  ],
  [
    "b461",
    "큑큒큓큕큖큗큙",
    6,
    "큡",
    10,
    "큮큯"
  ],
  [
    "b481",
    "큱큲큳큵",
    6,
    "큾큿킀킂",
    18,
    "뇟뇨뇩뇬뇰뇹뇻뇽누눅눈눋눌눔눕눗눙눠눴눼뉘뉜뉠뉨뉩뉴뉵뉼늄늅늉느늑는늘늙늚늠늡늣능늦늪늬늰늴니닉닌닐닒님닙닛닝닢다닥닦단닫",
    4,
    "닳담답닷",
    4,
    "닿대댁댄댈댐댑댓댔댕댜더덕덖던덛덜덞덟덤덥"
  ],
  [
    "b541",
    "킕",
    14,
    "킦킧킩킪킫킭",
    5
  ],
  [
    "b561",
    "킳킶킸킺",
    5,
    "탂탃탅탆탇탊",
    5,
    "탒탖",
    4
  ],
  [
    "b581",
    "탛탞탟탡탢탣탥",
    6,
    "탮탲",
    5,
    "탹",
    11,
    "덧덩덫덮데덱덴델뎀뎁뎃뎄뎅뎌뎐뎔뎠뎡뎨뎬도독돈돋돌돎돐돔돕돗동돛돝돠돤돨돼됐되된될됨됩됫됴두둑둔둘둠둡둣둥둬뒀뒈뒝뒤뒨뒬뒵뒷뒹듀듄듈듐듕드득든듣들듦듬듭듯등듸디딕딘딛딜딤딥딧딨딩딪따딱딴딸"
  ],
  [
    "b641",
    "턅",
    7,
    "턎",
    17
  ],
  [
    "b661",
    "턠",
    15,
    "턲턳턵턶턷턹턻턼턽턾"
  ],
  [
    "b681",
    "턿텂텆",
    5,
    "텎텏텑텒텓텕",
    6,
    "텞텠텢",
    5,
    "텩텪텫텭땀땁땃땄땅땋때땍땐땔땜땝땟땠땡떠떡떤떨떪떫떰떱떳떴떵떻떼떽뗀뗄뗌뗍뗏뗐뗑뗘뗬또똑똔똘똥똬똴뙈뙤뙨뚜뚝뚠뚤뚫뚬뚱뛔뛰뛴뛸뜀뜁뜅뜨뜩뜬뜯뜰뜸뜹뜻띄띈띌띔띕띠띤띨띰띱띳띵라락란랄람랍랏랐랑랒랖랗"
  ],
  [
    "b741",
    "텮",
    13,
    "텽",
    6,
    "톅톆톇톉톊"
  ],
  [
    "b761",
    "톋",
    20,
    "톢톣톥톦톧"
  ],
  [
    "b781",
    "톩",
    6,
    "톲톴톶톷톸톹톻톽톾톿퇁",
    14,
    "래랙랜랠램랩랫랬랭랴략랸럇량러럭런럴럼럽럿렀렁렇레렉렌렐렘렙렛렝려력련렬렴렵렷렸령례롄롑롓로록론롤롬롭롯롱롸롼뢍뢨뢰뢴뢸룀룁룃룅료룐룔룝룟룡루룩룬룰룸룹룻룽뤄뤘뤠뤼뤽륀륄륌륏륑류륙륜률륨륩"
  ],
  [
    "b841",
    "퇐",
    7,
    "퇙",
    17
  ],
  [
    "b861",
    "퇫",
    8,
    "퇵퇶퇷퇹",
    13
  ],
  [
    "b881",
    "툈툊",
    5,
    "툑",
    24,
    "륫륭르륵른를름릅릇릉릊릍릎리릭린릴림립릿링마막만많",
    4,
    "맘맙맛망맞맡맣매맥맨맬맴맵맷맸맹맺먀먁먈먕머먹먼멀멂멈멉멋멍멎멓메멕멘멜멤멥멧멨멩며멱면멸몃몄명몇몌모목몫몬몰몲몸몹못몽뫄뫈뫘뫙뫼"
  ],
  [
    "b941",
    "툪툫툮툯툱툲툳툵",
    6,
    "툾퉀퉂",
    5,
    "퉉퉊퉋퉌"
  ],
  [
    "b961",
    "퉍",
    14,
    "퉝",
    6,
    "퉥퉦퉧퉨"
  ],
  [
    "b981",
    "퉩",
    22,
    "튂튃튅튆튇튉튊튋튌묀묄묍묏묑묘묜묠묩묫무묵묶문묻물묽묾뭄뭅뭇뭉뭍뭏뭐뭔뭘뭡뭣뭬뮈뮌뮐뮤뮨뮬뮴뮷므믄믈믐믓미믹민믿밀밂밈밉밋밌밍및밑바",
    4,
    "받",
    4,
    "밤밥밧방밭배백밴밸뱀뱁뱃뱄뱅뱉뱌뱍뱐뱝버벅번벋벌벎범법벗"
  ],
  [
    "ba41",
    "튍튎튏튒튓튔튖",
    5,
    "튝튞튟튡튢튣튥",
    6,
    "튭"
  ],
  [
    "ba61",
    "튮튯튰튲",
    5,
    "튺튻튽튾틁틃",
    4,
    "틊틌",
    5
  ],
  [
    "ba81",
    "틒틓틕틖틗틙틚틛틝",
    6,
    "틦",
    9,
    "틲틳틵틶틷틹틺벙벚베벡벤벧벨벰벱벳벴벵벼벽변별볍볏볐병볕볘볜보복볶본볼봄봅봇봉봐봔봤봬뵀뵈뵉뵌뵐뵘뵙뵤뵨부북분붇불붉붊붐붑붓붕붙붚붜붤붰붸뷔뷕뷘뷜뷩뷰뷴뷸븀븃븅브븍븐블븜븝븟비빅빈빌빎빔빕빗빙빚빛빠빡빤"
  ],
  [
    "bb41",
    "틻",
    4,
    "팂팄팆",
    5,
    "팏팑팒팓팕팗",
    4,
    "팞팢팣"
  ],
  [
    "bb61",
    "팤팦팧팪팫팭팮팯팱",
    6,
    "팺팾",
    5,
    "퍆퍇퍈퍉"
  ],
  [
    "bb81",
    "퍊",
    31,
    "빨빪빰빱빳빴빵빻빼빽뺀뺄뺌뺍뺏뺐뺑뺘뺙뺨뻐뻑뻔뻗뻘뻠뻣뻤뻥뻬뼁뼈뼉뼘뼙뼛뼜뼝뽀뽁뽄뽈뽐뽑뽕뾔뾰뿅뿌뿍뿐뿔뿜뿟뿡쀼쁑쁘쁜쁠쁨쁩삐삑삔삘삠삡삣삥사삭삯산삳살삵삶삼삽삿샀상샅새색샌샐샘샙샛샜생샤"
  ],
  [
    "bc41",
    "퍪",
    17,
    "퍾퍿펁펂펃펅펆펇"
  ],
  [
    "bc61",
    "펈펉펊펋펎펒",
    5,
    "펚펛펝펞펟펡",
    6,
    "펪펬펮"
  ],
  [
    "bc81",
    "펯",
    4,
    "펵펶펷펹펺펻펽",
    6,
    "폆폇폊",
    5,
    "폑",
    5,
    "샥샨샬샴샵샷샹섀섄섈섐섕서",
    4,
    "섣설섦섧섬섭섯섰성섶세섹센셀셈셉셋셌셍셔셕션셜셤셥셧셨셩셰셴셸솅소속솎손솔솖솜솝솟송솥솨솩솬솰솽쇄쇈쇌쇔쇗쇘쇠쇤쇨쇰쇱쇳쇼쇽숀숄숌숍숏숑수숙순숟술숨숩숫숭"
  ],
  [
    "bd41",
    "폗폙",
    7,
    "폢폤",
    7,
    "폮폯폱폲폳폵폶폷"
  ],
  [
    "bd61",
    "폸폹폺폻폾퐀퐂",
    5,
    "퐉",
    13
  ],
  [
    "bd81",
    "퐗",
    5,
    "퐞",
    25,
    "숯숱숲숴쉈쉐쉑쉔쉘쉠쉥쉬쉭쉰쉴쉼쉽쉿슁슈슉슐슘슛슝스슥슨슬슭슴습슷승시식신싣실싫심십싯싱싶싸싹싻싼쌀쌈쌉쌌쌍쌓쌔쌕쌘쌜쌤쌥쌨쌩썅써썩썬썰썲썸썹썼썽쎄쎈쎌쏀쏘쏙쏜쏟쏠쏢쏨쏩쏭쏴쏵쏸쐈쐐쐤쐬쐰"
  ],
  [
    "be41",
    "퐸",
    7,
    "푁푂푃푅",
    14
  ],
  [
    "be61",
    "푔",
    7,
    "푝푞푟푡푢푣푥",
    7,
    "푮푰푱푲"
  ],
  [
    "be81",
    "푳",
    4,
    "푺푻푽푾풁풃",
    4,
    "풊풌풎",
    5,
    "풕",
    8,
    "쐴쐼쐽쑈쑤쑥쑨쑬쑴쑵쑹쒀쒔쒜쒸쒼쓩쓰쓱쓴쓸쓺쓿씀씁씌씐씔씜씨씩씬씰씸씹씻씽아악안앉않알앍앎앓암압앗았앙앝앞애액앤앨앰앱앳앴앵야약얀얄얇얌얍얏양얕얗얘얜얠얩어억언얹얻얼얽얾엄",
    6,
    "엌엎"
  ],
  [
    "bf41",
    "풞",
    10,
    "풪",
    14
  ],
  [
    "bf61",
    "풹",
    18,
    "퓍퓎퓏퓑퓒퓓퓕"
  ],
  [
    "bf81",
    "퓖",
    5,
    "퓝퓞퓠",
    7,
    "퓩퓪퓫퓭퓮퓯퓱",
    6,
    "퓹퓺퓼에엑엔엘엠엡엣엥여역엮연열엶엷염",
    5,
    "옅옆옇예옌옐옘옙옛옜오옥온올옭옮옰옳옴옵옷옹옻와왁완왈왐왑왓왔왕왜왝왠왬왯왱외왹왼욀욈욉욋욍요욕욘욜욤욥욧용우욱운울욹욺움웁웃웅워웍원월웜웝웠웡웨"
  ],
  [
    "c041",
    "퓾",
    5,
    "픅픆픇픉픊픋픍",
    6,
    "픖픘",
    5
  ],
  [
    "c061",
    "픞",
    25
  ],
  [
    "c081",
    "픸픹픺픻픾픿핁핂핃핅",
    6,
    "핎핐핒",
    5,
    "핚핛핝핞핟핡핢핣웩웬웰웸웹웽위윅윈윌윔윕윗윙유육윤율윰윱윳융윷으윽은을읊음읍읏응",
    7,
    "읜읠읨읫이익인일읽읾잃임입잇있잉잊잎자작잔잖잗잘잚잠잡잣잤장잦재잭잰잴잼잽잿쟀쟁쟈쟉쟌쟎쟐쟘쟝쟤쟨쟬저적전절젊"
  ],
  [
    "c141",
    "핤핦핧핪핬핮",
    5,
    "핶핷핹핺핻핽",
    6,
    "햆햊햋"
  ],
  [
    "c161",
    "햌햍햎햏햑",
    19,
    "햦햧"
  ],
  [
    "c181",
    "햨",
    31,
    "점접젓정젖제젝젠젤젬젭젯젱져젼졀졈졉졌졍졔조족존졸졺좀좁좃종좆좇좋좌좍좔좝좟좡좨좼좽죄죈죌죔죕죗죙죠죡죤죵주죽준줄줅줆줌줍줏중줘줬줴쥐쥑쥔쥘쥠쥡쥣쥬쥰쥴쥼즈즉즌즐즘즙즛증지직진짇질짊짐집짓"
  ],
  [
    "c241",
    "헊헋헍헎헏헑헓",
    4,
    "헚헜헞",
    5,
    "헦헧헩헪헫헭헮"
  ],
  [
    "c261",
    "헯",
    4,
    "헶헸헺",
    5,
    "혂혃혅혆혇혉",
    6,
    "혒"
  ],
  [
    "c281",
    "혖",
    5,
    "혝혞혟혡혢혣혥",
    7,
    "혮",
    9,
    "혺혻징짖짙짚짜짝짠짢짤짧짬짭짯짰짱째짹짼쨀쨈쨉쨋쨌쨍쨔쨘쨩쩌쩍쩐쩔쩜쩝쩟쩠쩡쩨쩽쪄쪘쪼쪽쫀쫄쫌쫍쫏쫑쫓쫘쫙쫠쫬쫴쬈쬐쬔쬘쬠쬡쭁쭈쭉쭌쭐쭘쭙쭝쭤쭸쭹쮜쮸쯔쯤쯧쯩찌찍찐찔찜찝찡찢찧차착찬찮찰참찹찻"
  ],
  [
    "c341",
    "혽혾혿홁홂홃홄홆홇홊홌홎홏홐홒홓홖홗홙홚홛홝",
    4
  ],
  [
    "c361",
    "홢",
    4,
    "홨홪",
    5,
    "홲홳홵",
    11
  ],
  [
    "c381",
    "횁횂횄횆",
    5,
    "횎횏횑횒횓횕",
    7,
    "횞횠횢",
    5,
    "횩횪찼창찾채책챈챌챔챕챗챘챙챠챤챦챨챰챵처척천철첨첩첫첬청체첵첸첼쳄쳅쳇쳉쳐쳔쳤쳬쳰촁초촉촌촐촘촙촛총촤촨촬촹최쵠쵤쵬쵭쵯쵱쵸춈추축춘출춤춥춧충춰췄췌췐취췬췰췸췹췻췽츄츈츌츔츙츠측츤츨츰츱츳층"
  ],
  [
    "c441",
    "횫횭횮횯횱",
    7,
    "횺횼",
    7,
    "훆훇훉훊훋"
  ],
  [
    "c461",
    "훍훎훏훐훒훓훕훖훘훚",
    5,
    "훡훢훣훥훦훧훩",
    4
  ],
  [
    "c481",
    "훮훯훱훲훳훴훶",
    5,
    "훾훿휁휂휃휅",
    11,
    "휒휓휔치칙친칟칠칡침칩칫칭카칵칸칼캄캅캇캉캐캑캔캘캠캡캣캤캥캬캭컁커컥컨컫컬컴컵컷컸컹케켁켄켈켐켑켓켕켜켠켤켬켭켯켰켱켸코콕콘콜콤콥콧콩콰콱콴콸쾀쾅쾌쾡쾨쾰쿄쿠쿡쿤쿨쿰쿱쿳쿵쿼퀀퀄퀑퀘퀭퀴퀵퀸퀼"
  ],
  [
    "c541",
    "휕휖휗휚휛휝휞휟휡",
    6,
    "휪휬휮",
    5,
    "휶휷휹"
  ],
  [
    "c561",
    "휺휻휽",
    6,
    "흅흆흈흊",
    5,
    "흒흓흕흚",
    4
  ],
  [
    "c581",
    "흟흢흤흦흧흨흪흫흭흮흯흱흲흳흵",
    6,
    "흾흿힀힂",
    5,
    "힊힋큄큅큇큉큐큔큘큠크큭큰클큼큽킁키킥킨킬킴킵킷킹타탁탄탈탉탐탑탓탔탕태택탠탤탬탭탯탰탱탸턍터턱턴털턺텀텁텃텄텅테텍텐텔템텝텟텡텨텬텼톄톈토톡톤톨톰톱톳통톺톼퇀퇘퇴퇸툇툉툐투툭툰툴툼툽툿퉁퉈퉜"
  ],
  [
    "c641",
    "힍힎힏힑",
    6,
    "힚힜힞",
    5
  ],
  [
    "c6a1",
    "퉤튀튁튄튈튐튑튕튜튠튤튬튱트특튼튿틀틂틈틉틋틔틘틜틤틥티틱틴틸팀팁팃팅파팍팎판팔팖팜팝팟팠팡팥패팩팬팰팸팹팻팼팽퍄퍅퍼퍽펀펄펌펍펏펐펑페펙펜펠펨펩펫펭펴편펼폄폅폈평폐폘폡폣포폭폰폴폼폽폿퐁"
  ],
  [
    "c7a1",
    "퐈퐝푀푄표푠푤푭푯푸푹푼푿풀풂품풉풋풍풔풩퓌퓐퓔퓜퓟퓨퓬퓰퓸퓻퓽프픈플픔픕픗피픽핀필핌핍핏핑하학한할핥함합핫항해핵핸핼햄햅햇했행햐향허헉헌헐헒험헙헛헝헤헥헨헬헴헵헷헹혀혁현혈혐협혓혔형혜혠"
  ],
  [
    "c8a1",
    "혤혭호혹혼홀홅홈홉홋홍홑화확환활홧황홰홱홴횃횅회획횐횔횝횟횡효횬횰횹횻후훅훈훌훑훔훗훙훠훤훨훰훵훼훽휀휄휑휘휙휜휠휨휩휫휭휴휵휸휼흄흇흉흐흑흔흖흗흘흙흠흡흣흥흩희흰흴흼흽힁히힉힌힐힘힙힛힝"
  ],
  [
    "caa1",
    "伽佳假價加可呵哥嘉嫁家暇架枷柯歌珂痂稼苛茄街袈訶賈跏軻迦駕刻却各恪慤殼珏脚覺角閣侃刊墾奸姦干幹懇揀杆柬桿澗癎看磵稈竿簡肝艮艱諫間乫喝曷渴碣竭葛褐蝎鞨勘坎堪嵌感憾戡敢柑橄減甘疳監瞰紺邯鑑鑒龕"
  ],
  [
    "cba1",
    "匣岬甲胛鉀閘剛堈姜岡崗康强彊慷江畺疆糠絳綱羌腔舡薑襁講鋼降鱇介价個凱塏愷愾慨改槪漑疥皆盖箇芥蓋豈鎧開喀客坑更粳羹醵倨去居巨拒据據擧渠炬祛距踞車遽鉅鋸乾件健巾建愆楗腱虔蹇鍵騫乞傑杰桀儉劍劒檢"
  ],
  [
    "cca1",
    "瞼鈐黔劫怯迲偈憩揭擊格檄激膈覡隔堅牽犬甄絹繭肩見譴遣鵑抉決潔結缺訣兼慊箝謙鉗鎌京俓倞傾儆勁勍卿坰境庚徑慶憬擎敬景暻更梗涇炅烱璟璥瓊痙硬磬竟競絅經耕耿脛莖警輕逕鏡頃頸驚鯨係啓堺契季屆悸戒桂械"
  ],
  [
    "cda1",
    "棨溪界癸磎稽系繫繼計誡谿階鷄古叩告呱固姑孤尻庫拷攷故敲暠枯槁沽痼皐睾稿羔考股膏苦苽菰藁蠱袴誥賈辜錮雇顧高鼓哭斛曲梏穀谷鵠困坤崑昆梱棍滾琨袞鯤汨滑骨供公共功孔工恐恭拱控攻珙空蚣貢鞏串寡戈果瓜"
  ],
  [
    "cea1",
    "科菓誇課跨過鍋顆廓槨藿郭串冠官寬慣棺款灌琯瓘管罐菅觀貫關館刮恝括适侊光匡壙廣曠洸炚狂珖筐胱鑛卦掛罫乖傀塊壞怪愧拐槐魁宏紘肱轟交僑咬喬嬌嶠巧攪敎校橋狡皎矯絞翹膠蕎蛟較轎郊餃驕鮫丘久九仇俱具勾"
  ],
  [
    "cfa1",
    "區口句咎嘔坵垢寇嶇廐懼拘救枸柩構歐毆毬求溝灸狗玖球瞿矩究絿耉臼舅舊苟衢謳購軀逑邱鉤銶駒驅鳩鷗龜國局菊鞠鞫麴君窘群裙軍郡堀屈掘窟宮弓穹窮芎躬倦券勸卷圈拳捲權淃眷厥獗蕨蹶闕机櫃潰詭軌饋句晷歸貴"
  ],
  [
    "d0a1",
    "鬼龜叫圭奎揆槻珪硅窺竅糾葵規赳逵閨勻均畇筠菌鈞龜橘克剋劇戟棘極隙僅劤勤懃斤根槿瑾筋芹菫覲謹近饉契今妗擒昑檎琴禁禽芩衾衿襟金錦伋及急扱汲級給亘兢矜肯企伎其冀嗜器圻基埼夔奇妓寄岐崎己幾忌技旗旣"
  ],
  [
    "d1a1",
    "朞期杞棋棄機欺氣汽沂淇玘琦琪璂璣畸畿碁磯祁祇祈祺箕紀綺羈耆耭肌記譏豈起錡錤飢饑騎騏驥麒緊佶吉拮桔金喫儺喇奈娜懦懶拏拿癩",
    5,
    "那樂",
    4,
    "諾酪駱亂卵暖欄煖爛蘭難鸞捏捺南嵐枏楠湳濫男藍襤拉"
  ],
  [
    "d2a1",
    "納臘蠟衲囊娘廊",
    4,
    "乃來內奈柰耐冷女年撚秊念恬拈捻寧寗努勞奴弩怒擄櫓爐瑙盧",
    5,
    "駑魯",
    10,
    "濃籠聾膿農惱牢磊腦賂雷尿壘",
    7,
    "嫩訥杻紐勒",
    5,
    "能菱陵尼泥匿溺多茶"
  ],
  [
    "d3a1",
    "丹亶但單團壇彖斷旦檀段湍短端簞緞蛋袒鄲鍛撻澾獺疸達啖坍憺擔曇淡湛潭澹痰聃膽蕁覃談譚錟沓畓答踏遝唐堂塘幢戇撞棠當糖螳黨代垈坮大對岱帶待戴擡玳臺袋貸隊黛宅德悳倒刀到圖堵塗導屠島嶋度徒悼挑掉搗桃"
  ],
  [
    "d4a1",
    "棹櫂淘渡滔濤燾盜睹禱稻萄覩賭跳蹈逃途道都鍍陶韜毒瀆牘犢獨督禿篤纛讀墩惇敦旽暾沌焞燉豚頓乭突仝冬凍動同憧東桐棟洞潼疼瞳童胴董銅兜斗杜枓痘竇荳讀豆逗頭屯臀芚遁遯鈍得嶝橙燈登等藤謄鄧騰喇懶拏癩羅"
  ],
  [
    "d5a1",
    "蘿螺裸邏樂洛烙珞絡落諾酪駱丹亂卵欄欒瀾爛蘭鸞剌辣嵐擥攬欖濫籃纜藍襤覽拉臘蠟廊朗浪狼琅瑯螂郞來崍徠萊冷掠略亮倆兩凉梁樑粮粱糧良諒輛量侶儷勵呂廬慮戾旅櫚濾礪藜蠣閭驢驪麗黎力曆歷瀝礫轢靂憐戀攣漣"
  ],
  [
    "d6a1",
    "煉璉練聯蓮輦連鍊冽列劣洌烈裂廉斂殮濂簾獵令伶囹寧岺嶺怜玲笭羚翎聆逞鈴零靈領齡例澧禮醴隷勞怒撈擄櫓潞瀘爐盧老蘆虜路輅露魯鷺鹵碌祿綠菉錄鹿麓論壟弄朧瀧瓏籠聾儡瀨牢磊賂賚賴雷了僚寮廖料燎療瞭聊蓼"
  ],
  [
    "d7a1",
    "遼鬧龍壘婁屢樓淚漏瘻累縷蔞褸鏤陋劉旒柳榴流溜瀏琉瑠留瘤硫謬類六戮陸侖倫崙淪綸輪律慄栗率隆勒肋凜凌楞稜綾菱陵俚利厘吏唎履悧李梨浬犁狸理璃異痢籬罹羸莉裏裡里釐離鯉吝潾燐璘藺躪隣鱗麟林淋琳臨霖砬"
  ],
  [
    "d8a1",
    "立笠粒摩瑪痲碼磨馬魔麻寞幕漠膜莫邈万卍娩巒彎慢挽晩曼滿漫灣瞞萬蔓蠻輓饅鰻唜抹末沫茉襪靺亡妄忘忙望網罔芒茫莽輞邙埋妹媒寐昧枚梅每煤罵買賣邁魅脈貊陌驀麥孟氓猛盲盟萌冪覓免冕勉棉沔眄眠綿緬面麵滅"
  ],
  [
    "d9a1",
    "蔑冥名命明暝椧溟皿瞑茗蓂螟酩銘鳴袂侮冒募姆帽慕摸摹暮某模母毛牟牡瑁眸矛耗芼茅謀謨貌木沐牧目睦穆鶩歿沒夢朦蒙卯墓妙廟描昴杳渺猫竗苗錨務巫憮懋戊拇撫无楙武毋無珷畝繆舞茂蕪誣貿霧鵡墨默們刎吻問文"
  ],
  [
    "daa1",
    "汶紊紋聞蚊門雯勿沕物味媚尾嵋彌微未梶楣渼湄眉米美薇謎迷靡黴岷悶愍憫敏旻旼民泯玟珉緡閔密蜜謐剝博拍搏撲朴樸泊珀璞箔粕縛膊舶薄迫雹駁伴半反叛拌搬攀斑槃泮潘班畔瘢盤盼磐磻礬絆般蟠返頒飯勃拔撥渤潑"
  ],
  [
    "dba1",
    "發跋醱鉢髮魃倣傍坊妨尨幇彷房放方旁昉枋榜滂磅紡肪膀舫芳蒡蚌訪謗邦防龐倍俳北培徘拜排杯湃焙盃背胚裴裵褙賠輩配陪伯佰帛柏栢白百魄幡樊煩燔番磻繁蕃藩飜伐筏罰閥凡帆梵氾汎泛犯範范法琺僻劈壁擘檗璧癖"
  ],
  [
    "dca1",
    "碧蘗闢霹便卞弁變辨辯邊別瞥鱉鼈丙倂兵屛幷昞昺柄棅炳甁病秉竝輧餠騈保堡報寶普步洑湺潽珤甫菩補褓譜輔伏僕匐卜宓復服福腹茯蔔複覆輹輻馥鰒本乶俸奉封峯峰捧棒烽熢琫縫蓬蜂逢鋒鳳不付俯傅剖副否咐埠夫婦"
  ],
  [
    "dda1",
    "孚孵富府復扶敷斧浮溥父符簿缶腐腑膚艀芙莩訃負賦賻赴趺部釜阜附駙鳧北分吩噴墳奔奮忿憤扮昐汾焚盆粉糞紛芬賁雰不佛弗彿拂崩朋棚硼繃鵬丕備匕匪卑妃婢庇悲憊扉批斐枇榧比毖毗毘沸泌琵痺砒碑秕秘粃緋翡肥"
  ],
  [
    "dea1",
    "脾臂菲蜚裨誹譬費鄙非飛鼻嚬嬪彬斌檳殯浜濱瀕牝玭貧賓頻憑氷聘騁乍事些仕伺似使俟僿史司唆嗣四士奢娑寫寺射巳師徙思捨斜斯柶査梭死沙泗渣瀉獅砂社祀祠私篩紗絲肆舍莎蓑蛇裟詐詞謝賜赦辭邪飼駟麝削數朔索"
  ],
  [
    "dfa1",
    "傘刪山散汕珊産疝算蒜酸霰乷撒殺煞薩三參杉森渗芟蔘衫揷澁鈒颯上傷像償商喪嘗孀尙峠常床庠廂想桑橡湘爽牀狀相祥箱翔裳觴詳象賞霜塞璽賽嗇塞穡索色牲生甥省笙墅壻嶼序庶徐恕抒捿敍暑曙書栖棲犀瑞筮絮緖署"
  ],
  [
    "e0a1",
    "胥舒薯西誓逝鋤黍鼠夕奭席惜昔晳析汐淅潟石碩蓆釋錫仙僊先善嬋宣扇敾旋渲煽琁瑄璇璿癬禪線繕羨腺膳船蘚蟬詵跣選銑鐥饍鮮卨屑楔泄洩渫舌薛褻設說雪齧剡暹殲纖蟾贍閃陝攝涉燮葉城姓宬性惺成星晟猩珹盛省筬"
  ],
  [
    "e1a1",
    "聖聲腥誠醒世勢歲洗稅笹細說貰召嘯塑宵小少巢所掃搔昭梳沼消溯瀟炤燒甦疏疎瘙笑篠簫素紹蔬蕭蘇訴逍遡邵銷韶騷俗屬束涑粟續謖贖速孫巽損蓀遜飡率宋悚松淞訟誦送頌刷殺灑碎鎖衰釗修受嗽囚垂壽嫂守岫峀帥愁"
  ],
  [
    "e2a1",
    "戍手授搜收數樹殊水洙漱燧狩獸琇璲瘦睡秀穗竪粹綏綬繡羞脩茱蒐蓚藪袖誰讐輸遂邃酬銖銹隋隧隨雖需須首髓鬚叔塾夙孰宿淑潚熟琡璹肅菽巡徇循恂旬栒楯橓殉洵淳珣盾瞬筍純脣舜荀蓴蕣詢諄醇錞順馴戌術述鉥崇崧"
  ],
  [
    "e3a1",
    "嵩瑟膝蝨濕拾習褶襲丞乘僧勝升承昇繩蠅陞侍匙嘶始媤尸屎屍市弑恃施是時枾柴猜矢示翅蒔蓍視試詩諡豕豺埴寔式息拭植殖湜熄篒蝕識軾食飾伸侁信呻娠宸愼新晨燼申神紳腎臣莘薪藎蜃訊身辛辰迅失室實悉審尋心沁"
  ],
  [
    "e4a1",
    "沈深瀋甚芯諶什十拾雙氏亞俄兒啞娥峨我牙芽莪蛾衙訝阿雅餓鴉鵝堊岳嶽幄惡愕握樂渥鄂鍔顎鰐齷安岸按晏案眼雁鞍顔鮟斡謁軋閼唵岩巖庵暗癌菴闇壓押狎鴨仰央怏昻殃秧鴦厓哀埃崖愛曖涯碍艾隘靄厄扼掖液縊腋額"
  ],
  [
    "e5a1",
    "櫻罌鶯鸚也倻冶夜惹揶椰爺耶若野弱掠略約若葯蒻藥躍亮佯兩凉壤孃恙揚攘敭暘梁楊樣洋瀁煬痒瘍禳穰糧羊良襄諒讓釀陽量養圄御於漁瘀禦語馭魚齬億憶抑檍臆偃堰彦焉言諺孼蘖俺儼嚴奄掩淹嶪業円予余勵呂女如廬"
  ],
  [
    "e6a1",
    "旅歟汝濾璵礖礪與艅茹輿轝閭餘驪麗黎亦力域役易曆歷疫繹譯轢逆驛嚥堧姸娟宴年延憐戀捐挻撚椽沇沿涎涓淵演漣烟然煙煉燃燕璉硏硯秊筵緣練縯聯衍軟輦蓮連鉛鍊鳶列劣咽悅涅烈熱裂說閱厭廉念捻染殮炎焰琰艶苒"
  ],
  [
    "e7a1",
    "簾閻髥鹽曄獵燁葉令囹塋寧嶺嶸影怜映暎楹榮永泳渶潁濚瀛瀯煐營獰玲瑛瑩瓔盈穎纓羚聆英詠迎鈴鍈零霙靈領乂倪例刈叡曳汭濊猊睿穢芮藝蘂禮裔詣譽豫醴銳隸霓預五伍俉傲午吾吳嗚塢墺奧娛寤悟惡懊敖旿晤梧汚澳"
  ],
  [
    "e8a1",
    "烏熬獒筽蜈誤鰲鼇屋沃獄玉鈺溫瑥瘟穩縕蘊兀壅擁瓮甕癰翁邕雍饔渦瓦窩窪臥蛙蝸訛婉完宛梡椀浣玩琓琬碗緩翫脘腕莞豌阮頑曰往旺枉汪王倭娃歪矮外嵬巍猥畏了僚僥凹堯夭妖姚寥寮尿嶢拗搖撓擾料曜樂橈燎燿瑤療"
  ],
  [
    "e9a1",
    "窈窯繇繞耀腰蓼蟯要謠遙遼邀饒慾欲浴縟褥辱俑傭冗勇埇墉容庸慂榕涌湧溶熔瑢用甬聳茸蓉踊鎔鏞龍于佑偶優又友右宇寓尤愚憂旴牛玗瑀盂祐禑禹紆羽芋藕虞迂遇郵釪隅雨雩勖彧旭昱栯煜稶郁頊云暈橒殞澐熉耘芸蕓"
  ],
  [
    "eaa1",
    "運隕雲韻蔚鬱亐熊雄元原員圓園垣媛嫄寃怨愿援沅洹湲源爰猿瑗苑袁轅遠阮院願鴛月越鉞位偉僞危圍委威尉慰暐渭爲瑋緯胃萎葦蔿蝟衛褘謂違韋魏乳侑儒兪劉唯喩孺宥幼幽庾悠惟愈愉揄攸有杻柔柚柳楡楢油洧流游溜"
  ],
  [
    "eba1",
    "濡猶猷琉瑜由留癒硫紐維臾萸裕誘諛諭踰蹂遊逾遺酉釉鍮類六堉戮毓肉育陸倫允奫尹崙淪潤玧胤贇輪鈗閏律慄栗率聿戎瀜絨融隆垠恩慇殷誾銀隱乙吟淫蔭陰音飮揖泣邑凝應膺鷹依倚儀宜意懿擬椅毅疑矣義艤薏蟻衣誼"
  ],
  [
    "eca1",
    "議醫二以伊利吏夷姨履已弛彛怡易李梨泥爾珥理異痍痢移罹而耳肄苡荑裏裡貽貳邇里離飴餌匿溺瀷益翊翌翼謚人仁刃印吝咽因姻寅引忍湮燐璘絪茵藺蚓認隣靭靷鱗麟一佚佾壹日溢逸鎰馹任壬妊姙恁林淋稔臨荏賃入卄"
  ],
  [
    "eda1",
    "立笠粒仍剩孕芿仔刺咨姉姿子字孜恣慈滋炙煮玆瓷疵磁紫者自茨蔗藉諮資雌作勺嚼斫昨灼炸爵綽芍酌雀鵲孱棧殘潺盞岑暫潛箴簪蠶雜丈仗匠場墻壯奬將帳庄張掌暲杖樟檣欌漿牆狀獐璋章粧腸臟臧莊葬蔣薔藏裝贓醬長"
  ],
  [
    "eea1",
    "障再哉在宰才材栽梓渽滓災縡裁財載齋齎爭箏諍錚佇低儲咀姐底抵杵楮樗沮渚狙猪疽箸紵苧菹著藷詛貯躇這邸雎齟勣吊嫡寂摘敵滴狄炙的積笛籍績翟荻謫賊赤跡蹟迪迹適鏑佃佺傳全典前剪塡塼奠專展廛悛戰栓殿氈澱"
  ],
  [
    "efa1",
    "煎琠田甸畑癲筌箋箭篆纏詮輾轉鈿銓錢鐫電顚顫餞切截折浙癤竊節絶占岾店漸点粘霑鮎點接摺蝶丁井亭停偵呈姃定幀庭廷征情挺政整旌晶晸柾楨檉正汀淀淨渟湞瀞炡玎珽町睛碇禎程穽精綎艇訂諪貞鄭酊釘鉦鋌錠霆靖"
  ],
  [
    "f0a1",
    "靜頂鼎制劑啼堤帝弟悌提梯濟祭第臍薺製諸蹄醍除際霽題齊俎兆凋助嘲弔彫措操早晁曺曹朝條棗槽漕潮照燥爪璪眺祖祚租稠窕粗糟組繰肇藻蚤詔調趙躁造遭釣阻雕鳥族簇足鏃存尊卒拙猝倧宗從悰慫棕淙琮種終綜縱腫"
  ],
  [
    "f1a1",
    "踪踵鍾鐘佐坐左座挫罪主住侏做姝胄呪周嗾奏宙州廚晝朱柱株注洲湊澍炷珠疇籌紂紬綢舟蛛註誅走躊輳週酎酒鑄駐竹粥俊儁准埈寯峻晙樽浚準濬焌畯竣蠢逡遵雋駿茁中仲衆重卽櫛楫汁葺增憎曾拯烝甑症繒蒸證贈之只"
  ],
  [
    "f2a1",
    "咫地址志持指摯支旨智枝枳止池沚漬知砥祉祗紙肢脂至芝芷蜘誌識贄趾遲直稙稷織職唇嗔塵振搢晉晋桭榛殄津溱珍瑨璡畛疹盡眞瞋秦縉縝臻蔯袗診賑軫辰進鎭陣陳震侄叱姪嫉帙桎瓆疾秩窒膣蛭質跌迭斟朕什執潗緝輯"
  ],
  [
    "f3a1",
    "鏶集徵懲澄且侘借叉嗟嵯差次此磋箚茶蹉車遮捉搾着窄錯鑿齪撰澯燦璨瓚竄簒纂粲纘讚贊鑽餐饌刹察擦札紮僭參塹慘慙懺斬站讒讖倉倡創唱娼廠彰愴敞昌昶暢槍滄漲猖瘡窓脹艙菖蒼債埰寀寨彩採砦綵菜蔡采釵冊柵策"
  ],
  [
    "f4a1",
    "責凄妻悽處倜刺剔尺慽戚拓擲斥滌瘠脊蹠陟隻仟千喘天川擅泉淺玔穿舛薦賤踐遷釧闡阡韆凸哲喆徹撤澈綴輟轍鐵僉尖沾添甛瞻簽籤詹諂堞妾帖捷牒疊睫諜貼輒廳晴淸聽菁請靑鯖切剃替涕滯締諦逮遞體初剿哨憔抄招梢"
  ],
  [
    "f5a1",
    "椒楚樵炒焦硝礁礎秒稍肖艸苕草蕉貂超酢醋醮促囑燭矗蜀觸寸忖村邨叢塚寵悤憁摠總聰蔥銃撮催崔最墜抽推椎楸樞湫皺秋芻萩諏趨追鄒酋醜錐錘鎚雛騶鰍丑畜祝竺筑築縮蓄蹙蹴軸逐春椿瑃出朮黜充忠沖蟲衝衷悴膵萃"
  ],
  [
    "f6a1",
    "贅取吹嘴娶就炊翠聚脆臭趣醉驟鷲側仄厠惻測層侈値嗤峙幟恥梔治淄熾痔痴癡稚穉緇緻置致蚩輜雉馳齒則勅飭親七柒漆侵寢枕沈浸琛砧針鍼蟄秤稱快他咤唾墮妥惰打拖朶楕舵陀馱駝倬卓啄坼度托拓擢晫柝濁濯琢琸託"
  ],
  [
    "f7a1",
    "鐸呑嘆坦彈憚歎灘炭綻誕奪脫探眈耽貪塔搭榻宕帑湯糖蕩兌台太怠態殆汰泰笞胎苔跆邰颱宅擇澤撑攄兎吐土討慟桶洞痛筒統通堆槌腿褪退頹偸套妬投透鬪慝特闖坡婆巴把播擺杷波派爬琶破罷芭跛頗判坂板版瓣販辦鈑"
  ],
  [
    "f8a1",
    "阪八叭捌佩唄悖敗沛浿牌狽稗覇貝彭澎烹膨愎便偏扁片篇編翩遍鞭騙貶坪平枰萍評吠嬖幣廢弊斃肺蔽閉陛佈包匍匏咆哺圃布怖抛抱捕暴泡浦疱砲胞脯苞葡蒲袍褒逋鋪飽鮑幅暴曝瀑爆輻俵剽彪慓杓標漂瓢票表豹飇飄驃"
  ],
  [
    "f9a1",
    "品稟楓諷豊風馮彼披疲皮被避陂匹弼必泌珌畢疋筆苾馝乏逼下何厦夏廈昰河瑕荷蝦賀遐霞鰕壑學虐謔鶴寒恨悍旱汗漢澣瀚罕翰閑閒限韓割轄函含咸啣喊檻涵緘艦銜陷鹹合哈盒蛤閤闔陜亢伉姮嫦巷恒抗杭桁沆港缸肛航"
  ],
  [
    "faa1",
    "行降項亥偕咳垓奚孩害懈楷海瀣蟹解該諧邂駭骸劾核倖幸杏荇行享向嚮珦鄕響餉饗香噓墟虛許憲櫶獻軒歇險驗奕爀赫革俔峴弦懸晛泫炫玄玹現眩睍絃絢縣舷衒見賢鉉顯孑穴血頁嫌俠協夾峽挾浹狹脅脇莢鋏頰亨兄刑型"
  ],
  [
    "fba1",
    "形泂滎瀅灐炯熒珩瑩荊螢衡逈邢鎣馨兮彗惠慧暳蕙蹊醯鞋乎互呼壕壺好岵弧戶扈昊晧毫浩淏湖滸澔濠濩灝狐琥瑚瓠皓祜糊縞胡芦葫蒿虎號蝴護豪鎬頀顥惑或酷婚昏混渾琿魂忽惚笏哄弘汞泓洪烘紅虹訌鴻化和嬅樺火畵"
  ],
  [
    "fca1",
    "禍禾花華話譁貨靴廓擴攫確碻穫丸喚奐宦幻患換歡晥桓渙煥環紈還驩鰥活滑猾豁闊凰幌徨恍惶愰慌晃晄榥況湟滉潢煌璜皇篁簧荒蝗遑隍黃匯回廻徊恢悔懷晦會檜淮澮灰獪繪膾茴蛔誨賄劃獲宖橫鐄哮嚆孝效斅曉梟涍淆"
  ],
  [
    "fda1",
    "爻肴酵驍侯候厚后吼喉嗅帿後朽煦珝逅勛勳塤壎焄熏燻薰訓暈薨喧暄煊萱卉喙毁彙徽揮暉煇諱輝麾休携烋畦虧恤譎鷸兇凶匈洶胸黑昕欣炘痕吃屹紇訖欠欽歆吸恰洽翕興僖凞喜噫囍姬嬉希憙憘戱晞曦熙熹熺犧禧稀羲詰"
  ]
], o1 = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  default: a1
}), s1 = [
  [
    "0",
    "\0",
    127
  ],
  [
    "a140",
    "　，、。．‧；：？！︰…‥﹐﹑﹒·﹔﹕﹖﹗｜–︱—︳╴︴﹏（）︵︶｛｝︷︸〔〕︹︺【】︻︼《》︽︾〈〉︿﹀「」﹁﹂『』﹃﹄﹙﹚"
  ],
  [
    "a1a1",
    "﹛﹜﹝﹞‘’“”〝〞‵′＃＆＊※§〃○●△▲◎☆★◇◆□■▽▼㊣℅¯￣＿ˍ﹉﹊﹍﹎﹋﹌﹟﹠﹡＋－×÷±√＜＞＝≦≧≠∞≒≡﹢",
    4,
    "～∩∪⊥∠∟⊿㏒㏑∫∮∵∴♀♂⊕⊙↑↓←→↖↗↙↘∥∣／"
  ],
  [
    "a240",
    "＼∕﹨＄￥〒￠￡％＠℃℉﹩﹪﹫㏕㎜㎝㎞㏎㎡㎎㎏㏄°兙兛兞兝兡兣嗧瓩糎▁",
    7,
    "▏▎▍▌▋▊▉┼┴┬┤├▔─│▕┌┐└┘╭"
  ],
  [
    "a2a1",
    "╮╰╯═╞╪╡◢◣◥◤╱╲╳０",
    9,
    "Ⅰ",
    9,
    "〡",
    8,
    "十卄卅Ａ",
    25,
    "ａ",
    21
  ],
  [
    "a340",
    "ｗｘｙｚΑ",
    16,
    "Σ",
    6,
    "α",
    16,
    "σ",
    6,
    "ㄅ",
    10
  ],
  [
    "a3a1",
    "ㄐ",
    25,
    "˙ˉˊˇˋ"
  ],
  [
    "a3e1",
    "€"
  ],
  [
    "a440",
    "一乙丁七乃九了二人儿入八几刀刁力匕十卜又三下丈上丫丸凡久么也乞于亡兀刃勺千叉口土士夕大女子孑孓寸小尢尸山川工己已巳巾干廾弋弓才"
  ],
  [
    "a4a1",
    "丑丐不中丰丹之尹予云井互五亢仁什仃仆仇仍今介仄元允內六兮公冗凶分切刈勻勾勿化匹午升卅卞厄友及反壬天夫太夭孔少尤尺屯巴幻廿弔引心戈戶手扎支文斗斤方日曰月木欠止歹毋比毛氏水火爪父爻片牙牛犬王丙"
  ],
  [
    "a540",
    "世丕且丘主乍乏乎以付仔仕他仗代令仙仞充兄冉冊冬凹出凸刊加功包匆北匝仟半卉卡占卯卮去可古右召叮叩叨叼司叵叫另只史叱台句叭叻四囚外"
  ],
  [
    "a5a1",
    "央失奴奶孕它尼巨巧左市布平幼弁弘弗必戊打扔扒扑斥旦朮本未末札正母民氐永汁汀氾犯玄玉瓜瓦甘生用甩田由甲申疋白皮皿目矛矢石示禾穴立丞丟乒乓乩亙交亦亥仿伉伙伊伕伍伐休伏仲件任仰仳份企伋光兇兆先全"
  ],
  [
    "a640",
    "共再冰列刑划刎刖劣匈匡匠印危吉吏同吊吐吁吋各向名合吃后吆吒因回囝圳地在圭圬圯圩夙多夷夸妄奸妃好她如妁字存宇守宅安寺尖屹州帆并年"
  ],
  [
    "a6a1",
    "式弛忙忖戎戌戍成扣扛托收早旨旬旭曲曳有朽朴朱朵次此死氖汝汗汙江池汐汕污汛汍汎灰牟牝百竹米糸缶羊羽老考而耒耳聿肉肋肌臣自至臼舌舛舟艮色艾虫血行衣西阡串亨位住佇佗佞伴佛何估佐佑伽伺伸佃佔似但佣"
  ],
  [
    "a740",
    "作你伯低伶余佝佈佚兌克免兵冶冷別判利刪刨劫助努劬匣即卵吝吭吞吾否呎吧呆呃吳呈呂君吩告吹吻吸吮吵吶吠吼呀吱含吟听囪困囤囫坊坑址坍"
  ],
  [
    "a7a1",
    "均坎圾坐坏圻壯夾妝妒妨妞妣妙妖妍妤妓妊妥孝孜孚孛完宋宏尬局屁尿尾岐岑岔岌巫希序庇床廷弄弟彤形彷役忘忌志忍忱快忸忪戒我抄抗抖技扶抉扭把扼找批扳抒扯折扮投抓抑抆改攻攸旱更束李杏材村杜杖杞杉杆杠"
  ],
  [
    "a840",
    "杓杗步每求汞沙沁沈沉沅沛汪決沐汰沌汨沖沒汽沃汲汾汴沆汶沍沔沘沂灶灼災灸牢牡牠狄狂玖甬甫男甸皂盯矣私秀禿究系罕肖肓肝肘肛肚育良芒"
  ],
  [
    "a8a1",
    "芋芍見角言谷豆豕貝赤走足身車辛辰迂迆迅迄巡邑邢邪邦那酉釆里防阮阱阪阬並乖乳事些亞享京佯依侍佳使佬供例來侃佰併侈佩佻侖佾侏侑佺兔兒兕兩具其典冽函刻券刷刺到刮制剁劾劻卒協卓卑卦卷卸卹取叔受味呵"
  ],
  [
    "a940",
    "咖呸咕咀呻呷咄咒咆呼咐呱呶和咚呢周咋命咎固垃坷坪坩坡坦坤坼夜奉奇奈奄奔妾妻委妹妮姑姆姐姍始姓姊妯妳姒姅孟孤季宗定官宜宙宛尚屈居"
  ],
  [
    "a9a1",
    "屆岷岡岸岩岫岱岳帘帚帖帕帛帑幸庚店府底庖延弦弧弩往征彿彼忝忠忽念忿怏怔怯怵怖怪怕怡性怩怫怛或戕房戾所承拉拌拄抿拂抹拒招披拓拔拋拈抨抽押拐拙拇拍抵拚抱拘拖拗拆抬拎放斧於旺昔易昌昆昂明昀昏昕昊"
  ],
  [
    "aa40",
    "昇服朋杭枋枕東果杳杷枇枝林杯杰板枉松析杵枚枓杼杪杲欣武歧歿氓氛泣注泳沱泌泥河沽沾沼波沫法泓沸泄油況沮泗泅泱沿治泡泛泊沬泯泜泖泠"
  ],
  [
    "aaa1",
    "炕炎炒炊炙爬爭爸版牧物狀狎狙狗狐玩玨玟玫玥甽疝疙疚的盂盲直知矽社祀祁秉秈空穹竺糾罔羌羋者肺肥肢肱股肫肩肴肪肯臥臾舍芳芝芙芭芽芟芹花芬芥芯芸芣芰芾芷虎虱初表軋迎返近邵邸邱邶采金長門阜陀阿阻附"
  ],
  [
    "ab40",
    "陂隹雨青非亟亭亮信侵侯便俠俑俏保促侶俘俟俊俗侮俐俄係俚俎俞侷兗冒冑冠剎剃削前剌剋則勇勉勃勁匍南卻厚叛咬哀咨哎哉咸咦咳哇哂咽咪品"
  ],
  [
    "aba1",
    "哄哈咯咫咱咻咩咧咿囿垂型垠垣垢城垮垓奕契奏奎奐姜姘姿姣姨娃姥姪姚姦威姻孩宣宦室客宥封屎屏屍屋峙峒巷帝帥帟幽庠度建弈弭彥很待徊律徇後徉怒思怠急怎怨恍恰恨恢恆恃恬恫恪恤扁拜挖按拼拭持拮拽指拱拷"
  ],
  [
    "ac40",
    "拯括拾拴挑挂政故斫施既春昭映昧是星昨昱昤曷柿染柱柔某柬架枯柵柩柯柄柑枴柚查枸柏柞柳枰柙柢柝柒歪殃殆段毒毗氟泉洋洲洪流津洌洱洞洗"
  ],
  [
    "aca1",
    "活洽派洶洛泵洹洧洸洩洮洵洎洫炫為炳炬炯炭炸炮炤爰牲牯牴狩狠狡玷珊玻玲珍珀玳甚甭畏界畎畋疫疤疥疢疣癸皆皇皈盈盆盃盅省盹相眉看盾盼眇矜砂研砌砍祆祉祈祇禹禺科秒秋穿突竿竽籽紂紅紀紉紇約紆缸美羿耄"
  ],
  [
    "ad40",
    "耐耍耑耶胖胥胚胃胄背胡胛胎胞胤胝致舢苧范茅苣苛苦茄若茂茉苒苗英茁苜苔苑苞苓苟苯茆虐虹虻虺衍衫要觔計訂訃貞負赴赳趴軍軌述迦迢迪迥"
  ],
  [
    "ada1",
    "迭迫迤迨郊郎郁郃酋酊重閂限陋陌降面革韋韭音頁風飛食首香乘亳倌倍倣俯倦倥俸倩倖倆值借倚倒們俺倀倔倨俱倡個候倘俳修倭倪俾倫倉兼冤冥冢凍凌准凋剖剜剔剛剝匪卿原厝叟哨唐唁唷哼哥哲唆哺唔哩哭員唉哮哪"
  ],
  [
    "ae40",
    "哦唧唇哽唏圃圄埂埔埋埃堉夏套奘奚娑娘娜娟娛娓姬娠娣娩娥娌娉孫屘宰害家宴宮宵容宸射屑展屐峭峽峻峪峨峰島崁峴差席師庫庭座弱徒徑徐恙"
  ],
  [
    "aea1",
    "恣恥恐恕恭恩息悄悟悚悍悔悌悅悖扇拳挈拿捎挾振捕捂捆捏捉挺捐挽挪挫挨捍捌效敉料旁旅時晉晏晃晒晌晅晁書朔朕朗校核案框桓根桂桔栩梳栗桌桑栽柴桐桀格桃株桅栓栘桁殊殉殷氣氧氨氦氤泰浪涕消涇浦浸海浙涓"
  ],
  [
    "af40",
    "浬涉浮浚浴浩涌涊浹涅浥涔烊烘烤烙烈烏爹特狼狹狽狸狷玆班琉珮珠珪珞畔畝畜畚留疾病症疲疳疽疼疹痂疸皋皰益盍盎眩真眠眨矩砰砧砸砝破砷"
  ],
  [
    "afa1",
    "砥砭砠砟砲祕祐祠祟祖神祝祗祚秤秣秧租秦秩秘窄窈站笆笑粉紡紗紋紊素索純紐紕級紜納紙紛缺罟羔翅翁耆耘耕耙耗耽耿胱脂胰脅胭胴脆胸胳脈能脊胼胯臭臬舀舐航舫舨般芻茫荒荔荊茸荐草茵茴荏茲茹茶茗荀茱茨荃"
  ],
  [
    "b040",
    "虔蚊蚪蚓蚤蚩蚌蚣蚜衰衷袁袂衽衹記訐討訌訕訊託訓訖訏訑豈豺豹財貢起躬軒軔軏辱送逆迷退迺迴逃追逅迸邕郡郝郢酒配酌釘針釗釜釙閃院陣陡"
  ],
  [
    "b0a1",
    "陛陝除陘陞隻飢馬骨高鬥鬲鬼乾偺偽停假偃偌做偉健偶偎偕偵側偷偏倏偯偭兜冕凰剪副勒務勘動匐匏匙匿區匾參曼商啪啦啄啞啡啃啊唱啖問啕唯啤唸售啜唬啣唳啁啗圈國圉域堅堊堆埠埤基堂堵執培夠奢娶婁婉婦婪婀"
  ],
  [
    "b140",
    "娼婢婚婆婊孰寇寅寄寂宿密尉專將屠屜屝崇崆崎崛崖崢崑崩崔崙崤崧崗巢常帶帳帷康庸庶庵庾張強彗彬彩彫得徙從徘御徠徜恿患悉悠您惋悴惦悽"
  ],
  [
    "b1a1",
    "情悻悵惜悼惘惕惆惟悸惚惇戚戛扈掠控捲掖探接捷捧掘措捱掩掉掃掛捫推掄授掙採掬排掏掀捻捩捨捺敝敖救教敗啟敏敘敕敔斜斛斬族旋旌旎晝晚晤晨晦晞曹勗望梁梯梢梓梵桿桶梱梧梗械梃棄梭梆梅梔條梨梟梡梂欲殺"
  ],
  [
    "b240",
    "毫毬氫涎涼淳淙液淡淌淤添淺清淇淋涯淑涮淞淹涸混淵淅淒渚涵淚淫淘淪深淮淨淆淄涪淬涿淦烹焉焊烽烯爽牽犁猜猛猖猓猙率琅琊球理現琍瓠瓶"
  ],
  [
    "b2a1",
    "瓷甜產略畦畢異疏痔痕疵痊痍皎盔盒盛眷眾眼眶眸眺硫硃硎祥票祭移窒窕笠笨笛第符笙笞笮粒粗粕絆絃統紮紹紼絀細紳組累終紲紱缽羞羚翌翎習耜聊聆脯脖脣脫脩脰脤舂舵舷舶船莎莞莘荸莢莖莽莫莒莊莓莉莠荷荻荼"
  ],
  [
    "b340",
    "莆莧處彪蛇蛀蚶蛄蚵蛆蛋蚱蚯蛉術袞袈被袒袖袍袋覓規訪訝訣訥許設訟訛訢豉豚販責貫貨貪貧赧赦趾趺軛軟這逍通逗連速逝逐逕逞造透逢逖逛途"
  ],
  [
    "b3a1",
    "部郭都酗野釵釦釣釧釭釩閉陪陵陳陸陰陴陶陷陬雀雪雩章竟頂頃魚鳥鹵鹿麥麻傢傍傅備傑傀傖傘傚最凱割剴創剩勞勝勛博厥啻喀喧啼喊喝喘喂喜喪喔喇喋喃喳單喟唾喲喚喻喬喱啾喉喫喙圍堯堪場堤堰報堡堝堠壹壺奠"
  ],
  [
    "b440",
    "婷媚婿媒媛媧孳孱寒富寓寐尊尋就嵌嵐崴嵇巽幅帽幀幃幾廊廁廂廄弼彭復循徨惑惡悲悶惠愜愣惺愕惰惻惴慨惱愎惶愉愀愒戟扉掣掌描揀揩揉揆揍"
  ],
  [
    "b4a1",
    "插揣提握揖揭揮捶援揪換摒揚揹敞敦敢散斑斐斯普晰晴晶景暑智晾晷曾替期朝棺棕棠棘棗椅棟棵森棧棹棒棲棣棋棍植椒椎棉棚楮棻款欺欽殘殖殼毯氮氯氬港游湔渡渲湧湊渠渥渣減湛湘渤湖湮渭渦湯渴湍渺測湃渝渾滋"
  ],
  [
    "b540",
    "溉渙湎湣湄湲湩湟焙焚焦焰無然煮焜牌犄犀猶猥猴猩琺琪琳琢琥琵琶琴琯琛琦琨甥甦畫番痢痛痣痙痘痞痠登發皖皓皴盜睏短硝硬硯稍稈程稅稀窘"
  ],
  [
    "b5a1",
    "窗窖童竣等策筆筐筒答筍筋筏筑粟粥絞結絨絕紫絮絲絡給絢絰絳善翔翕耋聒肅腕腔腋腑腎脹腆脾腌腓腴舒舜菩萃菸萍菠菅萋菁華菱菴著萊菰萌菌菽菲菊萸萎萄菜萇菔菟虛蛟蛙蛭蛔蛛蛤蛐蛞街裁裂袱覃視註詠評詞証詁"
  ],
  [
    "b640",
    "詔詛詐詆訴診訶詖象貂貯貼貳貽賁費賀貴買貶貿貸越超趁跎距跋跚跑跌跛跆軻軸軼辜逮逵週逸進逶鄂郵鄉郾酣酥量鈔鈕鈣鈉鈞鈍鈐鈇鈑閔閏開閑"
  ],
  [
    "b6a1",
    "間閒閎隊階隋陽隅隆隍陲隄雁雅雄集雇雯雲韌項順須飧飪飯飩飲飭馮馭黃黍黑亂傭債傲傳僅傾催傷傻傯僇剿剷剽募勦勤勢勣匯嗟嗨嗓嗦嗎嗜嗇嗑嗣嗤嗯嗚嗡嗅嗆嗥嗉園圓塞塑塘塗塚塔填塌塭塊塢塒塋奧嫁嫉嫌媾媽媼"
  ],
  [
    "b740",
    "媳嫂媲嵩嵯幌幹廉廈弒彙徬微愚意慈感想愛惹愁愈慎慌慄慍愾愴愧愍愆愷戡戢搓搾搞搪搭搽搬搏搜搔損搶搖搗搆敬斟新暗暉暇暈暖暄暘暍會榔業"
  ],
  [
    "b7a1",
    "楚楷楠楔極椰概楊楨楫楞楓楹榆楝楣楛歇歲毀殿毓毽溢溯滓溶滂源溝滇滅溥溘溼溺溫滑準溜滄滔溪溧溴煎煙煩煤煉照煜煬煦煌煥煞煆煨煖爺牒猷獅猿猾瑯瑚瑕瑟瑞瑁琿瑙瑛瑜當畸瘀痰瘁痲痱痺痿痴痳盞盟睛睫睦睞督"
  ],
  [
    "b840",
    "睹睪睬睜睥睨睢矮碎碰碗碘碌碉硼碑碓硿祺祿禁萬禽稜稚稠稔稟稞窟窠筷節筠筮筧粱粳粵經絹綑綁綏絛置罩罪署義羨群聖聘肆肄腱腰腸腥腮腳腫"
  ],
  [
    "b8a1",
    "腹腺腦舅艇蒂葷落萱葵葦葫葉葬葛萼萵葡董葩葭葆虞虜號蛹蜓蜈蜇蜀蛾蛻蜂蜃蜆蜊衙裟裔裙補裘裝裡裊裕裒覜解詫該詳試詩詰誇詼詣誠話誅詭詢詮詬詹詻訾詨豢貊貉賊資賈賄貲賃賂賅跡跟跨路跳跺跪跤跦躲較載軾輊"
  ],
  [
    "b940",
    "辟農運遊道遂達逼違遐遇遏過遍遑逾遁鄒鄗酬酪酩釉鈷鉗鈸鈽鉀鈾鉛鉋鉤鉑鈴鉉鉍鉅鈹鈿鉚閘隘隔隕雍雋雉雊雷電雹零靖靴靶預頑頓頊頒頌飼飴"
  ],
  [
    "b9a1",
    "飽飾馳馱馴髡鳩麂鼎鼓鼠僧僮僥僖僭僚僕像僑僱僎僩兢凳劃劂匱厭嗾嘀嘛嘗嗽嘔嘆嘉嘍嘎嗷嘖嘟嘈嘐嗶團圖塵塾境墓墊塹墅塽壽夥夢夤奪奩嫡嫦嫩嫗嫖嫘嫣孵寞寧寡寥實寨寢寤察對屢嶄嶇幛幣幕幗幔廓廖弊彆彰徹慇"
  ],
  [
    "ba40",
    "愿態慷慢慣慟慚慘慵截撇摘摔撤摸摟摺摑摧搴摭摻敲斡旗旖暢暨暝榜榨榕槁榮槓構榛榷榻榫榴槐槍榭槌榦槃榣歉歌氳漳演滾漓滴漩漾漠漬漏漂漢"
  ],
  [
    "baa1",
    "滿滯漆漱漸漲漣漕漫漯澈漪滬漁滲滌滷熔熙煽熊熄熒爾犒犖獄獐瑤瑣瑪瑰瑭甄疑瘧瘍瘋瘉瘓盡監瞄睽睿睡磁碟碧碳碩碣禎福禍種稱窪窩竭端管箕箋筵算箝箔箏箸箇箄粹粽精綻綰綜綽綾綠緊綴網綱綺綢綿綵綸維緒緇綬"
  ],
  [
    "bb40",
    "罰翠翡翟聞聚肇腐膀膏膈膊腿膂臧臺與舔舞艋蓉蒿蓆蓄蒙蒞蒲蒜蓋蒸蓀蓓蒐蒼蓑蓊蜿蜜蜻蜢蜥蜴蜘蝕蜷蜩裳褂裴裹裸製裨褚裯誦誌語誣認誡誓誤"
  ],
  [
    "bba1",
    "說誥誨誘誑誚誧豪貍貌賓賑賒赫趙趕跼輔輒輕輓辣遠遘遜遣遙遞遢遝遛鄙鄘鄞酵酸酷酴鉸銀銅銘銖鉻銓銜銨鉼銑閡閨閩閣閥閤隙障際雌雒需靼鞅韶頗領颯颱餃餅餌餉駁骯骰髦魁魂鳴鳶鳳麼鼻齊億儀僻僵價儂儈儉儅凜"
  ],
  [
    "bc40",
    "劇劈劉劍劊勰厲嘮嘻嘹嘲嘿嘴嘩噓噎噗噴嘶嘯嘰墀墟增墳墜墮墩墦奭嬉嫻嬋嫵嬌嬈寮寬審寫層履嶝嶔幢幟幡廢廚廟廝廣廠彈影德徵慶慧慮慝慕憂"
  ],
  [
    "bca1",
    "慼慰慫慾憧憐憫憎憬憚憤憔憮戮摩摯摹撞撲撈撐撰撥撓撕撩撒撮播撫撚撬撙撢撳敵敷數暮暫暴暱樣樟槨樁樞標槽模樓樊槳樂樅槭樑歐歎殤毅毆漿潼澄潑潦潔澆潭潛潸潮澎潺潰潤澗潘滕潯潠潟熟熬熱熨牖犛獎獗瑩璋璃"
  ],
  [
    "bd40",
    "瑾璀畿瘠瘩瘟瘤瘦瘡瘢皚皺盤瞎瞇瞌瞑瞋磋磅確磊碾磕碼磐稿稼穀稽稷稻窯窮箭箱範箴篆篇篁箠篌糊締練緯緻緘緬緝編緣線緞緩綞緙緲緹罵罷羯"
  ],
  [
    "bda1",
    "翩耦膛膜膝膠膚膘蔗蔽蔚蓮蔬蔭蔓蔑蔣蔡蔔蓬蔥蓿蔆螂蝴蝶蝠蝦蝸蝨蝙蝗蝌蝓衛衝褐複褒褓褕褊誼諒談諄誕請諸課諉諂調誰論諍誶誹諛豌豎豬賠賞賦賤賬賭賢賣賜質賡赭趟趣踫踐踝踢踏踩踟踡踞躺輝輛輟輩輦輪輜輞"
  ],
  [
    "be40",
    "輥適遮遨遭遷鄰鄭鄧鄱醇醉醋醃鋅銻銷鋪銬鋤鋁銳銼鋒鋇鋰銲閭閱霄霆震霉靠鞍鞋鞏頡頫頜颳養餓餒餘駝駐駟駛駑駕駒駙骷髮髯鬧魅魄魷魯鴆鴉"
  ],
  [
    "bea1",
    "鴃麩麾黎墨齒儒儘儔儐儕冀冪凝劑劓勳噙噫噹噩噤噸噪器噥噱噯噬噢噶壁墾壇壅奮嬝嬴學寰導彊憲憑憩憊懍憶憾懊懈戰擅擁擋撻撼據擄擇擂操撿擒擔撾整曆曉暹曄曇暸樽樸樺橙橫橘樹橄橢橡橋橇樵機橈歙歷氅濂澱澡"
  ],
  [
    "bf40",
    "濃澤濁澧澳激澹澶澦澠澴熾燉燐燒燈燕熹燎燙燜燃燄獨璜璣璘璟璞瓢甌甍瘴瘸瘺盧盥瞠瞞瞟瞥磨磚磬磧禦積穎穆穌穋窺篙簑築篤篛篡篩篦糕糖縊"
  ],
  [
    "bfa1",
    "縑縈縛縣縞縝縉縐罹羲翰翱翮耨膳膩膨臻興艘艙蕊蕙蕈蕨蕩蕃蕉蕭蕪蕞螃螟螞螢融衡褪褲褥褫褡親覦諦諺諫諱謀諜諧諮諾謁謂諷諭諳諶諼豫豭貓賴蹄踱踴蹂踹踵輻輯輸輳辨辦遵遴選遲遼遺鄴醒錠錶鋸錳錯錢鋼錫錄錚"
  ],
  [
    "c040",
    "錐錦錡錕錮錙閻隧隨險雕霎霑霖霍霓霏靛靜靦鞘頰頸頻頷頭頹頤餐館餞餛餡餚駭駢駱骸骼髻髭鬨鮑鴕鴣鴦鴨鴒鴛默黔龍龜優償儡儲勵嚎嚀嚐嚅嚇"
  ],
  [
    "c0a1",
    "嚏壕壓壑壎嬰嬪嬤孺尷屨嶼嶺嶽嶸幫彌徽應懂懇懦懋戲戴擎擊擘擠擰擦擬擱擢擭斂斃曙曖檀檔檄檢檜櫛檣橾檗檐檠歜殮毚氈濘濱濟濠濛濤濫濯澀濬濡濩濕濮濰燧營燮燦燥燭燬燴燠爵牆獰獲璩環璦璨癆療癌盪瞳瞪瞰瞬"
  ],
  [
    "c140",
    "瞧瞭矯磷磺磴磯礁禧禪穗窿簇簍篾篷簌篠糠糜糞糢糟糙糝縮績繆縷縲繃縫總縱繅繁縴縹繈縵縿縯罄翳翼聱聲聰聯聳臆臃膺臂臀膿膽臉膾臨舉艱薪"
  ],
  [
    "c1a1",
    "薄蕾薜薑薔薯薛薇薨薊虧蟀蟑螳蟒蟆螫螻螺蟈蟋褻褶襄褸褽覬謎謗謙講謊謠謝謄謐豁谿豳賺賽購賸賻趨蹉蹋蹈蹊轄輾轂轅輿避遽還邁邂邀鄹醣醞醜鍍鎂錨鍵鍊鍥鍋錘鍾鍬鍛鍰鍚鍔闊闋闌闈闆隱隸雖霜霞鞠韓顆颶餵騁"
  ],
  [
    "c240",
    "駿鮮鮫鮪鮭鴻鴿麋黏點黜黝黛鼾齋叢嚕嚮壙壘嬸彝懣戳擴擲擾攆擺擻擷斷曜朦檳檬櫃檻檸櫂檮檯歟歸殯瀉瀋濾瀆濺瀑瀏燻燼燾燸獷獵璧璿甕癖癘"
  ],
  [
    "c2a1",
    "癒瞽瞿瞻瞼礎禮穡穢穠竄竅簫簧簪簞簣簡糧織繕繞繚繡繒繙罈翹翻職聶臍臏舊藏薩藍藐藉薰薺薹薦蟯蟬蟲蟠覆覲觴謨謹謬謫豐贅蹙蹣蹦蹤蹟蹕軀轉轍邇邃邈醫醬釐鎔鎊鎖鎢鎳鎮鎬鎰鎘鎚鎗闔闖闐闕離雜雙雛雞霤鞣鞦"
  ],
  [
    "c340",
    "鞭韹額顏題顎顓颺餾餿餽餮馥騎髁鬃鬆魏魎魍鯊鯉鯽鯈鯀鵑鵝鵠黠鼕鼬儳嚥壞壟壢寵龐廬懲懷懶懵攀攏曠曝櫥櫝櫚櫓瀛瀟瀨瀚瀝瀕瀘爆爍牘犢獸"
  ],
  [
    "c3a1",
    "獺璽瓊瓣疇疆癟癡矇礙禱穫穩簾簿簸簽簷籀繫繭繹繩繪羅繳羶羹羸臘藩藝藪藕藤藥藷蟻蠅蠍蟹蟾襠襟襖襞譁譜識證譚譎譏譆譙贈贊蹼蹲躇蹶蹬蹺蹴轔轎辭邊邋醱醮鏡鏑鏟鏃鏈鏜鏝鏖鏢鏍鏘鏤鏗鏨關隴難霪霧靡韜韻類"
  ],
  [
    "c440",
    "願顛颼饅饉騖騙鬍鯨鯧鯖鯛鶉鵡鵲鵪鵬麒麗麓麴勸嚨嚷嚶嚴嚼壤孀孃孽寶巉懸懺攘攔攙曦朧櫬瀾瀰瀲爐獻瓏癢癥礦礪礬礫竇競籌籃籍糯糰辮繽繼"
  ],
  [
    "c4a1",
    "纂罌耀臚艦藻藹蘑藺蘆蘋蘇蘊蠔蠕襤覺觸議譬警譯譟譫贏贍躉躁躅躂醴釋鐘鐃鏽闡霰飄饒饑馨騫騰騷騵鰓鰍鹹麵黨鼯齟齣齡儷儸囁囀囂夔屬巍懼懾攝攜斕曩櫻欄櫺殲灌爛犧瓖瓔癩矓籐纏續羼蘗蘭蘚蠣蠢蠡蠟襪襬覽譴"
  ],
  [
    "c540",
    "護譽贓躊躍躋轟辯醺鐮鐳鐵鐺鐸鐲鐫闢霸霹露響顧顥饗驅驃驀騾髏魔魑鰭鰥鶯鶴鷂鶸麝黯鼙齜齦齧儼儻囈囊囉孿巔巒彎懿攤權歡灑灘玀瓤疊癮癬"
  ],
  [
    "c5a1",
    "禳籠籟聾聽臟襲襯觼讀贖贗躑躓轡酈鑄鑑鑒霽霾韃韁顫饕驕驍髒鬚鱉鰱鰾鰻鷓鷗鼴齬齪龔囌巖戀攣攫攪曬欐瓚竊籤籣籥纓纖纔臢蘸蘿蠱變邐邏鑣鑠鑤靨顯饜驚驛驗髓體髑鱔鱗鱖鷥麟黴囑壩攬灞癱癲矗罐羈蠶蠹衢讓讒"
  ],
  [
    "c640",
    "讖艷贛釀鑪靂靈靄韆顰驟鬢魘鱟鷹鷺鹼鹽鼇齷齲廳欖灣籬籮蠻觀躡釁鑲鑰顱饞髖鬣黌灤矚讚鑷韉驢驥纜讜躪釅鑽鑾鑼鱷鱸黷豔鑿鸚爨驪鬱鸛鸞籲"
  ],
  [
    "c940",
    "乂乜凵匚厂万丌乇亍囗兀屮彳丏冇与丮亓仂仉仈冘勼卬厹圠夃夬尐巿旡殳毌气爿丱丼仨仜仩仡仝仚刌匜卌圢圣夗夯宁宄尒尻屴屳帄庀庂忉戉扐氕"
  ],
  [
    "c9a1",
    "氶汃氿氻犮犰玊禸肊阞伎优伬仵伔仱伀价伈伝伂伅伢伓伄仴伒冱刓刉刐劦匢匟卍厊吇囡囟圮圪圴夼妀奼妅奻奾奷奿孖尕尥屼屺屻屾巟幵庄异弚彴忕忔忏扜扞扤扡扦扢扙扠扚扥旯旮朾朹朸朻机朿朼朳氘汆汒汜汏汊汔汋"
  ],
  [
    "ca40",
    "汌灱牞犴犵玎甪癿穵网艸艼芀艽艿虍襾邙邗邘邛邔阢阤阠阣佖伻佢佉体佤伾佧佒佟佁佘伭伳伿佡冏冹刜刞刡劭劮匉卣卲厎厏吰吷吪呔呅吙吜吥吘"
  ],
  [
    "caa1",
    "吽呏呁吨吤呇囮囧囥坁坅坌坉坋坒夆奀妦妘妠妗妎妢妐妏妧妡宎宒尨尪岍岏岈岋岉岒岊岆岓岕巠帊帎庋庉庌庈庍弅弝彸彶忒忑忐忭忨忮忳忡忤忣忺忯忷忻怀忴戺抃抌抎抏抔抇扱扻扺扰抁抈扷扽扲扴攷旰旴旳旲旵杅杇"
  ],
  [
    "cb40",
    "杙杕杌杈杝杍杚杋毐氙氚汸汧汫沄沋沏汱汯汩沚汭沇沕沜汦汳汥汻沎灴灺牣犿犽狃狆狁犺狅玕玗玓玔玒町甹疔疕皁礽耴肕肙肐肒肜芐芏芅芎芑芓"
  ],
  [
    "cba1",
    "芊芃芄豸迉辿邟邡邥邞邧邠阰阨阯阭丳侘佼侅佽侀侇佶佴侉侄佷佌侗佪侚佹侁佸侐侜侔侞侒侂侕佫佮冞冼冾刵刲刳剆刱劼匊匋匼厒厔咇呿咁咑咂咈呫呺呾呥呬呴呦咍呯呡呠咘呣呧呤囷囹坯坲坭坫坱坰坶垀坵坻坳坴坢"
  ],
  [
    "cc40",
    "坨坽夌奅妵妺姏姎妲姌姁妶妼姃姖妱妽姀姈妴姇孢孥宓宕屄屇岮岤岠岵岯岨岬岟岣岭岢岪岧岝岥岶岰岦帗帔帙弨弢弣弤彔徂彾彽忞忥怭怦怙怲怋"
  ],
  [
    "cca1",
    "怴怊怗怳怚怞怬怢怍怐怮怓怑怌怉怜戔戽抭抴拑抾抪抶拊抮抳抯抻抩抰抸攽斨斻昉旼昄昒昈旻昃昋昍昅旽昑昐曶朊枅杬枎枒杶杻枘枆构杴枍枌杺枟枑枙枃杽极杸杹枔欥殀歾毞氝沓泬泫泮泙沶泔沭泧沷泐泂沺泃泆泭泲"
  ],
  [
    "cd40",
    "泒泝沴沊沝沀泞泀洰泍泇沰泹泏泩泑炔炘炅炓炆炄炑炖炂炚炃牪狖狋狘狉狜狒狔狚狌狑玤玡玭玦玢玠玬玝瓝瓨甿畀甾疌疘皯盳盱盰盵矸矼矹矻矺"
  ],
  [
    "cda1",
    "矷祂礿秅穸穻竻籵糽耵肏肮肣肸肵肭舠芠苀芫芚芘芛芵芧芮芼芞芺芴芨芡芩苂芤苃芶芢虰虯虭虮豖迒迋迓迍迖迕迗邲邴邯邳邰阹阽阼阺陃俍俅俓侲俉俋俁俔俜俙侻侳俛俇俖侺俀侹俬剄剉勀勂匽卼厗厖厙厘咺咡咭咥哏"
  ],
  [
    "ce40",
    "哃茍咷咮哖咶哅哆咠呰咼咢咾呲哞咰垵垞垟垤垌垗垝垛垔垘垏垙垥垚垕壴复奓姡姞姮娀姱姝姺姽姼姶姤姲姷姛姩姳姵姠姾姴姭宨屌峐峘峌峗峋峛"
  ],
  [
    "cea1",
    "峞峚峉峇峊峖峓峔峏峈峆峎峟峸巹帡帢帣帠帤庰庤庢庛庣庥弇弮彖徆怷怹恔恲恞恅恓恇恉恛恌恀恂恟怤恄恘恦恮扂扃拏挍挋拵挎挃拫拹挏挌拸拶挀挓挔拺挕拻拰敁敃斪斿昶昡昲昵昜昦昢昳昫昺昝昴昹昮朏朐柁柲柈枺"
  ],
  [
    "cf40",
    "柜枻柸柘柀枷柅柫柤柟枵柍枳柷柶柮柣柂枹柎柧柰枲柼柆柭柌枮柦柛柺柉柊柃柪柋欨殂殄殶毖毘毠氠氡洨洴洭洟洼洿洒洊泚洳洄洙洺洚洑洀洝浂"
  ],
  [
    "cfa1",
    "洁洘洷洃洏浀洇洠洬洈洢洉洐炷炟炾炱炰炡炴炵炩牁牉牊牬牰牳牮狊狤狨狫狟狪狦狣玅珌珂珈珅玹玶玵玴珫玿珇玾珃珆玸珋瓬瓮甮畇畈疧疪癹盄眈眃眄眅眊盷盻盺矧矨砆砑砒砅砐砏砎砉砃砓祊祌祋祅祄秕种秏秖秎窀"
  ],
  [
    "d040",
    "穾竑笀笁籺籸籹籿粀粁紃紈紁罘羑羍羾耇耎耏耔耷胘胇胠胑胈胂胐胅胣胙胜胊胕胉胏胗胦胍臿舡芔苙苾苹茇苨茀苕茺苫苖苴苬苡苲苵茌苻苶苰苪"
  ],
  [
    "d0a1",
    "苤苠苺苳苭虷虴虼虳衁衎衧衪衩觓訄訇赲迣迡迮迠郱邽邿郕郅邾郇郋郈釔釓陔陏陑陓陊陎倞倅倇倓倢倰倛俵俴倳倷倬俶俷倗倜倠倧倵倯倱倎党冔冓凊凄凅凈凎剡剚剒剞剟剕剢勍匎厞唦哢唗唒哧哳哤唚哿唄唈哫唑唅哱"
  ],
  [
    "d140",
    "唊哻哷哸哠唎唃唋圁圂埌堲埕埒垺埆垽垼垸垶垿埇埐垹埁夎奊娙娖娭娮娕娏娗娊娞娳孬宧宭宬尃屖屔峬峿峮峱峷崀峹帩帨庨庮庪庬弳弰彧恝恚恧"
  ],
  [
    "d1a1",
    "恁悢悈悀悒悁悝悃悕悛悗悇悜悎戙扆拲挐捖挬捄捅挶捃揤挹捋捊挼挩捁挴捘捔捙挭捇挳捚捑挸捗捀捈敊敆旆旃旄旂晊晟晇晑朒朓栟栚桉栲栳栻桋桏栖栱栜栵栫栭栯桎桄栴栝栒栔栦栨栮桍栺栥栠欬欯欭欱欴歭肂殈毦毤"
  ],
  [
    "d240",
    "毨毣毢毧氥浺浣浤浶洍浡涒浘浢浭浯涑涍淯浿涆浞浧浠涗浰浼浟涂涘洯浨涋浾涀涄洖涃浻浽浵涐烜烓烑烝烋缹烢烗烒烞烠烔烍烅烆烇烚烎烡牂牸"
  ],
  [
    "d2a1",
    "牷牶猀狺狴狾狶狳狻猁珓珙珥珖玼珧珣珩珜珒珛珔珝珚珗珘珨瓞瓟瓴瓵甡畛畟疰痁疻痄痀疿疶疺皊盉眝眛眐眓眒眣眑眕眙眚眢眧砣砬砢砵砯砨砮砫砡砩砳砪砱祔祛祏祜祓祒祑秫秬秠秮秭秪秜秞秝窆窉窅窋窌窊窇竘笐"
  ],
  [
    "d340",
    "笄笓笅笏笈笊笎笉笒粄粑粊粌粈粍粅紞紝紑紎紘紖紓紟紒紏紌罜罡罞罠罝罛羖羒翃翂翀耖耾耹胺胲胹胵脁胻脀舁舯舥茳茭荄茙荑茥荖茿荁茦茜茢"
  ],
  [
    "d3a1",
    "荂荎茛茪茈茼荍茖茤茠茷茯茩荇荅荌荓茞茬荋茧荈虓虒蚢蚨蚖蚍蚑蚞蚇蚗蚆蚋蚚蚅蚥蚙蚡蚧蚕蚘蚎蚝蚐蚔衃衄衭衵衶衲袀衱衿衯袃衾衴衼訒豇豗豻貤貣赶赸趵趷趶軑軓迾迵适迿迻逄迼迶郖郠郙郚郣郟郥郘郛郗郜郤酐"
  ],
  [
    "d440",
    "酎酏釕釢釚陜陟隼飣髟鬯乿偰偪偡偞偠偓偋偝偲偈偍偁偛偊偢倕偅偟偩偫偣偤偆偀偮偳偗偑凐剫剭剬剮勖勓匭厜啵啶唼啍啐唴唪啑啢唶唵唰啒啅"
  ],
  [
    "d4a1",
    "唌唲啥啎唹啈唭唻啀啋圊圇埻堔埢埶埜埴堀埭埽堈埸堋埳埏堇埮埣埲埥埬埡堎埼堐埧堁堌埱埩埰堍堄奜婠婘婕婧婞娸娵婭婐婟婥婬婓婤婗婃婝婒婄婛婈媎娾婍娹婌婰婩婇婑婖婂婜孲孮寁寀屙崞崋崝崚崠崌崨崍崦崥崏"
  ],
  [
    "d540",
    "崰崒崣崟崮帾帴庱庴庹庲庳弶弸徛徖徟悊悐悆悾悰悺惓惔惏惤惙惝惈悱惛悷惊悿惃惍惀挲捥掊掂捽掽掞掭掝掗掫掎捯掇掐据掯捵掜捭掮捼掤挻掟"
  ],
  [
    "d5a1",
    "捸掅掁掑掍捰敓旍晥晡晛晙晜晢朘桹梇梐梜桭桮梮梫楖桯梣梬梩桵桴梲梏桷梒桼桫桲梪梀桱桾梛梖梋梠梉梤桸桻梑梌梊桽欶欳欷欸殑殏殍殎殌氪淀涫涴涳湴涬淩淢涷淶淔渀淈淠淟淖涾淥淜淝淛淴淊涽淭淰涺淕淂淏淉"
  ],
  [
    "d640",
    "淐淲淓淽淗淍淣涻烺焍烷焗烴焌烰焄烳焐烼烿焆焓焀烸烶焋焂焎牾牻牼牿猝猗猇猑猘猊猈狿猏猞玈珶珸珵琄琁珽琇琀珺珼珿琌琋珴琈畤畣痎痒痏"
  ],
  [
    "d6a1",
    "痋痌痑痐皏皉盓眹眯眭眱眲眴眳眽眥眻眵硈硒硉硍硊硌砦硅硐祤祧祩祪祣祫祡离秺秸秶秷窏窔窐笵筇笴笥笰笢笤笳笘笪笝笱笫笭笯笲笸笚笣粔粘粖粣紵紽紸紶紺絅紬紩絁絇紾紿絊紻紨罣羕羜羝羛翊翋翍翐翑翇翏翉耟"
  ],
  [
    "d740",
    "耞耛聇聃聈脘脥脙脛脭脟脬脞脡脕脧脝脢舑舸舳舺舴舲艴莐莣莨莍荺荳莤荴莏莁莕莙荵莔莩荽莃莌莝莛莪莋荾莥莯莈莗莰荿莦莇莮荶莚虙虖蚿蚷"
  ],
  [
    "d7a1",
    "蛂蛁蛅蚺蚰蛈蚹蚳蚸蛌蚴蚻蚼蛃蚽蚾衒袉袕袨袢袪袚袑袡袟袘袧袙袛袗袤袬袌袓袎覂觖觙觕訰訧訬訞谹谻豜豝豽貥赽赻赹趼跂趹趿跁軘軞軝軜軗軠軡逤逋逑逜逌逡郯郪郰郴郲郳郔郫郬郩酖酘酚酓酕釬釴釱釳釸釤釹釪"
  ],
  [
    "d840",
    "釫釷釨釮镺閆閈陼陭陫陱陯隿靪頄飥馗傛傕傔傞傋傣傃傌傎傝偨傜傒傂傇兟凔匒匑厤厧喑喨喥喭啷噅喢喓喈喏喵喁喣喒喤啽喌喦啿喕喡喎圌堩堷"
  ],
  [
    "d8a1",
    "堙堞堧堣堨埵塈堥堜堛堳堿堶堮堹堸堭堬堻奡媯媔媟婺媢媞婸媦婼媥媬媕媮娷媄媊媗媃媋媩婻婽媌媜媏媓媝寪寍寋寔寑寊寎尌尰崷嵃嵫嵁嵋崿崵嵑嵎嵕崳崺嵒崽崱嵙嵂崹嵉崸崼崲崶嵀嵅幄幁彘徦徥徫惉悹惌惢惎惄愔"
  ],
  [
    "d940",
    "惲愊愖愅惵愓惸惼惾惁愃愘愝愐惿愄愋扊掔掱掰揎揥揨揯揃撝揳揊揠揶揕揲揵摡揟掾揝揜揄揘揓揂揇揌揋揈揰揗揙攲敧敪敤敜敨敥斌斝斞斮旐旒"
  ],
  [
    "d9a1",
    "晼晬晻暀晱晹晪晲朁椌棓椄棜椪棬棪棱椏棖棷棫棤棶椓椐棳棡椇棌椈楰梴椑棯棆椔棸棐棽棼棨椋椊椗棎棈棝棞棦棴棑椆棔棩椕椥棇欹欻欿欼殔殗殙殕殽毰毲毳氰淼湆湇渟湉溈渼渽湅湢渫渿湁湝湳渜渳湋湀湑渻渃渮湞"
  ],
  [
    "da40",
    "湨湜湡渱渨湠湱湫渹渢渰湓湥渧湸湤湷湕湹湒湦渵渶湚焠焞焯烻焮焱焣焥焢焲焟焨焺焛牋牚犈犉犆犅犋猒猋猰猢猱猳猧猲猭猦猣猵猌琮琬琰琫琖"
  ],
  [
    "daa1",
    "琚琡琭琱琤琣琝琩琠琲瓻甯畯畬痧痚痡痦痝痟痤痗皕皒盚睆睇睄睍睅睊睎睋睌矞矬硠硤硥硜硭硱硪确硰硩硨硞硢祴祳祲祰稂稊稃稌稄窙竦竤筊笻筄筈筌筎筀筘筅粢粞粨粡絘絯絣絓絖絧絪絏絭絜絫絒絔絩絑絟絎缾缿罥"
  ],
  [
    "db40",
    "罦羢羠羡翗聑聏聐胾胔腃腊腒腏腇脽腍脺臦臮臷臸臹舄舼舽舿艵茻菏菹萣菀菨萒菧菤菼菶萐菆菈菫菣莿萁菝菥菘菿菡菋菎菖菵菉萉萏菞萑萆菂菳"
  ],
  [
    "dba1",
    "菕菺菇菑菪萓菃菬菮菄菻菗菢萛菛菾蛘蛢蛦蛓蛣蛚蛪蛝蛫蛜蛬蛩蛗蛨蛑衈衖衕袺裗袹袸裀袾袶袼袷袽袲褁裉覕覘覗觝觚觛詎詍訹詙詀詗詘詄詅詒詈詑詊詌詏豟貁貀貺貾貰貹貵趄趀趉跘跓跍跇跖跜跏跕跙跈跗跅軯軷軺"
  ],
  [
    "dc40",
    "軹軦軮軥軵軧軨軶軫軱軬軴軩逭逴逯鄆鄬鄄郿郼鄈郹郻鄁鄀鄇鄅鄃酡酤酟酢酠鈁鈊鈥鈃鈚鈦鈏鈌鈀鈒釿釽鈆鈄鈧鈂鈜鈤鈙鈗鈅鈖镻閍閌閐隇陾隈"
  ],
  [
    "dca1",
    "隉隃隀雂雈雃雱雰靬靰靮頇颩飫鳦黹亃亄亶傽傿僆傮僄僊傴僈僂傰僁傺傱僋僉傶傸凗剺剸剻剼嗃嗛嗌嗐嗋嗊嗝嗀嗔嗄嗩喿嗒喍嗏嗕嗢嗖嗈嗲嗍嗙嗂圔塓塨塤塏塍塉塯塕塎塝塙塥塛堽塣塱壼嫇嫄嫋媺媸媱媵媰媿嫈媻嫆"
  ],
  [
    "dd40",
    "媷嫀嫊媴媶嫍媹媐寖寘寙尟尳嵱嵣嵊嵥嵲嵬嵞嵨嵧嵢巰幏幎幊幍幋廅廌廆廋廇彀徯徭惷慉慊愫慅愶愲愮慆愯慏愩慀戠酨戣戥戤揅揱揫搐搒搉搠搤"
  ],
  [
    "dda1",
    "搳摃搟搕搘搹搷搢搣搌搦搰搨摁搵搯搊搚摀搥搧搋揧搛搮搡搎敯斒旓暆暌暕暐暋暊暙暔晸朠楦楟椸楎楢楱椿楅楪椹楂楗楙楺楈楉椵楬椳椽楥棰楸椴楩楀楯楄楶楘楁楴楌椻楋椷楜楏楑椲楒椯楻椼歆歅歃歂歈歁殛嗀毻毼"
  ],
  [
    "de40",
    "毹毷毸溛滖滈溏滀溟溓溔溠溱溹滆滒溽滁溞滉溷溰滍溦滏溲溾滃滜滘溙溒溎溍溤溡溿溳滐滊溗溮溣煇煔煒煣煠煁煝煢煲煸煪煡煂煘煃煋煰煟煐煓"
  ],
  [
    "dea1",
    "煄煍煚牏犍犌犑犐犎猼獂猻猺獀獊獉瑄瑊瑋瑒瑑瑗瑀瑏瑐瑎瑂瑆瑍瑔瓡瓿瓾瓽甝畹畷榃痯瘏瘃痷痾痼痹痸瘐痻痶痭痵痽皙皵盝睕睟睠睒睖睚睩睧睔睙睭矠碇碚碔碏碄碕碅碆碡碃硹碙碀碖硻祼禂祽祹稑稘稙稒稗稕稢稓"
  ],
  [
    "df40",
    "稛稐窣窢窞竫筦筤筭筴筩筲筥筳筱筰筡筸筶筣粲粴粯綈綆綀綍絿綅絺綎絻綃絼綌綔綄絽綒罭罫罧罨罬羦羥羧翛翜耡腤腠腷腜腩腛腢腲朡腞腶腧腯"
  ],
  [
    "dfa1",
    "腄腡舝艉艄艀艂艅蓱萿葖葶葹蒏蒍葥葑葀蒆葧萰葍葽葚葙葴葳葝蔇葞萷萺萴葺葃葸萲葅萩菙葋萯葂萭葟葰萹葎葌葒葯蓅蒎萻葇萶萳葨葾葄萫葠葔葮葐蜋蜄蛷蜌蛺蛖蛵蝍蛸蜎蜉蜁蛶蜍蜅裖裋裍裎裞裛裚裌裐覅覛觟觥觤"
  ],
  [
    "e040",
    "觡觠觢觜触詶誆詿詡訿詷誂誄詵誃誁詴詺谼豋豊豥豤豦貆貄貅賌赨赩趑趌趎趏趍趓趔趐趒跰跠跬跱跮跐跩跣跢跧跲跫跴輆軿輁輀輅輇輈輂輋遒逿"
  ],
  [
    "e0a1",
    "遄遉逽鄐鄍鄏鄑鄖鄔鄋鄎酮酯鉈鉒鈰鈺鉦鈳鉥鉞銃鈮鉊鉆鉭鉬鉏鉠鉧鉯鈶鉡鉰鈱鉔鉣鉐鉲鉎鉓鉌鉖鈲閟閜閞閛隒隓隑隗雎雺雽雸雵靳靷靸靲頏頍頎颬飶飹馯馲馰馵骭骫魛鳪鳭鳧麀黽僦僔僗僨僳僛僪僝僤僓僬僰僯僣僠"
  ],
  [
    "e140",
    "凘劀劁勩勫匰厬嘧嘕嘌嘒嗼嘏嘜嘁嘓嘂嗺嘝嘄嗿嗹墉塼墐墘墆墁塿塴墋塺墇墑墎塶墂墈塻墔墏壾奫嫜嫮嫥嫕嫪嫚嫭嫫嫳嫢嫠嫛嫬嫞嫝嫙嫨嫟孷寠"
  ],
  [
    "e1a1",
    "寣屣嶂嶀嵽嶆嵺嶁嵷嶊嶉嶈嵾嵼嶍嵹嵿幘幙幓廘廑廗廎廜廕廙廒廔彄彃彯徶愬愨慁慞慱慳慒慓慲慬憀慴慔慺慛慥愻慪慡慖戩戧戫搫摍摛摝摴摶摲摳摽摵摦撦摎撂摞摜摋摓摠摐摿搿摬摫摙摥摷敳斠暡暠暟朅朄朢榱榶槉"
  ],
  [
    "e240",
    "榠槎榖榰榬榼榑榙榎榧榍榩榾榯榿槄榽榤槔榹槊榚槏榳榓榪榡榞槙榗榐槂榵榥槆歊歍歋殞殟殠毃毄毾滎滵滱漃漥滸漷滻漮漉潎漙漚漧漘漻漒滭漊"
  ],
  [
    "e2a1",
    "漶潳滹滮漭潀漰漼漵滫漇漎潃漅滽滶漹漜滼漺漟漍漞漈漡熇熐熉熀熅熂熏煻熆熁熗牄牓犗犕犓獃獍獑獌瑢瑳瑱瑵瑲瑧瑮甀甂甃畽疐瘖瘈瘌瘕瘑瘊瘔皸瞁睼瞅瞂睮瞀睯睾瞃碲碪碴碭碨硾碫碞碥碠碬碢碤禘禊禋禖禕禔禓"
  ],
  [
    "e340",
    "禗禈禒禐稫穊稰稯稨稦窨窫窬竮箈箜箊箑箐箖箍箌箛箎箅箘劄箙箤箂粻粿粼粺綧綷緂綣綪緁緀緅綝緎緄緆緋緌綯綹綖綼綟綦綮綩綡緉罳翢翣翥翞"
  ],
  [
    "e3a1",
    "耤聝聜膉膆膃膇膍膌膋舕蒗蒤蒡蒟蒺蓎蓂蒬蒮蒫蒹蒴蓁蓍蒪蒚蒱蓐蒝蒧蒻蒢蒔蓇蓌蒛蒩蒯蒨蓖蒘蒶蓏蒠蓗蓔蓒蓛蒰蒑虡蜳蜣蜨蝫蝀蜮蜞蜡蜙蜛蝃蜬蝁蜾蝆蜠蜲蜪蜭蜼蜒蜺蜱蜵蝂蜦蜧蜸蜤蜚蜰蜑裷裧裱裲裺裾裮裼裶裻"
  ],
  [
    "e440",
    "裰裬裫覝覡覟覞觩觫觨誫誙誋誒誏誖谽豨豩賕賏賗趖踉踂跿踍跽踊踃踇踆踅跾踀踄輐輑輎輍鄣鄜鄠鄢鄟鄝鄚鄤鄡鄛酺酲酹酳銥銤鉶銛鉺銠銔銪銍"
  ],
  [
    "e4a1",
    "銦銚銫鉹銗鉿銣鋮銎銂銕銢鉽銈銡銊銆銌銙銧鉾銇銩銝銋鈭隞隡雿靘靽靺靾鞃鞀鞂靻鞄鞁靿韎韍頖颭颮餂餀餇馝馜駃馹馻馺駂馽駇骱髣髧鬾鬿魠魡魟鳱鳲鳵麧僿儃儰僸儆儇僶僾儋儌僽儊劋劌勱勯噈噂噌嘵噁噊噉噆噘"
  ],
  [
    "e540",
    "噚噀嘳嘽嘬嘾嘸嘪嘺圚墫墝墱墠墣墯墬墥墡壿嫿嫴嫽嫷嫶嬃嫸嬂嫹嬁嬇嬅嬏屧嶙嶗嶟嶒嶢嶓嶕嶠嶜嶡嶚嶞幩幝幠幜緳廛廞廡彉徲憋憃慹憱憰憢憉"
  ],
  [
    "e5a1",
    "憛憓憯憭憟憒憪憡憍慦憳戭摮摰撖撠撅撗撜撏撋撊撌撣撟摨撱撘敶敺敹敻斲斳暵暰暩暲暷暪暯樀樆樗槥槸樕槱槤樠槿槬槢樛樝槾樧槲槮樔槷槧橀樈槦槻樍槼槫樉樄樘樥樏槶樦樇槴樖歑殥殣殢殦氁氀毿氂潁漦潾澇濆澒"
  ],
  [
    "e640",
    "澍澉澌潢潏澅潚澖潶潬澂潕潲潒潐潗澔澓潝漀潡潫潽潧澐潓澋潩潿澕潣潷潪潻熲熯熛熰熠熚熩熵熝熥熞熤熡熪熜熧熳犘犚獘獒獞獟獠獝獛獡獚獙"
  ],
  [
    "e6a1",
    "獢璇璉璊璆璁瑽璅璈瑼瑹甈甇畾瘥瘞瘙瘝瘜瘣瘚瘨瘛皜皝皞皛瞍瞏瞉瞈磍碻磏磌磑磎磔磈磃磄磉禚禡禠禜禢禛歶稹窲窴窳箷篋箾箬篎箯箹篊箵糅糈糌糋緷緛緪緧緗緡縃緺緦緶緱緰緮緟罶羬羰羭翭翫翪翬翦翨聤聧膣膟"
  ],
  [
    "e740",
    "膞膕膢膙膗舖艏艓艒艐艎艑蔤蔻蔏蔀蔩蔎蔉蔍蔟蔊蔧蔜蓻蔫蓺蔈蔌蓴蔪蓲蔕蓷蓫蓳蓼蔒蓪蓩蔖蓾蔨蔝蔮蔂蓽蔞蓶蔱蔦蓧蓨蓰蓯蓹蔘蔠蔰蔋蔙蔯虢"
  ],
  [
    "e7a1",
    "蝖蝣蝤蝷蟡蝳蝘蝔蝛蝒蝡蝚蝑蝞蝭蝪蝐蝎蝟蝝蝯蝬蝺蝮蝜蝥蝏蝻蝵蝢蝧蝩衚褅褌褔褋褗褘褙褆褖褑褎褉覢覤覣觭觰觬諏諆誸諓諑諔諕誻諗誾諀諅諘諃誺誽諙谾豍貏賥賟賙賨賚賝賧趠趜趡趛踠踣踥踤踮踕踛踖踑踙踦踧"
  ],
  [
    "e840",
    "踔踒踘踓踜踗踚輬輤輘輚輠輣輖輗遳遰遯遧遫鄯鄫鄩鄪鄲鄦鄮醅醆醊醁醂醄醀鋐鋃鋄鋀鋙銶鋏鋱鋟鋘鋩鋗鋝鋌鋯鋂鋨鋊鋈鋎鋦鋍鋕鋉鋠鋞鋧鋑鋓"
  ],
  [
    "e8a1",
    "銵鋡鋆銴镼閬閫閮閰隤隢雓霅霈霂靚鞊鞎鞈韐韏頞頝頦頩頨頠頛頧颲餈飺餑餔餖餗餕駜駍駏駓駔駎駉駖駘駋駗駌骳髬髫髳髲髱魆魃魧魴魱魦魶魵魰魨魤魬鳼鳺鳽鳿鳷鴇鴀鳹鳻鴈鴅鴄麃黓鼏鼐儜儓儗儚儑凞匴叡噰噠噮"
  ],
  [
    "e940",
    "噳噦噣噭噲噞噷圜圛壈墽壉墿墺壂墼壆嬗嬙嬛嬡嬔嬓嬐嬖嬨嬚嬠嬞寯嶬嶱嶩嶧嶵嶰嶮嶪嶨嶲嶭嶯嶴幧幨幦幯廩廧廦廨廥彋徼憝憨憖懅憴懆懁懌憺"
  ],
  [
    "e9a1",
    "憿憸憌擗擖擐擏擉撽撉擃擛擳擙攳敿敼斢曈暾曀曊曋曏暽暻暺曌朣樴橦橉橧樲橨樾橝橭橶橛橑樨橚樻樿橁橪橤橐橏橔橯橩橠樼橞橖橕橍橎橆歕歔歖殧殪殫毈毇氄氃氆澭濋澣濇澼濎濈潞濄澽澞濊澨瀄澥澮澺澬澪濏澿澸"
  ],
  [
    "ea40",
    "澢濉澫濍澯澲澰燅燂熿熸燖燀燁燋燔燊燇燏熽燘熼燆燚燛犝犞獩獦獧獬獥獫獪瑿璚璠璔璒璕璡甋疀瘯瘭瘱瘽瘳瘼瘵瘲瘰皻盦瞚瞝瞡瞜瞛瞢瞣瞕瞙"
  ],
  [
    "eaa1",
    "瞗磝磩磥磪磞磣磛磡磢磭磟磠禤穄穈穇窶窸窵窱窷篞篣篧篝篕篥篚篨篹篔篪篢篜篫篘篟糒糔糗糐糑縒縡縗縌縟縠縓縎縜縕縚縢縋縏縖縍縔縥縤罃罻罼罺羱翯耪耩聬膱膦膮膹膵膫膰膬膴膲膷膧臲艕艖艗蕖蕅蕫蕍蕓蕡蕘"
  ],
  [
    "eb40",
    "蕀蕆蕤蕁蕢蕄蕑蕇蕣蔾蕛蕱蕎蕮蕵蕕蕧蕠薌蕦蕝蕔蕥蕬虣虥虤螛螏螗螓螒螈螁螖螘蝹螇螣螅螐螑螝螄螔螜螚螉褞褦褰褭褮褧褱褢褩褣褯褬褟觱諠"
  ],
  [
    "eba1",
    "諢諲諴諵諝謔諤諟諰諈諞諡諨諿諯諻貑貒貐賵賮賱賰賳赬赮趥趧踳踾踸蹀蹅踶踼踽蹁踰踿躽輶輮輵輲輹輷輴遶遹遻邆郺鄳鄵鄶醓醐醑醍醏錧錞錈錟錆錏鍺錸錼錛錣錒錁鍆錭錎錍鋋錝鋺錥錓鋹鋷錴錂錤鋿錩錹錵錪錔錌"
  ],
  [
    "ec40",
    "錋鋾錉錀鋻錖閼闍閾閹閺閶閿閵閽隩雔霋霒霐鞙鞗鞔韰韸頵頯頲餤餟餧餩馞駮駬駥駤駰駣駪駩駧骹骿骴骻髶髺髹髷鬳鮀鮅鮇魼魾魻鮂鮓鮒鮐魺鮕"
  ],
  [
    "eca1",
    "魽鮈鴥鴗鴠鴞鴔鴩鴝鴘鴢鴐鴙鴟麈麆麇麮麭黕黖黺鼒鼽儦儥儢儤儠儩勴嚓嚌嚍嚆嚄嚃噾嚂噿嚁壖壔壏壒嬭嬥嬲嬣嬬嬧嬦嬯嬮孻寱寲嶷幬幪徾徻懃憵憼懧懠懥懤懨懞擯擩擣擫擤擨斁斀斶旚曒檍檖檁檥檉檟檛檡檞檇檓檎"
  ],
  [
    "ed40",
    "檕檃檨檤檑橿檦檚檅檌檒歛殭氉濌澩濴濔濣濜濭濧濦濞濲濝濢濨燡燱燨燲燤燰燢獳獮獯璗璲璫璐璪璭璱璥璯甐甑甒甏疄癃癈癉癇皤盩瞵瞫瞲瞷瞶"
  ],
  [
    "eda1",
    "瞴瞱瞨矰磳磽礂磻磼磲礅磹磾礄禫禨穜穛穖穘穔穚窾竀竁簅簏篲簀篿篻簎篴簋篳簂簉簃簁篸篽簆篰篱簐簊糨縭縼繂縳顈縸縪繉繀繇縩繌縰縻縶繄縺罅罿罾罽翴翲耬膻臄臌臊臅臇膼臩艛艚艜薃薀薏薧薕薠薋薣蕻薤薚薞"
  ],
  [
    "ee40",
    "蕷蕼薉薡蕺蕸蕗薎薖薆薍薙薝薁薢薂薈薅蕹蕶薘薐薟虨螾螪螭蟅螰螬螹螵螼螮蟉蟃蟂蟌螷螯蟄蟊螴螶螿螸螽蟞螲褵褳褼褾襁襒褷襂覭覯覮觲觳謞"
  ],
  [
    "eea1",
    "謘謖謑謅謋謢謏謒謕謇謍謈謆謜謓謚豏豰豲豱豯貕貔賹赯蹎蹍蹓蹐蹌蹇轃轀邅遾鄸醚醢醛醙醟醡醝醠鎡鎃鎯鍤鍖鍇鍼鍘鍜鍶鍉鍐鍑鍠鍭鎏鍌鍪鍹鍗鍕鍒鍏鍱鍷鍻鍡鍞鍣鍧鎀鍎鍙闇闀闉闃闅閷隮隰隬霠霟霘霝霙鞚鞡鞜"
  ],
  [
    "ef40",
    "鞞鞝韕韔韱顁顄顊顉顅顃餥餫餬餪餳餲餯餭餱餰馘馣馡騂駺駴駷駹駸駶駻駽駾駼騃骾髾髽鬁髼魈鮚鮨鮞鮛鮦鮡鮥鮤鮆鮢鮠鮯鴳鵁鵧鴶鴮鴯鴱鴸鴰"
  ],
  [
    "efa1",
    "鵅鵂鵃鴾鴷鵀鴽翵鴭麊麉麍麰黈黚黻黿鼤鼣鼢齔龠儱儭儮嚘嚜嚗嚚嚝嚙奰嬼屩屪巀幭幮懘懟懭懮懱懪懰懫懖懩擿攄擽擸攁攃擼斔旛曚曛曘櫅檹檽櫡櫆檺檶檷櫇檴檭歞毉氋瀇瀌瀍瀁瀅瀔瀎濿瀀濻瀦濼濷瀊爁燿燹爃燽獶"
  ],
  [
    "f040",
    "璸瓀璵瓁璾璶璻瓂甔甓癜癤癙癐癓癗癚皦皽盬矂瞺磿礌礓礔礉礐礒礑禭禬穟簜簩簙簠簟簭簝簦簨簢簥簰繜繐繖繣繘繢繟繑繠繗繓羵羳翷翸聵臑臒"
  ],
  [
    "f0a1",
    "臐艟艞薴藆藀藃藂薳薵薽藇藄薿藋藎藈藅薱薶藒蘤薸薷薾虩蟧蟦蟢蟛蟫蟪蟥蟟蟳蟤蟔蟜蟓蟭蟘蟣螤蟗蟙蠁蟴蟨蟝襓襋襏襌襆襐襑襉謪謧謣謳謰謵譇謯謼謾謱謥謷謦謶謮謤謻謽謺豂豵貙貘貗賾贄贂贀蹜蹢蹠蹗蹖蹞蹥蹧"
  ],
  [
    "f140",
    "蹛蹚蹡蹝蹩蹔轆轇轈轋鄨鄺鄻鄾醨醥醧醯醪鎵鎌鎒鎷鎛鎝鎉鎧鎎鎪鎞鎦鎕鎈鎙鎟鎍鎱鎑鎲鎤鎨鎴鎣鎥闒闓闑隳雗雚巂雟雘雝霣霢霥鞬鞮鞨鞫鞤鞪"
  ],
  [
    "f1a1",
    "鞢鞥韗韙韖韘韺顐顑顒颸饁餼餺騏騋騉騍騄騑騊騅騇騆髀髜鬈鬄鬅鬩鬵魊魌魋鯇鯆鯃鮿鯁鮵鮸鯓鮶鯄鮹鮽鵜鵓鵏鵊鵛鵋鵙鵖鵌鵗鵒鵔鵟鵘鵚麎麌黟鼁鼀鼖鼥鼫鼪鼩鼨齌齕儴儵劖勷厴嚫嚭嚦嚧嚪嚬壚壝壛夒嬽嬾嬿巃幰"
  ],
  [
    "f240",
    "徿懻攇攐攍攉攌攎斄旞旝曞櫧櫠櫌櫑櫙櫋櫟櫜櫐櫫櫏櫍櫞歠殰氌瀙瀧瀠瀖瀫瀡瀢瀣瀩瀗瀤瀜瀪爌爊爇爂爅犥犦犤犣犡瓋瓅璷瓃甖癠矉矊矄矱礝礛"
  ],
  [
    "f2a1",
    "礡礜礗礞禰穧穨簳簼簹簬簻糬糪繶繵繸繰繷繯繺繲繴繨罋罊羃羆羷翽翾聸臗臕艤艡艣藫藱藭藙藡藨藚藗藬藲藸藘藟藣藜藑藰藦藯藞藢蠀蟺蠃蟶蟷蠉蠌蠋蠆蟼蠈蟿蠊蠂襢襚襛襗襡襜襘襝襙覈覷覶觶譐譈譊譀譓譖譔譋譕"
  ],
  [
    "f340",
    "譑譂譒譗豃豷豶貚贆贇贉趬趪趭趫蹭蹸蹳蹪蹯蹻軂轒轑轏轐轓辴酀鄿醰醭鏞鏇鏏鏂鏚鏐鏹鏬鏌鏙鎩鏦鏊鏔鏮鏣鏕鏄鏎鏀鏒鏧镽闚闛雡霩霫霬霨霦"
  ],
  [
    "f3a1",
    "鞳鞷鞶韝韞韟顜顙顝顗颿颽颻颾饈饇饃馦馧騚騕騥騝騤騛騢騠騧騣騞騜騔髂鬋鬊鬎鬌鬷鯪鯫鯠鯞鯤鯦鯢鯰鯔鯗鯬鯜鯙鯥鯕鯡鯚鵷鶁鶊鶄鶈鵱鶀鵸鶆鶋鶌鵽鵫鵴鵵鵰鵩鶅鵳鵻鶂鵯鵹鵿鶇鵨麔麑黀黼鼭齀齁齍齖齗齘匷嚲"
  ],
  [
    "f440",
    "嚵嚳壣孅巆巇廮廯忀忁懹攗攖攕攓旟曨曣曤櫳櫰櫪櫨櫹櫱櫮櫯瀼瀵瀯瀷瀴瀱灂瀸瀿瀺瀹灀瀻瀳灁爓爔犨獽獼璺皫皪皾盭矌矎矏矍矲礥礣礧礨礤礩"
  ],
  [
    "f4a1",
    "禲穮穬穭竷籉籈籊籇籅糮繻繾纁纀羺翿聹臛臙舋艨艩蘢藿蘁藾蘛蘀藶蘄蘉蘅蘌藽蠙蠐蠑蠗蠓蠖襣襦覹觷譠譪譝譨譣譥譧譭趮躆躈躄轙轖轗轕轘轚邍酃酁醷醵醲醳鐋鐓鏻鐠鐏鐔鏾鐕鐐鐨鐙鐍鏵鐀鏷鐇鐎鐖鐒鏺鐉鏸鐊鏿"
  ],
  [
    "f540",
    "鏼鐌鏶鐑鐆闞闠闟霮霯鞹鞻韽韾顠顢顣顟飁飂饐饎饙饌饋饓騲騴騱騬騪騶騩騮騸騭髇髊髆鬐鬒鬑鰋鰈鯷鰅鰒鯸鱀鰇鰎鰆鰗鰔鰉鶟鶙鶤鶝鶒鶘鶐鶛"
  ],
  [
    "f5a1",
    "鶠鶔鶜鶪鶗鶡鶚鶢鶨鶞鶣鶿鶩鶖鶦鶧麙麛麚黥黤黧黦鼰鼮齛齠齞齝齙龑儺儹劘劗囃嚽嚾孈孇巋巏廱懽攛欂櫼欃櫸欀灃灄灊灈灉灅灆爝爚爙獾甗癪矐礭礱礯籔籓糲纊纇纈纋纆纍罍羻耰臝蘘蘪蘦蘟蘣蘜蘙蘧蘮蘡蘠蘩蘞蘥"
  ],
  [
    "f640",
    "蠩蠝蠛蠠蠤蠜蠫衊襭襩襮襫觺譹譸譅譺譻贐贔趯躎躌轞轛轝酆酄酅醹鐿鐻鐶鐩鐽鐼鐰鐹鐪鐷鐬鑀鐱闥闤闣霵霺鞿韡顤飉飆飀饘饖騹騽驆驄驂驁騺"
  ],
  [
    "f6a1",
    "騿髍鬕鬗鬘鬖鬺魒鰫鰝鰜鰬鰣鰨鰩鰤鰡鶷鶶鶼鷁鷇鷊鷏鶾鷅鷃鶻鶵鷎鶹鶺鶬鷈鶱鶭鷌鶳鷍鶲鹺麜黫黮黭鼛鼘鼚鼱齎齥齤龒亹囆囅囋奱孋孌巕巑廲攡攠攦攢欋欈欉氍灕灖灗灒爞爟犩獿瓘瓕瓙瓗癭皭礵禴穰穱籗籜籙籛籚"
  ],
  [
    "f740",
    "糴糱纑罏羇臞艫蘴蘵蘳蘬蘲蘶蠬蠨蠦蠪蠥襱覿覾觻譾讄讂讆讅譿贕躕躔躚躒躐躖躗轠轢酇鑌鑐鑊鑋鑏鑇鑅鑈鑉鑆霿韣顪顩飋饔饛驎驓驔驌驏驈驊"
  ],
  [
    "f7a1",
    "驉驒驐髐鬙鬫鬻魖魕鱆鱈鰿鱄鰹鰳鱁鰼鰷鰴鰲鰽鰶鷛鷒鷞鷚鷋鷐鷜鷑鷟鷩鷙鷘鷖鷵鷕鷝麶黰鼵鼳鼲齂齫龕龢儽劙壨壧奲孍巘蠯彏戁戃戄攩攥斖曫欑欒欏毊灛灚爢玂玁玃癰矔籧籦纕艬蘺虀蘹蘼蘱蘻蘾蠰蠲蠮蠳襶襴襳觾"
  ],
  [
    "f840",
    "讌讎讋讈豅贙躘轤轣醼鑢鑕鑝鑗鑞韄韅頀驖驙鬞鬟鬠鱒鱘鱐鱊鱍鱋鱕鱙鱌鱎鷻鷷鷯鷣鷫鷸鷤鷶鷡鷮鷦鷲鷰鷢鷬鷴鷳鷨鷭黂黐黲黳鼆鼜鼸鼷鼶齃齏"
  ],
  [
    "f8a1",
    "齱齰齮齯囓囍孎屭攭曭曮欓灟灡灝灠爣瓛瓥矕礸禷禶籪纗羉艭虃蠸蠷蠵衋讔讕躞躟躠躝醾醽釂鑫鑨鑩雥靆靃靇韇韥驞髕魙鱣鱧鱦鱢鱞鱠鸂鷾鸇鸃鸆鸅鸀鸁鸉鷿鷽鸄麠鼞齆齴齵齶囔攮斸欘欙欗欚灢爦犪矘矙礹籩籫糶纚"
  ],
  [
    "f940",
    "纘纛纙臠臡虆虇虈襹襺襼襻觿讘讙躥躤躣鑮鑭鑯鑱鑳靉顲饟鱨鱮鱭鸋鸍鸐鸏鸒鸑麡黵鼉齇齸齻齺齹圞灦籯蠼趲躦釃鑴鑸鑶鑵驠鱴鱳鱱鱵鸔鸓黶鼊"
  ],
  [
    "f9a1",
    "龤灨灥糷虪蠾蠽蠿讞貜躩軉靋顳顴飌饡馫驤驦驧鬤鸕鸗齈戇欞爧虌躨钂钀钁驩驨鬮鸙爩虋讟钃鱹麷癵驫鱺鸝灩灪麤齾齉龘碁銹裏墻恒粧嫺╔╦╗╠╬╣╚╩╝╒╤╕╞╪╡╘╧╛╓╥╖╟╫╢╙╨╜║═╭╮╰╯▓"
  ]
], u1 = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  default: s1
}), f1 = [
  [
    "8740",
    "䏰䰲䘃䖦䕸𧉧䵷䖳𧲱䳢𧳅㮕䜶䝄䱇䱀𤊿𣘗𧍒𦺋𧃒䱗𪍑䝏䗚䲅𧱬䴇䪤䚡𦬣爥𥩔𡩣𣸆𣽡晍囻"
  ],
  [
    "8767",
    "綕夝𨮹㷴霴𧯯寛𡵞媤㘥𩺰嫑宷峼杮薓𩥅瑡璝㡵𡵓𣚞𦀡㻬"
  ],
  [
    "87a1",
    "𥣞㫵竼龗𤅡𨤍𣇪𠪊𣉞䌊蒄龖鐯䤰蘓墖靊鈘秐稲晠権袝瑌篅枂稬剏遆㓦珄𥶹瓆鿇垳䤯呌䄱𣚎堘穲𧭥讏䚮𦺈䆁𥶙箮𢒼鿈𢓁𢓉𢓌鿉蔄𣖻䂴鿊䓡𪷿拁灮鿋"
  ],
  [
    "8840",
    "㇀",
    4,
    "𠄌㇅𠃑𠃍㇆㇇𠃋𡿨㇈𠃊㇉㇊㇋㇌𠄎㇍㇎ĀÁǍÀĒÉĚÈŌÓǑÒ࿿Ê̄Ế࿿Ê̌ỀÊāáǎàɑēéěèīíǐìōóǒòūúǔùǖǘǚ"
  ],
  [
    "88a1",
    "ǜü࿿ê̄ế࿿ê̌ềêɡ⏚⏛"
  ],
  [
    "8940",
    "𪎩𡅅"
  ],
  [
    "8943",
    "攊"
  ],
  [
    "8946",
    "丽滝鵎釟"
  ],
  [
    "894c",
    "𧜵撑会伨侨兖兴农凤务动医华发变团声处备夲头学实実岚庆总斉柾栄桥济炼电纤纬纺织经统缆缷艺苏药视设询车轧轮"
  ],
  [
    "89a1",
    "琑糼緍楆竉刧"
  ],
  [
    "89ab",
    "醌碸酞肼"
  ],
  [
    "89b0",
    "贋胶𠧧"
  ],
  [
    "89b5",
    "肟黇䳍鷉鸌䰾𩷶𧀎鸊𪄳㗁"
  ],
  [
    "89c1",
    "溚舾甙"
  ],
  [
    "89c5",
    "䤑马骏龙禇𨑬𡷊𠗐𢫦两亁亀亇亿仫伷㑌侽㹈倃傈㑽㒓㒥円夅凛凼刅争剹劐匧㗇厩㕑厰㕓参吣㕭㕲㚁咓咣咴咹哐哯唘唣唨㖘唿㖥㖿嗗㗅"
  ],
  [
    "8a40",
    "𧶄唥"
  ],
  [
    "8a43",
    "𠱂𠴕𥄫喐𢳆㧬𠍁蹆𤶸𩓥䁓𨂾睺𢰸㨴䟕𨅝𦧲𤷪擝𠵼𠾴𠳕𡃴撍蹾𠺖𠰋𠽤𢲩𨉖𤓓"
  ],
  [
    "8a64",
    "𠵆𩩍𨃩䟴𤺧𢳂骲㩧𩗴㿭㔆𥋇𩟔𧣈𢵄鵮頕"
  ],
  [
    "8a76",
    "䏙𦂥撴哣𢵌𢯊𡁷㧻𡁯"
  ],
  [
    "8aa1",
    "𦛚𦜖𧦠擪𥁒𠱃蹨𢆡𨭌𠜱"
  ],
  [
    "8aac",
    "䠋𠆩㿺塳𢶍"
  ],
  [
    "8ab2",
    "𤗈𠓼𦂗𠽌𠶖啹䂻䎺"
  ],
  [
    "8abb",
    "䪴𢩦𡂝膪飵𠶜捹㧾𢝵跀嚡摼㹃"
  ],
  [
    "8ac9",
    "𪘁𠸉𢫏𢳉"
  ],
  [
    "8ace",
    "𡃈𣧂㦒㨆𨊛㕸𥹉𢃇噒𠼱𢲲𩜠㒼氽𤸻"
  ],
  [
    "8adf",
    "𧕴𢺋𢈈𪙛𨳍𠹺𠰴𦠜羓𡃏𢠃𢤹㗻𥇣𠺌𠾍𠺪㾓𠼰𠵇𡅏𠹌"
  ],
  [
    "8af6",
    "𠺫𠮩𠵈𡃀𡄽㿹𢚖搲𠾭"
  ],
  [
    "8b40",
    "𣏴𧘹𢯎𠵾𠵿𢱑𢱕㨘𠺘𡃇𠼮𪘲𦭐𨳒𨶙𨳊閪哌苄喹"
  ],
  [
    "8b55",
    "𩻃鰦骶𧝞𢷮煀腭胬尜𦕲脴㞗卟𨂽醶𠻺𠸏𠹷𠻻㗝𤷫㘉𠳖嚯𢞵𡃉𠸐𠹸𡁸𡅈𨈇𡑕𠹹𤹐𢶤婔𡀝𡀞𡃵𡃶垜𠸑"
  ],
  [
    "8ba1",
    "𧚔𨋍𠾵𠹻𥅾㜃𠾶𡆀𥋘𪊽𤧚𡠺𤅷𨉼墙剨㘚𥜽箲孨䠀䬬鼧䧧鰟鮍𥭴𣄽嗻㗲嚉丨夂𡯁屮靑𠂆乛亻㔾尣彑忄㣺扌攵歺氵氺灬爫丬犭𤣩罒礻糹罓𦉪㓁"
  ],
  [
    "8bde",
    "𦍋耂肀𦘒𦥑卝衤见𧢲讠贝钅镸长门𨸏韦页风飞饣𩠐鱼鸟黄歯龜丷𠂇阝户钢"
  ],
  [
    "8c40",
    "倻淾𩱳龦㷉袏𤅎灷峵䬠𥇍㕙𥴰愢𨨲辧釶熑朙玺𣊁𪄇㲋𡦀䬐磤琂冮𨜏䀉橣𪊺䈣蘏𠩯稪𩥇𨫪靕灍匤𢁾鏴盙𨧣龧矝亣俰傼丯众龨吴綋墒壐𡶶庒庙忂𢜒斋"
  ],
  [
    "8ca1",
    "𣏹椙橃𣱣泿"
  ],
  [
    "8ca7",
    "爀𤔅玌㻛𤨓嬕璹讃𥲤𥚕窓篬糃繬苸薗龩袐龪躹龫迏蕟駠鈡龬𨶹𡐿䁱䊢娚"
  ],
  [
    "8cc9",
    "顨杫䉶圽"
  ],
  [
    "8cce",
    "藖𤥻芿𧄍䲁𦵴嵻𦬕𦾾龭龮宖龯曧繛湗秊㶈䓃𣉖𢞖䎚䔶"
  ],
  [
    "8ce6",
    "峕𣬚諹屸㴒𣕑嵸龲煗䕘𤃬𡸣䱷㥸㑊𠆤𦱁諌侴𠈹妿腬顖𩣺弻"
  ],
  [
    "8d40",
    "𠮟"
  ],
  [
    "8d42",
    "𢇁𨥭䄂䚻𩁹㼇龳𪆵䃸㟖䛷𦱆䅼𨚲𧏿䕭㣔𥒚䕡䔛䶉䱻䵶䗪㿈𤬏㙡䓞䒽䇭崾嵈嵖㷼㠏嶤嶹㠠㠸幂庽弥徃㤈㤔㤿㥍惗愽峥㦉憷憹懏㦸戬抐拥挘㧸嚱"
  ],
  [
    "8da1",
    "㨃揢揻搇摚㩋擀崕嘡龟㪗斆㪽旿晓㫲暒㬢朖㭂枤栀㭘桊梄㭲㭱㭻椉楃牜楤榟榅㮼槖㯝橥橴橱檂㯬檙㯲檫檵櫔櫶殁毁毪汵沪㳋洂洆洦涁㳯涤涱渕渘温溆𨧀溻滢滚齿滨滩漤漴㵆𣽁澁澾㵪㵵熷岙㶊瀬㶑灐灔灯灿炉𠌥䏁㗱𠻘"
  ],
  [
    "8e40",
    "𣻗垾𦻓焾𥟠㙎榢𨯩孴穉𥣡𩓙穥穽𥦬窻窰竂竃燑𦒍䇊竚竝竪䇯咲𥰁笋筕笩𥌎𥳾箢筯莜𥮴𦱿篐萡箒箸𥴠㶭𥱥蒒篺簆簵𥳁籄粃𤢂粦晽𤕸糉糇糦籴糳糵糎"
  ],
  [
    "8ea1",
    "繧䔝𦹄絝𦻖璍綉綫焵綳緒𤁗𦀩緤㴓緵𡟹緥𨍭縝𦄡𦅚繮纒䌫鑬縧罀罁罇礶𦋐駡羗𦍑羣𡙡𠁨䕜𣝦䔃𨌺翺𦒉者耈耝耨耯𪂇𦳃耻耼聡𢜔䦉𦘦𣷣𦛨朥肧𨩈脇脚墰𢛶汿𦒘𤾸擧𡒊舘𡡞橓𤩥𤪕䑺舩𠬍𦩒𣵾俹𡓽蓢荢𦬊𤦧𣔰𡝳𣷸芪椛芳䇛"
  ],
  [
    "8f40",
    "蕋苐茚𠸖𡞴㛁𣅽𣕚艻苢茘𣺋𦶣𦬅𦮗𣗎㶿茝嗬莅䔋𦶥莬菁菓㑾𦻔橗蕚㒖𦹂𢻯葘𥯤葱㷓䓤檧葊𣲵祘蒨𦮖𦹷𦹃蓞萏莑䒠蒓蓤𥲑䉀𥳀䕃蔴嫲𦺙䔧蕳䔖枿蘖"
  ],
  [
    "8fa1",
    "𨘥𨘻藁𧂈蘂𡖂𧃍䕫䕪蘨㙈𡢢号𧎚虾蝱𪃸蟮𢰧螱蟚蠏噡虬桖䘏衅衆𧗠𣶹𧗤衞袜䙛袴袵揁装睷𧜏覇覊覦覩覧覼𨨥觧𧤤𧪽誜瞓釾誐𧩙竩𧬺𣾏䜓𧬸煼謌謟𥐰𥕥謿譌譍誩𤩺讐讛誯𡛟䘕衏貛𧵔𧶏貫㜥𧵓賖𧶘𧶽贒贃𡤐賛灜贑𤳉㻐起"
  ],
  [
    "9040",
    "趩𨀂𡀔𤦊㭼𨆼𧄌竧躭躶軃鋔輙輭𨍥𨐒辥錃𪊟𠩐辳䤪𨧞𨔽𣶻廸𣉢迹𪀔𨚼𨔁𢌥㦀𦻗逷𨔼𧪾遡𨕬𨘋邨𨜓郄𨛦邮都酧㫰醩釄粬𨤳𡺉鈎沟鉁鉢𥖹銹𨫆𣲛𨬌𥗛"
  ],
  [
    "90a1",
    "𠴱錬鍫𨫡𨯫炏嫃𨫢𨫥䥥鉄𨯬𨰹𨯿鍳鑛躼閅閦鐦閠濶䊹𢙺𨛘𡉼𣸮䧟氜陻隖䅬隣𦻕懚隶磵𨫠隽双䦡𦲸𠉴𦐐𩂯𩃥𤫑𡤕𣌊霱虂霶䨏䔽䖅𤫩灵孁霛靜𩇕靗孊𩇫靟鐥僐𣂷𣂼鞉鞟鞱鞾韀韒韠𥑬韮琜𩐳響韵𩐝𧥺䫑頴頳顋顦㬎𧅵㵑𠘰𤅜"
  ],
  [
    "9140",
    "𥜆飊颷飈飇䫿𦴧𡛓喰飡飦飬鍸餹𤨩䭲𩡗𩤅駵騌騻騐驘𥜥㛄𩂱𩯕髠髢𩬅髴䰎鬔鬭𨘀倴鬴𦦨㣃𣁽魐魀𩴾婅𡡣鮎𤉋鰂鯿鰌𩹨鷔𩾷𪆒𪆫𪃡𪄣𪇟鵾鶃𪄴鸎梈"
  ],
  [
    "91a1",
    "鷄𢅛𪆓𪈠𡤻𪈳鴹𪂹𪊴麐麕麞麢䴴麪麯𤍤黁㭠㧥㴝伲㞾𨰫鼂鼈䮖鐤𦶢鼗鼖鼹嚟嚊齅馸𩂋韲葿齢齩竜龎爖䮾𤥵𤦻煷𤧸𤍈𤩑玞𨯚𡣺禟𨥾𨸶鍩鏳𨩄鋬鎁鏋𨥬𤒹爗㻫睲穃烐𤑳𤏸煾𡟯炣𡢾𣖙㻇𡢅𥐯𡟸㜢𡛻𡠹㛡𡝴𡣑𥽋㜣𡛀坛𤨥𡏾𡊨"
  ],
  [
    "9240",
    "𡏆𡒶蔃𣚦蔃葕𤦔𧅥𣸱𥕜𣻻𧁒䓴𣛮𩦝𦼦柹㜳㰕㷧塬𡤢栐䁗𣜿𤃡𤂋𤄏𦰡哋嚞𦚱嚒𠿟𠮨𠸍鏆𨬓鎜仸儫㠙𤐶亼𠑥𠍿佋侊𥙑婨𠆫𠏋㦙𠌊𠐔㐵伩𠋀𨺳𠉵諚𠈌亘"
  ],
  [
    "92a1",
    "働儍侢伃𤨎𣺊佂倮偬傁俌俥偘僼兙兛兝兞湶𣖕𣸹𣺿浲𡢄𣺉冨凃𠗠䓝𠒣𠒒𠒑赺𨪜𠜎剙劤𠡳勡鍮䙺熌𤎌𠰠𤦬𡃤槑𠸝瑹㻞璙琔瑖玘䮎𤪼𤂍叐㖄爏𤃉喴𠍅响𠯆圝鉝雴鍦埝垍坿㘾壋媙𨩆𡛺𡝯𡜐娬妸銏婾嫏娒𥥆𡧳𡡡𤊕㛵洅瑃娡𥺃"
  ],
  [
    "9340",
    "媁𨯗𠐓鏠璌𡌃焅䥲鐈𨧻鎽㞠尞岞幞幈𡦖𡥼𣫮廍孏𡤃𡤄㜁𡢠㛝𡛾㛓脪𨩇𡶺𣑲𨦨弌弎𡤧𡞫婫𡜻孄蘔𧗽衠恾𢡠𢘫忛㺸𢖯𢖾𩂈𦽳懀𠀾𠁆𢘛憙憘恵𢲛𢴇𤛔𩅍"
  ],
  [
    "93a1",
    "摱𤙥𢭪㨩𢬢𣑐𩣪𢹸挷𪑛撶挱揑𤧣𢵧护𢲡搻敫楲㯴𣂎𣊭𤦉𣊫唍𣋠𡣙𩐿曎𣊉𣆳㫠䆐𥖄𨬢𥖏𡛼𥕛𥐥磮𣄃𡠪𣈴㑤𣈏𣆂𤋉暎𦴤晫䮓昰𧡰𡷫晣𣋒𣋡昞𥡲㣑𣠺𣞼㮙𣞢𣏾瓐㮖枏𤘪梶栞㯄檾㡣𣟕𤒇樳橒櫉欅𡤒攑梘橌㯗橺歗𣿀𣲚鎠鋲𨯪𨫋"
  ],
  [
    "9440",
    "銉𨀞𨧜鑧涥漋𤧬浧𣽿㶏渄𤀼娽渊塇洤硂焻𤌚𤉶烱牐犇犔𤞏𤜥兹𤪤𠗫瑺𣻸𣙟𤩊𤤗𥿡㼆㺱𤫟𨰣𣼵悧㻳瓌琼鎇琷䒟𦷪䕑疃㽣𤳙𤴆㽘畕癳𪗆㬙瑨𨫌𤦫𤦎㫻"
  ],
  [
    "94a1",
    "㷍𤩎㻿𤧅𤣳釺圲鍂𨫣𡡤僟𥈡𥇧睸𣈲眎眏睻𤚗𣞁㩞𤣰琸璛㺿𤪺𤫇䃈𤪖𦆮錇𥖁砞碍碈磒珐祙𧝁𥛣䄎禛蒖禥樭𣻺稺秴䅮𡛦䄲鈵秱𠵌𤦌𠊙𣶺𡝮㖗啫㕰㚪𠇔𠰍竢婙𢛵𥪯𥪜娍𠉛磰娪𥯆竾䇹籝籭䈑𥮳𥺼𥺦糍𤧹𡞰粎籼粮檲緜縇緓罎𦉡"
  ],
  [
    "9540",
    "𦅜𧭈綗𥺂䉪𦭵𠤖柖𠁎𣗏埄𦐒𦏸𤥢翝笧𠠬𥫩𥵃笌𥸎駦虅驣樜𣐿㧢𤧷𦖭騟𦖠蒀𧄧𦳑䓪脷䐂胆脉腂𦞴飃𦩂艢艥𦩑葓𦶧蘐𧈛媆䅿𡡀嬫𡢡嫤𡣘蚠蜨𣶏蠭𧐢娂"
  ],
  [
    "95a1",
    "衮佅袇袿裦襥襍𥚃襔𧞅𧞄𨯵𨯙𨮜𨧹㺭蒣䛵䛏㟲訽訜𩑈彍鈫𤊄旔焩烄𡡅鵭貟賩𧷜妚矃姰䍮㛔踪躧𤰉輰轊䋴汘澻𢌡䢛潹溋𡟚鯩㚵𤤯邻邗啱䤆醻鐄𨩋䁢𨫼鐧𨰝𨰻蓥訫閙閧閗閖𨴴瑅㻂𤣿𤩂𤏪㻧𣈥随𨻧𨹦𨹥㻌𤧭𤩸𣿮琒瑫㻼靁𩂰"
  ],
  [
    "9640",
    "桇䨝𩂓𥟟靝鍨𨦉𨰦𨬯𦎾銺嬑譩䤼珹𤈛鞛靱餸𠼦巁𨯅𤪲頟𩓚鋶𩗗釥䓀𨭐𤩧𨭤飜𨩅㼀鈪䤥萔餻饍𧬆㷽馛䭯馪驜𨭥𥣈檏騡嫾騯𩣱䮐𩥈馼䮽䮗鍽塲𡌂堢𤦸"
  ],
  [
    "96a1",
    "𡓨硄𢜟𣶸棅㵽鑘㤧慐𢞁𢥫愇鱏鱓鱻鰵鰐魿鯏𩸭鮟𪇵𪃾鴡䲮𤄄鸘䲰鴌𪆴𪃭𪃳𩤯鶥蒽𦸒𦿟𦮂藼䔳𦶤𦺄𦷰萠藮𦸀𣟗𦁤秢𣖜𣙀䤭𤧞㵢鏛銾鍈𠊿碹鉷鑍俤㑀遤𥕝砽硔碶硋𡝗𣇉𤥁㚚佲濚濙瀞瀞吔𤆵垻壳垊鴖埗焴㒯𤆬燫𦱀𤾗嬨𡞵𨩉"
  ],
  [
    "9740",
    "愌嫎娋䊼𤒈㜬䭻𨧼鎻鎸𡣖𠼝葲𦳀𡐓𤋺𢰦𤏁妔𣶷𦝁綨𦅛𦂤𤦹𤦋𨧺鋥珢㻩璴𨭣𡢟㻡𤪳櫘珳珻㻖𤨾𤪔𡟙𤩦𠎧𡐤𤧥瑈𤤖炥𤥶銄珦鍟𠓾錱𨫎𨨖鎆𨯧𥗕䤵𨪂煫"
  ],
  [
    "97a1",
    "𤥃𠳿嚤𠘚𠯫𠲸唂秄𡟺緾𡛂𤩐𡡒䔮鐁㜊𨫀𤦭妰𡢿𡢃𧒄媡㛢𣵛㚰鉟婹𨪁𡡢鍴㳍𠪴䪖㦊僴㵩㵌𡎜煵䋻𨈘渏𩃤䓫浗𧹏灧沯㳖𣿭𣸭渂漌㵯𠏵畑㚼㓈䚀㻚䡱姄鉮䤾轁𨰜𦯀堒埈㛖𡑒烾𤍢𤩱𢿣𡊰𢎽梹楧𡎘𣓥𧯴𣛟𨪃𣟖𣏺𤲟樚𣚭𦲷萾䓟䓎"
  ],
  [
    "9840",
    "𦴦𦵑𦲂𦿞漗𧄉茽𡜺菭𦲀𧁓𡟛妉媂𡞳婡婱𡤅𤇼㜭姯𡜼㛇熎鎐暚𤊥婮娫𤊓樫𣻹𧜶𤑛𤋊焝𤉙𨧡侰𦴨峂𤓎𧹍𤎽樌𤉖𡌄炦焳𤏩㶥泟勇𤩏繥姫崯㷳彜𤩝𡟟綤萦"
  ],
  [
    "98a1",
    "咅𣫺𣌀𠈔坾𠣕𠘙㿥𡾞𪊶瀃𩅛嵰玏糓𨩙𩐠俈翧狍猐𧫴猸猹𥛶獁獈㺩𧬘遬燵𤣲珡臶㻊県㻑沢国琙琞琟㻢㻰㻴㻺瓓㼎㽓畂畭畲疍㽼痈痜㿀癍㿗癴㿜発𤽜熈嘣覀塩䀝睃䀹条䁅㗛瞘䁪䁯属瞾矋売砘点砜䂨砹硇硑硦葈𥔵礳栃礲䄃"
  ],
  [
    "9940",
    "䄉禑禙辻稆込䅧窑䆲窼艹䇄竏竛䇏両筢筬筻簒簛䉠䉺类粜䊌粸䊔糭输烀𠳏総緔緐緽羮羴犟䎗耠耥笹耮耱联㷌垴炠肷胩䏭脌猪脎脒畠脔䐁㬹腖腙腚"
  ],
  [
    "99a1",
    "䐓堺腼膄䐥膓䐭膥埯臁臤艔䒏芦艶苊苘苿䒰荗险榊萅烵葤惣蒈䔄蒾蓡蓸蔐蔸蕒䔻蕯蕰藠䕷虲蚒蚲蛯际螋䘆䘗袮裿褤襇覑𧥧訩訸誔誴豑賔賲贜䞘塟跃䟭仮踺嗘坔蹱嗵躰䠷軎転軤軭軲辷迁迊迌逳駄䢭飠鈓䤞鈨鉘鉫銱銮銿"
  ],
  [
    "9a40",
    "鋣鋫鋳鋴鋽鍃鎄鎭䥅䥑麿鐗匁鐝鐭鐾䥪鑔鑹锭関䦧间阳䧥枠䨤靀䨵鞲韂噔䫤惨颹䬙飱塄餎餙冴餜餷饂饝饢䭰駅䮝騼鬏窃魩鮁鯝鯱鯴䱭鰠㝯𡯂鵉鰺"
  ],
  [
    "9aa1",
    "黾噐鶓鶽鷀鷼银辶鹻麬麱麽黆铜黢黱黸竈齄𠂔𠊷𠎠椚铃妬𠓗塀铁㞹𠗕𠘕𠙶𡚺块煳𠫂𠫍𠮿呪吆𠯋咞𠯻𠰻𠱓𠱥𠱼惧𠲍噺𠲵𠳝𠳭𠵯𠶲𠷈楕鰯螥𠸄𠸎𠻗𠾐𠼭𠹳尠𠾼帋𡁜𡁏𡁶朞𡁻𡂈𡂖㙇𡂿𡃓𡄯𡄻卤蒭𡋣𡍵𡌶讁𡕷𡘙𡟃𡟇乸炻𡠭𡥪"
  ],
  [
    "9b40",
    "𡨭𡩅𡰪𡱰𡲬𡻈拃𡻕𡼕熘桕𢁅槩㛈𢉼𢏗𢏺𢜪𢡱𢥏苽𢥧𢦓𢫕覥𢫨辠𢬎鞸𢬿顇骽𢱌"
  ],
  [
    "9b62",
    "𢲈𢲷𥯨𢴈𢴒𢶷𢶕𢹂𢽴𢿌𣀳𣁦𣌟𣏞徱晈暿𧩹𣕧𣗳爁𤦺矗𣘚𣜖纇𠍆墵朎"
  ],
  [
    "9ba1",
    "椘𣪧𧙗𥿢𣸑𣺹𧗾𢂚䣐䪸𤄙𨪚𤋮𤌍𤀻𤌴𤎖𤩅𠗊凒𠘑妟𡺨㮾𣳿𤐄𤓖垈𤙴㦛𤜯𨗨𩧉㝢𢇃譞𨭎駖𤠒𤣻𤨕爉𤫀𠱸奥𤺥𤾆𠝹軚𥀬劏圿煱𥊙𥐙𣽊𤪧喼𥑆𥑮𦭒釔㑳𥔿𧘲𥕞䜘𥕢𥕦𥟇𤤿𥡝偦㓻𣏌惞𥤃䝼𨥈𥪮𥮉𥰆𡶐垡煑澶𦄂𧰒遖𦆲𤾚譢𦐂𦑊"
  ],
  [
    "9c40",
    "嵛𦯷輶𦒄𡤜諪𤧶𦒈𣿯𦔒䯀𦖿𦚵𢜛鑥𥟡憕娧晉侻嚹𤔡𦛼乪𤤴陖涏𦲽㘘襷𦞙𦡮𦐑𦡞營𦣇筂𩃀𠨑𦤦鄄𦤹穅鷰𦧺騦𦨭㙟𦑩𠀡禃𦨴𦭛崬𣔙菏𦮝䛐𦲤画补𦶮墶"
  ],
  [
    "9ca1",
    "㜜𢖍𧁋𧇍㱔𧊀𧊅銁𢅺𧊋錰𧋦𤧐氹钟𧑐𠻸蠧裵𢤦𨑳𡞱溸𤨪𡠠㦤㚹尐秣䔿暶𩲭𩢤襃𧟌𧡘囖䃟𡘊㦡𣜯𨃨𡏅熭荦𧧝𩆨婧䲷𧂯𨦫𧧽𧨊𧬋𧵦𤅺筃祾𨀉澵𪋟樃𨌘厢𦸇鎿栶靝𨅯𨀣𦦵𡏭𣈯𨁈嶅𨰰𨂃圕頣𨥉嶫𤦈斾槕叒𤪥𣾁㰑朶𨂐𨃴𨄮𡾡𨅏"
  ],
  [
    "9d40",
    "𨆉𨆯𨈚𨌆𨌯𨎊㗊𨑨𨚪䣺揦𨥖砈鉕𨦸䏲𨧧䏟𨧨𨭆𨯔姸𨰉輋𨿅𩃬筑𩄐𩄼㷷𩅞𤫊运犏嚋𩓧𩗩𩖰𩖸𩜲𩣑𩥉𩥪𩧃𩨨𩬎𩵚𩶛纟𩻸𩼣䲤镇𪊓熢𪋿䶑递𪗋䶜𠲜达嗁"
  ],
  [
    "9da1",
    "辺𢒰边𤪓䔉繿潖檱仪㓤𨬬𧢝㜺躀𡟵𨀤𨭬𨮙𧨾𦚯㷫𧙕𣲷𥘵𥥖亚𥺁𦉘嚿𠹭踎孭𣺈𤲞揞拐𡟶𡡻攰嘭𥱊吚𥌑㷆𩶘䱽嘢嘞罉𥻘奵𣵀蝰东𠿪𠵉𣚺脗鵞贘瘻鱅癎瞹鍅吲腈苷嘥脲萘肽嗪祢噃吖𠺝㗎嘅嗱曱𨋢㘭甴嗰喺咗啲𠱁𠲖廐𥅈𠹶𢱢"
  ],
  [
    "9e40",
    "𠺢麫絚嗞𡁵抝靭咔賍燶酶揼掹揾啩𢭃鱲𢺳冚㓟𠶧冧呍唞唓癦踭𦢊疱肶蠄螆裇膶萜𡃁䓬猄𤜆宐茋𦢓噻𢛴𧴯𤆣𧵳𦻐𧊶酰𡇙鈈𣳼𪚩𠺬𠻹牦𡲢䝎𤿂𧿹𠿫䃺"
  ],
  [
    "9ea1",
    "鱝攟𢶠䣳𤟠𩵼𠿬𠸊恢𧖣𠿭"
  ],
  [
    "9ead",
    "𦁈𡆇熣纎鵐业丄㕷嬍沲卧㚬㧜卽㚥𤘘墚𤭮舭呋垪𥪕𠥹"
  ],
  [
    "9ec5",
    "㩒𢑥獴𩺬䴉鯭𣳾𩼰䱛𤾩𩖞𩿞葜𣶶𧊲𦞳𣜠挮紥𣻷𣸬㨪逈勌㹴㙺䗩𠒎癀嫰𠺶硺𧼮墧䂿噼鮋嵴癔𪐴麅䳡痹㟻愙𣃚𤏲"
  ],
  [
    "9ef5",
    "噝𡊩垧𤥣𩸆刴𧂮㖭汊鵼"
  ],
  [
    "9f40",
    "籖鬹埞𡝬屓擓𩓐𦌵𧅤蚭𠴨𦴢𤫢𠵱"
  ],
  [
    "9f4f",
    "凾𡼏嶎霃𡷑麁遌笟鬂峑箣扨挵髿篏鬪籾鬮籂粆鰕篼鬉鼗鰛𤤾齚啳寃俽麘俲剠㸆勑坧偖妷帒韈鶫轜呩鞴饀鞺匬愰"
  ],
  [
    "9fa1",
    "椬叚鰊鴂䰻陁榀傦畆𡝭駚剳"
  ],
  [
    "9fae",
    "酙隁酜"
  ],
  [
    "9fb2",
    "酑𨺗捿𦴣櫊嘑醎畺抅𠏼獏籰𥰡𣳽"
  ],
  [
    "9fc1",
    "𤤙盖鮝个𠳔莾衂"
  ],
  [
    "9fc9",
    "届槀僭坺刟巵从氱𠇲伹咜哚劚趂㗾弌㗳"
  ],
  [
    "9fdb",
    "歒酼龥鮗頮颴骺麨麄煺笔"
  ],
  [
    "9fe7",
    "毺蠘罸"
  ],
  [
    "9feb",
    "嘠𪙊蹷齓"
  ],
  [
    "9ff0",
    "跔蹏鸜踁抂𨍽踨蹵竓𤩷稾磘泪詧瘇"
  ],
  [
    "a040",
    "𨩚鼦泎蟖痃𪊲硓咢贌狢獱謭猂瓱賫𤪻蘯徺袠䒷"
  ],
  [
    "a055",
    "𡠻𦸅"
  ],
  [
    "a058",
    "詾𢔛"
  ],
  [
    "a05b",
    "惽癧髗鵄鍮鮏蟵"
  ],
  [
    "a063",
    "蠏賷猬霡鮰㗖犲䰇籑饊𦅙慙䰄麖慽"
  ],
  [
    "a073",
    "坟慯抦戹拎㩜懢厪𣏵捤栂㗒"
  ],
  [
    "a0a1",
    "嵗𨯂迚𨸹"
  ],
  [
    "a0a6",
    "僙𡵆礆匲阸𠼻䁥"
  ],
  [
    "a0ae",
    "矾"
  ],
  [
    "a0b0",
    "糂𥼚糚稭聦聣絍甅瓲覔舚朌聢𧒆聛瓰脃眤覉𦟌畓𦻑螩蟎臈螌詉貭譃眫瓸蓚㘵榲趦"
  ],
  [
    "a0d4",
    "覩瑨涹蟁𤀑瓧㷛煶悤憜㳑煢恷"
  ],
  [
    "a0e2",
    "罱𨬭牐惩䭾删㰘𣳇𥻗𧙖𥔱𡥄𡋾𩤃𦷜𧂭峁𦆭𨨏𣙷𠃮𦡆𤼎䕢嬟𦍌齐麦𦉫"
  ],
  [
    "a3c0",
    "␀",
    31,
    "␡"
  ],
  [
    "c6a1",
    "①",
    9,
    "⑴",
    9,
    "ⅰ",
    9,
    "丶丿亅亠冂冖冫勹匸卩厶夊宀巛⼳广廴彐彡攴无疒癶辵隶¨ˆヽヾゝゞ〃仝々〆〇ー［］✽ぁ",
    23
  ],
  [
    "c740",
    "す",
    58,
    "ァアィイ"
  ],
  [
    "c7a1",
    "ゥ",
    81,
    "А",
    5,
    "ЁЖ",
    4
  ],
  [
    "c840",
    "Л",
    26,
    "ёж",
    25,
    "⇧↸↹㇏𠃌乚𠂊刂䒑"
  ],
  [
    "c8a1",
    "龰冈龱𧘇"
  ],
  [
    "c8cd",
    "￢￤＇＂㈱№℡゛゜⺀⺄⺆⺇⺈⺊⺌⺍⺕⺜⺝⺥⺧⺪⺬⺮⺶⺼⺾⻆⻊⻌⻍⻏⻖⻗⻞⻣"
  ],
  [
    "c8f5",
    "ʃɐɛɔɵœøŋʊɪ"
  ],
  [
    "f9fe",
    "￭"
  ],
  [
    "fa40",
    "𠕇鋛𠗟𣿅蕌䊵珯况㙉𤥂𨧤鍄𡧛苮𣳈砼杄拟𤤳𨦪𠊠𦮳𡌅侫𢓭倈𦴩𧪄𣘀𤪱𢔓倩𠍾徤𠎀𠍇滛𠐟偽儁㑺儎顬㝃萖𤦤𠒇兠𣎴兪𠯿𢃼𠋥𢔰𠖎𣈳𡦃宂蝽𠖳𣲙冲冸"
  ],
  [
    "faa1",
    "鴴凉减凑㳜凓𤪦决凢卂凭菍椾𣜭彻刋刦刼劵剗劔効勅簕蕂勠蘍𦬓包𨫞啉滙𣾀𠥔𣿬匳卄𠯢泋𡜦栛珕恊㺪㣌𡛨燝䒢卭却𨚫卾卿𡖖𡘓矦厓𨪛厠厫厮玧𥝲㽙玜叁叅汉义埾叙㪫𠮏叠𣿫𢶣叶𠱷吓灹唫晗浛呭𦭓𠵴啝咏咤䞦𡜍𠻝㶴𠵍"
  ],
  [
    "fb40",
    "𨦼𢚘啇䳭启琗喆喩嘅𡣗𤀺䕒𤐵暳𡂴嘷曍𣊊暤暭噍噏磱囱鞇叾圀囯园𨭦㘣𡉏坆𤆥汮炋坂㚱𦱾埦𡐖堃𡑔𤍣堦𤯵塜墪㕡壠壜𡈼壻寿坃𪅐𤉸鏓㖡够梦㛃湙"
  ],
  [
    "fba1",
    "𡘾娤啓𡚒蔅姉𠵎𦲁𦴪𡟜姙𡟻𡞲𦶦浱𡠨𡛕姹𦹅媫婣㛦𤦩婷㜈媖瑥嫓𦾡𢕔㶅𡤑㜲𡚸広勐孶斈孼𧨎䀄䡝𠈄寕慠𡨴𥧌𠖥寳宝䴐尅𡭄尓珎尔𡲥𦬨屉䣝岅峩峯嶋𡷹𡸷崐崘嵆𡺤岺巗苼㠭𤤁𢁉𢅳芇㠶㯂帮檊幵幺𤒼𠳓厦亷廐厨𡝱帉廴𨒂"
  ],
  [
    "fc40",
    "廹廻㢠廼栾鐛弍𠇁弢㫞䢮𡌺强𦢈𢏐彘𢑱彣鞽𦹮彲鍀𨨶徧嶶㵟𥉐𡽪𧃸𢙨釖𠊞𨨩怱暅𡡷㥣㷇㘹垐𢞴祱㹀悞悤悳𤦂𤦏𧩓璤僡媠慤萤慂慈𦻒憁凴𠙖憇宪𣾷"
  ],
  [
    "fca1",
    "𢡟懓𨮝𩥝懐㤲𢦀𢣁怣慜攞掋𠄘担𡝰拕𢸍捬𤧟㨗搸揸𡎎𡟼撐澊𢸶頔𤂌𥜝擡擥鑻㩦携㩗敍漖𤨨𤨣斅敭敟𣁾斵𤥀䬷旑䃘𡠩无旣忟𣐀昘𣇷𣇸晄𣆤𣆥晋𠹵晧𥇦晳晴𡸽𣈱𨗴𣇈𥌓矅𢣷馤朂𤎜𤨡㬫槺𣟂杞杧杢𤇍𩃭柗䓩栢湐鈼栁𣏦𦶠桝"
  ],
  [
    "fd40",
    "𣑯槡樋𨫟楳棃𣗍椁椀㴲㨁𣘼㮀枬楡𨩊䋼椶榘㮡𠏉荣傐槹𣙙𢄪橅𣜃檝㯳枱櫈𩆜㰍欝𠤣惞欵歴𢟍溵𣫛𠎵𡥘㝀吡𣭚毡𣻼毜氷𢒋𤣱𦭑汚舦汹𣶼䓅𣶽𤆤𤤌𤤀"
  ],
  [
    "fda1",
    "𣳉㛥㳫𠴲鮃𣇹𢒑羏样𦴥𦶡𦷫涖浜湼漄𤥿𤂅𦹲蔳𦽴凇沜渝萮𨬡港𣸯瑓𣾂秌湏媑𣁋濸㜍澝𣸰滺𡒗𤀽䕕鏰潄潜㵎潴𩅰㴻澟𤅄濓𤂑𤅕𤀹𣿰𣾴𤄿凟𤅖𤅗𤅀𦇝灋灾炧炁烌烕烖烟䄄㷨熴熖𤉷焫煅媈煊煮岜𤍥煏鍢𤋁焬𤑚𤨧𤨢熺𨯨炽爎"
  ],
  [
    "fe40",
    "鑂爕夑鑃爤鍁𥘅爮牀𤥴梽牕牗㹕𣁄栍漽犂猪猫𤠣𨠫䣭𨠄猨献珏玪𠰺𦨮珉瑉𤇢𡛧𤨤昣㛅𤦷𤦍𤧻珷琕椃𤨦琹𠗃㻗瑜𢢭瑠𨺲瑇珤瑶莹瑬㜰瑴鏱樬璂䥓𤪌"
  ],
  [
    "fea1",
    "𤅟𤩹𨮏孆𨰃𡢞瓈𡦈甎瓩甞𨻙𡩋寗𨺬鎅畍畊畧畮𤾂㼄𤴓疎瑝疞疴瘂瘬癑癏癯癶𦏵皐臯㟸𦤑𦤎皡皥皷盌𦾟葢𥂝𥅽𡸜眞眦着撯𥈠睘𣊬瞯𨥤𨥨𡛁矴砉𡍶𤨒棊碯磇磓隥礮𥗠磗礴碱𧘌辸袄𨬫𦂃𢘜禆褀椂禀𥡗禝𧬹礼禩渪𧄦㺨秆𩄍秔"
  ]
], l1 = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  default: f1
}), c1 = Xt(Jh), h1 = Xt(_h), Bi = Xt(e1), Bo = Xt(r1), p1 = Xt(i1), d1 = Xt(o1), ko = Xt(u1), v1 = Xt(l1), y1 = {
  // == Japanese/ShiftJIS ====================================================
  // All japanese encodings are based on JIS X set of standards:
  // JIS X 0201 - Single-byte encoding of ASCII + ¥ + Kana chars at 0xA1-0xDF.
  // JIS X 0208 - Main set of 6879 characters, placed in 94x94 plane, to be encoded by 2 bytes. 
  //              Has several variations in 1978, 1983, 1990 and 1997.
  // JIS X 0212 - Supplementary plane of 6067 chars in 94x94 plane. 1990. Effectively dead.
  // JIS X 0213 - Extension and modern replacement of 0208 and 0212. Total chars: 11233.
  //              2 planes, first is superset of 0208, second - revised 0212.
  //              Introduced in 2000, revised 2004. Some characters are in Unicode Plane 2 (0x2xxxx)
  // Byte encodings are:
  //  * Shift_JIS: Compatible with 0201, uses not defined chars in top half as lead bytes for double-byte
  //               encoding of 0208. Lead byte ranges: 0x81-0x9F, 0xE0-0xEF; Trail byte ranges: 0x40-0x7E, 0x80-0x9E, 0x9F-0xFC.
  //               Windows CP932 is a superset of Shift_JIS. Some companies added more chars, notably KDDI.
  //  * EUC-JP:    Up to 3 bytes per character. Used mostly on *nixes.
  //               0x00-0x7F       - lower part of 0201
  //               0x8E, 0xA1-0xDF - upper part of 0201
  //               (0xA1-0xFE)x2   - 0208 plane (94x94).
  //               0x8F, (0xA1-0xFE)x2 - 0212 plane (94x94).
  //  * JIS X 208: 7-bit, direct encoding of 0208. Byte ranges: 0x21-0x7E (94 values). Uncommon.
  //               Used as-is in ISO2022 family.
  //  * ISO2022-JP: Stateful encoding, with escape sequences to switch between ASCII, 
  //                0201-1976 Roman, 0208-1978, 0208-1983.
  //  * ISO2022-JP-1: Adds esc seq for 0212-1990.
  //  * ISO2022-JP-2: Adds esc seq for GB2313-1980, KSX1001-1992, ISO8859-1, ISO8859-7.
  //  * ISO2022-JP-3: Adds esc seq for 0201-1976 Kana set, 0213-2000 Planes 1, 2.
  //  * ISO2022-JP-2004: Adds 0213-2004 Plane 1.
  //
  // After JIS X 0213 appeared, Shift_JIS-2004, EUC-JISX0213 and ISO2022-JP-2004 followed, with just changing the planes.
  //
  // Overall, it seems that it's a mess :( http://www8.plala.or.jp/tkubota1/unicode-symbols-map2.html
  shiftjis: {
    type: "_dbcs",
    table: function() {
      return c1;
    },
    encodeAdd: {
      "¥": 92,
      "‾": 126
    },
    encodeSkipVals: [{
      from: 60736,
      to: 63808
    }]
  },
  csshiftjis: "shiftjis",
  mskanji: "shiftjis",
  sjis: "shiftjis",
  windows31j: "shiftjis",
  ms31j: "shiftjis",
  xsjis: "shiftjis",
  windows932: "shiftjis",
  ms932: "shiftjis",
  932: "shiftjis",
  cp932: "shiftjis",
  eucjp: {
    type: "_dbcs",
    table: function() {
      return h1;
    },
    encodeAdd: {
      "¥": 92,
      "‾": 126
    }
  },
  // TODO: KDDI extension to Shift_JIS
  // TODO: IBM CCSID 942 = CP932, but F0-F9 custom chars and other char changes.
  // TODO: IBM CCSID 943 = Shift_JIS = CP932 with original Shift_JIS lower 128 chars.
  // == Chinese/GBK ==========================================================
  // http://en.wikipedia.org/wiki/GBK
  // We mostly implement W3C recommendation: https://www.w3.org/TR/encoding/#gbk-encoder
  // Oldest GB2312 (1981, ~7600 chars) is a subset of CP936
  gb2312: "cp936",
  gb231280: "cp936",
  gb23121980: "cp936",
  csgb2312: "cp936",
  csiso58gb231280: "cp936",
  euccn: "cp936",
  // Microsoft's CP936 is a subset and approximation of GBK.
  windows936: "cp936",
  ms936: "cp936",
  936: "cp936",
  cp936: {
    type: "_dbcs",
    table: function() {
      return Bi;
    }
  },
  // GBK (~22000 chars) is an extension of CP936 that added user-mapped chars and some other.
  gbk: {
    type: "_dbcs",
    table: function() {
      return Bi.concat(Bo);
    }
  },
  xgbk: "gbk",
  isoir58: "gbk",
  // GB18030 is an algorithmic extension of GBK.
  // Main source: https://www.w3.org/TR/encoding/#gbk-encoder
  // http://icu-project.org/docs/papers/gb18030.html
  // http://source.icu-project.org/repos/icu/data/trunk/charset/data/xml/gb-18030-2000.xml
  // http://www.khngai.com/chinese/charmap/tblgbk.php?page=0
  gb18030: {
    type: "_dbcs",
    table: function() {
      return Bi.concat(Bo);
    },
    gb18030: function() {
      return p1;
    },
    encodeSkipVals: [128],
    encodeAdd: {
      "€": 41699
    }
  },
  chinese: "gb18030",
  // == Korean ===============================================================
  // EUC-KR, KS_C_5601 and KS X 1001 are exactly the same.
  windows949: "cp949",
  ms949: "cp949",
  949: "cp949",
  cp949: {
    type: "_dbcs",
    table: function() {
      return d1;
    }
  },
  cseuckr: "cp949",
  csksc56011987: "cp949",
  euckr: "cp949",
  isoir149: "cp949",
  korean: "cp949",
  ksc56011987: "cp949",
  ksc56011989: "cp949",
  ksc5601: "cp949",
  // == Big5/Taiwan/Hong Kong ================================================
  // There are lots of tables for Big5 and cp950. Please see the following links for history:
  // http://moztw.org/docs/big5/  http://www.haible.de/bruno/charsets/conversion-tables/Big5.html
  // Variations, in roughly number of defined chars:
  //  * Windows CP 950: Microsoft variant of Big5. Canonical: http://www.unicode.org/Public/MAPPINGS/VENDORS/MICSFT/WINDOWS/CP950.TXT
  //  * Windows CP 951: Microsoft variant of Big5-HKSCS-2001. Seems to be never public. http://me.abelcheung.org/articles/research/what-is-cp951/
  //  * Big5-2003 (Taiwan standard) almost superset of cp950.
  //  * Unicode-at-on (UAO) / Mozilla 1.8. Falling out of use on the Web. Not supported by other browsers.
  //  * Big5-HKSCS (-2001, -2004, -2008). Hong Kong standard. 
  //    many unicode code points moved from PUA to Supplementary plane (U+2XXXX) over the years.
  //    Plus, it has 4 combining sequences.
  //    Seems that Mozilla refused to support it for 10 yrs. https://bugzilla.mozilla.org/show_bug.cgi?id=162431 https://bugzilla.mozilla.org/show_bug.cgi?id=310299
  //    because big5-hkscs is the only encoding to include astral characters in non-algorithmic way.
  //    Implementations are not consistent within browsers; sometimes labeled as just big5.
  //    MS Internet Explorer switches from big5 to big5-hkscs when a patch applied.
  //    Great discussion & recap of what's going on https://bugzilla.mozilla.org/show_bug.cgi?id=912470#c31
  //    In the encoder, it might make sense to support encoding old PUA mappings to Big5 bytes seq-s.
  //    Official spec: http://www.ogcio.gov.hk/en/business/tech_promotion/ccli/terms/doc/2003cmp_2008.txt
  //                   http://www.ogcio.gov.hk/tc/business/tech_promotion/ccli/terms/doc/hkscs-2008-big5-iso.txt
  // 
  // Current understanding of how to deal with Big5(-HKSCS) is in the Encoding Standard, http://encoding.spec.whatwg.org/#big5-encoder
  // Unicode mapping (http://www.unicode.org/Public/MAPPINGS/OBSOLETE/EASTASIA/OTHER/BIG5.TXT) is said to be wrong.
  windows950: "cp950",
  ms950: "cp950",
  950: "cp950",
  cp950: {
    type: "_dbcs",
    table: function() {
      return ko;
    }
  },
  // Big5 has many variations and is an extension of cp950. We use Encoding Standard's as a consensus.
  big5: "big5hkscs",
  big5hkscs: {
    type: "_dbcs",
    table: function() {
      return ko.concat(v1);
    },
    encodeSkipVals: [41676]
  },
  cnbig5: "big5hkscs",
  csbig5: "big5hkscs",
  xxbig5: "big5hkscs"
}, g1 = be(function(t, e) {
  for (var r = [Bh, Mh, Gh, Hh, Wh, Xh, Kh, y1], n = 0; n < r.length; n++) {
    var t = r[n];
    for (var a in t)
      Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
  }
}), bf = Xe.Buffer, oi = Ye.Transform, m1 = function(e) {
  e.encodeStream = function(n, a) {
    return new hr(e.getEncoder(n, a), a);
  }, e.decodeStream = function(n, a) {
    return new Vt(e.getDecoder(n, a), a);
  }, e.supportsStreams = !0, e.IconvLiteEncoderStream = hr, e.IconvLiteDecoderStream = Vt, e._collect = Vt.prototype.collect;
};
function hr(t, e) {
  this.conv = t, e = e || {}, e.decodeStrings = !1, oi.call(this, e);
}
hr.prototype = Object.create(oi.prototype, {
  constructor: {
    value: hr
  }
});
hr.prototype._transform = function(t, e, r) {
  if (typeof t != "string") return r(new Error("Iconv encoding stream needs strings as its input."));
  try {
    var n = this.conv.write(t);
    n && n.length && this.push(n), r();
  } catch (a) {
    r(a);
  }
};
hr.prototype._flush = function(t) {
  try {
    var e = this.conv.end();
    e && e.length && this.push(e), t();
  } catch (r) {
    t(r);
  }
};
hr.prototype.collect = function(t) {
  var e = [];
  return this.on("error", t), this.on("data", function(r) {
    e.push(r);
  }), this.on("end", function() {
    t(null, bf.concat(e));
  }), this;
};
function Vt(t, e) {
  this.conv = t, e = e || {}, e.encoding = this.encoding = "utf8", oi.call(this, e);
}
Vt.prototype = Object.create(oi.prototype, {
  constructor: {
    value: Vt
  }
});
Vt.prototype._transform = function(t, e, r) {
  if (!bf.isBuffer(t)) return r(new Error("Iconv decoding stream needs buffers as its input."));
  try {
    var n = this.conv.write(t);
    n && n.length && this.push(n, this.encoding), r();
  } catch (a) {
    r(a);
  }
};
Vt.prototype._flush = function(t) {
  try {
    var e = this.conv.end();
    e && e.length && this.push(e, this.encoding), t();
  } catch (r) {
    t(r);
  }
};
Vt.prototype.collect = function(t) {
  var e = "";
  return this.on("error", t), this.on("data", function(r) {
    e += r;
  }), this.on("end", function() {
    t(null, e);
  }), this;
};
var Se = Xe.Buffer, b1 = function(e) {
  var r = void 0;
  e.supportsNodeEncodingsExtension = !(Se.from || new Se(0) instanceof Uint8Array), e.extendNodeEncodings = function() {
    if (!r) {
      if (r = {}, !e.supportsNodeEncodingsExtension) {
        console.error("ACTION NEEDED: require('iconv-lite').extendNodeEncodings() is not supported in your version of Node"), console.error("See more info at https://github.com/ashtuchkin/iconv-lite/wiki/Node-v4-compatibility");
        return;
      }
      var a = {
        hex: !0,
        utf8: !0,
        "utf-8": !0,
        ascii: !0,
        binary: !0,
        base64: !0,
        ucs2: !0,
        "ucs-2": !0,
        utf16le: !0,
        "utf-16le": !0
      };
      Se.isNativeEncoding = function(u) {
        return u && a[u.toLowerCase()];
      };
      var o = Xe.SlowBuffer;
      if (r.SlowBufferToString = o.prototype.toString, o.prototype.toString = function(u, f, l) {
        return u = String(u || "utf8").toLowerCase(), Se.isNativeEncoding(u) ? r.SlowBufferToString.call(this, u, f, l) : (typeof f > "u" && (f = 0), typeof l > "u" && (l = this.length), e.decode(this.slice(f, l), u));
      }, r.SlowBufferWrite = o.prototype.write, o.prototype.write = function(u, f, l, c) {
        if (isFinite(f))
          isFinite(l) || (c = l, l = void 0);
        else {
          var p = c;
          c = f, f = l, l = p;
        }
        f = +f || 0;
        var y = this.length - f;
        if (l ? (l = +l, l > y && (l = y)) : l = y, c = String(c || "utf8").toLowerCase(), Se.isNativeEncoding(c)) return r.SlowBufferWrite.call(this, u, f, l, c);
        if (u.length > 0 && (l < 0 || f < 0)) throw new RangeError("attempt to write beyond buffer bounds");
        var v = e.encode(u, c);
        return v.length < l && (l = v.length), v.copy(this, f, 0, l), l;
      }, r.BufferIsEncoding = Se.isEncoding, Se.isEncoding = function(u) {
        return Se.isNativeEncoding(u) || e.encodingExists(u);
      }, r.BufferByteLength = Se.byteLength, Se.byteLength = o.byteLength = function(u, f) {
        return f = String(f || "utf8").toLowerCase(), Se.isNativeEncoding(f) ? r.BufferByteLength.call(this, u, f) : e.encode(u, f).length;
      }, r.BufferToString = Se.prototype.toString, Se.prototype.toString = function(u, f, l) {
        return u = String(u || "utf8").toLowerCase(), Se.isNativeEncoding(u) ? r.BufferToString.call(this, u, f, l) : (typeof f > "u" && (f = 0), typeof l > "u" && (l = this.length), e.decode(this.slice(f, l), u));
      }, r.BufferWrite = Se.prototype.write, Se.prototype.write = function(u, f, l, c) {
        var p = f, y = l, v = c;
        if (isFinite(f))
          isFinite(l) || (c = l, l = void 0);
        else {
          var m = c;
          c = f, f = l, l = m;
        }
        if (c = String(c || "utf8").toLowerCase(), Se.isNativeEncoding(c)) return r.BufferWrite.call(this, u, p, y, v);
        f = +f || 0;
        var w = this.length - f;
        if (l ? (l = +l, l > w && (l = w)) : l = w, u.length > 0 && (l < 0 || f < 0)) throw new RangeError("attempt to write beyond buffer bounds");
        var F = e.encode(u, c);
        return F.length < l && (l = F.length), F.copy(this, f, 0, l), l;
      }, e.supportsStreams) {
        var s = Ye.Readable;
        r.ReadableSetEncoding = s.prototype.setEncoding, s.prototype.setEncoding = function(f, l) {
          this._readableState.decoder = e.getDecoder(f, l), this._readableState.encoding = f;
        }, s.prototype.collect = e._collect;
      }
    }
  }, e.undoExtendNodeEncodings = function() {
    if (e.supportsNodeEncodingsExtension) {
      if (!r) throw new Error("require('iconv-lite').undoExtendNodeEncodings(): Nothing to undo; extendNodeEncodings() is not called.");
      delete Se.isNativeEncoding;
      var a = Xe.SlowBuffer;
      if (a.prototype.toString = r.SlowBufferToString, a.prototype.write = r.SlowBufferWrite, Se.isEncoding = r.BufferIsEncoding, Se.byteLength = r.BufferByteLength, Se.prototype.toString = r.BufferToString, Se.prototype.write = r.BufferWrite, e.supportsStreams) {
        var o = Ye.Readable;
        o.prototype.setEncoding = r.ReadableSetEncoding, delete o.prototype.collect;
      }
      r = void 0;
    }
  };
}, _r = be(function(t) {
  var e = qr.Buffer, r = t.exports;
  r.encodings = null, r.defaultCharUnicode = "�", r.defaultCharSingleByte = "?", r.encode = function(s, u, f) {
    s = "" + (s || "");
    var l = r.getEncoder(u, f), c = l.write(s), p = l.end();
    return p && p.length > 0 ? e.concat([c, p]) : c;
  }, r.decode = function(s, u, f) {
    typeof s == "string" && (r.skipDecodeWarning || (console.error("Iconv-lite warning: decode()-ing strings is deprecated. Refer to https://github.com/ashtuchkin/iconv-lite/wiki/Use-Buffers-when-decoding"), r.skipDecodeWarning = !0), s = e.from("" + (s || ""), "binary"));
    var l = r.getDecoder(u, f), c = l.write(s), p = l.end();
    return p ? c + p : c;
  }, r.encodingExists = function(s) {
    try {
      return r.getCodec(s), !0;
    } catch {
      return !1;
    }
  }, r.toEncoding = r.encode, r.fromEncoding = r.decode, r._codecDataCache = {}, r.getCodec = function(s) {
    r.encodings || (r.encodings = g1);
    for (var u = r._canonicalizeEncoding(s), f = {}; ; ) {
      var l = r._codecDataCache[u];
      if (l) return l;
      var c = r.encodings[u];
      switch (typeof c) {
        case "string":
          u = c;
          break;
        case "object":
          for (var p in c)
            f[p] = c[p];
          f.encodingName || (f.encodingName = u), u = c.type;
          break;
        case "function":
          return f.encodingName || (f.encodingName = u), l = new c(f, r), r._codecDataCache[f.encodingName] = l, l;
        default:
          throw new Error("Encoding not recognized: '" + s + "' (searched as: '" + u + "')");
      }
    }
  }, r._canonicalizeEncoding = function(o) {
    return ("" + o).toLowerCase().replace(/:\d{4}$|[^0-9a-z]/g, "");
  }, r.getEncoder = function(s, u) {
    var f = r.getCodec(s), l = new f.encoder(u, f);
    return f.bomAware && u && u.addBOM && (l = new Po.PrependBOM(l, u)), l;
  }, r.getDecoder = function(s, u) {
    var f = r.getCodec(s), l = new f.decoder(u, f);
    return f.bomAware && !(u && u.stripBOM === !1) && (l = new Po.StripBOM(l, u)), l;
  };
  var n = typeof jt < "u" && jt.versions && jt.versions.node;
  if (n) {
    var a = n.split(".").map(Number);
    (a[0] > 0 || a[1] >= 10) && m1(r), b1(r);
  }
}), io = be(function(t) {
  (function() {
    var e, r;
    try {
      r = _r;
    } catch {
    }
    e = (function() {
      var n;
      function a(o) {
        this.buffer = o, this.pos = 0, this.length = this.buffer.length;
      }
      a.TYPES = {
        UInt8: 1,
        UInt16: 2,
        UInt24: 3,
        UInt32: 4,
        Int8: 1,
        Int16: 2,
        Int24: 3,
        Int32: 4,
        Float: 4,
        Double: 8
      };
      for (n in pe.prototype)
        n.slice(0, 4) === "read" && (function(o) {
          var s;
          return s = a.TYPES[o.replace(/read|[BL]E/g, "")], a.prototype[o] = function() {
            var u;
            return u = this.buffer[o](this.pos), this.pos += s, u;
          };
        })(n);
      return a.prototype.readString = function(o, s) {
        var u, f, l, c, p;
        switch (s == null && (s = "ascii"), s) {
          case "utf16le":
          case "ucs2":
          case "utf8":
          case "ascii":
            return this.buffer.toString(s, this.pos, this.pos += o);
          case "utf16be":
            for (u = new pe(this.readBuffer(o)), l = c = 0, p = u.length - 1; c < p; l = c += 2)
              f = u[l], u[l] = u[l + 1], u[l + 1] = f;
            return u.toString("utf16le");
          default:
            if (u = this.readBuffer(o), r)
              try {
                return r.decode(u, s);
              } catch {
              }
            return u;
        }
      }, a.prototype.readBuffer = function(o) {
        return this.buffer.slice(this.pos, this.pos += o);
      }, a.prototype.readUInt24BE = function() {
        return (this.readUInt16BE() << 8) + this.readUInt8();
      }, a.prototype.readUInt24LE = function() {
        return this.readUInt16LE() + (this.readUInt8() << 16);
      }, a.prototype.readInt24BE = function() {
        return (this.readInt16BE() << 8) + this.readUInt8();
      }, a.prototype.readInt24LE = function() {
        return this.readUInt16LE() + (this.readInt8() << 16);
      }, a;
    })(), t.exports = e;
  }).call(Me);
}), w1 = be(function(t) {
  (function() {
    var e, r, n, a, o = {}.hasOwnProperty, s = function(f, l) {
      for (var c in l)
        o.call(l, c) && (f[c] = l[c]);
      function p() {
        this.constructor = f;
      }
      return p.prototype = l.prototype, f.prototype = new p(), f.__super__ = l.prototype, f;
    };
    a = Ye, e = io;
    try {
      n = _r;
    } catch {
    }
    r = (function(u) {
      var f;
      s(l, u);
      function l(c) {
        c == null && (c = 65536), l.__super__.constructor.apply(this, arguments), this.buffer = new pe(c), this.bufferOffset = 0, this.pos = 0;
      }
      for (f in pe.prototype)
        f.slice(0, 5) === "write" && (function(c) {
          var p;
          return p = +e.TYPES[c.replace(/write|[BL]E/g, "")], l.prototype[c] = function(y) {
            return this.ensure(p), this.buffer[c](y, this.bufferOffset), this.bufferOffset += p, this.pos += p;
          };
        })(f);
      return l.prototype._read = function() {
      }, l.prototype.ensure = function(c) {
        if (this.bufferOffset + c > this.buffer.length)
          return this.flush();
      }, l.prototype.flush = function() {
        if (this.bufferOffset > 0)
          return this.push(new pe(this.buffer.slice(0, this.bufferOffset))), this.bufferOffset = 0;
      }, l.prototype.writeBuffer = function(c) {
        return this.flush(), this.push(c), this.pos += c.length;
      }, l.prototype.writeString = function(c, p) {
        var y, v, m, w, F;
        switch (p == null && (p = "ascii"), p) {
          case "utf16le":
          case "ucs2":
          case "utf8":
          case "ascii":
            return this.writeBuffer(new pe(c, p));
          case "utf16be":
            for (y = new pe(c, "utf16le"), m = w = 0, F = y.length - 1; w < F; m = w += 2)
              v = y[m], y[m] = y[m + 1], y[m + 1] = v;
            return this.writeBuffer(y);
          default:
            if (n)
              return this.writeBuffer(n.encode(c, p));
            throw new Error("Install iconv-lite to enable additional string encodings.");
        }
      }, l.prototype.writeUInt24BE = function(c) {
        return this.ensure(3), this.buffer[this.bufferOffset++] = c >>> 16 & 255, this.buffer[this.bufferOffset++] = c >>> 8 & 255, this.buffer[this.bufferOffset++] = c & 255, this.pos += 3;
      }, l.prototype.writeUInt24LE = function(c) {
        return this.ensure(3), this.buffer[this.bufferOffset++] = c & 255, this.buffer[this.bufferOffset++] = c >>> 8 & 255, this.buffer[this.bufferOffset++] = c >>> 16 & 255, this.pos += 3;
      }, l.prototype.writeInt24BE = function(c) {
        return c >= 0 ? this.writeUInt24BE(c) : this.writeUInt24BE(c + 16777215 + 1);
      }, l.prototype.writeInt24LE = function(c) {
        return c >= 0 ? this.writeUInt24LE(c) : this.writeUInt24LE(c + 16777215 + 1);
      }, l.prototype.fill = function(c, p) {
        var y;
        return p < this.buffer.length ? (this.ensure(p), this.buffer.fill(c, this.bufferOffset, this.bufferOffset + p), this.bufferOffset += p, this.pos += p) : (y = new pe(p), y.fill(c), this.writeBuffer(y));
      }, l.prototype.end = function() {
        return this.flush(), this.push(null);
      }, l;
    })(a.Readable), t.exports = r;
  }).call(Me);
}), ee = be(function(t, e) {
  (function() {
    var r, n, a, o = {}.hasOwnProperty, s = function(f, l) {
      for (var c in l)
        o.call(l, c) && (f[c] = l[c]);
      function p() {
        this.constructor = f;
      }
      return p.prototype = l.prototype, f.prototype = new p(), f.__super__ = l.prototype, f;
    };
    r = io, a = (function() {
      function u(f, l) {
        this.type = f, this.endian = l ?? "BE", this.fn = this.type, this.type[this.type.length - 1] !== "8" && (this.fn += this.endian);
      }
      return u.prototype.size = function() {
        return r.TYPES[this.type];
      }, u.prototype.decode = function(f) {
        return f["read" + this.fn]();
      }, u.prototype.encode = function(f, l) {
        return f["write" + this.fn](l);
      }, u;
    })(), e.Number = a, e.uint8 = new a("UInt8"), e.uint16be = e.uint16 = new a("UInt16", "BE"), e.uint16le = new a("UInt16", "LE"), e.uint24be = e.uint24 = new a("UInt24", "BE"), e.uint24le = new a("UInt24", "LE"), e.uint32be = e.uint32 = new a("UInt32", "BE"), e.uint32le = new a("UInt32", "LE"), e.int8 = new a("Int8"), e.int16be = e.int16 = new a("Int16", "BE"), e.int16le = new a("Int16", "LE"), e.int24be = e.int24 = new a("Int24", "BE"), e.int24le = new a("Int24", "LE"), e.int32be = e.int32 = new a("Int32", "BE"), e.int32le = new a("Int32", "LE"), e.floatbe = e.float = new a("Float", "BE"), e.floatle = new a("Float", "LE"), e.doublebe = e.double = new a("Double", "BE"), e.doublele = new a("Double", "LE"), n = (function(u) {
      s(f, u);
      function f(l, c, p) {
        p == null && (p = l >> 1), f.__super__.constructor.call(this, "Int" + l, c), this._point = 1 << p;
      }
      return f.prototype.decode = function(l) {
        return f.__super__.decode.call(this, l) / this._point;
      }, f.prototype.encode = function(l, c) {
        return f.__super__.encode.call(this, l, c * this._point | 0);
      }, f;
    })(a), e.Fixed = n, e.fixed16be = e.fixed16 = new n(16, "BE"), e.fixed16le = new n(16, "LE"), e.fixed32be = e.fixed32 = new n(32, "BE"), e.fixed32le = new n(32, "LE");
  }).call(Me);
});
ee.Number;
ee.uint8;
ee.uint16be;
ee.uint16;
ee.uint16le;
ee.uint24be;
ee.uint24;
ee.uint24le;
ee.uint32be;
ee.uint32;
ee.uint32le;
ee.int8;
ee.int16be;
ee.int16;
ee.int16le;
ee.int24be;
ee.int24;
ee.int24le;
ee.int32be;
ee.int32;
ee.int32le;
ee.floatbe;
ee.floatle;
ee.doublebe;
ee.doublele;
ee.Fixed;
ee.fixed16be;
ee.fixed16;
ee.fixed16le;
ee.fixed32be;
ee.fixed32;
ee.fixed32le;
var Ct = be(function(t, e) {
  (function() {
    var r, n;
    r = ee.Number, e.resolveLength = function(a, o, s) {
      var u;
      if (typeof a == "number" ? u = a : typeof a == "function" ? u = a.call(s, s) : s && typeof a == "string" ? u = s[a] : o && a instanceof r && (u = a.decode(o)), isNaN(u))
        throw new Error("Not a fixed size");
      return u;
    }, n = /* @__PURE__ */ (function() {
      function a(o) {
        var s, u;
        o == null && (o = {}), this.enumerable = !0, this.configurable = !0;
        for (s in o)
          u = o[s], this[s] = u;
      }
      return a;
    })(), e.PropertyDescriptor = n;
  }).call(Me);
}), wf = Ct.resolveLength, F1 = Ct.PropertyDescriptor, Ff = be(function(t) {
  (function() {
    var e, r, n;
    r = ee.Number, n = Ct, e = (function() {
      function a(o, s, u) {
        this.type = o, this.length = s, this.lengthType = u ?? "count";
      }
      return a.prototype.decode = function(o, s) {
        var u, f, l, c, p, y;
        if (l = o.pos, c = [], u = s, this.length != null && (f = n.resolveLength(this.length, o, s)), this.length instanceof r && (Object.defineProperties(c, {
          parent: {
            value: s
          },
          _startOffset: {
            value: l
          },
          _currentOffset: {
            value: 0,
            writable: !0
          },
          _length: {
            value: f
          }
        }), u = c), f == null || this.lengthType === "bytes")
          for (p = f != null ? o.pos + f : s?._length ? s._startOffset + s._length : o.length; o.pos < p; )
            c.push(this.type.decode(o, u));
        else
          for (y = 0; y < f; y += 1)
            c.push(this.type.decode(o, u));
        return c;
      }, a.prototype.size = function(o, s) {
        var u, f, l, c;
        if (!o)
          return this.type.size(null, s) * n.resolveLength(this.length, null, s);
        for (f = 0, this.length instanceof r && (f += this.length.size(), s = {
          parent: s
        }), l = 0, c = o.length; l < c; l++)
          u = o[l], f += this.type.size(u, s);
        return f;
      }, a.prototype.encode = function(o, s, u) {
        var f, l, c, p, y, v;
        for (f = u, this.length instanceof r && (f = {
          pointers: [],
          startOffset: o.pos,
          parent: u
        }, f.pointerOffset = o.pos + this.size(s, f), this.length.encode(o, s.length)), y = 0, v = s.length; y < v; y++)
          c = s[y], this.type.encode(o, c, f);
        if (this.length instanceof r)
          for (l = 0; l < f.pointers.length; )
            p = f.pointers[l++], p.type.encode(o, p.val);
      }, a;
    })(), t.exports = e;
  }).call(Me);
}), x1 = be(function(t) {
  (function() {
    var e, r, n, a, o, s, u = {}.hasOwnProperty, f = function(c, p) {
      for (var y in p)
        u.call(p, y) && (c[y] = p[y]);
      function v() {
        this.constructor = c;
      }
      return v.prototype = p.prototype, c.prototype = new v(), c.__super__ = p.prototype, c;
    };
    e = Ff, a = ee.Number, s = Ct, o = Qc.inspect, n = (function(l) {
      f(c, l);
      function c() {
        return c.__super__.constructor.apply(this, arguments);
      }
      return c.prototype.decode = function(p, y) {
        var v, m, w;
        return m = p.pos, v = s.resolveLength(this.length, p, y), this.length instanceof a && (y = {
          parent: y,
          _startOffset: m,
          _currentOffset: 0,
          _length: v
        }), w = new r(this.type, v, p, y), p.pos += v * this.type.size(null, y), w;
      }, c.prototype.size = function(p, y) {
        return p instanceof r && (p = p.toArray()), c.__super__.size.call(this, p, y);
      }, c.prototype.encode = function(p, y, v) {
        return y instanceof r && (y = y.toArray()), c.__super__.encode.call(this, p, y, v);
      }, c;
    })(e), r = (function() {
      function l(c, p, y, v) {
        this.type = c, this.length = p, this.stream = y, this.ctx = v, this.base = this.stream.pos, this.items = [];
      }
      return l.prototype.get = function(c) {
        var p;
        if (!(c < 0 || c >= this.length))
          return this.items[c] == null && (p = this.stream.pos, this.stream.pos = this.base + this.type.size(null, this.ctx) * c, this.items[c] = this.type.decode(this.stream, this.ctx), this.stream.pos = p), this.items[c];
      }, l.prototype.toArray = function() {
        var c, p, y, v;
        for (v = [], c = p = 0, y = this.length; p < y; c = p += 1)
          v.push(this.get(c));
        return v;
      }, l.prototype.inspect = function() {
        return o(this.toArray());
      }, l;
    })(), t.exports = n;
  }).call(Me);
}), S1 = be(function(t) {
  (function() {
    var e;
    e = (function() {
      function r(n, a) {
        this.type = n, this.flags = a ?? [];
      }
      return r.prototype.decode = function(n) {
        var a, o, s, u, f, l, c;
        for (u = this.type.decode(n), s = {}, c = this.flags, o = f = 0, l = c.length; f < l; o = ++f)
          a = c[o], a != null && (s[a] = !!(u & 1 << o));
        return s;
      }, r.prototype.size = function() {
        return this.type.size();
      }, r.prototype.encode = function(n, a) {
        var o, s, u, f, l, c;
        for (u = 0, c = this.flags, s = f = 0, l = c.length; f < l; s = ++f)
          o = c[s], o != null && a[o] && (u |= 1 << s);
        return this.type.encode(n, u);
      }, r;
    })(), t.exports = e;
  }).call(Me);
}), A1 = be(function(t) {
  (function() {
    var e;
    e = (function() {
      function r(n) {
        this.type = n;
      }
      return r.prototype.decode = function(n, a) {
        return !!this.type.decode(n, a);
      }, r.prototype.size = function(n, a) {
        return this.type.size(n, a);
      }, r.prototype.encode = function(n, a, o) {
        return this.type.encode(n, +a, o);
      }, r;
    })(), t.exports = e;
  }).call(Me);
}), E1 = be(function(t) {
  (function() {
    var e, r, n;
    n = Ct, r = ee.Number, e = (function() {
      function a(o) {
        this.length = o;
      }
      return a.prototype.decode = function(o, s) {
        var u;
        return u = n.resolveLength(this.length, o, s), o.readBuffer(u);
      }, a.prototype.size = function(o, s) {
        return o ? o.length : n.resolveLength(this.length, null, s);
      }, a.prototype.encode = function(o, s, u) {
        return this.length instanceof r && this.length.encode(o, s.length), o.writeBuffer(s);
      }, a;
    })(), t.exports = e;
  }).call(Me);
}), C1 = be(function(t) {
  (function() {
    var e;
    e = (function() {
      function r(n, a) {
        this.type = n, this.options = a ?? [];
      }
      return r.prototype.decode = function(n) {
        var a;
        return a = this.type.decode(n), this.options[a] || a;
      }, r.prototype.size = function() {
        return this.type.size();
      }, r.prototype.encode = function(n, a) {
        var o;
        if (o = this.options.indexOf(a), o === -1)
          throw new Error("Unknown option in enum: " + a);
        return this.type.encode(n, o);
      }, r;
    })(), t.exports = e;
  }).call(Me);
}), I1 = be(function(t) {
  (function() {
    var e;
    e = (function() {
      function r(n, a) {
        this.type = n, this.condition = a ?? !0;
      }
      return r.prototype.decode = function(n, a) {
        var o;
        if (o = this.condition, typeof o == "function" && (o = o.call(a, a)), o)
          return this.type.decode(n, a);
      }, r.prototype.size = function(n, a) {
        var o;
        return o = this.condition, typeof o == "function" && (o = o.call(a, a)), o ? this.type.size(n, a) : 0;
      }, r.prototype.encode = function(n, a, o) {
        var s;
        if (s = this.condition, typeof s == "function" && (s = s.call(o, o)), s)
          return this.type.encode(n, a, o);
      }, r;
    })(), t.exports = e;
  }).call(Me);
}), O1 = be(function(t) {
  (function() {
    var e, r;
    r = Ct, e = (function() {
      function n(a, o) {
        this.type = a, this.count = o ?? 1;
      }
      return n.prototype.decode = function(a, o) {
        a.pos += this.size(null, o);
      }, n.prototype.size = function(a, o) {
        var s;
        return s = r.resolveLength(this.count, null, o), this.type.size() * s;
      }, n.prototype.encode = function(a, o, s) {
        return a.fill(0, this.size(o, s));
      }, n;
    })(), t.exports = e;
  }).call(Me);
}), D1 = be(function(t) {
  (function() {
    var e, r, n;
    e = ee.Number, n = Ct, r = (function() {
      function a(o, s) {
        this.length = o, this.encoding = s ?? "ascii";
      }
      return a.prototype.decode = function(o, s) {
        var u, f, l, c, p;
        return l = (function() {
          if (this.length != null)
            return n.resolveLength(this.length, o, s);
          for (u = o.buffer, l = o.length, c = o.pos; c < l && u[c] !== 0; )
            ++c;
          return c - o.pos;
        }).call(this), f = this.encoding, typeof f == "function" && (f = f.call(s, s) || "ascii"), p = o.readString(l, f), this.length == null && o.pos < o.length && o.pos++, p;
      }, a.prototype.size = function(o, s) {
        var u, f;
        return o ? (u = this.encoding, typeof u == "function" && (u = u.call(s?.val, s?.val) || "ascii"), u === "utf16be" && (u = "utf16le"), f = pe.byteLength(o, u), this.length instanceof e && (f += this.length.size()), this.length == null && f++, f) : n.resolveLength(this.length, null, s);
      }, a.prototype.encode = function(o, s, u) {
        var f;
        if (f = this.encoding, typeof f == "function" && (f = f.call(u?.val, u?.val) || "ascii"), this.length instanceof e && this.length.encode(o, pe.byteLength(s, f)), o.writeString(s, f), this.length == null)
          return o.writeUInt8(0);
      }, a;
    })(), t.exports = r;
  }).call(Me);
}), xf = be(function(t) {
  (function() {
    var e, r;
    r = Ct, e = (function() {
      function n(a) {
        this.fields = a ?? {};
      }
      return n.prototype.decode = function(a, o, s) {
        var u, f;
        return s == null && (s = 0), u = this._setup(a, o, s), this._parseFields(a, u, this.fields), (f = this.process) != null && f.call(u, a), u;
      }, n.prototype._setup = function(a, o, s) {
        var u;
        return u = {}, Object.defineProperties(u, {
          parent: {
            value: o
          },
          _startOffset: {
            value: a.pos
          },
          _currentOffset: {
            value: 0,
            writable: !0
          },
          _length: {
            value: s
          }
        }), u;
      }, n.prototype._parseFields = function(a, o, s) {
        var u, f, l;
        for (u in s)
          f = s[u], typeof f == "function" ? l = f.call(o, o) : l = f.decode(a, o), l !== void 0 && (l instanceof r.PropertyDescriptor ? Object.defineProperty(o, u, l) : o[u] = l), o._currentOffset = a.pos - o._startOffset;
      }, n.prototype.size = function(a, o, s) {
        var u, f, l, c, p;
        a == null && (a = {}), s == null && (s = !0), u = {
          parent: o,
          val: a,
          pointerSize: 0
        }, l = 0, p = this.fields;
        for (f in p)
          c = p[f], c.size != null && (l += c.size(a[f], u));
        return s && (l += u.pointerSize), l;
      }, n.prototype.encode = function(a, o, s) {
        var u, f, l, c, p, y, v;
        (y = this.preEncode) != null && y.call(o, a), u = {
          pointers: [],
          startOffset: a.pos,
          parent: s,
          val: o,
          pointerSize: 0
        }, u.pointerOffset = a.pos + this.size(o, u, !1), v = this.fields;
        for (l in v)
          p = v[l], p.encode != null && p.encode(a, o[l], u);
        for (f = 0; f < u.pointers.length; )
          c = u.pointers[f++], c.type.encode(a, c.val, c.parent);
      }, n;
    })(), t.exports = e;
  }).call(Me);
}), T1 = be(function(t) {
  (function() {
    var e, r, n = {}.hasOwnProperty, a = function(s, u) {
      for (var f in u)
        n.call(u, f) && (s[f] = u[f]);
      function l() {
        this.constructor = s;
      }
      return l.prototype = u.prototype, s.prototype = new l(), s.__super__ = u.prototype, s;
    };
    e = xf, r = (function(o) {
      a(s, o);
      function s(u, f) {
        this.type = u, this.versions = f ?? {};
      }
      return s.prototype.versionGetter = function(u) {
        if (typeof this.type == "string")
          return this.type.split(".").reduce(function(f, l) {
            if (typeof f < "u")
              return f[l];
          }, u);
      }, s.prototype.versionSetter = function(u, f) {
        if (typeof this.type == "string")
          return this.type.split(".").reduce(function(l, c) {
            return l[c] = f;
          }, u);
      }, s.prototype.decode = function(u, f, l) {
        var c, p, y;
        if (l == null && (l = 0), p = this._setup(u, f, l), typeof this.type == "string" ? p.version = this.versionGetter(f) : p.version = this.type.decode(u), this.versions.header && this._parseFields(u, p, this.versions.header), c = this.versions[p.version], c == null)
          throw new Error("Unknown version " + p.version);
        return c instanceof s ? c.decode(u, f) : (this._parseFields(u, p, c), (y = this.process) != null && y.call(p, u), p);
      }, s.prototype.size = function(u, f, l) {
        var c, p, y, v, m, w;
        if (l == null && (l = !0), !u)
          throw new Error("Not a fixed size");
        if (c = {
          parent: f,
          val: u,
          pointerSize: 0
        }, v = 0, typeof this.type != "string" && (v += this.type.size(u.version, c)), this.versions.header) {
          w = this.versions.header;
          for (y in w)
            m = w[y], m.size != null && (v += m.size(u[y], c));
        }
        if (p = this.versions[u.version], p == null)
          throw new Error("Unknown version " + u.version);
        for (y in p)
          m = p[y], m.size != null && (v += m.size(u[y], c));
        return l && (v += c.pointerSize), v;
      }, s.prototype.encode = function(u, f, l) {
        var c, p, y, v, m, w, F, S;
        if ((F = this.preEncode) != null && F.call(f, u), c = {
          pointers: [],
          startOffset: u.pos,
          parent: l,
          val: f,
          pointerSize: 0
        }, c.pointerOffset = u.pos + this.size(f, c, !1), typeof this.type != "string" && this.type.encode(u, f.version), this.versions.header) {
          S = this.versions.header;
          for (v in S)
            w = S[v], w.encode != null && w.encode(u, f[v], c);
        }
        p = this.versions[f.version];
        for (v in p)
          w = p[v], w.encode != null && w.encode(u, f[v], c);
        for (y = 0; y < c.pointers.length; )
          m = c.pointers[y++], m.type.encode(u, m.val, m.parent);
      }, s;
    })(e), t.exports = r;
  }).call(Me);
}), ao = be(function(t, e) {
  (function() {
    var r, n, a;
    a = Ct, r = (function() {
      function o(s, u, f) {
        var l, c, p, y;
        this.offsetType = s, this.type = u, this.options = f ?? {}, this.type === "void" && (this.type = null), (l = this.options).type == null && (l.type = "local"), (c = this.options).allowNull == null && (c.allowNull = !0), (p = this.options).nullValue == null && (p.nullValue = 0), (y = this.options).lazy == null && (y.lazy = !1);
      }
      return o.prototype.relativeToGetter = function(s) {
        return this.options.relativeTo.split(".").reduce(function(u, f) {
          return u[f];
        }, s);
      }, o.prototype.decode = function(s, u) {
        var f, l, c, p, y, v;
        return c = this.offsetType.decode(s, u), c === this.options.nullValue && this.options.allowNull ? null : (y = (function() {
          switch (this.options.type) {
            case "local":
              return u._startOffset;
            case "immediate":
              return s.pos - this.offsetType.size();
            case "parent":
              return u.parent._startOffset;
            default:
              for (f = u; f.parent; )
                f = f.parent;
              return f._startOffset || 0;
          }
        }).call(this), this.options.relativeTo && (y += this.relativeToGetter(u)), p = c + y, this.type != null ? (v = null, l = /* @__PURE__ */ (function(m) {
          return function() {
            var w;
            return v != null || (w = s.pos, s.pos = p, v = m.type.decode(s, u), s.pos = w), v;
          };
        })(this), this.options.lazy ? new a.PropertyDescriptor({
          get: l
        }) : l()) : p);
      }, o.prototype.size = function(s, u) {
        var f, l;
        switch (f = u, this.options.type) {
          case "local":
          case "immediate":
            break;
          case "parent":
            u = u.parent;
            break;
          default:
            for (; u.parent; )
              u = u.parent;
        }
        if (l = this.type, l == null) {
          if (!(s instanceof n))
            throw new Error("Must be a VoidPointer");
          l = s.type, s = s.value;
        }
        return s && u && (u.pointerSize += l.size(s, f)), this.offsetType.size();
      }, o.prototype.encode = function(s, u, f) {
        var l, c, p;
        if (l = f, u == null) {
          this.offsetType.encode(s, this.options.nullValue);
          return;
        }
        switch (this.options.type) {
          case "local":
            c = f.startOffset;
            break;
          case "immediate":
            c = s.pos + this.offsetType.size(u, l);
            break;
          case "parent":
            f = f.parent, c = f.startOffset;
            break;
          default:
            for (c = 0; f.parent; )
              f = f.parent;
        }
        if (this.options.relativeTo && (c += this.relativeToGetter(l.val)), this.offsetType.encode(s, f.pointerOffset - c), p = this.type, p == null) {
          if (!(u instanceof n))
            throw new Error("Must be a VoidPointer");
          p = u.type, u = u.value;
        }
        return f.pointers.push({
          type: p,
          val: u,
          parent: l
        }), f.pointerOffset += p.size(u, l);
      }, o;
    })(), n = /* @__PURE__ */ (function() {
      function o(s, u) {
        this.type = s, this.value = u;
      }
      return o;
    })(), e.Pointer = r, e.VoidPointer = n;
  }).call(Me);
});
ao.Pointer;
ao.VoidPointer;
var i = be(function(t, e) {
  (function() {
    var r, n, a, o;
    e.EncodeStream = w1, e.DecodeStream = io, e.Array = Ff, e.LazyArray = x1, e.Bitfield = S1, e.Boolean = A1, e.Buffer = E1, e.Enum = C1, e.Optional = I1, e.Reserved = O1, e.String = D1, e.Struct = xf, e.VersionedStruct = T1, a = ee;
    for (r in a)
      n = a[r], e[r] = n;
    o = ao;
    for (r in o)
      n = o[r], e[r] = n;
  }).call(Me);
});
i.EncodeStream;
i.DecodeStream;
i.Array;
i.LazyArray;
i.Bitfield;
i.Boolean;
i.Buffer;
i.Enum;
i.Optional;
i.Reserved;
i.String;
i.Struct;
i.VersionedStruct;
var ki = [], Hr = {
  logErrors: !1,
  registerFormat: function(e) {
    ki.push(e);
  },
  create: function(e, r) {
    for (var n = new pe.from(e), a = 0; a < ki.length; a++) {
      var o = ki[a];
      if (o.probe(n)) {
        var s = new o(new i.DecodeStream(n));
        return r ? s.getFont(r) : s;
      }
    }
    throw new Error("Unknown font format");
  }
};
function Ne(t, e, r) {
  if (r.get) {
    var n = r.get;
    r.get = function() {
      var o = n.call(this);
      return Object.defineProperty(this, e, {
        value: o
      }), o;
    };
  } else if (typeof r.value == "function") {
    var a = r.value;
    return {
      get: function() {
        var s = /* @__PURE__ */ new Map();
        function u() {
          for (var f = arguments.length, l = new Array(f), c = 0; c < f; c++)
            l[c] = arguments[c];
          var p = l.length > 0 ? l[0] : "value";
          if (s.has(p))
            return s.get(p);
          var y = a.apply(this, l);
          return s.set(p, y), y;
        }
        return Object.defineProperty(this, e, {
          value: u
        }), u;
      }
    };
  }
}
var P1 = new i.Struct({
  firstCode: i.uint16,
  entryCount: i.uint16,
  idDelta: i.int16,
  idRangeOffset: i.uint16
}), Li = new i.Struct({
  startCharCode: i.uint32,
  endCharCode: i.uint32,
  glyphID: i.uint32
}), B1 = new i.Struct({
  startUnicodeValue: i.uint24,
  additionalCount: i.uint8
}), k1 = new i.Struct({
  unicodeValue: i.uint24,
  glyphID: i.uint16
}), L1 = new i.Array(B1, i.uint32), M1 = new i.Array(k1, i.uint32), U1 = new i.Struct({
  varSelector: i.uint24,
  defaultUVS: new i.Pointer(i.uint32, L1, {
    type: "parent"
  }),
  nonDefaultUVS: new i.Pointer(i.uint32, M1, {
    type: "parent"
  })
}), N1 = new i.VersionedStruct(i.uint16, {
  0: {
    // Byte encoding
    length: i.uint16,
    // Total table length in bytes (set to 262 for format 0)
    language: i.uint16,
    // Language code for this encoding subtable, or zero if language-independent
    codeMap: new i.LazyArray(i.uint8, 256)
  },
  2: {
    // High-byte mapping (CJK)
    length: i.uint16,
    language: i.uint16,
    subHeaderKeys: new i.Array(i.uint16, 256),
    subHeaderCount: function(e) {
      return Math.max.apply(Math, e.subHeaderKeys);
    },
    subHeaders: new i.LazyArray(P1, "subHeaderCount"),
    glyphIndexArray: new i.LazyArray(i.uint16, "subHeaderCount")
  },
  4: {
    // Segment mapping to delta values
    length: i.uint16,
    // Total table length in bytes
    language: i.uint16,
    // Language code
    segCountX2: i.uint16,
    segCount: function(e) {
      return e.segCountX2 >> 1;
    },
    searchRange: i.uint16,
    entrySelector: i.uint16,
    rangeShift: i.uint16,
    endCode: new i.LazyArray(i.uint16, "segCount"),
    reservedPad: new i.Reserved(i.uint16),
    // This value should be zero
    startCode: new i.LazyArray(i.uint16, "segCount"),
    idDelta: new i.LazyArray(i.int16, "segCount"),
    idRangeOffset: new i.LazyArray(i.uint16, "segCount"),
    glyphIndexArray: new i.LazyArray(i.uint16, function(t) {
      return (t.length - t._currentOffset) / 2;
    })
  },
  6: {
    // Trimmed table
    length: i.uint16,
    language: i.uint16,
    firstCode: i.uint16,
    entryCount: i.uint16,
    glyphIndices: new i.LazyArray(i.uint16, "entryCount")
  },
  8: {
    // mixed 16-bit and 32-bit coverage
    reserved: new i.Reserved(i.uint16),
    length: i.uint32,
    language: i.uint16,
    is32: new i.LazyArray(i.uint8, 8192),
    nGroups: i.uint32,
    groups: new i.LazyArray(Li, "nGroups")
  },
  10: {
    // Trimmed Array
    reserved: new i.Reserved(i.uint16),
    length: i.uint32,
    language: i.uint32,
    firstCode: i.uint32,
    entryCount: i.uint32,
    glyphIndices: new i.LazyArray(i.uint16, "numChars")
  },
  12: {
    // Segmented coverage
    reserved: new i.Reserved(i.uint16),
    length: i.uint32,
    language: i.uint32,
    nGroups: i.uint32,
    groups: new i.LazyArray(Li, "nGroups")
  },
  13: {
    // Many-to-one range mappings (same as 12 except for group.startGlyphID)
    reserved: new i.Reserved(i.uint16),
    length: i.uint32,
    language: i.uint32,
    nGroups: i.uint32,
    groups: new i.LazyArray(Li, "nGroups")
  },
  14: {
    // Unicode Variation Sequences
    length: i.uint32,
    numRecords: i.uint32,
    varSelectors: new i.LazyArray(U1, "numRecords")
  }
}), R1 = new i.Struct({
  platformID: i.uint16,
  // Platform identifier
  encodingID: i.uint16,
  // Platform-specific encoding identifier
  table: new i.Pointer(i.uint32, N1, {
    type: "parent",
    lazy: !0
  })
}), z1 = new i.Struct({
  version: i.uint16,
  numSubtables: i.uint16,
  tables: new i.Array(R1, "numSubtables")
}), j1 = new i.Struct({
  version: i.int32,
  // 0x00010000 (version 1.0)
  revision: i.int32,
  // set by font manufacturer
  checkSumAdjustment: i.uint32,
  magicNumber: i.uint32,
  // set to 0x5F0F3CF5
  flags: i.uint16,
  unitsPerEm: i.uint16,
  // range from 64 to 16384
  created: new i.Array(i.int32, 2),
  modified: new i.Array(i.int32, 2),
  xMin: i.int16,
  // for all glyph bounding boxes
  yMin: i.int16,
  // for all glyph bounding boxes
  xMax: i.int16,
  // for all glyph bounding boxes
  yMax: i.int16,
  // for all glyph bounding boxes
  macStyle: new i.Bitfield(i.uint16, ["bold", "italic", "underline", "outline", "shadow", "condensed", "extended"]),
  lowestRecPPEM: i.uint16,
  // smallest readable size in pixels
  fontDirectionHint: i.int16,
  indexToLocFormat: i.int16,
  // 0 for short offsets, 1 for long
  glyphDataFormat: i.int16
  // 0 for current format
}), V1 = new i.Struct({
  version: i.int32,
  ascent: i.int16,
  // Distance from baseline of highest ascender
  descent: i.int16,
  // Distance from baseline of lowest descender
  lineGap: i.int16,
  // Typographic line gap
  advanceWidthMax: i.uint16,
  // Maximum advance width value in 'hmtx' table
  minLeftSideBearing: i.int16,
  // Maximum advance width value in 'hmtx' table
  minRightSideBearing: i.int16,
  // Minimum right sidebearing value
  xMaxExtent: i.int16,
  caretSlopeRise: i.int16,
  // Used to calculate the slope of the cursor (rise/run); 1 for vertical
  caretSlopeRun: i.int16,
  // 0 for vertical
  caretOffset: i.int16,
  // Set to 0 for non-slanted fonts
  reserved: new i.Reserved(i.int16, 4),
  metricDataFormat: i.int16,
  // 0 for current format
  numberOfMetrics: i.uint16
  // Number of advance widths in 'hmtx' table
}), G1 = new i.Struct({
  advance: i.uint16,
  bearing: i.int16
}), q1 = new i.Struct({
  metrics: new i.LazyArray(G1, function(t) {
    return t.parent.hhea.numberOfMetrics;
  }),
  bearings: new i.LazyArray(i.int16, function(t) {
    return t.parent.maxp.numGlyphs - t.parent.hhea.numberOfMetrics;
  })
}), H1 = new i.Struct({
  version: i.int32,
  numGlyphs: i.uint16,
  // The number of glyphs in the font
  maxPoints: i.uint16,
  // Maximum points in a non-composite glyph
  maxContours: i.uint16,
  // Maximum contours in a non-composite glyph
  maxComponentPoints: i.uint16,
  // Maximum points in a composite glyph
  maxComponentContours: i.uint16,
  // Maximum contours in a composite glyph
  maxZones: i.uint16,
  // 1 if instructions do not use the twilight zone, 2 otherwise
  maxTwilightPoints: i.uint16,
  // Maximum points used in Z0
  maxStorage: i.uint16,
  // Number of Storage Area locations
  maxFunctionDefs: i.uint16,
  // Number of FDEFs
  maxInstructionDefs: i.uint16,
  // Number of IDEFs
  maxStackElements: i.uint16,
  // Maximum stack depth
  maxSizeOfInstructions: i.uint16,
  // Maximum byte count for glyph instructions
  maxComponentElements: i.uint16,
  // Maximum number of components referenced at “top level” for any composite glyph
  maxComponentDepth: i.uint16
  // Maximum levels of recursion; 1 for simple components
});
function Sf(t, e, r) {
  return r === void 0 && (r = 0), t === 1 && Lo[r] ? Lo[r] : W1[t][e];
}
var W1 = [
  // unicode
  ["utf16be", "utf16be", "utf16be", "utf16be", "utf16be", "utf16be"],
  // macintosh
  // Mappings available at http://unicode.org/Public/MAPPINGS/VENDORS/APPLE/
  // 0	Roman                 17	Malayalam
  // 1	Japanese	            18	Sinhalese
  // 2	Traditional Chinese	  19	Burmese
  // 3	Korean	              20	Khmer
  // 4	Arabic	              21	Thai
  // 5	Hebrew	              22	Laotian
  // 6	Greek	                23	Georgian
  // 7	Russian	              24	Armenian
  // 8	RSymbol	              25	Simplified Chinese
  // 9	Devanagari	          26	Tibetan
  // 10	Gurmukhi	            27	Mongolian
  // 11	Gujarati	            28	Geez
  // 12	Oriya	                29	Slavic
  // 13	Bengali	              30	Vietnamese
  // 14	Tamil	                31	Sindhi
  // 15	Telugu	              32	(Uninterpreted)
  // 16	Kannada
  ["macroman", "shift-jis", "big5", "euc-kr", "iso-8859-6", "iso-8859-8", "macgreek", "maccyrillic", "symbol", "Devanagari", "Gurmukhi", "Gujarati", "Oriya", "Bengali", "Tamil", "Telugu", "Kannada", "Malayalam", "Sinhalese", "Burmese", "Khmer", "macthai", "Laotian", "Georgian", "Armenian", "gb-2312-80", "Tibetan", "Mongolian", "Geez", "maccenteuro", "Vietnamese", "Sindhi"],
  // ISO (deprecated)
  ["ascii"],
  // windows
  // Docs here: http://msdn.microsoft.com/en-us/library/system.text.encoding(v=vs.110).aspx
  ["symbol", "utf16be", "shift-jis", "gb18030", "big5", "wansung", "johab", null, null, null, "utf16be"]
], Lo = {
  15: "maciceland",
  17: "macturkish",
  18: "maccroatian",
  24: "maccenteuro",
  25: "maccenteuro",
  26: "maccenteuro",
  27: "maccenteuro",
  28: "maccenteuro",
  30: "maciceland",
  37: "macromania",
  38: "maccenteuro",
  39: "maccenteuro",
  40: "maccenteuro",
  143: "macinuit",
  // Unsupported by iconv-lite
  146: "macgaelic"
  // Unsupported by iconv-lite
}, X1 = [
  // unicode
  [],
  {
    // macintosh
    0: "en",
    30: "fo",
    60: "ks",
    90: "rw",
    1: "fr",
    31: "fa",
    61: "ku",
    91: "rn",
    2: "de",
    32: "ru",
    62: "sd",
    92: "ny",
    3: "it",
    33: "zh",
    63: "bo",
    93: "mg",
    4: "nl",
    34: "nl-BE",
    64: "ne",
    94: "eo",
    5: "sv",
    35: "ga",
    65: "sa",
    128: "cy",
    6: "es",
    36: "sq",
    66: "mr",
    129: "eu",
    7: "da",
    37: "ro",
    67: "bn",
    130: "ca",
    8: "pt",
    38: "cz",
    68: "as",
    131: "la",
    9: "no",
    39: "sk",
    69: "gu",
    132: "qu",
    10: "he",
    40: "si",
    70: "pa",
    133: "gn",
    11: "ja",
    41: "yi",
    71: "or",
    134: "ay",
    12: "ar",
    42: "sr",
    72: "ml",
    135: "tt",
    13: "fi",
    43: "mk",
    73: "kn",
    136: "ug",
    14: "el",
    44: "bg",
    74: "ta",
    137: "dz",
    15: "is",
    45: "uk",
    75: "te",
    138: "jv",
    16: "mt",
    46: "be",
    76: "si",
    139: "su",
    17: "tr",
    47: "uz",
    77: "my",
    140: "gl",
    18: "hr",
    48: "kk",
    78: "km",
    141: "af",
    19: "zh-Hant",
    49: "az-Cyrl",
    79: "lo",
    142: "br",
    20: "ur",
    50: "az-Arab",
    80: "vi",
    143: "iu",
    21: "hi",
    51: "hy",
    81: "id",
    144: "gd",
    22: "th",
    52: "ka",
    82: "tl",
    145: "gv",
    23: "ko",
    53: "mo",
    83: "ms",
    146: "ga",
    24: "lt",
    54: "ky",
    84: "ms-Arab",
    147: "to",
    25: "pl",
    55: "tg",
    85: "am",
    148: "el-polyton",
    26: "hu",
    56: "tk",
    86: "ti",
    149: "kl",
    27: "es",
    57: "mn-CN",
    87: "om",
    150: "az",
    28: "lv",
    58: "mn",
    88: "so",
    151: "nn",
    29: "se",
    59: "ps",
    89: "sw"
  },
  // ISO (deprecated)
  [],
  {
    // windows                                        
    1078: "af",
    16393: "en-IN",
    1159: "rw",
    1074: "tn",
    1052: "sq",
    6153: "en-IE",
    1089: "sw",
    1115: "si",
    1156: "gsw",
    8201: "en-JM",
    1111: "kok",
    1051: "sk",
    1118: "am",
    17417: "en-MY",
    1042: "ko",
    1060: "sl",
    5121: "ar-DZ",
    5129: "en-NZ",
    1088: "ky",
    11274: "es-AR",
    15361: "ar-BH",
    13321: "en-PH",
    1108: "lo",
    16394: "es-BO",
    3073: "ar",
    18441: "en-SG",
    1062: "lv",
    13322: "es-CL",
    2049: "ar-IQ",
    7177: "en-ZA",
    1063: "lt",
    9226: "es-CO",
    11265: "ar-JO",
    11273: "en-TT",
    2094: "dsb",
    5130: "es-CR",
    13313: "ar-KW",
    2057: "en-GB",
    1134: "lb",
    7178: "es-DO",
    12289: "ar-LB",
    1033: "en",
    1071: "mk",
    12298: "es-EC",
    4097: "ar-LY",
    12297: "en-ZW",
    2110: "ms-BN",
    17418: "es-SV",
    6145: "ary",
    1061: "et",
    1086: "ms",
    4106: "es-GT",
    8193: "ar-OM",
    1080: "fo",
    1100: "ml",
    18442: "es-HN",
    16385: "ar-QA",
    1124: "fil",
    1082: "mt",
    2058: "es-MX",
    1025: "ar-SA",
    1035: "fi",
    1153: "mi",
    19466: "es-NI",
    10241: "ar-SY",
    2060: "fr-BE",
    1146: "arn",
    6154: "es-PA",
    7169: "aeb",
    3084: "fr-CA",
    1102: "mr",
    15370: "es-PY",
    14337: "ar-AE",
    1036: "fr",
    1148: "moh",
    10250: "es-PE",
    9217: "ar-YE",
    5132: "fr-LU",
    1104: "mn",
    20490: "es-PR",
    1067: "hy",
    6156: "fr-MC",
    2128: "mn-CN",
    3082: "es",
    1101: "as",
    4108: "fr-CH",
    1121: "ne",
    1034: "es",
    2092: "az-Cyrl",
    1122: "fy",
    1044: "nb",
    21514: "es-US",
    1068: "az",
    1110: "gl",
    2068: "nn",
    14346: "es-UY",
    1133: "ba",
    1079: "ka",
    1154: "oc",
    8202: "es-VE",
    1069: "eu",
    3079: "de-AT",
    1096: "or",
    2077: "sv-FI",
    1059: "be",
    1031: "de",
    1123: "ps",
    1053: "sv",
    2117: "bn",
    5127: "de-LI",
    1045: "pl",
    1114: "syr",
    1093: "bn-IN",
    4103: "de-LU",
    1046: "pt",
    1064: "tg",
    8218: "bs-Cyrl",
    2055: "de-CH",
    2070: "pt-PT",
    2143: "tzm",
    5146: "bs",
    1032: "el",
    1094: "pa",
    1097: "ta",
    1150: "br",
    1135: "kl",
    1131: "qu-BO",
    1092: "tt",
    1026: "bg",
    1095: "gu",
    2155: "qu-EC",
    1098: "te",
    1027: "ca",
    1128: "ha",
    3179: "qu",
    1054: "th",
    3076: "zh-HK",
    1037: "he",
    1048: "ro",
    1105: "bo",
    5124: "zh-MO",
    1081: "hi",
    1047: "rm",
    1055: "tr",
    2052: "zh",
    1038: "hu",
    1049: "ru",
    1090: "tk",
    4100: "zh-SG",
    1039: "is",
    9275: "smn",
    1152: "ug",
    1028: "zh-TW",
    1136: "ig",
    4155: "smj-NO",
    1058: "uk",
    1155: "co",
    1057: "id",
    5179: "smj",
    1070: "hsb",
    1050: "hr",
    1117: "iu",
    3131: "se-FI",
    1056: "ur",
    4122: "hr-BA",
    2141: "iu-Latn",
    1083: "se",
    2115: "uz-Cyrl",
    1029: "cs",
    2108: "ga",
    2107: "se-SE",
    1091: "uz",
    1030: "da",
    1076: "xh",
    8251: "sms",
    1066: "vi",
    1164: "prs",
    1077: "zu",
    6203: "sma-NO",
    1106: "cy",
    1125: "dv",
    1040: "it",
    7227: "sms",
    1160: "wo",
    2067: "nl-BE",
    2064: "it-CH",
    1103: "sa",
    1157: "sah",
    1043: "nl",
    1041: "ja",
    7194: "sr-Cyrl-BA",
    1144: "ii",
    3081: "en-AU",
    1099: "kn",
    3098: "sr",
    1130: "yo",
    10249: "en-BZ",
    1087: "kk",
    6170: "sr-Latn-BA",
    4105: "en-CA",
    1107: "km",
    2074: "sr-Latn",
    9225: "en-029",
    1158: "quc",
    1132: "nso"
  }
];
function Y1(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = K1(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function K1(t, e) {
  if (t) {
    if (typeof t == "string") return Mo(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Mo(t, e);
  }
}
function Mo(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
var Uo = new i.Struct({
  platformID: i.uint16,
  encodingID: i.uint16,
  languageID: i.uint16,
  nameID: i.uint16,
  length: i.uint16,
  string: new i.Pointer(i.uint16, new i.String("length", function(t) {
    return Sf(t.platformID, t.encodingID, t.languageID);
  }), {
    type: "parent",
    relativeTo: "parent.stringOffset",
    allowNull: !1
  })
}), Z1 = new i.Struct({
  length: i.uint16,
  tag: new i.Pointer(i.uint16, new i.String("length", "utf16be"), {
    type: "parent",
    relativeTo: "stringOffset"
  })
}), Vn = new i.VersionedStruct(i.uint16, {
  0: {
    count: i.uint16,
    stringOffset: i.uint16,
    records: new i.Array(Uo, "count")
  },
  1: {
    count: i.uint16,
    stringOffset: i.uint16,
    records: new i.Array(Uo, "count"),
    langTagCount: i.uint16,
    langTags: new i.Array(Z1, "langTagCount")
  }
}), pa = [
  "copyright",
  "fontFamily",
  "fontSubfamily",
  "uniqueSubfamily",
  "fullName",
  "version",
  "postscriptName",
  // Note: A font may have only one PostScript name and that name must be ASCII.
  "trademark",
  "manufacturer",
  "designer",
  "description",
  "vendorURL",
  "designerURL",
  "license",
  "licenseURL",
  null,
  // reserved
  "preferredFamily",
  "preferredSubfamily",
  "compatibleFull",
  "sampleText",
  "postscriptCIDFontName",
  "wwsFamilyName",
  "wwsSubfamilyName"
];
Vn.process = function(t) {
  for (var e = {}, r = Y1(this.records), n; !(n = r()).done; ) {
    var a = n.value, o = X1[a.platformID][a.languageID];
    o == null && this.langTags != null && a.languageID >= 32768 && (o = this.langTags[a.languageID - 32768].tag), o == null && (o = a.platformID + "-" + a.languageID);
    var s = a.nameID >= 256 ? "fontFeatures" : pa[a.nameID] || a.nameID;
    e[s] == null && (e[s] = {});
    var u = e[s];
    a.nameID >= 256 && (u = u[a.nameID] || (u[a.nameID] = {})), (typeof a.string == "string" || typeof u[o] != "string") && (u[o] = a.string);
  }
  this.records = e;
};
Vn.preEncode = function() {
  if (!Array.isArray(this.records)) {
    this.version = 0;
    var t = [];
    for (var e in this.records) {
      var r = this.records[e];
      e !== "fontFeatures" && (t.push({
        platformID: 3,
        encodingID: 1,
        languageID: 1033,
        nameID: pa.indexOf(e),
        length: pe.byteLength(r.en, "utf16le"),
        string: r.en
      }), e === "postscriptName" && t.push({
        platformID: 1,
        encodingID: 0,
        languageID: 0,
        nameID: pa.indexOf(e),
        length: r.en.length,
        string: r.en
      }));
    }
    this.records = t, this.count = t.length, this.stringOffset = Vn.size(this, null, !1);
  }
};
var Af = new i.VersionedStruct(i.uint16, {
  header: {
    xAvgCharWidth: i.int16,
    // average weighted advance width of lower case letters and space
    usWeightClass: i.uint16,
    // visual weight of stroke in glyphs
    usWidthClass: i.uint16,
    // relative change from the normal aspect ratio (width to height ratio)
    fsType: new i.Bitfield(i.uint16, [
      // Indicates font embedding licensing rights
      null,
      "noEmbedding",
      "viewOnly",
      "editable",
      null,
      null,
      null,
      null,
      "noSubsetting",
      "bitmapOnly"
    ]),
    ySubscriptXSize: i.int16,
    // recommended horizontal size in pixels for subscripts
    ySubscriptYSize: i.int16,
    // recommended vertical size in pixels for subscripts
    ySubscriptXOffset: i.int16,
    // recommended horizontal offset for subscripts
    ySubscriptYOffset: i.int16,
    // recommended vertical offset form the baseline for subscripts
    ySuperscriptXSize: i.int16,
    // recommended horizontal size in pixels for superscripts
    ySuperscriptYSize: i.int16,
    // recommended vertical size in pixels for superscripts
    ySuperscriptXOffset: i.int16,
    // recommended horizontal offset for superscripts
    ySuperscriptYOffset: i.int16,
    // recommended vertical offset from the baseline for superscripts
    yStrikeoutSize: i.int16,
    // width of the strikeout stroke
    yStrikeoutPosition: i.int16,
    // position of the strikeout stroke relative to the baseline
    sFamilyClass: i.int16,
    // classification of font-family design
    panose: new i.Array(i.uint8, 10),
    // describe the visual characteristics of a given typeface
    ulCharRange: new i.Array(i.uint32, 4),
    vendorID: new i.String(4),
    // four character identifier for the font vendor
    fsSelection: new i.Bitfield(i.uint16, [
      // bit field containing information about the font
      "italic",
      "underscore",
      "negative",
      "outlined",
      "strikeout",
      "bold",
      "regular",
      "useTypoMetrics",
      "wws",
      "oblique"
    ]),
    usFirstCharIndex: i.uint16,
    // The minimum Unicode index in this font
    usLastCharIndex: i.uint16
    // The maximum Unicode index in this font
  },
  // The Apple version of this table ends here, but the Microsoft one continues on...
  0: {},
  1: {
    typoAscender: i.int16,
    typoDescender: i.int16,
    typoLineGap: i.int16,
    winAscent: i.uint16,
    winDescent: i.uint16,
    codePageRange: new i.Array(i.uint32, 2)
  },
  2: {
    // these should be common with version 1 somehow
    typoAscender: i.int16,
    typoDescender: i.int16,
    typoLineGap: i.int16,
    winAscent: i.uint16,
    winDescent: i.uint16,
    codePageRange: new i.Array(i.uint32, 2),
    xHeight: i.int16,
    capHeight: i.int16,
    defaultChar: i.uint16,
    breakChar: i.uint16,
    maxContent: i.uint16
  },
  5: {
    typoAscender: i.int16,
    typoDescender: i.int16,
    typoLineGap: i.int16,
    winAscent: i.uint16,
    winDescent: i.uint16,
    codePageRange: new i.Array(i.uint32, 2),
    xHeight: i.int16,
    capHeight: i.int16,
    defaultChar: i.uint16,
    breakChar: i.uint16,
    maxContent: i.uint16,
    usLowerOpticalPointSize: i.uint16,
    usUpperOpticalPointSize: i.uint16
  }
}), Mi = Af.versions;
Mi[3] = Mi[4] = Mi[2];
var J1 = new i.VersionedStruct(i.fixed32, {
  header: {
    // these fields exist at the top of all versions
    italicAngle: i.fixed32,
    // Italic angle in counter-clockwise degrees from the vertical.
    underlinePosition: i.int16,
    // Suggested distance of the top of the underline from the baseline
    underlineThickness: i.int16,
    // Suggested values for the underline thickness
    isFixedPitch: i.uint32,
    // Whether the font is monospaced
    minMemType42: i.uint32,
    // Minimum memory usage when a TrueType font is downloaded as a Type 42 font
    maxMemType42: i.uint32,
    // Maximum memory usage when a TrueType font is downloaded as a Type 42 font
    minMemType1: i.uint32,
    // Minimum memory usage when a TrueType font is downloaded as a Type 1 font
    maxMemType1: i.uint32
    // Maximum memory usage when a TrueType font is downloaded as a Type 1 font
  },
  1: {},
  // version 1 has no additional fields
  2: {
    numberOfGlyphs: i.uint16,
    glyphNameIndex: new i.Array(i.uint16, "numberOfGlyphs"),
    names: new i.Array(new i.String(i.uint8))
  },
  2.5: {
    numberOfGlyphs: i.uint16,
    offsets: new i.Array(i.uint8, "numberOfGlyphs")
  },
  3: {},
  // version 3 has no additional fields
  4: {
    map: new i.Array(i.uint32, function(t) {
      return t.parent.maxp.numGlyphs;
    })
  }
}), Q1 = new i.Struct({
  controlValues: new i.Array(i.int16)
}), _1 = new i.Struct({
  instructions: new i.Array(i.uint8)
}), oo = new i.VersionedStruct("head.indexToLocFormat", {
  0: {
    offsets: new i.Array(i.uint16)
  },
  1: {
    offsets: new i.Array(i.uint32)
  }
});
oo.process = function() {
  if (this.version === 0)
    for (var t = 0; t < this.offsets.length; t++)
      this.offsets[t] <<= 1;
};
oo.preEncode = function() {
  if (this.version == null && (this.version = this.offsets[this.offsets.length - 1] > 65535 ? 1 : 0, this.version === 0))
    for (var t = 0; t < this.offsets.length; t++)
      this.offsets[t] >>>= 1;
};
var $1 = new i.Struct({
  controlValueProgram: new i.Array(i.uint8)
}), e0 = new i.Array(new i.Buffer());
function No(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = t0(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function t0(t, e) {
  if (t) {
    if (typeof t == "string") return Ro(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Ro(t, e);
  }
}
function Ro(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
var lt = /* @__PURE__ */ (function() {
  function t(r) {
    this.type = r;
  }
  var e = t.prototype;
  return e.getCFFVersion = function(n) {
    for (; n && !n.hdrSize; )
      n = n.parent;
    return n ? n.version : -1;
  }, e.decode = function(n, a) {
    var o = this.getCFFVersion(a), s = o >= 2 ? n.readUInt32BE() : n.readUInt16BE();
    if (s === 0)
      return [];
    var u = n.readUInt8(), f;
    if (u === 1)
      f = i.uint8;
    else if (u === 2)
      f = i.uint16;
    else if (u === 3)
      f = i.uint24;
    else if (u === 4)
      f = i.uint32;
    else
      throw new Error("Bad offset size in CFFIndex: " + u + " " + n.pos);
    for (var l = [], c = n.pos + (s + 1) * u - 1, p = f.decode(n), y = 0; y < s; y++) {
      var v = f.decode(n);
      if (this.type != null) {
        var m = n.pos;
        n.pos = c + p, a.length = v - p, l.push(this.type.decode(n, a)), n.pos = m;
      } else
        l.push({
          offset: c + p,
          length: v - p
        });
      p = v;
    }
    return n.pos = c + p, l;
  }, e.size = function(n, a) {
    var o = 2;
    if (n.length === 0)
      return o;
    for (var s = this.type || new i.Buffer(), u = 1, f = 0; f < n.length; f++) {
      var l = n[f];
      u += s.size(l, a);
    }
    var c;
    if (u <= 255)
      c = i.uint8;
    else if (u <= 65535)
      c = i.uint16;
    else if (u <= 16777215)
      c = i.uint24;
    else if (u <= 4294967295)
      c = i.uint32;
    else
      throw new Error("Bad offset in CFFIndex");
    return o += 1 + c.size() * (n.length + 1), o += u - 1, o;
  }, e.encode = function(n, a, o) {
    if (n.writeUInt16BE(a.length), a.length !== 0) {
      for (var s = this.type || new i.Buffer(), u = [], f = 1, l = No(a), c; !(c = l()).done; ) {
        var p = c.value, y = s.size(p, o);
        u.push(y), f += y;
      }
      var v;
      if (f <= 255)
        v = i.uint8;
      else if (f <= 65535)
        v = i.uint16;
      else if (f <= 16777215)
        v = i.uint24;
      else if (f <= 4294967295)
        v = i.uint32;
      else
        throw new Error("Bad offset in CFFIndex");
      n.writeUInt8(v.size()), f = 1, v.encode(n, f);
      for (var m = 0, w = u; m < w.length; m++) {
        var F = w[m];
        f += F, v.encode(n, f);
      }
      for (var S = No(a), I; !(I = S()).done; ) {
        var A = I.value;
        s.encode(n, A, o);
      }
    }
  }, t;
})(), zo = Object.prototype.toString, Ef = function(e) {
  var r = zo.call(e), n = r === "[object Arguments]";
  return n || (n = r !== "[object Array]" && e !== null && typeof e == "object" && typeof e.length == "number" && e.length >= 0 && zo.call(e.callee) === "[object Function]"), n;
}, Cf;
if (!Object.keys) {
  var Fn = Object.prototype.hasOwnProperty, jo = Object.prototype.toString, r0 = Ef, Vo = Object.prototype.propertyIsEnumerable, n0 = !Vo.call({
    toString: null
  }, "toString"), i0 = Vo.call(function() {
  }, "prototype"), xn = ["toString", "toLocaleString", "valueOf", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "constructor"], Ui = function(e) {
    var r = e.constructor;
    return r && r.prototype === e;
  }, a0 = {
    $applicationCache: !0,
    $console: !0,
    $external: !0,
    $frame: !0,
    $frameElement: !0,
    $frames: !0,
    $innerHeight: !0,
    $innerWidth: !0,
    $onmozfullscreenchange: !0,
    $onmozfullscreenerror: !0,
    $outerHeight: !0,
    $outerWidth: !0,
    $pageXOffset: !0,
    $pageYOffset: !0,
    $parent: !0,
    $scrollLeft: !0,
    $scrollTop: !0,
    $scrollX: !0,
    $scrollY: !0,
    $self: !0,
    $webkitIndexedDB: !0,
    $webkitStorageInfo: !0,
    $window: !0
  }, o0 = (function() {
    if (typeof window > "u")
      return !1;
    for (var t in window)
      try {
        if (!a0["$" + t] && Fn.call(window, t) && window[t] !== null && typeof window[t] == "object")
          try {
            Ui(window[t]);
          } catch {
            return !0;
          }
      } catch {
        return !0;
      }
    return !1;
  })(), s0 = function(e) {
    if (typeof window > "u" || !o0)
      return Ui(e);
    try {
      return Ui(e);
    } catch {
      return !1;
    }
  };
  Cf = function(e) {
    var r = e !== null && typeof e == "object", n = jo.call(e) === "[object Function]", a = r0(e), o = r && jo.call(e) === "[object String]", s = [];
    if (!r && !n && !a)
      throw new TypeError("Object.keys called on a non-object");
    var u = i0 && n;
    if (o && e.length > 0 && !Fn.call(e, 0))
      for (var f = 0; f < e.length; ++f)
        s.push(String(f));
    if (a && e.length > 0)
      for (var l = 0; l < e.length; ++l)
        s.push(String(l));
    else
      for (var c in e)
        !(u && c === "prototype") && Fn.call(e, c) && s.push(String(c));
    if (n0)
      for (var p = s0(e), y = 0; y < xn.length; ++y)
        !(p && xn[y] === "constructor") && Fn.call(e, xn[y]) && s.push(xn[y]);
    return s;
  };
}
var u0 = Cf, f0 = Array.prototype.slice, Go = Object.keys, kn = Go ? function(e) {
  return Go(e);
} : u0, qo = Object.keys;
kn.shim = function() {
  if (Object.keys) {
    var e = (function() {
      var r = Object.keys(arguments);
      return r && r.length === arguments.length;
    })(1, 2);
    e || (Object.keys = function(n) {
      return Ef(n) ? qo(f0.call(n)) : qo(n);
    });
  } else
    Object.keys = kn;
  return Object.keys || kn;
};
var da = kn, l0 = typeof Symbol == "function" && typeof Symbol.toStringTag == "symbol", va = Object.prototype.toString, si = function(e) {
  return l0 && e && typeof e == "object" && Symbol.toStringTag in e ? !1 : va.call(e) === "[object Arguments]";
}, If = function(e) {
  return si(e) ? !0 : e !== null && typeof e == "object" && typeof e.length == "number" && e.length >= 0 && va.call(e) !== "[object Array]" && va.call(e.callee) === "[object Function]";
}, c0 = (function() {
  return si(arguments);
})();
si.isLegacyArguments = If;
var Ho = c0 ? si : If, h0 = typeof Symbol == "function" && typeof /* @__PURE__ */ Symbol("foo") == "symbol", p0 = Object.prototype.toString, d0 = Array.prototype.concat, so = Object.defineProperty, v0 = function(e) {
  return typeof e == "function" && p0.call(e) === "[object Function]";
}, y0 = function() {
  var e = {};
  try {
    so(e, "x", {
      enumerable: !1,
      value: e
    });
    for (var r in e)
      return !1;
    return e.x === e;
  } catch {
    return !1;
  }
}, Of = so && y0(), g0 = function(e, r, n, a) {
  r in e && (!v0(a) || !a()) || (Of ? so(e, r, {
    configurable: !0,
    enumerable: !1,
    value: n,
    writable: !0
  }) : e[r] = n);
}, Df = function(e, r) {
  var n = arguments.length > 2 ? arguments[2] : {}, a = da(r);
  h0 && (a = d0.call(a, Object.getOwnPropertySymbols(r)));
  for (var o = 0; o < a.length; o += 1)
    g0(e, a[o], r[a[o]], n[a[o]]);
};
Df.supportsDescriptors = !!Of;
var vn = Df, m0 = "Function.prototype.bind called on incompatible ", Ni = Array.prototype.slice, b0 = Object.prototype.toString, w0 = "[object Function]", F0 = function(e) {
  var r = this;
  if (typeof r != "function" || b0.call(r) !== w0)
    throw new TypeError(m0 + r);
  for (var n = Ni.call(arguments, 1), a, o = function() {
    if (this instanceof a) {
      var p = r.apply(this, n.concat(Ni.call(arguments)));
      return Object(p) === p ? p : this;
    } else
      return r.apply(e, n.concat(Ni.call(arguments)));
  }, s = Math.max(0, r.length - n.length), u = [], f = 0; f < s; f++)
    u.push("$" + f);
  if (a = Function("binder", "return function (" + u.join(",") + "){ return binder.apply(this,arguments); }")(o), r.prototype) {
    var l = function() {
    };
    l.prototype = r.prototype, a.prototype = new l(), l.prototype = null;
  }
  return a;
}, ui = Function.prototype.bind || F0, x0 = function() {
  if (typeof Symbol != "function" || typeof Object.getOwnPropertySymbols != "function")
    return !1;
  if (typeof Symbol.iterator == "symbol")
    return !0;
  var e = {}, r = /* @__PURE__ */ Symbol("test"), n = Object(r);
  if (typeof r == "string" || Object.prototype.toString.call(r) !== "[object Symbol]" || Object.prototype.toString.call(n) !== "[object Symbol]")
    return !1;
  var a = 42;
  e[r] = a;
  for (r in e)
    return !1;
  if (typeof Object.keys == "function" && Object.keys(e).length !== 0 || typeof Object.getOwnPropertyNames == "function" && Object.getOwnPropertyNames(e).length !== 0)
    return !1;
  var o = Object.getOwnPropertySymbols(e);
  if (o.length !== 1 || o[0] !== r || !Object.prototype.propertyIsEnumerable.call(e, r))
    return !1;
  if (typeof Object.getOwnPropertyDescriptor == "function") {
    var s = Object.getOwnPropertyDescriptor(e, r);
    if (s.value !== a || s.enumerable !== !0)
      return !1;
  }
  return !0;
}, Wo = Me.Symbol, S0 = function() {
  return typeof Wo != "function" || typeof Symbol != "function" || typeof Wo("foo") != "symbol" || typeof /* @__PURE__ */ Symbol("bar") != "symbol" ? !1 : x0();
}, k, on = TypeError, fr = Object.getOwnPropertyDescriptor;
if (fr)
  try {
    fr({}, "");
  } catch {
    fr = null;
  }
var Ri = function() {
  throw new on();
}, A0 = fr ? (function() {
  try {
    return arguments.callee, Ri;
  } catch {
    try {
      return fr(arguments, "callee").get;
    } catch {
      return Ri;
    }
  }
})() : Ri, _t = S0(), rr = Object.getPrototypeOf || function(t) {
  return t.__proto__;
}, E0 = k, C0 = k, I0 = k, zi = typeof Uint8Array > "u" ? k : rr(Uint8Array), ji = {
  "%Array%": Array,
  "%ArrayBuffer%": typeof ArrayBuffer > "u" ? k : ArrayBuffer,
  "%ArrayBufferPrototype%": typeof ArrayBuffer > "u" ? k : ArrayBuffer.prototype,
  "%ArrayIteratorPrototype%": _t ? rr([][Symbol.iterator]()) : k,
  "%ArrayPrototype%": Array.prototype,
  "%ArrayProto_entries%": Array.prototype.entries,
  "%ArrayProto_forEach%": Array.prototype.forEach,
  "%ArrayProto_keys%": Array.prototype.keys,
  "%ArrayProto_values%": Array.prototype.values,
  "%AsyncFromSyncIteratorPrototype%": k,
  "%AsyncFunction%": C0,
  "%AsyncFunctionPrototype%": k,
  "%AsyncGenerator%": k,
  "%AsyncGeneratorFunction%": I0,
  "%AsyncGeneratorPrototype%": k,
  "%AsyncIteratorPrototype%": k,
  "%Atomics%": typeof Atomics > "u" ? k : Atomics,
  "%Boolean%": Boolean,
  "%BooleanPrototype%": Boolean.prototype,
  "%DataView%": typeof DataView > "u" ? k : DataView,
  "%DataViewPrototype%": typeof DataView > "u" ? k : DataView.prototype,
  "%Date%": Date,
  "%DatePrototype%": Date.prototype,
  "%decodeURI%": decodeURI,
  "%decodeURIComponent%": decodeURIComponent,
  "%encodeURI%": encodeURI,
  "%encodeURIComponent%": encodeURIComponent,
  "%Error%": Error,
  "%ErrorPrototype%": Error.prototype,
  "%eval%": eval,
  // eslint-disable-line no-eval
  "%EvalError%": EvalError,
  "%EvalErrorPrototype%": EvalError.prototype,
  "%Float32Array%": typeof Float32Array > "u" ? k : Float32Array,
  "%Float32ArrayPrototype%": typeof Float32Array > "u" ? k : Float32Array.prototype,
  "%Float64Array%": typeof Float64Array > "u" ? k : Float64Array,
  "%Float64ArrayPrototype%": typeof Float64Array > "u" ? k : Float64Array.prototype,
  "%Function%": Function,
  "%FunctionPrototype%": Function.prototype,
  "%Generator%": k,
  "%GeneratorFunction%": E0,
  "%GeneratorPrototype%": k,
  "%Int8Array%": typeof Int8Array > "u" ? k : Int8Array,
  "%Int8ArrayPrototype%": typeof Int8Array > "u" ? k : Int8Array.prototype,
  "%Int16Array%": typeof Int16Array > "u" ? k : Int16Array,
  "%Int16ArrayPrototype%": typeof Int16Array > "u" ? k : Int8Array.prototype,
  "%Int32Array%": typeof Int32Array > "u" ? k : Int32Array,
  "%Int32ArrayPrototype%": typeof Int32Array > "u" ? k : Int32Array.prototype,
  "%isFinite%": isFinite,
  "%isNaN%": isNaN,
  "%IteratorPrototype%": _t ? rr(rr([][Symbol.iterator]())) : k,
  "%JSON%": typeof JSON == "object" ? JSON : k,
  "%JSONParse%": typeof JSON == "object" ? JSON.parse : k,
  "%Map%": typeof Map > "u" ? k : Map,
  "%MapIteratorPrototype%": typeof Map > "u" || !_t ? k : rr((/* @__PURE__ */ new Map())[Symbol.iterator]()),
  "%MapPrototype%": typeof Map > "u" ? k : Map.prototype,
  "%Math%": Math,
  "%Number%": Number,
  "%NumberPrototype%": Number.prototype,
  "%Object%": Object,
  "%ObjectPrototype%": Object.prototype,
  "%ObjProto_toString%": Object.prototype.toString,
  "%ObjProto_valueOf%": Object.prototype.valueOf,
  "%parseFloat%": parseFloat,
  "%parseInt%": parseInt,
  "%Promise%": typeof Promise > "u" ? k : Promise,
  "%PromisePrototype%": typeof Promise > "u" ? k : Promise.prototype,
  "%PromiseProto_then%": typeof Promise > "u" ? k : Promise.prototype.then,
  "%Promise_all%": typeof Promise > "u" ? k : Promise.all,
  "%Promise_reject%": typeof Promise > "u" ? k : Promise.reject,
  "%Promise_resolve%": typeof Promise > "u" ? k : Promise.resolve,
  "%Proxy%": typeof Proxy > "u" ? k : Proxy,
  "%RangeError%": RangeError,
  "%RangeErrorPrototype%": RangeError.prototype,
  "%ReferenceError%": ReferenceError,
  "%ReferenceErrorPrototype%": ReferenceError.prototype,
  "%Reflect%": typeof Reflect > "u" ? k : Reflect,
  "%RegExp%": RegExp,
  "%RegExpPrototype%": RegExp.prototype,
  "%Set%": typeof Set > "u" ? k : Set,
  "%SetIteratorPrototype%": typeof Set > "u" || !_t ? k : rr((/* @__PURE__ */ new Set())[Symbol.iterator]()),
  "%SetPrototype%": typeof Set > "u" ? k : Set.prototype,
  "%SharedArrayBuffer%": typeof SharedArrayBuffer > "u" ? k : SharedArrayBuffer,
  "%SharedArrayBufferPrototype%": typeof SharedArrayBuffer > "u" ? k : SharedArrayBuffer.prototype,
  "%String%": String,
  "%StringIteratorPrototype%": _t ? rr(""[Symbol.iterator]()) : k,
  "%StringPrototype%": String.prototype,
  "%Symbol%": _t ? Symbol : k,
  "%SymbolPrototype%": _t ? Symbol.prototype : k,
  "%SyntaxError%": SyntaxError,
  "%SyntaxErrorPrototype%": SyntaxError.prototype,
  "%ThrowTypeError%": A0,
  "%TypedArray%": zi,
  "%TypedArrayPrototype%": zi ? zi.prototype : k,
  "%TypeError%": on,
  "%TypeErrorPrototype%": on.prototype,
  "%Uint8Array%": typeof Uint8Array > "u" ? k : Uint8Array,
  "%Uint8ArrayPrototype%": typeof Uint8Array > "u" ? k : Uint8Array.prototype,
  "%Uint8ClampedArray%": typeof Uint8ClampedArray > "u" ? k : Uint8ClampedArray,
  "%Uint8ClampedArrayPrototype%": typeof Uint8ClampedArray > "u" ? k : Uint8ClampedArray.prototype,
  "%Uint16Array%": typeof Uint16Array > "u" ? k : Uint16Array,
  "%Uint16ArrayPrototype%": typeof Uint16Array > "u" ? k : Uint16Array.prototype,
  "%Uint32Array%": typeof Uint32Array > "u" ? k : Uint32Array,
  "%Uint32ArrayPrototype%": typeof Uint32Array > "u" ? k : Uint32Array.prototype,
  "%URIError%": URIError,
  "%URIErrorPrototype%": URIError.prototype,
  "%WeakMap%": typeof WeakMap > "u" ? k : WeakMap,
  "%WeakMapPrototype%": typeof WeakMap > "u" ? k : WeakMap.prototype,
  "%WeakSet%": typeof WeakSet > "u" ? k : WeakSet,
  "%WeakSetPrototype%": typeof WeakSet > "u" ? k : WeakSet.prototype
}, Xo = ui.call(Function.call, String.prototype.replace), O0 = /[^%.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|%$))/g, D0 = /\\(\\)?/g, T0 = function(e) {
  var r = [];
  return Xo(e, O0, function(n, a, o, s) {
    r[r.length] = o ? Xo(s, D0, "$1") : a || n;
  }), r;
}, P0 = function(e, r) {
  if (!(e in ji))
    throw new SyntaxError("intrinsic " + e + " does not exist!");
  if (typeof ji[e] > "u")
    throw new on("intrinsic " + e + " exists, but is not available. Please file an issue!");
  return ji[e];
}, B0 = function(e, r) {
  if (e.length === 0)
    throw new TypeError("intrinsic name must be a non-empty string");
  if (arguments.length > 1 && typeof r != "boolean")
    throw new TypeError('"allowMissing" argument must be a boolean');
  for (var n = T0(e), a = P0("%" + (n.length > 0 ? n[0] : "") + "%"), o = 1; o < n.length; o += 1)
    if (a != null)
      if (fr && o + 1 >= n.length) {
        var s = fr(a, n[o]);
        if (!(n[o] in a))
          throw new on("base intrinsic for " + e + " exists, but the property is not available.");
        a = s ? s.get || s.value : a[n[o]];
      } else
        a = a[n[o]];
  return a;
}, Tf = B0("%Function%"), k0 = Tf.apply, L0 = Tf.call, uo = function() {
  return ui.apply(L0, arguments);
}, M0 = function() {
  return ui.apply(k0, arguments);
};
uo.apply = M0;
var Yo = function(e) {
  return e !== e;
}, Pf = function(e, r) {
  return e === 0 && r === 0 ? 1 / e === 1 / r : !!(e === r || Yo(e) && Yo(r));
}, fo = function() {
  return typeof Object.is == "function" ? Object.is : Pf;
}, U0 = function() {
  var e = fo();
  return vn(Object, {
    is: e
  }, {
    is: function() {
      return Object.is !== e;
    }
  }), e;
}, Bf = uo(fo(), Object);
vn(Bf, {
  getPolyfill: fo,
  implementation: Pf,
  shim: U0
});
var Ko = Bf, N0 = ui.call(Function.call, Object.prototype.hasOwnProperty), R0 = RegExp.prototype.exec, z0 = Object.getOwnPropertyDescriptor, j0 = function(e) {
  try {
    var r = e.lastIndex;
    return e.lastIndex = 0, R0.call(e), !0;
  } catch {
    return !1;
  } finally {
    e.lastIndex = r;
  }
}, V0 = Object.prototype.toString, G0 = "[object RegExp]", q0 = typeof Symbol == "function" && typeof Symbol.toStringTag == "symbol", Zo = function(e) {
  if (!e || typeof e != "object")
    return !1;
  if (!q0)
    return V0.call(e) === G0;
  var r = z0(e, "lastIndex"), n = r && N0(r, "value");
  return n ? j0(e) : !1;
}, H0 = Object, W0 = TypeError, lo = function() {
  if (this != null && this !== H0(this))
    throw new W0("RegExp.prototype.flags getter called on non-object");
  var e = "";
  return this.global && (e += "g"), this.ignoreCase && (e += "i"), this.multiline && (e += "m"), this.dotAll && (e += "s"), this.unicode && (e += "u"), this.sticky && (e += "y"), e;
}, X0 = vn.supportsDescriptors, Y0 = Object.getOwnPropertyDescriptor, K0 = TypeError, kf = function() {
  if (!X0)
    throw new K0("RegExp.prototype.flags requires a true ES5 environment that supports property descriptors");
  if (/a/mig.flags === "gim") {
    var e = Y0(RegExp.prototype, "flags");
    if (e && typeof e.get == "function" && typeof /a/.dotAll == "boolean")
      return e.get;
  }
  return lo;
}, Z0 = vn.supportsDescriptors, J0 = Object.getOwnPropertyDescriptor, Q0 = Object.defineProperty, _0 = TypeError, Jo = Object.getPrototypeOf, $0 = /a/, ep = function() {
  if (!Z0 || !Jo)
    throw new _0("RegExp.prototype.flags requires a true ES5 environment that supports property descriptors");
  var e = kf(), r = Jo($0), n = J0(r, "flags");
  return (!n || n.get !== e) && Q0(r, "flags", {
    configurable: !0,
    enumerable: !1,
    get: e
  }), e;
}, Lf = uo(lo);
vn(Lf, {
  getPolyfill: kf,
  implementation: lo,
  shim: ep
});
var Qo = Lf, tp = Date.prototype.getDay, rp = function(e) {
  try {
    return tp.call(e), !0;
  } catch {
    return !1;
  }
}, np = Object.prototype.toString, ip = "[object Date]", ap = typeof Symbol == "function" && typeof Symbol.toStringTag == "symbol", _o = function(e) {
  return typeof e != "object" || e === null ? !1 : ap ? rp(e) : np.call(e) === ip;
}, $o = Date.prototype.getTime;
function Mf(t, e, r) {
  var n = r || {};
  return (n.strict ? Ko(t, e) : t === e) ? !0 : !t || !e || typeof t != "object" && typeof e != "object" ? n.strict ? Ko(t, e) : t == e : op(t, e, n);
}
function es(t) {
  return t == null;
}
function ts(t) {
  return !(!t || typeof t != "object" || typeof t.length != "number" || typeof t.copy != "function" || typeof t.slice != "function" || t.length > 0 && typeof t[0] != "number");
}
function op(t, e, r) {
  var n, a;
  if (typeof t != typeof e || es(t) || es(e) || t.prototype !== e.prototype || Ho(t) !== Ho(e))
    return !1;
  var o = Zo(t), s = Zo(e);
  if (o !== s)
    return !1;
  if (o || s)
    return t.source === e.source && Qo(t) === Qo(e);
  if (_o(t) && _o(e))
    return $o.call(t) === $o.call(e);
  var u = ts(t), f = ts(e);
  if (u !== f)
    return !1;
  if (u || f) {
    if (t.length !== e.length)
      return !1;
    for (n = 0; n < t.length; n++)
      if (t[n] !== e[n])
        return !1;
    return !0;
  }
  if (typeof t != typeof e)
    return !1;
  try {
    var l = da(t), c = da(e);
  } catch {
    return !1;
  }
  if (l.length !== c.length)
    return !1;
  for (l.sort(), c.sort(), n = l.length - 1; n >= 0; n--)
    if (l[n] != c[n])
      return !1;
  for (n = l.length - 1; n >= 0; n--)
    if (a = l[n], !Mf(t[a], e[a], r))
      return !1;
  return !0;
}
var rs = Mf, Wr = 15, ns = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", ".", "E", "E-", null, "-"], is = {
  ".": 10,
  E: 11,
  "E-": 12,
  "-": 14
}, Vi = /* @__PURE__ */ (function() {
  function t() {
  }
  return t.decode = function(r, n) {
    if (32 <= n && n <= 246)
      return n - 139;
    if (247 <= n && n <= 250)
      return (n - 247) * 256 + r.readUInt8() + 108;
    if (251 <= n && n <= 254)
      return -(n - 251) * 256 - r.readUInt8() - 108;
    if (n === 28)
      return r.readInt16BE();
    if (n === 29)
      return r.readInt32BE();
    if (n === 30) {
      for (var a = ""; ; ) {
        var o = r.readUInt8(), s = o >> 4;
        if (s === Wr)
          break;
        a += ns[s];
        var u = o & 15;
        if (u === Wr)
          break;
        a += ns[u];
      }
      return parseFloat(a);
    }
    return null;
  }, t.size = function(r) {
    if (r.forceLarge && (r = 32768), (r | 0) !== r) {
      var n = "" + r;
      return 1 + Math.ceil((n.length + 1) / 2);
    } else return -107 <= r && r <= 107 ? 1 : 108 <= r && r <= 1131 || -1131 <= r && r <= -108 ? 2 : -32768 <= r && r <= 32767 ? 3 : 5;
  }, t.encode = function(r, n) {
    var a = Number(n);
    if (n.forceLarge)
      return r.writeUInt8(29), r.writeInt32BE(a);
    if ((a | 0) !== a) {
      r.writeUInt8(30);
      for (var o = "" + a, s = 0; s < o.length; s += 2) {
        var u = o[s], f = is[u] || +u;
        if (s === o.length - 1)
          var l = Wr;
        else
          var c = o[s + 1], l = is[c] || +c;
        r.writeUInt8(f << 4 | l & 15);
      }
      if (l !== Wr)
        return r.writeUInt8(Wr << 4);
    } else return -107 <= a && a <= 107 ? r.writeUInt8(a + 139) : 108 <= a && a <= 1131 ? (a -= 108, r.writeUInt8((a >> 8) + 247), r.writeUInt8(a & 255)) : -1131 <= a && a <= -108 ? (a = -a - 108, r.writeUInt8((a >> 8) + 251), r.writeUInt8(a & 255)) : -32768 <= a && a <= 32767 ? (r.writeUInt8(28), r.writeInt16BE(a)) : (r.writeUInt8(29), r.writeInt32BE(a));
  }, t;
})();
function Xr(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = sp(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function sp(t, e) {
  if (t) {
    if (typeof t == "string") return as(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return as(t, e);
  }
}
function as(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
var fi = /* @__PURE__ */ (function() {
  function t(r) {
    r === void 0 && (r = []), this.ops = r, this.fields = {};
    for (var n = Xr(r), a; !(a = n()).done; ) {
      var o = a.value, s = Array.isArray(o[0]) ? o[0][0] << 8 | o[0][1] : o[0];
      this.fields[s] = o;
    }
  }
  var e = t.prototype;
  return e.decodeOperands = function(n, a, o, s) {
    var u = this;
    if (Array.isArray(n))
      return s.map(function(f, l) {
        return u.decodeOperands(n[l], a, o, [f]);
      });
    if (n.decode != null)
      return n.decode(a, o, s);
    switch (n) {
      case "number":
      case "offset":
      case "sid":
        return s[0];
      case "boolean":
        return !!s[0];
      default:
        return s;
    }
  }, e.encodeOperands = function(n, a, o, s) {
    var u = this;
    return Array.isArray(n) ? s.map(function(f, l) {
      return u.encodeOperands(n[l], a, o, f)[0];
    }) : n.encode != null ? n.encode(a, s, o) : typeof s == "number" ? [s] : typeof s == "boolean" ? [+s] : Array.isArray(s) ? s : [s];
  }, e.decode = function(n, a) {
    var o = n.pos + a.length, s = {}, u = [];
    Object.defineProperties(s, {
      parent: {
        value: a
      },
      _startOffset: {
        value: n.pos
      }
    });
    for (var f in this.fields) {
      var l = this.fields[f];
      s[l[1]] = l[3];
    }
    for (; n.pos < o; ) {
      var c = n.readUInt8();
      if (c < 28) {
        c === 12 && (c = c << 8 | n.readUInt8());
        var p = this.fields[c];
        if (!p)
          throw new Error("Unknown operator " + c);
        var y = this.decodeOperands(p[2], n, s, u);
        y != null && (y instanceof F1 ? Object.defineProperty(s, p[1], y) : s[p[1]] = y), u = [];
      } else
        u.push(Vi.decode(n, c));
    }
    return s;
  }, e.size = function(n, a, o) {
    o === void 0 && (o = !0);
    var s = {
      parent: a,
      val: n,
      pointerSize: 0,
      startOffset: a.startOffset || 0
    }, u = 0;
    for (var f in this.fields) {
      var l = this.fields[f], c = n[l[1]];
      if (!(c == null || rs(c, l[3]))) {
        for (var p = this.encodeOperands(l[2], null, s, c), y = Xr(p), v; !(v = y()).done; ) {
          var m = v.value;
          u += Vi.size(m);
        }
        var w = Array.isArray(l[0]) ? l[0] : [l[0]];
        u += w.length;
      }
    }
    return o && (u += s.pointerSize), u;
  }, e.encode = function(n, a, o) {
    var s = {
      pointers: [],
      startOffset: n.pos,
      parent: o,
      val: a,
      pointerSize: 0
    };
    s.pointerOffset = n.pos + this.size(a, s, !1);
    for (var u = Xr(this.ops), f; !(f = u()).done; ) {
      var l = f.value, c = a[l[1]];
      if (!(c == null || rs(c, l[3]))) {
        for (var p = this.encodeOperands(l[2], n, s, c), y = Xr(p), v; !(v = y()).done; ) {
          var m = v.value;
          Vi.encode(n, m);
        }
        for (var w = Array.isArray(l[0]) ? l[0] : [l[0]], F = Xr(w), S; !(S = F()).done; ) {
          var I = S.value;
          n.writeUInt8(I);
        }
      }
    }
    for (var A = 0; A < s.pointers.length; ) {
      var M = s.pointers[A++];
      M.type.encode(n, M.val, M.parent);
    }
  }, t;
})();
function up(t, e) {
  t.prototype = Object.create(e.prototype), t.prototype.constructor = t, t.__proto__ = e;
}
var rt = /* @__PURE__ */ (function(t) {
  up(e, t);
  function e(n, a) {
    return a === void 0 && (a = {}), a.type == null && (a.type = "global"), t.call(this, null, n, a) || this;
  }
  var r = e.prototype;
  return r.decode = function(a, o, s) {
    return this.offsetType = {
      decode: function() {
        return s[0];
      }
    }, t.prototype.decode.call(this, a, o, s);
  }, r.encode = function(a, o, s) {
    if (!a)
      return this.offsetType = {
        size: function() {
          return 0;
        }
      }, this.size(o, s), [new os(0)];
    var u = null;
    return this.offsetType = {
      encode: function(l, c) {
        return u = c;
      }
    }, t.prototype.encode.call(this, a, o, s), [new os(u)];
  }, e;
})(i.Pointer), os = /* @__PURE__ */ (function() {
  function t(r) {
    this.val = r, this.forceLarge = !0;
  }
  var e = t.prototype;
  return e.valueOf = function() {
    return this.val;
  }, t;
})(), fp = /* @__PURE__ */ (function() {
  function t() {
  }
  return t.decode = function(r, n, a) {
    for (var o = a.pop(); a.length > o; )
      a.pop();
  }, t;
})(), ya = new fi([
  // key       name                    type                                          default
  [6, "BlueValues", "delta", null],
  [7, "OtherBlues", "delta", null],
  [8, "FamilyBlues", "delta", null],
  [9, "FamilyOtherBlues", "delta", null],
  [[12, 9], "BlueScale", "number", 0.039625],
  [[12, 10], "BlueShift", "number", 7],
  [[12, 11], "BlueFuzz", "number", 1],
  [10, "StdHW", "number", null],
  [11, "StdVW", "number", null],
  [[12, 12], "StemSnapH", "delta", null],
  [[12, 13], "StemSnapV", "delta", null],
  [[12, 14], "ForceBold", "boolean", !1],
  [[12, 17], "LanguageGroup", "number", 0],
  [[12, 18], "ExpansionFactor", "number", 0.06],
  [[12, 19], "initialRandomSeed", "number", 0],
  [20, "defaultWidthX", "number", 0],
  [21, "nominalWidthX", "number", 0],
  [22, "vsindex", "number", 0],
  [23, "blend", fp, null],
  [19, "Subrs", new rt(new lt(), {
    type: "local"
  }), null]
]), Ln = [".notdef", "space", "exclam", "quotedbl", "numbersign", "dollar", "percent", "ampersand", "quoteright", "parenleft", "parenright", "asterisk", "plus", "comma", "hyphen", "period", "slash", "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "colon", "semicolon", "less", "equal", "greater", "question", "at", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "bracketleft", "backslash", "bracketright", "asciicircum", "underscore", "quoteleft", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "braceleft", "bar", "braceright", "asciitilde", "exclamdown", "cent", "sterling", "fraction", "yen", "florin", "section", "currency", "quotesingle", "quotedblleft", "guillemotleft", "guilsinglleft", "guilsinglright", "fi", "fl", "endash", "dagger", "daggerdbl", "periodcentered", "paragraph", "bullet", "quotesinglbase", "quotedblbase", "quotedblright", "guillemotright", "ellipsis", "perthousand", "questiondown", "grave", "acute", "circumflex", "tilde", "macron", "breve", "dotaccent", "dieresis", "ring", "cedilla", "hungarumlaut", "ogonek", "caron", "emdash", "AE", "ordfeminine", "Lslash", "Oslash", "OE", "ordmasculine", "ae", "dotlessi", "lslash", "oslash", "oe", "germandbls", "onesuperior", "logicalnot", "mu", "trademark", "Eth", "onehalf", "plusminus", "Thorn", "onequarter", "divide", "brokenbar", "degree", "thorn", "threequarters", "twosuperior", "registered", "minus", "eth", "multiply", "threesuperior", "copyright", "Aacute", "Acircumflex", "Adieresis", "Agrave", "Aring", "Atilde", "Ccedilla", "Eacute", "Ecircumflex", "Edieresis", "Egrave", "Iacute", "Icircumflex", "Idieresis", "Igrave", "Ntilde", "Oacute", "Ocircumflex", "Odieresis", "Ograve", "Otilde", "Scaron", "Uacute", "Ucircumflex", "Udieresis", "Ugrave", "Yacute", "Ydieresis", "Zcaron", "aacute", "acircumflex", "adieresis", "agrave", "aring", "atilde", "ccedilla", "eacute", "ecircumflex", "edieresis", "egrave", "iacute", "icircumflex", "idieresis", "igrave", "ntilde", "oacute", "ocircumflex", "odieresis", "ograve", "otilde", "scaron", "uacute", "ucircumflex", "udieresis", "ugrave", "yacute", "ydieresis", "zcaron", "exclamsmall", "Hungarumlautsmall", "dollaroldstyle", "dollarsuperior", "ampersandsmall", "Acutesmall", "parenleftsuperior", "parenrightsuperior", "twodotenleader", "onedotenleader", "zerooldstyle", "oneoldstyle", "twooldstyle", "threeoldstyle", "fouroldstyle", "fiveoldstyle", "sixoldstyle", "sevenoldstyle", "eightoldstyle", "nineoldstyle", "commasuperior", "threequartersemdash", "periodsuperior", "questionsmall", "asuperior", "bsuperior", "centsuperior", "dsuperior", "esuperior", "isuperior", "lsuperior", "msuperior", "nsuperior", "osuperior", "rsuperior", "ssuperior", "tsuperior", "ff", "ffi", "ffl", "parenleftinferior", "parenrightinferior", "Circumflexsmall", "hyphensuperior", "Gravesmall", "Asmall", "Bsmall", "Csmall", "Dsmall", "Esmall", "Fsmall", "Gsmall", "Hsmall", "Ismall", "Jsmall", "Ksmall", "Lsmall", "Msmall", "Nsmall", "Osmall", "Psmall", "Qsmall", "Rsmall", "Ssmall", "Tsmall", "Usmall", "Vsmall", "Wsmall", "Xsmall", "Ysmall", "Zsmall", "colonmonetary", "onefitted", "rupiah", "Tildesmall", "exclamdownsmall", "centoldstyle", "Lslashsmall", "Scaronsmall", "Zcaronsmall", "Dieresissmall", "Brevesmall", "Caronsmall", "Dotaccentsmall", "Macronsmall", "figuredash", "hypheninferior", "Ogoneksmall", "Ringsmall", "Cedillasmall", "questiondownsmall", "oneeighth", "threeeighths", "fiveeighths", "seveneighths", "onethird", "twothirds", "zerosuperior", "foursuperior", "fivesuperior", "sixsuperior", "sevensuperior", "eightsuperior", "ninesuperior", "zeroinferior", "oneinferior", "twoinferior", "threeinferior", "fourinferior", "fiveinferior", "sixinferior", "seveninferior", "eightinferior", "nineinferior", "centinferior", "dollarinferior", "periodinferior", "commainferior", "Agravesmall", "Aacutesmall", "Acircumflexsmall", "Atildesmall", "Adieresissmall", "Aringsmall", "AEsmall", "Ccedillasmall", "Egravesmall", "Eacutesmall", "Ecircumflexsmall", "Edieresissmall", "Igravesmall", "Iacutesmall", "Icircumflexsmall", "Idieresissmall", "Ethsmall", "Ntildesmall", "Ogravesmall", "Oacutesmall", "Ocircumflexsmall", "Otildesmall", "Odieresissmall", "OEsmall", "Oslashsmall", "Ugravesmall", "Uacutesmall", "Ucircumflexsmall", "Udieresissmall", "Yacutesmall", "Thornsmall", "Ydieresissmall", "001.000", "001.001", "001.002", "001.003", "Black", "Bold", "Book", "Light", "Medium", "Regular", "Roman", "Semibold"], Uf = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "space", "exclam", "quotedbl", "numbersign", "dollar", "percent", "ampersand", "quoteright", "parenleft", "parenright", "asterisk", "plus", "comma", "hyphen", "period", "slash", "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "colon", "semicolon", "less", "equal", "greater", "question", "at", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "bracketleft", "backslash", "bracketright", "asciicircum", "underscore", "quoteleft", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "braceleft", "bar", "braceright", "asciitilde", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "exclamdown", "cent", "sterling", "fraction", "yen", "florin", "section", "currency", "quotesingle", "quotedblleft", "guillemotleft", "guilsinglleft", "guilsinglright", "fi", "fl", "", "endash", "dagger", "daggerdbl", "periodcentered", "", "paragraph", "bullet", "quotesinglbase", "quotedblbase", "quotedblright", "guillemotright", "ellipsis", "perthousand", "", "questiondown", "", "grave", "acute", "circumflex", "tilde", "macron", "breve", "dotaccent", "dieresis", "", "ring", "cedilla", "", "hungarumlaut", "ogonek", "caron", "emdash", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "AE", "", "ordfeminine", "", "", "", "", "Lslash", "Oslash", "OE", "ordmasculine", "", "", "", "", "", "ae", "", "", "", "dotlessi", "", "", "lslash", "oslash", "oe", "germandbls"], lp = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "space", "exclamsmall", "Hungarumlautsmall", "", "dollaroldstyle", "dollarsuperior", "ampersandsmall", "Acutesmall", "parenleftsuperior", "parenrightsuperior", "twodotenleader", "onedotenleader", "comma", "hyphen", "period", "fraction", "zerooldstyle", "oneoldstyle", "twooldstyle", "threeoldstyle", "fouroldstyle", "fiveoldstyle", "sixoldstyle", "sevenoldstyle", "eightoldstyle", "nineoldstyle", "colon", "semicolon", "commasuperior", "threequartersemdash", "periodsuperior", "questionsmall", "", "asuperior", "bsuperior", "centsuperior", "dsuperior", "esuperior", "", "", "isuperior", "", "", "lsuperior", "msuperior", "nsuperior", "osuperior", "", "", "rsuperior", "ssuperior", "tsuperior", "", "ff", "fi", "fl", "ffi", "ffl", "parenleftinferior", "", "parenrightinferior", "Circumflexsmall", "hyphensuperior", "Gravesmall", "Asmall", "Bsmall", "Csmall", "Dsmall", "Esmall", "Fsmall", "Gsmall", "Hsmall", "Ismall", "Jsmall", "Ksmall", "Lsmall", "Msmall", "Nsmall", "Osmall", "Psmall", "Qsmall", "Rsmall", "Ssmall", "Tsmall", "Usmall", "Vsmall", "Wsmall", "Xsmall", "Ysmall", "Zsmall", "colonmonetary", "onefitted", "rupiah", "Tildesmall", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "exclamdownsmall", "centoldstyle", "Lslashsmall", "", "", "Scaronsmall", "Zcaronsmall", "Dieresissmall", "Brevesmall", "Caronsmall", "", "Dotaccentsmall", "", "", "Macronsmall", "", "", "figuredash", "hypheninferior", "", "", "Ogoneksmall", "Ringsmall", "Cedillasmall", "", "", "", "onequarter", "onehalf", "threequarters", "questiondownsmall", "oneeighth", "threeeighths", "fiveeighths", "seveneighths", "onethird", "twothirds", "", "", "zerosuperior", "onesuperior", "twosuperior", "threesuperior", "foursuperior", "fivesuperior", "sixsuperior", "sevensuperior", "eightsuperior", "ninesuperior", "zeroinferior", "oneinferior", "twoinferior", "threeinferior", "fourinferior", "fiveinferior", "sixinferior", "seveninferior", "eightinferior", "nineinferior", "centinferior", "dollarinferior", "periodinferior", "commainferior", "Agravesmall", "Aacutesmall", "Acircumflexsmall", "Atildesmall", "Adieresissmall", "Aringsmall", "AEsmall", "Ccedillasmall", "Egravesmall", "Eacutesmall", "Ecircumflexsmall", "Edieresissmall", "Igravesmall", "Iacutesmall", "Icircumflexsmall", "Idieresissmall", "Ethsmall", "Ntildesmall", "Ogravesmall", "Oacutesmall", "Ocircumflexsmall", "Otildesmall", "Odieresissmall", "OEsmall", "Oslashsmall", "Ugravesmall", "Uacutesmall", "Ucircumflexsmall", "Udieresissmall", "Yacutesmall", "Thornsmall", "Ydieresissmall"], Nf = [".notdef", "space", "exclam", "quotedbl", "numbersign", "dollar", "percent", "ampersand", "quoteright", "parenleft", "parenright", "asterisk", "plus", "comma", "hyphen", "period", "slash", "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "colon", "semicolon", "less", "equal", "greater", "question", "at", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "bracketleft", "backslash", "bracketright", "asciicircum", "underscore", "quoteleft", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "braceleft", "bar", "braceright", "asciitilde", "exclamdown", "cent", "sterling", "fraction", "yen", "florin", "section", "currency", "quotesingle", "quotedblleft", "guillemotleft", "guilsinglleft", "guilsinglright", "fi", "fl", "endash", "dagger", "daggerdbl", "periodcentered", "paragraph", "bullet", "quotesinglbase", "quotedblbase", "quotedblright", "guillemotright", "ellipsis", "perthousand", "questiondown", "grave", "acute", "circumflex", "tilde", "macron", "breve", "dotaccent", "dieresis", "ring", "cedilla", "hungarumlaut", "ogonek", "caron", "emdash", "AE", "ordfeminine", "Lslash", "Oslash", "OE", "ordmasculine", "ae", "dotlessi", "lslash", "oslash", "oe", "germandbls", "onesuperior", "logicalnot", "mu", "trademark", "Eth", "onehalf", "plusminus", "Thorn", "onequarter", "divide", "brokenbar", "degree", "thorn", "threequarters", "twosuperior", "registered", "minus", "eth", "multiply", "threesuperior", "copyright", "Aacute", "Acircumflex", "Adieresis", "Agrave", "Aring", "Atilde", "Ccedilla", "Eacute", "Ecircumflex", "Edieresis", "Egrave", "Iacute", "Icircumflex", "Idieresis", "Igrave", "Ntilde", "Oacute", "Ocircumflex", "Odieresis", "Ograve", "Otilde", "Scaron", "Uacute", "Ucircumflex", "Udieresis", "Ugrave", "Yacute", "Ydieresis", "Zcaron", "aacute", "acircumflex", "adieresis", "agrave", "aring", "atilde", "ccedilla", "eacute", "ecircumflex", "edieresis", "egrave", "iacute", "icircumflex", "idieresis", "igrave", "ntilde", "oacute", "ocircumflex", "odieresis", "ograve", "otilde", "scaron", "uacute", "ucircumflex", "udieresis", "ugrave", "yacute", "ydieresis", "zcaron"], cp = [".notdef", "space", "exclamsmall", "Hungarumlautsmall", "dollaroldstyle", "dollarsuperior", "ampersandsmall", "Acutesmall", "parenleftsuperior", "parenrightsuperior", "twodotenleader", "onedotenleader", "comma", "hyphen", "period", "fraction", "zerooldstyle", "oneoldstyle", "twooldstyle", "threeoldstyle", "fouroldstyle", "fiveoldstyle", "sixoldstyle", "sevenoldstyle", "eightoldstyle", "nineoldstyle", "colon", "semicolon", "commasuperior", "threequartersemdash", "periodsuperior", "questionsmall", "asuperior", "bsuperior", "centsuperior", "dsuperior", "esuperior", "isuperior", "lsuperior", "msuperior", "nsuperior", "osuperior", "rsuperior", "ssuperior", "tsuperior", "ff", "fi", "fl", "ffi", "ffl", "parenleftinferior", "parenrightinferior", "Circumflexsmall", "hyphensuperior", "Gravesmall", "Asmall", "Bsmall", "Csmall", "Dsmall", "Esmall", "Fsmall", "Gsmall", "Hsmall", "Ismall", "Jsmall", "Ksmall", "Lsmall", "Msmall", "Nsmall", "Osmall", "Psmall", "Qsmall", "Rsmall", "Ssmall", "Tsmall", "Usmall", "Vsmall", "Wsmall", "Xsmall", "Ysmall", "Zsmall", "colonmonetary", "onefitted", "rupiah", "Tildesmall", "exclamdownsmall", "centoldstyle", "Lslashsmall", "Scaronsmall", "Zcaronsmall", "Dieresissmall", "Brevesmall", "Caronsmall", "Dotaccentsmall", "Macronsmall", "figuredash", "hypheninferior", "Ogoneksmall", "Ringsmall", "Cedillasmall", "onequarter", "onehalf", "threequarters", "questiondownsmall", "oneeighth", "threeeighths", "fiveeighths", "seveneighths", "onethird", "twothirds", "zerosuperior", "onesuperior", "twosuperior", "threesuperior", "foursuperior", "fivesuperior", "sixsuperior", "sevensuperior", "eightsuperior", "ninesuperior", "zeroinferior", "oneinferior", "twoinferior", "threeinferior", "fourinferior", "fiveinferior", "sixinferior", "seveninferior", "eightinferior", "nineinferior", "centinferior", "dollarinferior", "periodinferior", "commainferior", "Agravesmall", "Aacutesmall", "Acircumflexsmall", "Atildesmall", "Adieresissmall", "Aringsmall", "AEsmall", "Ccedillasmall", "Egravesmall", "Eacutesmall", "Ecircumflexsmall", "Edieresissmall", "Igravesmall", "Iacutesmall", "Icircumflexsmall", "Idieresissmall", "Ethsmall", "Ntildesmall", "Ogravesmall", "Oacutesmall", "Ocircumflexsmall", "Otildesmall", "Odieresissmall", "OEsmall", "Oslashsmall", "Ugravesmall", "Uacutesmall", "Ucircumflexsmall", "Udieresissmall", "Yacutesmall", "Thornsmall", "Ydieresissmall"], hp = [".notdef", "space", "dollaroldstyle", "dollarsuperior", "parenleftsuperior", "parenrightsuperior", "twodotenleader", "onedotenleader", "comma", "hyphen", "period", "fraction", "zerooldstyle", "oneoldstyle", "twooldstyle", "threeoldstyle", "fouroldstyle", "fiveoldstyle", "sixoldstyle", "sevenoldstyle", "eightoldstyle", "nineoldstyle", "colon", "semicolon", "commasuperior", "threequartersemdash", "periodsuperior", "asuperior", "bsuperior", "centsuperior", "dsuperior", "esuperior", "isuperior", "lsuperior", "msuperior", "nsuperior", "osuperior", "rsuperior", "ssuperior", "tsuperior", "ff", "fi", "fl", "ffi", "ffl", "parenleftinferior", "parenrightinferior", "hyphensuperior", "colonmonetary", "onefitted", "rupiah", "centoldstyle", "figuredash", "hypheninferior", "onequarter", "onehalf", "threequarters", "oneeighth", "threeeighths", "fiveeighths", "seveneighths", "onethird", "twothirds", "zerosuperior", "onesuperior", "twosuperior", "threesuperior", "foursuperior", "fivesuperior", "sixsuperior", "sevensuperior", "eightsuperior", "ninesuperior", "zeroinferior", "oneinferior", "twoinferior", "threeinferior", "fourinferior", "fiveinferior", "sixinferior", "seveninferior", "eightinferior", "nineinferior", "centinferior", "dollarinferior", "periodinferior", "commainferior"], Rf = new i.Struct({
  reserved: new i.Reserved(i.uint16),
  reqFeatureIndex: i.uint16,
  featureCount: i.uint16,
  featureIndexes: new i.Array(i.uint16, "featureCount")
}), pp = new i.Struct({
  tag: new i.String(4),
  langSys: new i.Pointer(i.uint16, Rf, {
    type: "parent"
  })
}), dp = new i.Struct({
  defaultLangSys: new i.Pointer(i.uint16, Rf),
  count: i.uint16,
  langSysRecords: new i.Array(pp, "count")
}), vp = new i.Struct({
  tag: new i.String(4),
  script: new i.Pointer(i.uint16, dp, {
    type: "parent"
  })
}), zf = new i.Array(vp, i.uint16), jf = new i.Struct({
  featureParams: i.uint16,
  // pointer
  lookupCount: i.uint16,
  lookupListIndexes: new i.Array(i.uint16, "lookupCount")
}), yp = new i.Struct({
  tag: new i.String(4),
  feature: new i.Pointer(i.uint16, jf, {
    type: "parent"
  })
}), Vf = new i.Array(yp, i.uint16), gp = new i.Struct({
  markAttachmentType: i.uint8,
  flags: new i.Bitfield(i.uint8, ["rightToLeft", "ignoreBaseGlyphs", "ignoreLigatures", "ignoreMarks", "useMarkFilteringSet"])
});
function Gn(t) {
  var e = new i.Struct({
    lookupType: i.uint16,
    flags: gp,
    subTableCount: i.uint16,
    subTables: new i.Array(new i.Pointer(i.uint16, t), "subTableCount"),
    markFilteringSet: new i.Optional(i.uint16, function(r) {
      return r.flags.flags.useMarkFilteringSet;
    })
  });
  return new i.LazyArray(new i.Pointer(i.uint16, e), i.uint16);
}
var mp = new i.Struct({
  start: i.uint16,
  end: i.uint16,
  startCoverageIndex: i.uint16
}), he = new i.VersionedStruct(i.uint16, {
  1: {
    glyphCount: i.uint16,
    glyphs: new i.Array(i.uint16, "glyphCount")
  },
  2: {
    rangeCount: i.uint16,
    rangeRecords: new i.Array(mp, "rangeCount")
  }
}), bp = new i.Struct({
  start: i.uint16,
  end: i.uint16,
  class: i.uint16
}), Gt = new i.VersionedStruct(i.uint16, {
  1: {
    // Class array
    startGlyph: i.uint16,
    glyphCount: i.uint16,
    classValueArray: new i.Array(i.uint16, "glyphCount")
  },
  2: {
    // Class ranges
    classRangeCount: i.uint16,
    classRangeRecord: new i.Array(bp, "classRangeCount")
  }
}), Rt = new i.Struct({
  a: i.uint16,
  // startSize for hinting Device, outerIndex for VariationIndex
  b: i.uint16,
  // endSize for Device, innerIndex for VariationIndex
  deltaFormat: i.uint16
}), yn = new i.Struct({
  sequenceIndex: i.uint16,
  lookupListIndex: i.uint16
}), wp = new i.Struct({
  glyphCount: i.uint16,
  lookupCount: i.uint16,
  input: new i.Array(i.uint16, function(t) {
    return t.glyphCount - 1;
  }),
  lookupRecords: new i.Array(yn, "lookupCount")
}), Fp = new i.Array(new i.Pointer(i.uint16, wp), i.uint16), xp = new i.Struct({
  glyphCount: i.uint16,
  lookupCount: i.uint16,
  classes: new i.Array(i.uint16, function(t) {
    return t.glyphCount - 1;
  }),
  lookupRecords: new i.Array(yn, "lookupCount")
}), Sp = new i.Array(new i.Pointer(i.uint16, xp), i.uint16), Gf = new i.VersionedStruct(i.uint16, {
  1: {
    // Simple context
    coverage: new i.Pointer(i.uint16, he),
    ruleSetCount: i.uint16,
    ruleSets: new i.Array(new i.Pointer(i.uint16, Fp), "ruleSetCount")
  },
  2: {
    // Class-based context
    coverage: new i.Pointer(i.uint16, he),
    classDef: new i.Pointer(i.uint16, Gt),
    classSetCnt: i.uint16,
    classSet: new i.Array(new i.Pointer(i.uint16, Sp), "classSetCnt")
  },
  3: {
    glyphCount: i.uint16,
    lookupCount: i.uint16,
    coverages: new i.Array(new i.Pointer(i.uint16, he), "glyphCount"),
    lookupRecords: new i.Array(yn, "lookupCount")
  }
}), Ap = new i.Struct({
  backtrackGlyphCount: i.uint16,
  backtrack: new i.Array(i.uint16, "backtrackGlyphCount"),
  inputGlyphCount: i.uint16,
  input: new i.Array(i.uint16, function(t) {
    return t.inputGlyphCount - 1;
  }),
  lookaheadGlyphCount: i.uint16,
  lookahead: new i.Array(i.uint16, "lookaheadGlyphCount"),
  lookupCount: i.uint16,
  lookupRecords: new i.Array(yn, "lookupCount")
}), ss = new i.Array(new i.Pointer(i.uint16, Ap), i.uint16), qf = new i.VersionedStruct(i.uint16, {
  1: {
    // Simple context glyph substitution
    coverage: new i.Pointer(i.uint16, he),
    chainCount: i.uint16,
    chainRuleSets: new i.Array(new i.Pointer(i.uint16, ss), "chainCount")
  },
  2: {
    // Class-based chaining context
    coverage: new i.Pointer(i.uint16, he),
    backtrackClassDef: new i.Pointer(i.uint16, Gt),
    inputClassDef: new i.Pointer(i.uint16, Gt),
    lookaheadClassDef: new i.Pointer(i.uint16, Gt),
    chainCount: i.uint16,
    chainClassSet: new i.Array(new i.Pointer(i.uint16, ss), "chainCount")
  },
  3: {
    // Coverage-based chaining context
    backtrackGlyphCount: i.uint16,
    backtrackCoverage: new i.Array(new i.Pointer(i.uint16, he), "backtrackGlyphCount"),
    inputGlyphCount: i.uint16,
    inputCoverage: new i.Array(new i.Pointer(i.uint16, he), "inputGlyphCount"),
    lookaheadGlyphCount: i.uint16,
    lookaheadCoverage: new i.Array(new i.Pointer(i.uint16, he), "lookaheadGlyphCount"),
    lookupCount: i.uint16,
    lookupRecords: new i.Array(yn, "lookupCount")
  }
}), Yr, $r = new i.Fixed(16, "BE", 14), Ep = new i.Struct({
  startCoord: $r,
  peakCoord: $r,
  endCoord: $r
}), Cp = new i.Struct({
  axisCount: i.uint16,
  regionCount: i.uint16,
  variationRegions: new i.Array(new i.Array(Ep, "axisCount"), "regionCount")
}), Ip = new i.Struct({
  shortDeltas: new i.Array(i.int16, function(t) {
    return t.parent.shortDeltaCount;
  }),
  regionDeltas: new i.Array(i.int8, function(t) {
    return t.parent.regionIndexCount - t.parent.shortDeltaCount;
  }),
  deltas: function(e) {
    return e.shortDeltas.concat(e.regionDeltas);
  }
}), Op = new i.Struct({
  itemCount: i.uint16,
  shortDeltaCount: i.uint16,
  regionIndexCount: i.uint16,
  regionIndexes: new i.Array(i.uint16, "regionIndexCount"),
  deltaSets: new i.Array(Ip, "itemCount")
}), li = new i.Struct({
  format: i.uint16,
  variationRegionList: new i.Pointer(i.uint32, Cp),
  variationDataCount: i.uint16,
  itemVariationData: new i.Array(new i.Pointer(i.uint32, Op), "variationDataCount")
}), Dp = new i.VersionedStruct(i.uint16, {
  1: (Yr = {
    axisIndex: i.uint16
  }, Yr.axisIndex = i.uint16, Yr.filterRangeMinValue = $r, Yr.filterRangeMaxValue = $r, Yr)
}), Tp = new i.Struct({
  conditionCount: i.uint16,
  conditionTable: new i.Array(new i.Pointer(i.uint32, Dp), "conditionCount")
}), Pp = new i.Struct({
  featureIndex: i.uint16,
  alternateFeatureTable: new i.Pointer(i.uint32, jf, {
    type: "parent"
  })
}), Bp = new i.Struct({
  version: i.fixed32,
  substitutionCount: i.uint16,
  substitutions: new i.Array(Pp, "substitutionCount")
}), kp = new i.Struct({
  conditionSet: new i.Pointer(i.uint32, Tp, {
    type: "parent"
  }),
  featureTableSubstitution: new i.Pointer(i.uint32, Bp, {
    type: "parent"
  })
}), Hf = new i.Struct({
  majorVersion: i.uint16,
  minorVersion: i.uint16,
  featureVariationRecordCount: i.uint32,
  featureVariationRecords: new i.Array(kp, "featureVariationRecordCount")
});
function Wf(t, e) {
  t.prototype = Object.create(e.prototype), t.prototype.constructor = t, t.__proto__ = e;
}
var Xf = /* @__PURE__ */ (function() {
  function t(r, n) {
    this.predefinedOps = r, this.type = n;
  }
  var e = t.prototype;
  return e.decode = function(n, a, o) {
    return this.predefinedOps[o[0]] ? this.predefinedOps[o[0]] : this.type.decode(n, a, o);
  }, e.size = function(n, a) {
    return this.type.size(n, a);
  }, e.encode = function(n, a, o) {
    var s = this.predefinedOps.indexOf(a);
    return s !== -1 ? s : this.type.encode(n, a, o);
  }, t;
})(), Lp = /* @__PURE__ */ (function(t) {
  Wf(e, t);
  function e() {
    return t.call(this, "UInt8") || this;
  }
  var r = e.prototype;
  return r.decode = function(a) {
    return i.uint8.decode(a) & 127;
  }, e;
})(i.Number), Yf = new i.Struct({
  first: i.uint16,
  nLeft: i.uint8
}), Mp = new i.Struct({
  first: i.uint16,
  nLeft: i.uint16
}), Up = new i.VersionedStruct(new Lp(), {
  0: {
    nCodes: i.uint8,
    codes: new i.Array(i.uint8, "nCodes")
  },
  1: {
    nRanges: i.uint8,
    ranges: new i.Array(Yf, "nRanges")
  }
  // TODO: supplement?
}), Np = new Xf([Uf, lp], new rt(Up, {
  lazy: !0
})), us = /* @__PURE__ */ (function(t) {
  Wf(e, t);
  function e() {
    return t.apply(this, arguments) || this;
  }
  var r = e.prototype;
  return r.decode = function(a, o) {
    for (var s = wf(this.length, a, o), u = 0, f = []; u < s; ) {
      var l = this.type.decode(a, o);
      l.offset = u, u += l.nLeft + 1, f.push(l);
    }
    return f;
  }, e;
})(i.Array), Rp = new i.VersionedStruct(i.uint8, {
  0: {
    glyphs: new i.Array(i.uint16, function(t) {
      return t.parent.CharStrings.length - 1;
    })
  },
  1: {
    ranges: new us(Yf, function(t) {
      return t.parent.CharStrings.length - 1;
    })
  },
  2: {
    ranges: new us(Mp, function(t) {
      return t.parent.CharStrings.length - 1;
    })
  }
}), zp = new Xf([Nf, cp, hp], new rt(Rp, {
  lazy: !0
})), jp = new i.Struct({
  first: i.uint16,
  fd: i.uint8
}), Vp = new i.Struct({
  first: i.uint32,
  fd: i.uint16
}), Kf = new i.VersionedStruct(i.uint8, {
  0: {
    fds: new i.Array(i.uint8, function(t) {
      return t.parent.CharStrings.length;
    })
  },
  3: {
    nRanges: i.uint16,
    ranges: new i.Array(jp, "nRanges"),
    sentinel: i.uint16
  },
  4: {
    nRanges: i.uint32,
    ranges: new i.Array(Vp, "nRanges"),
    sentinel: i.uint32
  }
}), Gi = new rt(ya), Zf = /* @__PURE__ */ (function() {
  function t() {
  }
  var e = t.prototype;
  return e.decode = function(n, a, o) {
    return a.length = o[0], Gi.decode(n, a, [o[1]]);
  }, e.size = function(n, a) {
    return [ya.size(n, a, !1), Gi.size(n, a)[0]];
  }, e.encode = function(n, a, o) {
    return [ya.size(a, o, !1), Gi.encode(n, a, o)[0]];
  }, t;
})(), Jf = new fi([
  // key       name                   type(s)                                 default
  [18, "Private", new Zf(), null],
  [[12, 38], "FontName", "sid", null]
]), Gp = new fi([
  // key       name                   type(s)                                 default
  [[12, 30], "ROS", ["sid", "sid", "number"], null],
  [0, "version", "sid", null],
  [1, "Notice", "sid", null],
  [[12, 0], "Copyright", "sid", null],
  [2, "FullName", "sid", null],
  [3, "FamilyName", "sid", null],
  [4, "Weight", "sid", null],
  [[12, 1], "isFixedPitch", "boolean", !1],
  [[12, 2], "ItalicAngle", "number", 0],
  [[12, 3], "UnderlinePosition", "number", -100],
  [[12, 4], "UnderlineThickness", "number", 50],
  [[12, 5], "PaintType", "number", 0],
  [[12, 6], "CharstringType", "number", 2],
  [[12, 7], "FontMatrix", "array", [1e-3, 0, 0, 1e-3, 0, 0]],
  [13, "UniqueID", "number", null],
  [5, "FontBBox", "array", [0, 0, 0, 0]],
  [[12, 8], "StrokeWidth", "number", 0],
  [14, "XUID", "array", null],
  [15, "charset", zp, Nf],
  [16, "Encoding", Np, Uf],
  [17, "CharStrings", new rt(new lt()), null],
  [18, "Private", new Zf(), null],
  [[12, 20], "SyntheticBase", "number", null],
  [[12, 21], "PostScript", "sid", null],
  [[12, 22], "BaseFontName", "sid", null],
  [[12, 23], "BaseFontBlend", "delta", null],
  // CID font specific
  [[12, 31], "CIDFontVersion", "number", 0],
  [[12, 32], "CIDFontRevision", "number", 0],
  [[12, 33], "CIDFontType", "number", 0],
  [[12, 34], "CIDCount", "number", 8720],
  [[12, 35], "UIDBase", "number", null],
  [[12, 37], "FDSelect", new rt(Kf), null],
  [[12, 36], "FDArray", new rt(new lt(Jf)), null],
  [[12, 38], "FontName", "sid", null]
]), qp = new i.Struct({
  length: i.uint16,
  itemVariationStore: li
}), Hp = new fi([[[12, 7], "FontMatrix", "array", [1e-3, 0, 0, 1e-3, 0, 0]], [17, "CharStrings", new rt(new lt()), null], [[12, 37], "FDSelect", new rt(Kf), null], [[12, 36], "FDArray", new rt(new lt(Jf)), null], [24, "vstore", new rt(qp), null], [25, "maxstack", "number", 193]]), Qf = new i.VersionedStruct(i.fixed16, {
  1: {
    hdrSize: i.uint8,
    offSize: i.uint8,
    nameIndex: new lt(new i.String("length")),
    topDictIndex: new lt(Gp),
    stringIndex: new lt(new i.String("length")),
    globalSubrIndex: new lt()
  },
  2: {
    hdrSize: i.uint8,
    length: i.uint16,
    topDict: Hp,
    globalSubrIndex: new lt()
  }
});
function Wp(t, e) {
  for (var r = 0; r < e.length; r++) {
    var n = e[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(t, n.key, n);
  }
}
function Xp(t, e, r) {
  return e && Wp(t.prototype, e), t;
}
var _f = /* @__PURE__ */ (function() {
  function t(r) {
    this.stream = r, this.decode();
  }
  t.decode = function(n) {
    return new t(n);
  };
  var e = t.prototype;
  return e.decode = function() {
    this.stream.pos;
    var n = Qf.decode(this.stream);
    for (var a in n) {
      var o = n[a];
      this[a] = o;
    }
    if (this.version < 2) {
      if (this.topDictIndex.length !== 1)
        throw new Error("Only a single font is allowed in CFF");
      this.topDict = this.topDictIndex[0];
    }
    return this.isCIDFont = this.topDict.ROS != null, this;
  }, e.string = function(n) {
    return this.version >= 2 ? null : n < Ln.length ? Ln[n] : this.stringIndex[n - Ln.length];
  }, e.getCharString = function(n) {
    return this.stream.pos = this.topDict.CharStrings[n].offset, this.stream.readBuffer(this.topDict.CharStrings[n].length);
  }, e.getGlyphName = function(n) {
    if (this.version >= 2 || this.isCIDFont)
      return null;
    var a = this.topDict.charset;
    if (Array.isArray(a))
      return a[n];
    if (n === 0)
      return ".notdef";
    switch (n -= 1, a.version) {
      case 0:
        return this.string(a.glyphs[n]);
      case 1:
      case 2:
        for (var o = 0; o < a.ranges.length; o++) {
          var s = a.ranges[o];
          if (s.offset <= n && n <= s.offset + s.nLeft)
            return this.string(s.first + (n - s.offset));
        }
        break;
    }
    return null;
  }, e.fdForGlyph = function(n) {
    if (!this.topDict.FDSelect)
      return null;
    switch (this.topDict.FDSelect.version) {
      case 0:
        return this.topDict.FDSelect.fds[n];
      case 3:
      case 4:
        for (var a = this.topDict.FDSelect.ranges, o = 0, s = a.length - 1; o <= s; ) {
          var u = o + s >> 1;
          if (n < a[u].first)
            s = u - 1;
          else if (u < s && n > a[u + 1].first)
            o = u + 1;
          else
            return a[u].fd;
        }
      default:
        throw new Error("Unknown FDSelect version: " + this.topDict.FDSelect.version);
    }
  }, e.privateDictForGlyph = function(n) {
    if (this.topDict.FDSelect) {
      var a = this.fdForGlyph(n);
      return this.topDict.FDArray[a] ? this.topDict.FDArray[a].Private : null;
    }
    return this.version < 2 ? this.topDict.Private : this.topDict.FDArray[0].Private;
  }, Xp(t, [{
    key: "postscriptName",
    get: function() {
      return this.version < 2 ? this.nameIndex[0] : null;
    }
  }, {
    key: "fullName",
    get: function() {
      return this.string(this.topDict.FullName);
    }
  }, {
    key: "familyName",
    get: function() {
      return this.string(this.topDict.FamilyName);
    }
  }]), t;
})(), Yp = new i.Struct({
  glyphIndex: i.uint16,
  vertOriginY: i.int16
}), Kp = new i.Struct({
  majorVersion: i.uint16,
  minorVersion: i.uint16,
  defaultVertOriginY: i.int16,
  numVertOriginYMetrics: i.uint16,
  metrics: new i.Array(Yp, "numVertOriginYMetrics")
}), Or = new i.Struct({
  height: i.uint8,
  width: i.uint8,
  horiBearingX: i.int8,
  horiBearingY: i.int8,
  horiAdvance: i.uint8,
  vertBearingX: i.int8,
  vertBearingY: i.int8,
  vertAdvance: i.uint8
}), Sn = new i.Struct({
  height: i.uint8,
  width: i.uint8,
  bearingX: i.int8,
  bearingY: i.int8,
  advance: i.uint8
}), fs = new i.Struct({
  glyph: i.uint16,
  xOffset: i.int8,
  yOffset: i.int8
}), ls = function() {
}, qi = function() {
};
new i.VersionedStruct("version", {
  1: {
    metrics: Sn,
    data: ls
  },
  2: {
    metrics: Sn,
    data: qi
  },
  // format 3 is deprecated
  // format 4 is not supported by Microsoft
  5: {
    data: qi
  },
  6: {
    metrics: Or,
    data: ls
  },
  7: {
    metrics: Or,
    data: qi
  },
  8: {
    metrics: Sn,
    pad: new i.Reserved(i.uint8),
    numComponents: i.uint16,
    components: new i.Array(fs, "numComponents")
  },
  9: {
    metrics: Or,
    pad: new i.Reserved(i.uint8),
    numComponents: i.uint16,
    components: new i.Array(fs, "numComponents")
  },
  17: {
    metrics: Sn,
    dataLen: i.uint32,
    data: new i.Buffer("dataLen")
  },
  18: {
    metrics: Or,
    dataLen: i.uint32,
    data: new i.Buffer("dataLen")
  },
  19: {
    dataLen: i.uint32,
    data: new i.Buffer("dataLen")
  }
});
var cs = new i.Struct({
  ascender: i.int8,
  descender: i.int8,
  widthMax: i.uint8,
  caretSlopeNumerator: i.int8,
  caretSlopeDenominator: i.int8,
  caretOffset: i.int8,
  minOriginSB: i.int8,
  minAdvanceSB: i.int8,
  maxBeforeBL: i.int8,
  minAfterBL: i.int8,
  pad: new i.Reserved(i.int8, 2)
}), Zp = new i.Struct({
  glyphCode: i.uint16,
  offset: i.uint16
}), Jp = new i.VersionedStruct(i.uint16, {
  header: {
    imageFormat: i.uint16,
    imageDataOffset: i.uint32
  },
  1: {
    offsetArray: new i.Array(i.uint32, function(t) {
      return t.parent.lastGlyphIndex - t.parent.firstGlyphIndex + 1;
    })
  },
  2: {
    imageSize: i.uint32,
    bigMetrics: Or
  },
  3: {
    offsetArray: new i.Array(i.uint16, function(t) {
      return t.parent.lastGlyphIndex - t.parent.firstGlyphIndex + 1;
    })
  },
  4: {
    numGlyphs: i.uint32,
    glyphArray: new i.Array(Zp, function(t) {
      return t.numGlyphs + 1;
    })
  },
  5: {
    imageSize: i.uint32,
    bigMetrics: Or,
    numGlyphs: i.uint32,
    glyphCodeArray: new i.Array(i.uint16, "numGlyphs")
  }
}), Qp = new i.Struct({
  firstGlyphIndex: i.uint16,
  lastGlyphIndex: i.uint16,
  subtable: new i.Pointer(i.uint32, Jp)
}), _p = new i.Struct({
  indexSubTableArray: new i.Pointer(i.uint32, new i.Array(Qp, 1), {
    type: "parent"
  }),
  indexTablesSize: i.uint32,
  numberOfIndexSubTables: i.uint32,
  colorRef: i.uint32,
  hori: cs,
  vert: cs,
  startGlyphIndex: i.uint16,
  endGlyphIndex: i.uint16,
  ppemX: i.uint8,
  ppemY: i.uint8,
  bitDepth: i.uint8,
  flags: new i.Bitfield(i.uint8, ["horizontal", "vertical"])
}), $p = new i.Struct({
  version: i.uint32,
  // 0x00020000
  numSizes: i.uint32,
  sizes: new i.Array(_p, "numSizes")
}), ed = new i.Struct({
  ppem: i.uint16,
  resolution: i.uint16,
  imageOffsets: new i.Array(new i.Pointer(i.uint32, "void"), function(t) {
    return t.parent.parent.maxp.numGlyphs + 1;
  })
}), td = new i.Struct({
  version: i.uint16,
  flags: new i.Bitfield(i.uint16, ["renderOutlines"]),
  numImgTables: i.uint32,
  imageTables: new i.Array(new i.Pointer(i.uint32, ed), "numImgTables")
}), rd = new i.Struct({
  gid: i.uint16,
  // Glyph ID of layer glyph (must be in z-order from bottom to top).
  paletteIndex: i.uint16
  // Index value to use in the appropriate palette. This value must
}), nd = new i.Struct({
  gid: i.uint16,
  // Glyph ID of reference glyph. This glyph is for reference only
  // and is not rendered for color.
  firstLayerIndex: i.uint16,
  // Index (from beginning of the Layer Records) to the layer record.
  // There will be numLayers consecutive entries for this base glyph.
  numLayers: i.uint16
}), id = new i.Struct({
  version: i.uint16,
  numBaseGlyphRecords: i.uint16,
  baseGlyphRecord: new i.Pointer(i.uint32, new i.Array(nd, "numBaseGlyphRecords")),
  layerRecords: new i.Pointer(i.uint32, new i.Array(rd, "numLayerRecords"), {
    lazy: !0
  }),
  numLayerRecords: i.uint16
}), ad = new i.Struct({
  blue: i.uint8,
  green: i.uint8,
  red: i.uint8,
  alpha: i.uint8
}), od = new i.VersionedStruct(i.uint16, {
  header: {
    numPaletteEntries: i.uint16,
    numPalettes: i.uint16,
    numColorRecords: i.uint16,
    colorRecords: new i.Pointer(i.uint32, new i.Array(ad, "numColorRecords")),
    colorRecordIndices: new i.Array(i.uint16, "numPalettes")
  },
  0: {},
  1: {
    offsetPaletteTypeArray: new i.Pointer(i.uint32, new i.Array(i.uint32, "numPalettes")),
    offsetPaletteLabelArray: new i.Pointer(i.uint32, new i.Array(i.uint16, "numPalettes")),
    offsetPaletteEntryLabelArray: new i.Pointer(i.uint32, new i.Array(i.uint16, "numPaletteEntries"))
  }
}), sn = new i.VersionedStruct(i.uint16, {
  1: {
    // Design units only
    coordinate: i.int16
    // X or Y value, in design units
  },
  2: {
    // Design units plus contour point
    coordinate: i.int16,
    // X or Y value, in design units
    referenceGlyph: i.uint16,
    // GlyphID of control glyph
    baseCoordPoint: i.uint16
    // Index of contour point on the referenceGlyph
  },
  3: {
    // Design units plus Device table
    coordinate: i.int16,
    // X or Y value, in design units
    deviceTable: new i.Pointer(i.uint16, Rt)
    // Device table for X or Y value
  }
}), sd = new i.Struct({
  defaultIndex: i.uint16,
  // Index of default baseline for this script-same index in the BaseTagList
  baseCoordCount: i.uint16,
  baseCoords: new i.Array(new i.Pointer(i.uint16, sn), "baseCoordCount")
}), ud = new i.Struct({
  tag: new i.String(4),
  // 4-byte feature identification tag-must match FeatureTag in FeatureList
  minCoord: new i.Pointer(i.uint16, sn, {
    type: "parent"
  }),
  // May be NULL
  maxCoord: new i.Pointer(i.uint16, sn, {
    type: "parent"
  })
  // May be NULL
}), $f = new i.Struct({
  minCoord: new i.Pointer(i.uint16, sn),
  // May be NULL
  maxCoord: new i.Pointer(i.uint16, sn),
  // May be NULL
  featMinMaxCount: i.uint16,
  // May be 0
  featMinMaxRecords: new i.Array(ud, "featMinMaxCount")
  // In alphabetical order
}), fd = new i.Struct({
  tag: new i.String(4),
  // 4-byte language system identification tag
  minMax: new i.Pointer(i.uint16, $f, {
    type: "parent"
  })
}), ld = new i.Struct({
  baseValues: new i.Pointer(i.uint16, sd),
  // May be NULL
  defaultMinMax: new i.Pointer(i.uint16, $f),
  // May be NULL
  baseLangSysCount: i.uint16,
  // May be 0
  baseLangSysRecords: new i.Array(fd, "baseLangSysCount")
  // in alphabetical order by BaseLangSysTag
}), cd = new i.Struct({
  tag: new i.String(4),
  // 4-byte script identification tag
  script: new i.Pointer(i.uint16, ld, {
    type: "parent"
  })
}), hd = new i.Array(cd, i.uint16), pd = new i.Array(new i.String(4), i.uint16), hs = new i.Struct({
  baseTagList: new i.Pointer(i.uint16, pd),
  // May be NULL
  baseScriptList: new i.Pointer(i.uint16, hd)
}), dd = new i.VersionedStruct(i.uint32, {
  header: {
    horizAxis: new i.Pointer(i.uint16, hs),
    // May be NULL
    vertAxis: new i.Pointer(i.uint16, hs)
    // May be NULL
  },
  65536: {},
  65537: {
    itemVariationStore: new i.Pointer(i.uint32, li)
  }
}), vd = new i.Array(i.uint16, i.uint16), yd = new i.Struct({
  coverage: new i.Pointer(i.uint16, he),
  glyphCount: i.uint16,
  attachPoints: new i.Array(new i.Pointer(i.uint16, vd), "glyphCount")
}), gd = new i.VersionedStruct(i.uint16, {
  1: {
    // Design units only
    coordinate: i.int16
  },
  2: {
    // Contour point
    caretValuePoint: i.uint16
  },
  3: {
    // Design units plus Device table
    coordinate: i.int16,
    deviceTable: new i.Pointer(i.uint16, Rt)
  }
}), md = new i.Array(new i.Pointer(i.uint16, gd), i.uint16), bd = new i.Struct({
  coverage: new i.Pointer(i.uint16, he),
  ligGlyphCount: i.uint16,
  ligGlyphs: new i.Array(new i.Pointer(i.uint16, md), "ligGlyphCount")
}), ps = new i.Struct({
  markSetTableFormat: i.uint16,
  markSetCount: i.uint16,
  coverage: new i.Array(new i.Pointer(i.uint32, he), "markSetCount")
}), wd = new i.VersionedStruct(i.uint32, {
  header: {
    glyphClassDef: new i.Pointer(i.uint16, Gt),
    attachList: new i.Pointer(i.uint16, yd),
    ligCaretList: new i.Pointer(i.uint16, bd),
    markAttachClassDef: new i.Pointer(i.uint16, Gt)
  },
  65536: {},
  65538: {
    markGlyphSetsDef: new i.Pointer(i.uint16, ps)
  },
  65539: {
    markGlyphSetsDef: new i.Pointer(i.uint16, ps),
    itemVariationStore: new i.Pointer(i.uint32, li)
  }
}), wr = new i.Bitfield(i.uint16, ["xPlacement", "yPlacement", "xAdvance", "yAdvance", "xPlaDevice", "yPlaDevice", "xAdvDevice", "yAdvDevice"]), Fd = {
  xPlacement: i.int16,
  yPlacement: i.int16,
  xAdvance: i.int16,
  yAdvance: i.int16,
  xPlaDevice: new i.Pointer(i.uint16, Rt, {
    type: "global",
    relativeTo: "rel"
  }),
  yPlaDevice: new i.Pointer(i.uint16, Rt, {
    type: "global",
    relativeTo: "rel"
  }),
  xAdvDevice: new i.Pointer(i.uint16, Rt, {
    type: "global",
    relativeTo: "rel"
  }),
  yAdvDevice: new i.Pointer(i.uint16, Rt, {
    type: "global",
    relativeTo: "rel"
  })
}, Nr = /* @__PURE__ */ (function() {
  function t(r) {
    r === void 0 && (r = "valueFormat"), this.key = r;
  }
  var e = t.prototype;
  return e.buildStruct = function(n) {
    for (var a = n; !a[this.key] && a.parent; )
      a = a.parent;
    if (a[this.key]) {
      var o = {};
      o.rel = function() {
        return a._startOffset;
      };
      var s = a[this.key];
      for (var u in s)
        s[u] && (o[u] = Fd[u]);
      return new i.Struct(o);
    }
  }, e.size = function(n, a) {
    return this.buildStruct(a).size(n, a);
  }, e.decode = function(n, a) {
    var o = this.buildStruct(a).decode(n, a);
    return delete o.rel, o;
  }, t;
})(), xd = new i.Struct({
  secondGlyph: i.uint16,
  value1: new Nr("valueFormat1"),
  value2: new Nr("valueFormat2")
}), Sd = new i.Array(xd, i.uint16), Ad = new i.Struct({
  value1: new Nr("valueFormat1"),
  value2: new Nr("valueFormat2")
}), un = new i.VersionedStruct(i.uint16, {
  1: {
    // Design units only
    xCoordinate: i.int16,
    yCoordinate: i.int16
  },
  2: {
    // Design units plus contour point
    xCoordinate: i.int16,
    yCoordinate: i.int16,
    anchorPoint: i.uint16
  },
  3: {
    // Design units plus Device tables
    xCoordinate: i.int16,
    yCoordinate: i.int16,
    xDeviceTable: new i.Pointer(i.uint16, Rt),
    yDeviceTable: new i.Pointer(i.uint16, Rt)
  }
}), Ed = new i.Struct({
  entryAnchor: new i.Pointer(i.uint16, un, {
    type: "parent"
  }),
  exitAnchor: new i.Pointer(i.uint16, un, {
    type: "parent"
  })
}), Cd = new i.Struct({
  class: i.uint16,
  markAnchor: new i.Pointer(i.uint16, un, {
    type: "parent"
  })
}), Hi = new i.Array(Cd, i.uint16), Id = new i.Array(new i.Pointer(i.uint16, un), function(t) {
  return t.parent.classCount;
}), ds = new i.Array(Id, i.uint16), Od = new i.Array(new i.Pointer(i.uint16, un), function(t) {
  return t.parent.parent.classCount;
}), Dd = new i.Array(Od, i.uint16), Td = new i.Array(new i.Pointer(i.uint16, Dd), i.uint16), Rr = new i.VersionedStruct("lookupType", {
  1: new i.VersionedStruct(i.uint16, {
    // Single Adjustment
    1: {
      // Single positioning value
      coverage: new i.Pointer(i.uint16, he),
      valueFormat: wr,
      value: new Nr()
    },
    2: {
      coverage: new i.Pointer(i.uint16, he),
      valueFormat: wr,
      valueCount: i.uint16,
      values: new i.LazyArray(new Nr(), "valueCount")
    }
  }),
  2: new i.VersionedStruct(i.uint16, {
    // Pair Adjustment Positioning
    1: {
      // Adjustments for glyph pairs
      coverage: new i.Pointer(i.uint16, he),
      valueFormat1: wr,
      valueFormat2: wr,
      pairSetCount: i.uint16,
      pairSets: new i.LazyArray(new i.Pointer(i.uint16, Sd), "pairSetCount")
    },
    2: {
      // Class pair adjustment
      coverage: new i.Pointer(i.uint16, he),
      valueFormat1: wr,
      valueFormat2: wr,
      classDef1: new i.Pointer(i.uint16, Gt),
      classDef2: new i.Pointer(i.uint16, Gt),
      class1Count: i.uint16,
      class2Count: i.uint16,
      classRecords: new i.LazyArray(new i.LazyArray(Ad, "class2Count"), "class1Count")
    }
  }),
  3: {
    // Cursive Attachment Positioning
    format: i.uint16,
    coverage: new i.Pointer(i.uint16, he),
    entryExitCount: i.uint16,
    entryExitRecords: new i.Array(Ed, "entryExitCount")
  },
  4: {
    // MarkToBase Attachment Positioning
    format: i.uint16,
    markCoverage: new i.Pointer(i.uint16, he),
    baseCoverage: new i.Pointer(i.uint16, he),
    classCount: i.uint16,
    markArray: new i.Pointer(i.uint16, Hi),
    baseArray: new i.Pointer(i.uint16, ds)
  },
  5: {
    // MarkToLigature Attachment Positioning
    format: i.uint16,
    markCoverage: new i.Pointer(i.uint16, he),
    ligatureCoverage: new i.Pointer(i.uint16, he),
    classCount: i.uint16,
    markArray: new i.Pointer(i.uint16, Hi),
    ligatureArray: new i.Pointer(i.uint16, Td)
  },
  6: {
    // MarkToMark Attachment Positioning
    format: i.uint16,
    mark1Coverage: new i.Pointer(i.uint16, he),
    mark2Coverage: new i.Pointer(i.uint16, he),
    classCount: i.uint16,
    mark1Array: new i.Pointer(i.uint16, Hi),
    mark2Array: new i.Pointer(i.uint16, ds)
  },
  7: Gf,
  // Contextual positioning
  8: qf,
  // Chaining contextual positioning
  9: {
    // Extension Positioning
    posFormat: i.uint16,
    lookupType: i.uint16,
    // cannot also be 9
    extension: new i.Pointer(i.uint32, Rr)
  }
});
Rr.versions[9].extension.type = Rr;
var Pd = new i.VersionedStruct(i.uint32, {
  header: {
    scriptList: new i.Pointer(i.uint16, zf),
    featureList: new i.Pointer(i.uint16, Vf),
    lookupList: new i.Pointer(i.uint16, new Gn(Rr))
  },
  65536: {},
  65537: {
    featureVariations: new i.Pointer(i.uint32, Hf)
  }
}), el = new i.Array(i.uint16, i.uint16), Bd = el, kd = new i.Struct({
  glyph: i.uint16,
  compCount: i.uint16,
  components: new i.Array(i.uint16, function(t) {
    return t.compCount - 1;
  })
}), Ld = new i.Array(new i.Pointer(i.uint16, kd), i.uint16), qn = new i.VersionedStruct("lookupType", {
  1: new i.VersionedStruct(i.uint16, {
    // Single Substitution
    1: {
      coverage: new i.Pointer(i.uint16, he),
      deltaGlyphID: i.int16
    },
    2: {
      coverage: new i.Pointer(i.uint16, he),
      glyphCount: i.uint16,
      substitute: new i.LazyArray(i.uint16, "glyphCount")
    }
  }),
  2: {
    // Multiple Substitution
    substFormat: i.uint16,
    coverage: new i.Pointer(i.uint16, he),
    count: i.uint16,
    sequences: new i.LazyArray(new i.Pointer(i.uint16, el), "count")
  },
  3: {
    // Alternate Substitution
    substFormat: i.uint16,
    coverage: new i.Pointer(i.uint16, he),
    count: i.uint16,
    alternateSet: new i.LazyArray(new i.Pointer(i.uint16, Bd), "count")
  },
  4: {
    // Ligature Substitution
    substFormat: i.uint16,
    coverage: new i.Pointer(i.uint16, he),
    count: i.uint16,
    ligatureSets: new i.LazyArray(new i.Pointer(i.uint16, Ld), "count")
  },
  5: Gf,
  // Contextual Substitution
  6: qf,
  // Chaining Contextual Substitution
  7: {
    // Extension Substitution
    substFormat: i.uint16,
    lookupType: i.uint16,
    // cannot also be 7
    extension: new i.Pointer(i.uint32, qn)
  },
  8: {
    // Reverse Chaining Contextual Single Substitution
    substFormat: i.uint16,
    coverage: new i.Pointer(i.uint16, he),
    backtrackCoverage: new i.Array(new i.Pointer(i.uint16, he), "backtrackGlyphCount"),
    lookaheadGlyphCount: i.uint16,
    lookaheadCoverage: new i.Array(new i.Pointer(i.uint16, he), "lookaheadGlyphCount"),
    glyphCount: i.uint16,
    substitutes: new i.Array(i.uint16, "glyphCount")
  }
});
qn.versions[7].extension.type = qn;
var Md = new i.VersionedStruct(i.uint32, {
  header: {
    scriptList: new i.Pointer(i.uint16, zf),
    featureList: new i.Pointer(i.uint16, Vf),
    lookupList: new i.Pointer(i.uint16, new Gn(qn))
  },
  65536: {},
  65537: {
    featureVariations: new i.Pointer(i.uint32, Hf)
  }
}), Dt = new i.Array(i.uint16, i.uint16), Ud = new i.Struct({
  shrinkageEnableGSUB: new i.Pointer(i.uint16, Dt),
  shrinkageDisableGSUB: new i.Pointer(i.uint16, Dt),
  shrinkageEnableGPOS: new i.Pointer(i.uint16, Dt),
  shrinkageDisableGPOS: new i.Pointer(i.uint16, Dt),
  shrinkageJstfMax: new i.Pointer(i.uint16, new Gn(Rr)),
  extensionEnableGSUB: new i.Pointer(i.uint16, Dt),
  extensionDisableGSUB: new i.Pointer(i.uint16, Dt),
  extensionEnableGPOS: new i.Pointer(i.uint16, Dt),
  extensionDisableGPOS: new i.Pointer(i.uint16, Dt),
  extensionJstfMax: new i.Pointer(i.uint16, new Gn(Rr))
}), tl = new i.Array(new i.Pointer(i.uint16, Ud), i.uint16), Nd = new i.Struct({
  tag: new i.String(4),
  jstfLangSys: new i.Pointer(i.uint16, tl)
}), Rd = new i.Struct({
  extenderGlyphs: new i.Pointer(i.uint16, new i.Array(i.uint16, i.uint16)),
  // array of glyphs to extend line length
  defaultLangSys: new i.Pointer(i.uint16, tl),
  langSysCount: i.uint16,
  langSysRecords: new i.Array(Nd, "langSysCount")
}), zd = new i.Struct({
  tag: new i.String(4),
  script: new i.Pointer(i.uint16, Rd, {
    type: "parent"
  })
}), jd = new i.Struct({
  version: i.uint32,
  // should be 0x00010000
  scriptCount: i.uint16,
  scriptList: new i.Array(zd, "scriptCount")
}), Vd = /* @__PURE__ */ (function() {
  function t(r) {
    this._size = r;
  }
  var e = t.prototype;
  return e.decode = function(n, a) {
    switch (this.size(0, a)) {
      case 1:
        return n.readUInt8();
      case 2:
        return n.readUInt16BE();
      case 3:
        return n.readUInt24BE();
      case 4:
        return n.readUInt32BE();
    }
  }, e.size = function(n, a) {
    return wf(this._size, null, a);
  }, t;
})(), Gd = new i.Struct({
  entry: new Vd(function(t) {
    return ((t.parent.entryFormat & 48) >> 4) + 1;
  }),
  outerIndex: function(e) {
    return e.entry >> (e.parent.entryFormat & 15) + 1;
  },
  innerIndex: function(e) {
    return e.entry & (1 << (e.parent.entryFormat & 15) + 1) - 1;
  }
}), Wi = new i.Struct({
  entryFormat: i.uint16,
  mapCount: i.uint16,
  mapData: new i.Array(Gd, "mapCount")
}), qd = new i.Struct({
  majorVersion: i.uint16,
  minorVersion: i.uint16,
  itemVariationStore: new i.Pointer(i.uint32, li),
  advanceWidthMapping: new i.Pointer(i.uint32, Wi),
  LSBMapping: new i.Pointer(i.uint32, Wi),
  RSBMapping: new i.Pointer(i.uint32, Wi)
}), Hd = new i.Struct({
  format: i.uint32,
  length: i.uint32,
  offset: i.uint32
}), Wd = new i.Struct({
  reserved: new i.Reserved(i.uint16, 2),
  cbSignature: i.uint32,
  // Length (in bytes) of the PKCS#7 packet in pbSignature
  signature: new i.Buffer("cbSignature")
}), Xd = new i.Struct({
  ulVersion: i.uint32,
  // Version number of the DSIG table (0x00000001)
  usNumSigs: i.uint16,
  // Number of signatures in the table
  usFlag: i.uint16,
  // Permission flags
  signatures: new i.Array(Hd, "usNumSigs"),
  signatureBlocks: new i.Array(Wd, "usNumSigs")
}), Yd = new i.Struct({
  rangeMaxPPEM: i.uint16,
  // Upper limit of range, in ppem
  rangeGaspBehavior: new i.Bitfield(i.uint16, [
    // Flags describing desired rasterizer behavior
    "grayscale",
    "gridfit",
    "symmetricSmoothing",
    "symmetricGridfit"
    // only in version 1, for ClearType
  ])
}), Kd = new i.Struct({
  version: i.uint16,
  // set to 0
  numRanges: i.uint16,
  gaspRanges: new i.Array(Yd, "numRanges")
  // Sorted by ppem
}), Zd = new i.Struct({
  pixelSize: i.uint8,
  maximumWidth: i.uint8,
  widths: new i.Array(i.uint8, function(t) {
    return t.parent.parent.maxp.numGlyphs;
  })
}), Jd = new i.Struct({
  version: i.uint16,
  numRecords: i.int16,
  sizeDeviceRecord: i.int32,
  records: new i.Array(Zd, "numRecords")
}), Qd = new i.Struct({
  left: i.uint16,
  right: i.uint16,
  value: i.int16
}), vs = new i.Struct({
  firstGlyph: i.uint16,
  nGlyphs: i.uint16,
  offsets: new i.Array(i.uint16, "nGlyphs"),
  max: function(e) {
    return e.offsets.length && Math.max.apply(Math, e.offsets);
  }
}), _d = new i.Struct({
  off: function(e) {
    return e._startOffset - e.parent.parent._startOffset;
  },
  len: function(e) {
    return ((e.parent.leftTable.max - e.off) / e.parent.rowWidth + 1) * (e.parent.rowWidth / 2);
  },
  values: new i.LazyArray(i.int16, "len")
}), ys = new i.VersionedStruct("format", {
  0: {
    nPairs: i.uint16,
    searchRange: i.uint16,
    entrySelector: i.uint16,
    rangeShift: i.uint16,
    pairs: new i.Array(Qd, "nPairs")
  },
  2: {
    rowWidth: i.uint16,
    leftTable: new i.Pointer(i.uint16, vs, {
      type: "parent"
    }),
    rightTable: new i.Pointer(i.uint16, vs, {
      type: "parent"
    }),
    array: new i.Pointer(i.uint16, _d, {
      type: "parent"
    })
  },
  3: {
    glyphCount: i.uint16,
    kernValueCount: i.uint8,
    leftClassCount: i.uint8,
    rightClassCount: i.uint8,
    flags: i.uint8,
    kernValue: new i.Array(i.int16, "kernValueCount"),
    leftClass: new i.Array(i.uint8, "glyphCount"),
    rightClass: new i.Array(i.uint8, "glyphCount"),
    kernIndex: new i.Array(i.uint8, function(t) {
      return t.leftClassCount * t.rightClassCount;
    })
  }
}), gs = new i.VersionedStruct("version", {
  0: {
    // Microsoft uses this format
    subVersion: i.uint16,
    // Microsoft has an extra sub-table version number
    length: i.uint16,
    // Length of the subtable, in bytes
    format: i.uint8,
    // Format of subtable
    coverage: new i.Bitfield(i.uint8, [
      "horizontal",
      // 1 if table has horizontal data, 0 if vertical
      "minimum",
      // If set to 1, the table has minimum values. If set to 0, the table has kerning values.
      "crossStream",
      // If set to 1, kerning is perpendicular to the flow of the text
      "override"
      // If set to 1 the value in this table replaces the accumulated value
    ]),
    subtable: ys,
    padding: new i.Reserved(i.uint8, function(t) {
      return t.length - t._currentOffset;
    })
  },
  1: {
    // Apple uses this format
    length: i.uint32,
    coverage: new i.Bitfield(i.uint8, [
      null,
      null,
      null,
      null,
      null,
      "variation",
      // Set if table has variation kerning values
      "crossStream",
      // Set if table has cross-stream kerning values
      "vertical"
      // Set if table has vertical kerning values
    ]),
    format: i.uint8,
    tupleIndex: i.uint16,
    subtable: ys,
    padding: new i.Reserved(i.uint8, function(t) {
      return t.length - t._currentOffset;
    })
  }
}), $d = new i.VersionedStruct(i.uint16, {
  0: {
    // Microsoft Version
    nTables: i.uint16,
    tables: new i.Array(gs, "nTables")
  },
  1: {
    // Apple Version
    reserved: new i.Reserved(i.uint16),
    // the other half of the version number
    nTables: i.uint32,
    tables: new i.Array(gs, "nTables")
  }
}), ev = new i.Struct({
  version: i.uint16,
  numGlyphs: i.uint16,
  yPels: new i.Array(i.uint8, "numGlyphs")
}), tv = new i.Struct({
  version: i.uint16,
  fontNumber: i.uint32,
  pitch: i.uint16,
  xHeight: i.uint16,
  style: i.uint16,
  typeFamily: i.uint16,
  capHeight: i.uint16,
  symbolSet: i.uint16,
  typeface: new i.String(16),
  characterComplement: new i.String(8),
  fileName: new i.String(6),
  strokeWeight: new i.String(1),
  widthType: new i.String(1),
  serifStyle: i.uint8,
  reserved: new i.Reserved(i.uint8)
}), rv = new i.Struct({
  bCharSet: i.uint8,
  // Character set
  xRatio: i.uint8,
  // Value to use for x-Ratio
  yStartRatio: i.uint8,
  // Starting y-Ratio value
  yEndRatio: i.uint8
  // Ending y-Ratio value
}), nv = new i.Struct({
  yPelHeight: i.uint16,
  // yPelHeight to which values apply
  yMax: i.int16,
  // Maximum value (in pels) for this yPelHeight
  yMin: i.int16
  // Minimum value (in pels) for this yPelHeight
}), iv = new i.Struct({
  recs: i.uint16,
  // Number of height records in this group
  startsz: i.uint8,
  // Starting yPelHeight
  endsz: i.uint8,
  // Ending yPelHeight
  entries: new i.Array(nv, "recs")
  // The VDMX records
}), av = new i.Struct({
  version: i.uint16,
  // Version number (0 or 1)
  numRecs: i.uint16,
  // Number of VDMX groups present
  numRatios: i.uint16,
  // Number of aspect ratio groupings
  ratioRanges: new i.Array(rv, "numRatios"),
  // Ratio ranges
  offsets: new i.Array(i.uint16, "numRatios"),
  // Offset to the VDMX group for this ratio range
  groups: new i.Array(iv, "numRecs")
  // The actual VDMX groupings
}), ov = new i.Struct({
  version: i.uint16,
  // Version number of the Vertical Header Table
  ascent: i.int16,
  // The vertical typographic ascender for this font
  descent: i.int16,
  // The vertical typographic descender for this font
  lineGap: i.int16,
  // The vertical typographic line gap for this font
  advanceHeightMax: i.int16,
  // The maximum advance height measurement found in the font
  minTopSideBearing: i.int16,
  // The minimum top side bearing measurement found in the font
  minBottomSideBearing: i.int16,
  // The minimum bottom side bearing measurement found in the font
  yMaxExtent: i.int16,
  caretSlopeRise: i.int16,
  // Caret slope (rise/run)
  caretSlopeRun: i.int16,
  caretOffset: i.int16,
  // Set value equal to 0 for nonslanted fonts
  reserved: new i.Reserved(i.int16, 4),
  metricDataFormat: i.int16,
  // Set to 0
  numberOfMetrics: i.uint16
  // Number of advance heights in the Vertical Metrics table
}), sv = new i.Struct({
  advance: i.uint16,
  // The advance height of the glyph
  bearing: i.int16
  // The top sidebearing of the glyph
}), uv = new i.Struct({
  metrics: new i.LazyArray(sv, function(t) {
    return t.parent.vhea.numberOfMetrics;
  }),
  bearings: new i.LazyArray(i.int16, function(t) {
    return t.parent.maxp.numGlyphs - t.parent.vhea.numberOfMetrics;
  })
}), ms = new i.Fixed(16, "BE", 14), fv = new i.Struct({
  fromCoord: ms,
  toCoord: ms
}), lv = new i.Struct({
  pairCount: i.uint16,
  correspondence: new i.Array(fv, "pairCount")
}), cv = new i.Struct({
  version: i.fixed32,
  axisCount: i.uint32,
  segment: new i.Array(lv, "axisCount")
});
function hv(t, e) {
  t.prototype = Object.create(e.prototype), t.prototype.constructor = t, t.__proto__ = e;
}
var pv = /* @__PURE__ */ (function() {
  function t(r, n, a) {
    this.type = r, this.stream = n, this.parent = a, this.base = this.stream.pos, this._items = [];
  }
  var e = t.prototype;
  return e.getItem = function(n) {
    if (this._items[n] == null) {
      var a = this.stream.pos;
      this.stream.pos = this.base + this.type.size(null, this.parent) * n, this._items[n] = this.type.decode(this.stream, this.parent), this.stream.pos = a;
    }
    return this._items[n];
  }, e.inspect = function() {
    return "[UnboundedArray " + this.type.constructor.name + "]";
  }, t;
})(), ht = /* @__PURE__ */ (function(t) {
  hv(e, t);
  function e(n) {
    return t.call(this, n, 0) || this;
  }
  var r = e.prototype;
  return r.decode = function(a, o) {
    return new pv(this.type, a, o);
  }, e;
})(i.Array), qt = function(e) {
  e === void 0 && (e = i.uint16);
  var r = /* @__PURE__ */ (function() {
    function u(l) {
      this.type = l;
    }
    var f = u.prototype;
    return f.decode = function(c, p) {
      return p = p.parent.parent, this.type.decode(c, p);
    }, f.size = function(c, p) {
      return p = p.parent.parent, this.type.size(c, p);
    }, f.encode = function(c, p, y) {
      return y = y.parent.parent, this.type.encode(c, p, y);
    }, u;
  })();
  e = new r(e);
  var n = new i.Struct({
    unitSize: i.uint16,
    nUnits: i.uint16,
    searchRange: i.uint16,
    entrySelector: i.uint16,
    rangeShift: i.uint16
  }), a = new i.Struct({
    lastGlyph: i.uint16,
    firstGlyph: i.uint16,
    value: e
  }), o = new i.Struct({
    lastGlyph: i.uint16,
    firstGlyph: i.uint16,
    values: new i.Pointer(i.uint16, new i.Array(e, function(u) {
      return u.lastGlyph - u.firstGlyph + 1;
    }), {
      type: "parent"
    })
  }), s = new i.Struct({
    glyph: i.uint16,
    value: e
  });
  return new i.VersionedStruct(i.uint16, {
    0: {
      values: new ht(e)
      // length == number of glyphs maybe?
    },
    2: {
      binarySearchHeader: n,
      segments: new i.Array(a, function(u) {
        return u.binarySearchHeader.nUnits;
      })
    },
    4: {
      binarySearchHeader: n,
      segments: new i.Array(o, function(u) {
        return u.binarySearchHeader.nUnits;
      })
    },
    6: {
      binarySearchHeader: n,
      segments: new i.Array(s, function(u) {
        return u.binarySearchHeader.nUnits;
      })
    },
    8: {
      firstGlyph: i.uint16,
      count: i.uint16,
      values: new i.Array(e, "count")
    }
  });
};
function An(t, e) {
  t === void 0 && (t = {}), e === void 0 && (e = i.uint16);
  var r = Object.assign({
    newState: i.uint16,
    flags: i.uint16
  }, t), n = new i.Struct(r), a = new ht(new i.Array(i.uint16, function(s) {
    return s.nClasses;
  })), o = new i.Struct({
    nClasses: i.uint32,
    classTable: new i.Pointer(i.uint32, new qt(e)),
    stateArray: new i.Pointer(i.uint32, a),
    entryTable: new i.Pointer(i.uint32, new ht(n))
  });
  return o;
}
function dv(t, e) {
  t === void 0 && (t = {}), e === void 0 && (e = i.uint16);
  var r = new i.Struct({
    version: function() {
      return 8;
    },
    // simulate LookupTable
    firstGlyph: i.uint16,
    values: new i.Array(i.uint8, i.uint16)
  }), n = Object.assign({
    newStateOffset: i.uint16,
    // convert offset to stateArray index
    newState: function(f) {
      return (f.newStateOffset - (f.parent.stateArray.base - f.parent._startOffset)) / f.parent.nClasses;
    },
    flags: i.uint16
  }, t), a = new i.Struct(n), o = new ht(new i.Array(i.uint8, function(u) {
    return u.nClasses;
  })), s = new i.Struct({
    nClasses: i.uint16,
    classTable: new i.Pointer(i.uint16, r),
    stateArray: new i.Pointer(i.uint16, o),
    entryTable: new i.Pointer(i.uint16, new ht(a))
  });
  return s;
}
var vv = new i.VersionedStruct("format", {
  0: {
    // Distance-based, no mapping
    deltas: new i.Array(i.int16, 32)
  },
  1: {
    // Distance-based, with mapping
    deltas: new i.Array(i.int16, 32),
    mappingData: new qt(i.uint16)
  },
  2: {
    // Control point-based, no mapping
    standardGlyph: i.uint16,
    controlPoints: new i.Array(i.uint16, 32)
  },
  3: {
    // Control point-based, with mapping
    standardGlyph: i.uint16,
    controlPoints: new i.Array(i.uint16, 32),
    mappingData: new qt(i.uint16)
  }
}), yv = new i.Struct({
  version: i.fixed32,
  format: i.uint16,
  defaultBaseline: i.uint16,
  subtable: vv
}), gv = new i.Struct({
  setting: i.uint16,
  nameIndex: i.int16,
  name: function(e) {
    return e.parent.parent.parent.name.records.fontFeatures[e.nameIndex];
  }
}), mv = new i.Struct({
  feature: i.uint16,
  nSettings: i.uint16,
  settingTable: new i.Pointer(i.uint32, new i.Array(gv, "nSettings"), {
    type: "parent"
  }),
  featureFlags: new i.Bitfield(i.uint8, [null, null, null, null, null, null, "hasDefault", "exclusive"]),
  defaultSetting: i.uint8,
  nameIndex: i.int16,
  name: function(e) {
    return e.parent.parent.name.records.fontFeatures[e.nameIndex];
  }
}), bv = new i.Struct({
  version: i.fixed32,
  featureNameCount: i.uint16,
  reserved1: new i.Reserved(i.uint16),
  reserved2: new i.Reserved(i.uint32),
  featureNames: new i.Array(mv, "featureNameCount")
}), wv = new i.Struct({
  axisTag: new i.String(4),
  minValue: i.fixed32,
  defaultValue: i.fixed32,
  maxValue: i.fixed32,
  flags: i.uint16,
  nameID: i.uint16,
  name: function(e) {
    return e.parent.parent.name.records.fontFeatures[e.nameID];
  }
}), Fv = new i.Struct({
  nameID: i.uint16,
  name: function(e) {
    return e.parent.parent.name.records.fontFeatures[e.nameID];
  },
  flags: i.uint16,
  coord: new i.Array(i.fixed32, function(t) {
    return t.parent.axisCount;
  }),
  postscriptNameID: new i.Optional(i.uint16, function(t) {
    return t.parent.instanceSize - t._currentOffset > 0;
  })
}), xv = new i.Struct({
  version: i.fixed32,
  offsetToData: i.uint16,
  countSizePairs: i.uint16,
  axisCount: i.uint16,
  axisSize: i.uint16,
  instanceCount: i.uint16,
  instanceSize: i.uint16,
  axis: new i.Array(wv, "axisCount"),
  instance: new i.Array(Fv, "instanceCount")
}), Sv = new i.Fixed(16, "BE", 14), Av = /* @__PURE__ */ (function() {
  function t() {
  }
  return t.decode = function(r, n) {
    return n.flags ? r.readUInt32BE() : r.readUInt16BE() * 2;
  }, t;
})(), Ev = new i.Struct({
  version: i.uint16,
  reserved: new i.Reserved(i.uint16),
  axisCount: i.uint16,
  globalCoordCount: i.uint16,
  globalCoords: new i.Pointer(i.uint32, new i.Array(new i.Array(Sv, "axisCount"), "globalCoordCount")),
  glyphCount: i.uint16,
  flags: i.uint16,
  offsetToData: i.uint32,
  offsets: new i.Array(new i.Pointer(Av, "void", {
    relativeTo: "offsetToData",
    allowNull: !1
  }), function(t) {
    return t.glyphCount + 1;
  })
}), Cv = new i.Struct({
  length: i.uint16,
  coverage: i.uint16,
  subFeatureFlags: i.uint32,
  stateTable: new dv()
}), Iv = new i.Struct({
  justClass: i.uint32,
  beforeGrowLimit: i.fixed32,
  beforeShrinkLimit: i.fixed32,
  afterGrowLimit: i.fixed32,
  afterShrinkLimit: i.fixed32,
  growFlags: i.uint16,
  shrinkFlags: i.uint16
}), Ov = new i.Array(Iv, i.uint32), Dv = new i.VersionedStruct("actionType", {
  0: {
    // Decomposition action
    lowerLimit: i.fixed32,
    upperLimit: i.fixed32,
    order: i.uint16,
    glyphs: new i.Array(i.uint16, i.uint16)
  },
  1: {
    // Unconditional add glyph action
    addGlyph: i.uint16
  },
  2: {
    // Conditional add glyph action
    substThreshold: i.fixed32,
    addGlyph: i.uint16,
    substGlyph: i.uint16
  },
  3: {},
  // Stretch glyph action (no data, not supported by CoreText)
  4: {
    // Ductile glyph action (not supported by CoreText)
    variationAxis: i.uint32,
    minimumLimit: i.fixed32,
    noStretchValue: i.fixed32,
    maximumLimit: i.fixed32
  },
  5: {
    // Repeated add glyph action
    flags: i.uint16,
    glyph: i.uint16
  }
}), Tv = new i.Struct({
  actionClass: i.uint16,
  actionType: i.uint16,
  actionLength: i.uint32,
  actionData: Dv,
  padding: new i.Reserved(i.uint8, function(t) {
    return t.actionLength - t._currentOffset;
  })
}), Pv = new i.Array(Tv, i.uint32), Bv = new i.Struct({
  lookupTable: new qt(new i.Pointer(i.uint16, Pv))
}), bs = new i.Struct({
  classTable: new i.Pointer(i.uint16, Cv, {
    type: "parent"
  }),
  wdcOffset: i.uint16,
  postCompensationTable: new i.Pointer(i.uint16, Bv, {
    type: "parent"
  }),
  widthDeltaClusters: new qt(new i.Pointer(i.uint16, Ov, {
    type: "parent",
    relativeTo: "wdcOffset"
  }))
}), kv = new i.Struct({
  version: i.uint32,
  format: i.uint16,
  horizontal: new i.Pointer(i.uint16, bs),
  vertical: new i.Pointer(i.uint16, bs)
}), Lv = {
  action: i.uint16
}, Mv = {
  markIndex: i.uint16,
  currentIndex: i.uint16
}, Uv = {
  currentInsertIndex: i.uint16,
  markedInsertIndex: i.uint16
}, Nv = new i.Struct({
  items: new ht(new i.Pointer(i.uint32, new qt()))
}), Rv = new i.VersionedStruct("type", {
  0: {
    // Indic Rearrangement Subtable
    stateTable: new An()
  },
  1: {
    // Contextual Glyph Substitution Subtable
    stateTable: new An(Mv),
    substitutionTable: new i.Pointer(i.uint32, Nv)
  },
  2: {
    // Ligature subtable
    stateTable: new An(Lv),
    ligatureActions: new i.Pointer(i.uint32, new ht(i.uint32)),
    components: new i.Pointer(i.uint32, new ht(i.uint16)),
    ligatureList: new i.Pointer(i.uint32, new ht(i.uint16))
  },
  4: {
    // Non-contextual Glyph Substitution Subtable
    lookupTable: new qt()
  },
  5: {
    // Glyph Insertion Subtable
    stateTable: new An(Uv),
    insertionActions: new i.Pointer(i.uint32, new ht(i.uint16))
  }
}), zv = new i.Struct({
  length: i.uint32,
  coverage: i.uint24,
  type: i.uint8,
  subFeatureFlags: i.uint32,
  table: Rv,
  padding: new i.Reserved(i.uint8, function(t) {
    return t.length - t._currentOffset;
  })
}), jv = new i.Struct({
  featureType: i.uint16,
  featureSetting: i.uint16,
  enableFlags: i.uint32,
  disableFlags: i.uint32
}), Vv = new i.Struct({
  defaultFlags: i.uint32,
  chainLength: i.uint32,
  nFeatureEntries: i.uint32,
  nSubtables: i.uint32,
  features: new i.Array(jv, "nFeatureEntries"),
  subtables: new i.Array(zv, "nSubtables")
}), Gv = new i.Struct({
  version: i.uint16,
  unused: new i.Reserved(i.uint16),
  nChains: i.uint32,
  chains: new i.Array(Vv, "nChains")
}), qv = new i.Struct({
  left: i.int16,
  top: i.int16,
  right: i.int16,
  bottom: i.int16
}), Hv = new i.Struct({
  version: i.fixed32,
  format: i.uint16,
  lookupTable: new qt(qv)
}), z = {};
z.cmap = z1;
z.head = j1;
z.hhea = V1;
z.hmtx = q1;
z.maxp = H1;
z.name = Vn;
z["OS/2"] = Af;
z.post = J1;
z.fpgm = _1;
z.loca = oo;
z.prep = $1;
z["cvt "] = Q1;
z.glyf = e0;
z["CFF "] = _f;
z.CFF2 = _f;
z.VORG = Kp;
z.EBLC = $p;
z.CBLC = z.EBLC;
z.sbix = td;
z.COLR = id;
z.CPAL = od;
z.BASE = dd;
z.GDEF = wd;
z.GPOS = Pd;
z.GSUB = Md;
z.JSTF = jd;
z.HVAR = qd;
z.DSIG = Xd;
z.gasp = Kd;
z.hdmx = Jd;
z.kern = $d;
z.LTSH = ev;
z.PCLT = tv;
z.VDMX = av;
z.vhea = ov;
z.vmtx = uv;
z.avar = cv;
z.bsln = yv;
z.feat = bv;
z.fvar = xv;
z.gvar = Ev;
z.just = kv;
z.morx = Gv;
z.opbd = Hv;
function Wv(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = Xv(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function Xv(t, e) {
  if (t) {
    if (typeof t == "string") return ws(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return ws(t, e);
  }
}
function ws(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
var Yv = new i.Struct({
  tag: new i.String(4),
  checkSum: i.uint32,
  offset: new i.Pointer(i.uint32, "void", {
    type: "global"
  }),
  length: i.uint32
}), ci = new i.Struct({
  tag: new i.String(4),
  numTables: i.uint16,
  searchRange: i.uint16,
  entrySelector: i.uint16,
  rangeShift: i.uint16,
  tables: new i.Array(Yv, "numTables")
});
ci.process = function() {
  for (var t = {}, e = Wv(this.tables), r; !(r = e()).done; ) {
    var n = r.value;
    t[n.tag] = n;
  }
  this.tables = t;
};
ci.preEncode = function(t) {
  var e = [];
  for (var r in this.tables) {
    var n = this.tables[r];
    n && e.push({
      tag: r,
      checkSum: 0,
      offset: new i.VoidPointer(z[r], n),
      length: z[r].size(n)
    });
  }
  this.tag = "true", this.numTables = e.length, this.tables = e;
  var a = Math.floor(Math.log(this.numTables) / Math.LN2), o = Math.pow(2, a);
  this.searchRange = o * 16, this.entrySelector = Math.log(o) / Math.LN2, this.rangeShift = this.numTables * 16 - this.searchRange;
};
function Mn(t, e) {
  for (var r = 0, n = t.length - 1; r <= n; ) {
    var a = r + n >> 1, o = e(t[a]);
    if (o < 0)
      n = a - 1;
    else if (o > 0)
      r = a + 1;
    else
      return a;
  }
  return -1;
}
function Cr(t, e) {
  for (var r = []; t < e; )
    r.push(t++);
  return r;
}
var Tt;
function Fr(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = Kv(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function Kv(t, e) {
  if (t) {
    if (typeof t == "string") return Fs(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Fs(t, e);
  }
}
function Fs(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
function xs(t, e, r, n, a) {
  var o = {};
  return Object.keys(n).forEach(function(s) {
    o[s] = n[s];
  }), o.enumerable = !!o.enumerable, o.configurable = !!o.configurable, ("value" in o || o.initializer) && (o.writable = !0), o = r.slice().reverse().reduce(function(s, u) {
    return u(t, e, s) || s;
  }, o), a && o.initializer !== void 0 && (o.value = o.initializer ? o.initializer.call(a) : void 0, o.initializer = void 0), o.initializer === void 0 && (Object.defineProperty(t, e, o), o = null), o;
}
var Zv = (Tt = /* @__PURE__ */ (function() {
  function t(r) {
    if (this.encoding = null, this.cmap = this.findSubtable(r, [
      // 32-bit subtables
      [3, 10],
      [0, 6],
      [0, 4],
      // 16-bit subtables
      [3, 1],
      [0, 3],
      [0, 2],
      [0, 1],
      [0, 0]
    ]), !this.cmap && _r)
      for (var n = Fr(r.tables), a; !(a = n()).done; ) {
        var o = a.value, s = Sf(o.platformID, o.encodingID, o.table.language - 1);
        _r.encodingExists(s) && (this.cmap = o.table, this.encoding = s);
      }
    if (!this.cmap)
      throw new Error("Could not find a supported cmap table");
    this.uvs = this.findSubtable(r, [[0, 5]]), this.uvs && this.uvs.version !== 14 && (this.uvs = null);
  }
  var e = t.prototype;
  return e.findSubtable = function(n, a) {
    for (var o = Fr(a), s; !(s = o()).done; )
      for (var u = s.value, f = u[0], l = u[1], c = Fr(n.tables), p; !(p = c()).done; ) {
        var y = p.value;
        if (y.platformID === f && y.encodingID === l)
          return y.table;
      }
    return null;
  }, e.lookup = function(n, a) {
    if (this.encoding) {
      var o = _r.encode(String.fromCodePoint(n), this.encoding);
      n = 0;
      for (var s = 0; s < o.length; s++)
        n = n << 8 | o[s];
    } else if (a) {
      var u = this.getVariationSelector(n, a);
      if (u)
        return u;
    }
    var f = this.cmap;
    switch (f.version) {
      case 0:
        return f.codeMap.get(n) || 0;
      case 4: {
        for (var l = 0, c = f.segCount - 1; l <= c; ) {
          var p = l + c >> 1;
          if (n < f.startCode.get(p))
            c = p - 1;
          else if (n > f.endCode.get(p))
            l = p + 1;
          else {
            var y = f.idRangeOffset.get(p), v = void 0;
            if (y === 0)
              v = n + f.idDelta.get(p);
            else {
              var m = y / 2 + (n - f.startCode.get(p)) - (f.segCount - p);
              v = f.glyphIndexArray.get(m) || 0, v !== 0 && (v += f.idDelta.get(p));
            }
            return v & 65535;
          }
        }
        return 0;
      }
      case 8:
        throw new Error("TODO: cmap format 8");
      case 6:
      case 10:
        return f.glyphIndices.get(n - f.firstCode) || 0;
      case 12:
      case 13: {
        for (var w = 0, F = f.nGroups - 1; w <= F; ) {
          var S = w + F >> 1, I = f.groups.get(S);
          if (n < I.startCharCode)
            F = S - 1;
          else if (n > I.endCharCode)
            w = S + 1;
          else
            return f.version === 12 ? I.glyphID + (n - I.startCharCode) : I.glyphID;
        }
        return 0;
      }
      case 14:
        throw new Error("TODO: cmap format 14");
      default:
        throw new Error("Unknown cmap format " + f.version);
    }
  }, e.getVariationSelector = function(n, a) {
    if (!this.uvs)
      return 0;
    var o = this.uvs.varSelectors.toArray(), s = Mn(o, function(f) {
      return a - f.varSelector;
    }), u = o[s];
    return s !== -1 && u.defaultUVS && (s = Mn(u.defaultUVS, function(f) {
      return n < f.startUnicodeValue ? -1 : n > f.startUnicodeValue + f.additionalCount ? 1 : 0;
    })), s !== -1 && u.nonDefaultUVS && (s = Mn(u.nonDefaultUVS, function(f) {
      return n - f.unicodeValue;
    }), s !== -1) ? u.nonDefaultUVS[s].glyphID : 0;
  }, e.getCharacterSet = function() {
    var n = this.cmap;
    switch (n.version) {
      case 0:
        return Cr(0, n.codeMap.length);
      case 4: {
        for (var a = [], o = n.endCode.toArray(), s = 0; s < o.length; s++) {
          var u = o[s] + 1, f = n.startCode.get(s);
          a.push.apply(a, Cr(f, u));
        }
        return a;
      }
      case 8:
        throw new Error("TODO: cmap format 8");
      case 6:
      case 10:
        return Cr(n.firstCode, n.firstCode + n.glyphIndices.length);
      case 12:
      case 13: {
        for (var l = [], c = Fr(n.groups.toArray()), p; !(p = c()).done; ) {
          var y = p.value;
          l.push.apply(l, Cr(y.startCharCode, y.endCharCode + 1));
        }
        return l;
      }
      case 14:
        throw new Error("TODO: cmap format 14");
      default:
        throw new Error("Unknown cmap format " + n.version);
    }
  }, e.codePointsForGlyph = function(n) {
    var a = this.cmap;
    switch (a.version) {
      case 0: {
        for (var o = [], s = 0; s < 256; s++)
          a.codeMap.get(s) === n && o.push(s);
        return o;
      }
      case 4: {
        for (var u = [], f = 0; f < a.segCount; f++)
          for (var l = a.endCode.get(f), c = a.startCode.get(f), p = a.idRangeOffset.get(f), y = a.idDelta.get(f), v = c; v <= l; v++) {
            var m = 0;
            if (p === 0)
              m = v + y;
            else {
              var w = p / 2 + (v - c) - (a.segCount - f);
              m = a.glyphIndexArray.get(w) || 0, m !== 0 && (m += y);
            }
            m === n && u.push(v);
          }
        return u;
      }
      case 12: {
        for (var F = [], S = Fr(a.groups.toArray()), I; !(I = S()).done; ) {
          var A = I.value;
          n >= A.glyphID && n <= A.glyphID + (A.endCharCode - A.startCharCode) && F.push(A.startCharCode + (n - A.glyphID));
        }
        return F;
      }
      case 13: {
        for (var M = [], L = Fr(a.groups.toArray()), P; !(P = L()).done; ) {
          var G = P.value;
          n === G.glyphID && M.push.apply(M, Cr(G.startCharCode, G.endCharCode + 1));
        }
        return M;
      }
      default:
        throw new Error("Unknown cmap format " + a.version);
    }
  }, t;
})(), xs(Tt.prototype, "getCharacterSet", [Ne], Object.getOwnPropertyDescriptor(Tt.prototype, "getCharacterSet"), Tt.prototype), xs(Tt.prototype, "codePointsForGlyph", [Ne], Object.getOwnPropertyDescriptor(Tt.prototype, "codePointsForGlyph"), Tt.prototype), Tt);
function Jv(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = Qv(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function Qv(t, e) {
  if (t) {
    if (typeof t == "string") return Ss(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Ss(t, e);
  }
}
function Ss(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
var _v = /* @__PURE__ */ (function() {
  function t(r) {
    this.kern = r.kern;
  }
  var e = t.prototype;
  return e.process = function(n, a) {
    for (var o = 0; o < n.length - 1; o++) {
      var s = n[o].id, u = n[o + 1].id;
      a[o].xAdvance += this.getKerning(s, u);
    }
  }, e.getKerning = function(n, a) {
    for (var o = 0, s = Jv(this.kern.tables), u; !(u = s()).done; ) {
      var f = u.value;
      if (!f.coverage.crossStream) {
        switch (f.version) {
          case 0:
            if (!f.coverage.horizontal)
              continue;
            break;
          case 1:
            if (f.coverage.vertical || f.coverage.variation)
              continue;
            break;
          default:
            throw new Error("Unsupported kerning table version " + f.version);
        }
        var l = 0, c = f.subtable;
        switch (f.format) {
          case 0:
            var p = Mn(c.pairs, function(w) {
              return n - w.left || a - w.right;
            });
            p >= 0 && (l = c.pairs[p].value);
            break;
          case 2:
            var y = 0, v = 0;
            n >= c.leftTable.firstGlyph && n < c.leftTable.firstGlyph + c.leftTable.nGlyphs ? y = c.leftTable.offsets[n - c.leftTable.firstGlyph] : y = c.array.off, a >= c.rightTable.firstGlyph && a < c.rightTable.firstGlyph + c.rightTable.nGlyphs && (v = c.rightTable.offsets[a - c.rightTable.firstGlyph]);
            var m = (y + v - c.array.off) / 2;
            l = c.array.values.get(m);
            break;
          case 3:
            if (n >= c.glyphCount || a >= c.glyphCount)
              return 0;
            l = c.kernValue[c.kernIndex[c.leftClass[n] * c.rightClassCount + c.rightClass[a]]];
            break;
          default:
            throw new Error("Unsupported kerning sub-table format " + f.format);
        }
        f.coverage.override ? o = l : o += l;
      }
    }
    return o;
  }, t;
})(), co = 0, rl = -3;
function fn() {
  this.table = new Uint16Array(16), this.trans = new Uint16Array(288);
}
function $v(t, e) {
  this.source = t, this.sourceIndex = 0, this.tag = 0, this.bitcount = 0, this.dest = e, this.destLen = 0, this.ltree = new fn(), this.dtree = new fn();
}
var nl = new fn(), il = new fn(), ho = new Uint8Array(30), po = new Uint16Array(30), al = new Uint8Array(30), ol = new Uint16Array(30), ey = new Uint8Array([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]), As = new fn(), nt = new Uint8Array(320);
function sl(t, e, r, n) {
  var a, o;
  for (a = 0; a < r; ++a)
    t[a] = 0;
  for (a = 0; a < 30 - r; ++a)
    t[a + r] = a / r | 0;
  for (o = n, a = 0; a < 30; ++a)
    e[a] = o, o += 1 << t[a];
}
function ty(t, e) {
  var r;
  for (r = 0; r < 7; ++r)
    t.table[r] = 0;
  for (t.table[7] = 24, t.table[8] = 152, t.table[9] = 112, r = 0; r < 24; ++r)
    t.trans[r] = 256 + r;
  for (r = 0; r < 144; ++r)
    t.trans[24 + r] = r;
  for (r = 0; r < 8; ++r)
    t.trans[168 + r] = 280 + r;
  for (r = 0; r < 112; ++r)
    t.trans[176 + r] = 144 + r;
  for (r = 0; r < 5; ++r)
    e.table[r] = 0;
  for (e.table[5] = 32, r = 0; r < 32; ++r)
    e.trans[r] = r;
}
var Es = new Uint16Array(16);
function Xi(t, e, r, n) {
  var a, o;
  for (a = 0; a < 16; ++a)
    t.table[a] = 0;
  for (a = 0; a < n; ++a)
    t.table[e[r + a]]++;
  for (t.table[0] = 0, o = 0, a = 0; a < 16; ++a)
    Es[a] = o, o += t.table[a];
  for (a = 0; a < n; ++a)
    e[r + a] && (t.trans[Es[e[r + a]]++] = a);
}
function ry(t) {
  t.bitcount-- || (t.tag = t.source[t.sourceIndex++], t.bitcount = 7);
  var e = t.tag & 1;
  return t.tag >>>= 1, e;
}
function ot(t, e, r) {
  if (!e) return r;
  for (; t.bitcount < 24; )
    t.tag |= t.source[t.sourceIndex++] << t.bitcount, t.bitcount += 8;
  var n = t.tag & 65535 >>> 16 - e;
  return t.tag >>>= e, t.bitcount -= e, n + r;
}
function ga(t, e) {
  for (; t.bitcount < 24; )
    t.tag |= t.source[t.sourceIndex++] << t.bitcount, t.bitcount += 8;
  var r = 0, n = 0, a = 0, o = t.tag;
  do
    n = 2 * n + (o & 1), o >>>= 1, ++a, r += e.table[a], n -= e.table[a];
  while (n >= 0);
  return t.tag = o, t.bitcount -= a, e.trans[r + n];
}
function ny(t, e, r) {
  var n, a, o, s, u, f;
  for (n = ot(t, 5, 257), a = ot(t, 5, 1), o = ot(t, 4, 4), s = 0; s < 19; ++s)
    nt[s] = 0;
  for (s = 0; s < o; ++s) {
    var l = ot(t, 3, 0);
    nt[ey[s]] = l;
  }
  for (Xi(As, nt, 0, 19), u = 0; u < n + a; ) {
    var c = ga(t, As);
    switch (c) {
      case 16:
        var p = nt[u - 1];
        for (f = ot(t, 2, 3); f; --f)
          nt[u++] = p;
        break;
      case 17:
        for (f = ot(t, 3, 3); f; --f)
          nt[u++] = 0;
        break;
      case 18:
        for (f = ot(t, 7, 11); f; --f)
          nt[u++] = 0;
        break;
      default:
        nt[u++] = c;
        break;
    }
  }
  Xi(e, nt, 0, n), Xi(r, nt, n, a);
}
function Cs(t, e, r) {
  for (; ; ) {
    var n = ga(t, e);
    if (n === 256)
      return co;
    if (n < 256)
      t.dest[t.destLen++] = n;
    else {
      var a, o, s, u;
      for (n -= 257, a = ot(t, ho[n], po[n]), o = ga(t, r), s = t.destLen - ot(t, al[o], ol[o]), u = s; u < s + a; ++u)
        t.dest[t.destLen++] = t.dest[u];
    }
  }
}
function iy(t) {
  for (var e, r, n; t.bitcount > 8; )
    t.sourceIndex--, t.bitcount -= 8;
  if (e = t.source[t.sourceIndex + 1], e = 256 * e + t.source[t.sourceIndex], r = t.source[t.sourceIndex + 3], r = 256 * r + t.source[t.sourceIndex + 2], e !== (~r & 65535)) return rl;
  for (t.sourceIndex += 4, n = e; n; --n)
    t.dest[t.destLen++] = t.source[t.sourceIndex++];
  return t.bitcount = 0, co;
}
function ay(t, e) {
  var r = new $v(t, e), n, a, o;
  do {
    switch (n = ry(r), a = ot(r, 2, 0), a) {
      case 0:
        o = iy(r);
        break;
      case 1:
        o = Cs(r, nl, il);
        break;
      case 2:
        ny(r, r.ltree, r.dtree), o = Cs(r, r.ltree, r.dtree);
        break;
      default:
        o = rl;
    }
    if (o !== co) throw new Error("Data error");
  } while (!n);
  return r.destLen < r.dest.length ? typeof r.dest.slice == "function" ? r.dest.slice(0, r.destLen) : r.dest.subarray(0, r.destLen) : r.dest;
}
ty(nl, il);
sl(ho, po, 4, 3);
sl(al, ol, 2, 1);
ho[28] = 0;
po[28] = 258;
var oy = ay, ul, ma;
ma = oy;
ul = (function() {
  var t, e, r, n, a, o, s, u, f, l, c, p, y, v, m, w;
  p = 11, v = 5, y = p - v, c = 65536 >> p, a = 1 << y, s = a - 1, u = 2, t = 1 << v, r = t - 1, l = 65536 >> v, f = 1024 >> v, o = l + f, w = o, m = 32, n = w + m, e = 1 << u;
  function F(S) {
    var I, A, M;
    I = typeof S.readUInt32BE == "function" && typeof S.slice == "function", I || S instanceof Uint8Array ? (I ? (this.highStart = S.readUInt32BE(0), this.errorValue = S.readUInt32BE(4), A = S.readUInt32BE(8), S = S.slice(12)) : (M = new DataView(S.buffer), this.highStart = M.getUint32(0), this.errorValue = M.getUint32(4), A = M.getUint32(8), S = S.subarray(12)), S = ma(S, new Uint8Array(A)), S = ma(S, new Uint8Array(A)), this.data = new Uint32Array(S.buffer)) : (this.data = S.data, this.highStart = S.highStart, this.errorValue = S.errorValue);
  }
  return F.prototype.get = function(S) {
    var I;
    return S < 0 || S > 1114111 ? this.errorValue : S < 55296 || S > 56319 && S <= 65535 ? (I = (this.data[S >> v] << u) + (S & r), this.data[I]) : S <= 65535 ? (I = (this.data[l + (S - 55296 >> v)] << u) + (S & r), this.data[I]) : S < this.highStart ? (I = this.data[n - c + (S >> p)], I = this.data[I + (S >> v & s)], I = (I << u) + (S & r), this.data[I]) : this.data[this.data.length - e];
  }, F;
})();
var hi = ul, fl = be(function(t, e) {
  (function() {
    for (var r = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", n = new Uint8Array(256), a = 0; a < r.length; a++)
      n[r.charCodeAt(a)] = a;
    e.encode = function(o) {
      var s = new Uint8Array(o), u, f = s.length, l = "";
      for (u = 0; u < f; u += 3)
        l += r[s[u] >> 2], l += r[(s[u] & 3) << 4 | s[u + 1] >> 4], l += r[(s[u + 1] & 15) << 2 | s[u + 2] >> 6], l += r[s[u + 2] & 63];
      return f % 3 === 2 ? l = l.substring(0, l.length - 1) + "=" : f % 3 === 1 && (l = l.substring(0, l.length - 2) + "=="), l;
    }, e.decode = function(o) {
      var s = o.length * 0.75, u = o.length, f, l = 0, c, p, y, v;
      o[o.length - 1] === "=" && (s--, o[o.length - 2] === "=" && s--);
      var m = new ArrayBuffer(s), w = new Uint8Array(m);
      for (f = 0; f < u; f += 4)
        c = n[o.charCodeAt(f)], p = n[o.charCodeAt(f + 1)], y = n[o.charCodeAt(f + 2)], v = n[o.charCodeAt(f + 3)], w[l++] = c << 2 | p >> 4, w[l++] = (p & 15) << 4 | y >> 2, w[l++] = (y & 3) << 6 | v & 63;
      return m;
    };
  })();
});
fl.encode;
var Yt = fl.decode, sy = "eJxtVtty4zYM/Rc/70Ni97LbN1tJ49SXeGI3O93OjgayGBERRXoo0h5Np/9eAKTcpNOHECAFAgfAAZ2/JkcIqnEeVT/55c9JcZx8mnzradk5Wva83clW8bZjraZly8s68lnLZ2y3Nrzla2tedkhL8crGsmVtHXhhLxvLCzvd8N0t3/0my4mvccjCTb5/mhxdV6FF2xQG+j6h3LpQPivna+UVA5lX7qxGWT5joznOQhl34dMQ4KhVXX78fD0e7Z7OyhsYSHt0Acp9rPqjxxPb3rlYGXW1zNsxrBz/61eirNUrb4qiuL3J8jbLaZazLH/I8scsf8ry5yw/Z/klyWn2N83+ptnfNPubZn/T7G+W7WfZfjbaZ//T7H+a/c+yn1n2Mxv9MK5tbAOQfEEPHaQPn7PhlzHBmzGzmzGFaw4j2Nsx2u0I71ZwfezVtba5mlmswEL54vBIrMjYGVtqAFEmtS3x2XWdY6qtISDLhTu5zr0yIx+tVh6DMOjBK9UK504BmZDF4NEYUee+UxaBby9V5ZVwykMlH/dkB6wcNBAsLlErk0PlIedyawO2BrG+U2cyauiLpGYbMKw9RN/FVif1DTxhZT56HNjhATrkyTgoE5uY8rdQg3gmwtIfT9QerSY1QUFJmYEcsFIZxgCWQHEQmp0mZwS2iez9Pmh0p5Q71cW1istfENyaLLkfHhu0wLZPjZaQz9HKhQOlZFyT3EXrOO4iaqzTtwrshXGtdKc4/MbZxpkUf41dFcUMqctcPnUpZROl/ZFiql5li0OKu6Cy5dN9pNpmfQEBWqHJ6ag54JMpC42tFNsD9ZOtHgxw9NTmA75STo1O0HklYjepkSt2l9Q/pJ7YM9IXKe4CuihVH4wLWG6hkZ7uNDR9uQNhQPTQ6+CTrwF0uWaTZ/UGwtvf4DwiL1JenOILKub4RqmgsNzAILy00RiBYBX4csHqcEwVLIhNojyZunwMkEj74Kifx3y6U76Tze9MvfD+vE937wiHl8B7Defsr+/ACgPvTQV9DhaP0Ash6MyOPRRUcxmbk0fHfh67E00XmHLOL4WE3IHpBq+stBkqKq/KHKQiWameo0nLea2HOikbYiODLpdIWmOGk+7fHxeRspDHYqXBOyq5TBInuHcx6FKG9VqirfMfzmg6keiSoMzPqk/T8mjTM4KOOE8dpUv4vx+0oYIx+B5MUP7dCUc7RN9e672Mthm7RYTUHQo1MAHeO0+/Oo7qlp41DW2XhlwDUQZTc3ya/JV2b0LsTTQhfVzpWMOFxlXeM7BBZuCAXkd5s/dY14lnGydGB2iFtHPt+PQr+bZNWaC8PjuIpNpyCUz6IlqFr86z3X0zUPZEgY/9mFsIMtX/7ZOX54B+vOnRBi2uNVx0uaSXmRPdoDxUd/Fk3CC12WNjvzJR03dla1WusIU2Ir/vCi7yX4DQiCMzeOYR/f06+f73P0+ms+k=", uy = "eJwBAyH83gARAAAAAAAAAAFQcF14dyCb+/v26XFKh3FoUbGOqloNVXufUqs2tWqEqtoj1A56qrVJq2rUiE1bhFoxUzOtFXsFQWpGhIaEIHn7/X3fX3ve97/nef54PvfnHtd13Rdh8XLDDTeX5f3t0GB0lJwsd6Dw5QmGYu6XYfvLYAjhIAHaxkRWuvikR+KJV9hj1X96p/s4QYbovx/lBrMApgvB2mwIA1NEjxbrTWOuMqbU1efdSoC9YD/suT9iE6T+rOf9uoP80LlN+9BacPahPwipjDz+0EmhWFmFBmMj21TFdcL5NLs07xpL3mdPFnO5ODibdse69jL33z3+K5Q92B6sjluwC7UvvoM6txCnGnAB1OcC4cUfCRX01oex5qQUD62G8cWD+r+GsY98ngsDLj0j7Vk7JBjuYcK4az4zgVk0kvB7PBCujwj+0FVDBLdeYakxlhPDdkXzH9H9WwXaNz+K5daeF119kJdWvyex05u7z3XKGIKzOJVaimVboeyDwPwasbz7WUeSp8B5BBPbshBEELpqoJYME863zOC55cxelqe8LrLq5sN94rbKudMNx/Ej/shKPpVMwEKjjrQhv8P6o0/Z+DIgI30bL6WTjpz4utnrYpAJyNTg0z81OQu60PsLCTesdMSd62sTODJrUwhiOL68ZNJ+iEPK4F7boxP1D3NLJwmUVeEjJY1EzR5jpWeYACbWFUMEG7aXMrnUcnABA10RP2VGvRqUHFAz+fxVicV9dQcCX/Kei2YY6Tk+Cj0ydkgaBJ9fylKEa8456c3rzdKVNF6eKT2LPeLTgCJ7ZvaA//dSG6/EA4CrYXkvJgJujvR7B7CO9B2HqUr1E5cXu0/q2JBQzc+oPeye54LYOP33mDR6IrKbv9txnGwTIJ223BZ2zXTZc6yfrh34pvjxS+W82q9DqjlHOkoM7skNMxyw2CCG9jbn0E79SN59gSyIaAccW+7ASeyLD5CnXa7pOzwizkIZEMbjWrygrg6lFH9XxyOh6CR6cm9K+NK3xORuLk/M1j2fni2ly/Duj/sq7ez+3ZdCVmbcI6Dn/F1Prp+yLr2kuEhrpGhyYGKe8wZc8eNiTVIxgWFqXbRvVPOQwDrcFFsFn9lal544Fl4FNc1Nyisqvk9hP6viSwdCMAZKXPZ4htqbTDleWkEnQIUUvd/1XFQKn4ZIf3uwmrVaZRe0C7+x9I8iDngk385C/CyC4LNZZpiN1+wV3TM45aHxNS+HLCRKr2ioPYsf7cIdXfxR2sPoDSOJpCAyZea/B4cBvyPaOCuGDpf8oYOG66uH339EEpZOzAEByaEcyIsbKt/RWWS67gIImd+QDJ7LOw7yWlSdi4Y3CH6LzejQzYAnH7n2wj5XgIVZlxX0cmN6aI5Hl3ZRsUcCAl3QvSGHU6jm/bEHz+MYVag08A4uQu3FwROdcIaarqxXS90aNV2EMEZ36VdxkmDJ6OdrOM6yJPTquaumZhmOCC62Qutl+T8zjJO+AyC/uZHpWQlI6UdzBrJnnibEwqH40kCY+4lyHV3FiQlyAaYnLPMQnagA6prvdB9ZqBlugdYRXnf+T2b7TXOgLXQHyADJcjRmCE5fJQftnrOo6rlZx2W/HpmGMvhPf3L+Z1I58zY+RfuLELQ8KguTJM175I/EanpgSa2K7IKf7/5n2PW9KB99sFDhozTDGL2NWPUk0f0qw7ONA7ldRaurdWK7OqnYshtO/eRHcEgO4cfsnV8tONRczg+TruFw0zQ6lYFwwLqj+T77IrS9iGZjB5yvQzT32SHc3n3LONHIW4/CFy0nj8VpBvDBqKYknlvL55XOV+Butf8O7zE55T2VoKlHkxBOkcg+MnFlMUyTXJTm3dcBGQ0DZBzfslYfWDKh8ivd+I68fyoPMdyJgR25qAmRYTdp7rBoy/bM2RfAXCZknEnproH2JCxjQsF0Opnf+/sdMiiRP6zetKM5xRMY4xp0KpX3nPQtfbgEPPcsqC5aQzGFro8V/Dw1fk1jiKwH5q/RYzBeUFmR9/dVWBRZ+ohAj9EVK5b5EiYoChS+Ptcwr+fej852S3Nhvgo41+sjfuYZyrd8ZCigvyFJe+lAGgH7IqstI1zeU3X/Zl5886qWw/OY1B9QoJHQoRRjCB/B38uHLssfVVYG/UA59OqT04t+n0HLXBBATKr08qA2VYU1+UioakUG2pita+oLpkDRb5RPL+OGpAKcVv/IS+EGZoe7S71QpYPqRlVNQX1kk3ZwlxqdDtyHA7NjQsHn9l9a5HLXR/EsJVIiDtZCoxwbl2HEAxdzmqvQNvCTVMyOGEXCk27aF1bdgr2xmtt30jd95B86hGetozcLTZOP/9rFqgOy2rij6zZET7CXl8Jj1M/jkicUrztUjLRi9+1s4I1pJxEC/ebrJ2wc7jS63R4ZivwNGg+mQ5RN6MWCSIT2Q3PzjFsqZENbDszg9SW/NdHx+8qJV8e//JXM9+Cb+bPJpU+9RpFFn+6wrzskPdJoC/iHHWk2drN7J8buAMlHKYKlF35HqxC55pyuYjiFHdeOxHykxa1WJVODLd8CJPrrLFMDB8Wt3lcIDXgX15hrvq/IPYSrd5Nd1HwzgYH3rB2A4aV64iiEGimL+aHNVxeDpCwHcsfAV9/sM8qM9NxATQLh7W70ZJj4Y1Vzql2gONEq5msJxL+AFnXreKioOZpGOtiOGVUaOI11hasBC1OCIvvK0uyV4SpObt1pqjtHCwObH6Rw71U2j2cMDxeb8ze0GsKebiSeKMVOfzvmi9xXgbdP34DE+EHR5sz2MUpTFykzF0pffBosTLI1tdQpkHg9QcC0ObxnTRIOEfSPUXUrmskKhZk/uD88JqkdNDrhJbXVGvenwqIp5mW90eiR6nXyB9cycYGtwPxPriDlv28d+OqB8AAor3wNg+Q0OhmAamz2j3v3uiZ4C3m+KAsc905Jeqi92MO9zN46rVpju7dnPBbUuQCzjPrj+TwYP6MhAJepeZHE25t67hFRBqhKDRD05qUkhP1J6TXhvW+fxFR/RwSs40kKK5z4wxXUYpUQCcGlMFXzUhDx0MNRl0iOqtGV1xU9QbG8sqDkVJ6DOp+sfnt2ruEX6sY6c+vLRpjwzx15Dkup9pG69kxDhI7eE/AFvP6pyNZsovps8lm3UJUwWDYbraD+JDWUg8iOsQZRm5wUxW58eHNlNmbsqlAGR6MGdVFfvO6W+KXk/hZnPxujqix4h6Jk2ZnS0/pHtEYL4wP7q75WrmVY7Evgx2C/9STbtZbf5Jt4PUqGOpvmowpGEYpAwr4tVL2JcE/c3OT6S7k7X64zcYZf/YufIfmapa88WT5P6pEvZMSAdBqiHFrt+sYju+ppx46AnnI98gLKVKAEETIrJbt0d7NoqPHhNGYW6dUPdlYfqIpnb/Mlvh7Pw2ActsP7+sGWve2RZ6iYTha93IfDF9QKcp9rF/cfxv5qdIsS6CyYNWJe+JGAohHnVRGWmfMeo7u2t7l4qUTDIEOK2AyvP9g5wkO2qQ5na1s1ynUW33KzBCB3oF6B8LU/yQzeLeNQ2/C3P2yD77XTN288Bj5wvU7VbJAg23NsKC32A+1Ab8kfFyNrRxS6rBUHjg5IKISp8dOwPK1Lno9f6bBKfBd7ptJuvQoAPHXMKE2LfgN8I5BuFWO9Nw+VqKx5K80El1nskBh/mF7u2MziOfKdNjZFoy08d5jxNfZxbTjMN0tfu2GhLxx7K9Dstd45izOdxXfpVZoJrkrPK8B8Xz5muzloJUYbA+tAwVMgdMGulbS+maM7yAnT3xkNST3I7M2DzbSfTK9seoGUkcvyTrBXYmDIay0Az+PXsUlql16lpS7E08PyiozCLQ13bBiUB19Wc5cDkRD4p8WWAMhwQ2bpHCpqqbj9KWStielihwyZKrK36XNqKJTK/OnLXR2B82bxM6YCM26zMl4HH2WkjYcsS9phTuqUs8rn2yon3/mvoGaMvA1IXvMH/Zjc+na4cg0IKY83pQAqqokv+sd0/pUkzg4aO9BOM6WiLo4JbDQhmKUdB4ia6UUczKZ2tKurG9l5Y3LWrUc+CjYf3KZuYDjeLfpSTq2x0cYqND/fQd8XzIkAFK946eu7XMqVX0qeNXZ8jWDCF54lxesIh1xmWcc4O3DJVm8P2t00yhcjsMzr+ptYyUgbGm7BXKWxLdgLiALer7H3cRmxNfhRUJMXLzQYwssHKn2ly2j3rfA69HcIyqXJsiJfhTA5keZLlYWG50ZjhtqA60tP1KLz3LonE8eX/nKrHl3fnzfynlsXCYIFfbQRXT4aOGwfVELNy9miyob3f13383R/YZE2kr8fw+66O5op6J5zO7i/SJHmFXpaXp5qV55FXCAGqK2R22e+0rPnUTP43FebAWq/Cmdrv7F/Da80vqJ8zTSUD93GXzNYKG9uAXxT58jPopzywbiFILbWnaLNytbmUD8N4Hmnrus0UZZymfLKDPFG91cYbrd04Arq2okt/R+3ZjPzgka/NdEGik1zWeppfUwEHwL3FZFpnp9J/a2jqguYsQW/NcItyXqfcsma391RegTSEoWsm5Xnx6R/ZAMMRQz72cH3yVSP7H1jJsI93us3UmxSxHGg/43cbUstlFzGI5G++qeExS2HBbk56uZ9jxTBX5XrefiBZsnXLGqleRmZFLqCQ7DEH2afOsECIY0CWbU3+oBF24Zsd93i1pjnudkk5nv0t3CdOr2sbIINsuP2HQTL8zWRuGzbkxrXAE9sbIvAyiA0VplxhvQ1ein82xyeAkNRsZFfI7bOivqpxtDM0acBhj3cNsNqI+zaoDOvH+jxiyZ/c0sW6E6bysE+/dZ4Y0RhIaxxbdrmmnFZzJBAFGiBP+jFobfyPPwa4P3b94VMkiGMyh1d7aI65km9LPbzUTLeqCrZ8wfLmeuZu9b+o9QesubuMcv4LgL6ZkyUct5R7QmTfojF4c/DPs9HfIhmtoeWb6vW8tqsMC68lH/6RfMSxvXrHunDi1WeccmJIlWB4fwLZQchDyqMzK91Vgc+1AnWum/7KZ8VsDWhZZ6UOfywteP85QvmaNXJL9CBDqeJA/099Pi30cJdDzljXfq0yvl4hWC9Es8EgMpk6oAdesEfcD3eSP6JcZGIb5vneQ+VJga1Vomm5PQ415gxPpznOHHu8YDBryFot86lBm/PvAdVROf/+yGSntfci3g6reznm3UH0xaubmwwvInsPfrVsCLE/QmT4CS5m0vuZhemRsqY1DASZShSHp9CBo+NwxAtNz1TOyaCfrT2aYTazcsm5laz9b3sDJq1ZtRXB5oUScF++XqNWFteRB/8Hx4p9BhyvVq1nMV9c1JMsAKcihK+4cUn+jPQ53b9tGv2OAQ+I1s+GzMbMKKotMHrwFC+dIxdVptpFOdGcr2z2DFh8y1AEdbO8LODyomnE6d2RVGesmPrDr+guyFqlymuCh2WrAEoCLceLUWyZdFp6Ld58AWvSWKtUwjwgegG0VoHNgKWKzvIvPyatpnfSVCF2sTjXv5qouBkDYmVgJpghFPqrGFCiI8Q5mrY7pC163h6vxBU7z69K9/27ffU1osig2ehmSfEWxSsGoPwf9nLHVvmub9mtcr1Tstw/Om3fw5Hz7+0aPKwLIeHNf4ux6C/1ukT41/kM4S+6XI6/XT6SDxsHqE9CKD/hyyK8oCq81tpikXmv2brN52S08dyaldZ7r969pfmLh4u3BiSgIrWay1uGIoQuIqrl448iBiR62ApyU/Pq9B3JSlhw2++Y5Tn9hWGy4DluVcG7sFCIz9HlMgcNwbXFBFaA9qyAoc1n9kPNej+3cG+3057y9BRtwU7KTSiBl2Rt1duxn/xE3kWqS4ZNoVfg1bQPXmQU3E2arRjpmHpyp3Dc7ogrIbUBuRQpe3ekpTBJPXscGGmjI44mWILPY04XEzTnt3PvZtaOPPhemX/hlzOA15SlJ9VC8cMAH2aVEdYkA4RHw+RJgiojRLQJoSPFfpg9FvEdKafH+ivL25ZfbOZfFt3M3V2fNDQbRnpPuEOUy36ZF/6vl2x7pfK++qGD1nlnNAlhVkyKHeZjebHkMUwdQN+PGlUeMompXoT3UOuvVYp5vtRaCBeEbKp4W5PQY9sfG8yLAj8mC9rLAVXngd3wARvPvjjjLQx7Gt1H0/wfoQtPix739/ZASRB7MDmWxaO1KrQwey6aGTdpA1yJuargtSGN6fxNlp51437+6nce1pgc356DpniwMu2gjlinBkxh7wh6O0xj18sowFXcYmCN4juR2XtFjEi6dTG5tIGy59awLtCksCzarejoeMZ2iTumxqWr/T0jOPQ8OwwOHJW477P4sTavZbkvdtbF6cQtOrDeqYzVQaqFfVgumm1lu8RxtisE9Miz3xyZFVXHccXPzPLKKin9OHqR6nwD4Z2za1+W06eI6Suj+qUIFQbG7KpY/1qSNTp+nqWQPlZrTeuWbPKvEkwZDjOsc0FxQktxDeXZlNMrNUGUIxI1FwBD7VgfyvyU3fVnNJJwcE+bJLv5hhlVhvrfeV/YGQakfVOqKCPb928FzybArT9XNc+6J0vhAnqmEn8h6biN+n9yowpG0bi4zl0KCkoKdn2HwV/WYvPyToJo8JJlWt5bvH5/rO4P5tGlqExS9DYaBJZ4krGro+3HFyZEeTe7LoTwryD2VfnZjs5Yi/zySAz8qNLBbC6jeSJCVODOqxgfFKPRsUWsaX0gOL2ynwBi3cwfCGt+FkFoa5rF5SzgM9YojS0okoAlkD7xLcYFQoaPBuWDpfG7WAIDvxksMtV10tekkdgz0Boj/U1Co5QSgWTFfVhLtvMAN2pNB7A3Nv3Lml6yakCO0jFVYr6u5FZu6XqAizxz5xg3gFnbJtCq63N/rKYvRc5QW4myEh8gFURgd7crWh475wiuyYTLd6RX90/IN1Qz3I1avBomt61fY+2hJVmJh3/UfKlubNeSmoEu7/Zp5OlthHyiiCFGaFORxvsI/WeeiPZA/ms6Rj18eRi2Nd4QTBU/eKbHUkPvolajZJLsvdFONxtl/3C40hwPUFQLOLdkXnT4pmdZYDPIfsDv7YG30nDcdOf6LeJQ7RDkgNbQp4hEhkGorhjupybZgJcUtwJX31OrjXRshV621tJDbui7oFT7x+/HPRuvvYkw7HcQbsSQNKMDQPk4BecMau0vDAB1OPxb7c/oIvTa1DfUixMf6hHLRAMXN1VCBUt4ZJnjkxbyvrQG7esZvpfUVk1rKsUc30cazkVU45oLJwMdVas6WZBfHQmR/7ueiRyazVr//e8hJiXbwLuNI2IH3LsK+Q9t9zXOmuHBkXpNehWyEC5V/psu1nXqRyrWavMeYmgrsHalPq9wJ0C3i6wqjC3IImaFMp8F08SdhI2ia1dURMI0oXLlIcwucL83bxeXATgBOFx8cVFujlh8mYZzFNOxZmSor/IbHOaJ9hDMjYaGTkFgWq1WFkw05finDIjsV0ngnJ+2b1KgKqtq/oKgYSfJPD37/dxfcZXNgpyl2u9UwBC2W5nWFU2UmhuCVV1NA4duR8d9dIbGzMyxY6Goy6daSYHpPlDuvJghyRm784QQl6ZuC+uzuqk0z7ntfdF47vYmlmlbnad94L9Ez/WmOW7fLL0gqEI+mPz/ZMWh/honFXDRWYvw8r+Us5hnJAm3RK4zZH08F9r2HKUWrO8Xg9J1Tc53UuRS8j80an+T0kvJjId2P7uTEKdGkkVmW43mhvz1B21GIAyxUSn8g2kKKahA7Ji+2cjH/6A5AIrmbhMVwdjvYiP8fIztqjKoVF9jzzsr58Nr1Eb5t/XFZwdEBU9XhwvvbyAhY2CQGzy08BoYzZgV5Sm0SZRdMi2FZabU/nv1UR+62j6wFXiskbcudOR2KRSiShFXeKJOsBrKPNdh62N5zwp893S4bfW7U2Qt4o2nM6YFKdwsgKO6T929bqocxftf6E0voPNrD1G1PnBcewBP5nC+Rw0mJJ2/K58ZRRUw7UWHDdDuWyk30DyX6gKat2qc3xagElUgMJ+xv6yCX32Eduhlz1aPlKZUk+4ixo1F0yawnmJWrMvkUyZvsHV52CZgAm0IIewj+RGguiw7yIjLXyolnCkqXnvMv+2Ugvj2eEuzX5IKWPtgpuINchpK7BzJuTZ+JcdwIBY9+Y6hyMxlB2X31NLSFG9JzhxPYIIss5YN9tBGm48PlvKpZy8+gfmudVFDYfOoUNWfhfaIe4d9m/wwRfPpzu1ClAH/djGoH52GY67243NHnjhzTC2EIGU7w8btYaPYv4BU/4f/4crI5Djlw543+GWmBPS9G//BzZMWriRfSadTMtq87aXo7119uV+u+Ygf/UMrtCdyS+KhxsILBeoSwVekJAdgChnz6CLlTqpytZb5VtFXzT0ZooeXRD04sATL+p8sSnhKTVx8B0ksGDIhXj5D1TcQ2KnWcas1izyrmZctUFZJ0MbmNPvs6Otth5dNXiVY2DUTJvBV10Qn2Hwp3+PyU6X0w5KSF1Q7xCZLKpxHo7SmY3nBTcXwOSiayTjPyPP1Cws5+Nf3+Nqo4j7skQGjGnI+vrCc5bmvNerifKkju9pu/L47fCvD00Huj4QG4Jhc+VG/sgb/es3oHrSg5Dt1pIwgNqlB8X3zYgJVoqr71RmtWMi37C+oUZ+EyCdXB4yW1XJk1POmINibv/TmPcNZxFDT9HUNQCC0I98TTs7T4oh9KPnWqkhcQ1N0lhWiYmxQcRLxmNXcEQ91N7DUoH1CVanrCckL08IYSIz97XZ0tYe3Qwtqt8F+zhqu4g8mbd9e2nK9q3rda1iB7EfsNLqcLtzyoLeX/oDKYrol2M67zEDXBMtzSrNb5qYa1WPUgB/BXqMbjQkBLWXPISD4xWiEK9JZwOpSQvxQZDvIe5GB6Piew42lRWv+ucjiqKZ+atwYlfdLINTJFpLPyWeYIwXsH6rtJArlOZcBGyx92ynvNWi2MHhd61PvYjXurpfHvnyuuoxacPgbv0yEoGRfiRx2egqwuPTzb/HxFQZDVKjyaNsKvp1sGk+fJmvhIT8gOlz+8qxmNh2pUbUELtGgIflWUAu7q/vb3wqfm4K05VBzPbEpQfYfxYRlxQXFlUL+L9zkg3FtLVZWBrGulTcOHoxtVcia7lPwPpolPnAjUTTLjyYnbyiu1C9gXMZKE0w7VNGXLPB3YSYo1GhPJQrR+4+xaeJYeJOsUH7IQ7l0JYelacK8m0pX/UxI87fHG8OIBvEtynZbu0UvWp/CDV7Vx41m0Xp9frUM/9joqenlZs2naPUe3F28d43E/yz35s8tMh5TzQZud2cU2xx3bc7vYynQPZJ2Igzs9v4qZVWBs84j3EZJBx7/PoWeu/0s23oHeunIQAcMOLSFTlqLiNZhlN9SkyVdRow82T7x2B1zTtNA/irtD3NQh44aH26S/8h1BrPDqCs00UN7xUvRRcNqwxej3ucq/zXj2BYZZiesg4zx2hOu+yAeb2zHXMEGFJBuQJLQu+Hvqu4Z84o16tRhqZVe/H6mRzt5fp776534RP/gItyHP53VWz6A82ZSJ225Djkn039GMCw2w1Q+SbZK5JRVBTHOB+hwToxzQ5h0HNhrpLDaFn2Tl2T6wkPfIvY/NqyVGY3HZwZnO/maBf530o1DX+qqa/C38IPgLusEOdCXVj4v8+8FhvO9Kw3ynWbvzXxJEdhsMGufPiO749Pap8vLlym8g0OTU1qyTMCDSbuluJxp+80povN3jQZxzKmyjAPit6QSxP+6VrdJSmnNcrmqh9wwsuTM/VUlPxUovi9qhh+2VqTkvP3WFj6le/kBbH0O1+itM8+WSrn+iDjbfBOyGz3q6rjvDjZ1TfisBUlPrauJPzLTWz09geNwdr+vUU/vG71A2K+PohiCsFJLDxrq41jPcYnPKU9vYYWY16yNhzP0PfkK2HF+5dzOwb3OEzlviVaS1X6vdI/7ICTOI73VzSca0Q8W09UKJc0Q84iB+95pm3sKxegNsIEYLhwyP//0vJp43Swwd+LZ6jhA9zJ8Zfx5e1W3viivGExt2Qu7ST6GBV633MJOhjoGNmKUeOLOrs/8aa6+tlpYeFYaPvD9PL4zKttb91zSSDcLHkeCAD/re/hIPgvFt2gVo6hDjwM3il07DepDdQNA6ZtewDeihojMhjUzF9AJ6CB7DOHtOxD2ebkdH2i+w1AHvQXkcWhj2fLkVtdHTz48eRqX2618iakwFHOuUQF/C+r1OOkCl1b1NN+s2vJ3XKc453UVloDLfL5vfhD7Z+K0Nk3qiaaucEy48FVt2iRJw/zOH4wQeK/kv+oYIaJ1K6RvXHYpQZnWw+Puo3Gx4Y7CQ6RqM7RzyheGy2ieb9HFxnR5PYuvP8OUf3fCJ+pwQ9uPJ8PlnQlxFeLZhkWaEPSQjvbpevnbcqiqzof+5HAI10DbzYevT1mTFs9yu8gMIH/wHLU7dY+CEHhNzBtIGIH1+qpBDmRQ6tA1PUyIMok2fwFgGCUbPDCAKJR7U8fkpVKio4ZIAn+ajspnBQgjsW3X+bSInnXn5x8e4TVt2/bzdh/qATUV7TinHmRh4N/hOmnq6CFUhOcnt7A8/P1CR+dE0BpViVHFoGr0Ajo3GiRbSro235Tec+oN/apx70nELjZZ1eyknYiTgaoK99pPtRs0/m83CLiN50zcMf67S0znjfmB5q7MpcaM+96K7b5HBOknw7OHvCrqiLRJTL0JzM+WGK9Tz9ZsSeNtqpMHtM2TjxtXsd1vQtODR+xuDaFvckm8+LtxbH+x3w485uj9IYqGAZy9T1IZ94G8t2ab8t8o0TpkfTdYz8Sz1rryfCYt3pxjemkMquwh0Y0LqsHsU5KDlBPdc2zvjZD/ZIp2mAdfaYG21AeCdfZ0oOmvjLLuEMRWLuKoIgFEc3Xl0ryJpCc2vRJ7gCieQE58H7ODGjfy+S1eSpwKK+kCtrouCNrFMDbZhNh28NYbZuaf8Gg2tb0l6B82LglbpRwUq+/RqvyDfcx78cpCrpj/PDLb9e59PhjsskL23rKCi74FC/f+JMquxMVpkPZEVrJC4tHc7fDKu/J+ZxVEqARp35RLJj+z4dXPljMiPwSihHKfY9zO2hzH0qch90aCIeCaPNGQT9mnIp/d+7rztjIV7fLidWh8h50l37NsOwh8B1CoMz7zo51lS35AAFJZPttlwUcbxPdPFVzl6bX8qQnTbTz9ghxOvEj/e66oM21wJqXY1VWwKZjprOh0IW4M9pbFxbeVerSHege/dz/AftD39M=", Kt = JSON.parse(String.fromCharCode.apply(String, Wt.inflate(Yt(sy)))), fy = Wt.inflate(Yt(uy)), gn = new hi(fy), ly = Math.log2 || function(t) {
  return Math.log(t) / Math.LN2;
}, pi = function(e) {
  return ly(e) + 1 | 0;
}, cy = pi(Kt.categories.length - 1), ll = pi(Kt.combiningClasses.length - 1), vo = pi(Kt.scripts.length - 1), di = pi(Kt.eaw.length - 1), mn = 10, hy = ll + vo + di + mn, py = vo + di + mn, dy = di + mn, vy = mn, yy = (1 << cy) - 1, gy = (1 << ll) - 1, my = (1 << vo) - 1, by = (1 << di) - 1, wy = (1 << mn) - 1, yt = function(e) {
  var r = gn.get(e);
  return Kt.categories[r >> hy & yy];
}, Fy = function(e) {
  var r = gn.get(e);
  return Kt.combiningClasses[r >> py & gy];
}, xy = function(e) {
  var r = gn.get(e);
  return Kt.scripts[r >> dy & my];
}, Sy = function(e) {
  var r = gn.get(e);
  return Kt.eaw[r >> vy & by];
}, Ay = function(e) {
  var r = gn.get(e), n = r & wy;
  if (n === 0)
    return null;
  if (n <= 50)
    return n - 1;
  if (n < 480) {
    var a = (n >> 4) - 12, o = (n & 15) + 1;
    return a / o;
  } else if (n < 768) {
    r = (n >> 5) - 14;
    for (var s = (n & 31) + 2; s > 0; )
      r *= 10, s--;
    return r;
  } else {
    r = (n >> 2) - 191;
    for (var u = (n & 3) + 1; u > 0; )
      r *= 60, u--;
    return r;
  }
}, Ey = function(e) {
  var r = yt(e);
  return r === "Lu" || r === "Ll" || r === "Lt" || r === "Lm" || r === "Lo" || r === "Nl";
}, Cy = function(e) {
  return yt(e) === "Nd";
}, Iy = function(e) {
  var r = yt(e);
  return r === "Pc" || r === "Pd" || r === "Pe" || r === "Pf" || r === "Pi" || r === "Po" || r === "Ps";
}, Oy = function(e) {
  return yt(e) === "Ll";
}, Dy = function(e) {
  return yt(e) === "Lu";
}, Ty = function(e) {
  return yt(e) === "Lt";
}, Py = function(e) {
  var r = yt(e);
  return r === "Zs" || r === "Zl" || r === "Zp";
}, By = function(e) {
  var r = yt(e);
  return r === "Nd" || r === "No" || r === "Nl" || r === "Lu" || r === "Ll" || r === "Lt" || r === "Lm" || r === "Lo" || r === "Me" || r === "Mc";
}, ky = function(e) {
  var r = yt(e);
  return r === "Mn" || r === "Me" || r === "Mc";
}, St = {
  getCategory: yt,
  getCombiningClass: Fy,
  getScript: xy,
  getEastAsianWidth: Sy,
  getNumericValue: Ay,
  isAlphabetic: Ey,
  isDigit: Cy,
  isPunctuation: Iy,
  isLowerCase: Oy,
  isUpperCase: Dy,
  isTitleCase: Ty,
  isWhiteSpace: Py,
  isBaseForm: By,
  isMark: ky
}, Ly = /* @__PURE__ */ (function() {
  function t(r) {
    this.font = r;
  }
  var e = t.prototype;
  return e.positionGlyphs = function(n, a) {
    for (var o = 0, s = 0, u = 0; u < n.length; u++) {
      var f = n[u];
      f.isMark ? s = u : (o !== s && this.positionCluster(n, a, o, s), o = s = u);
    }
    return o !== s && this.positionCluster(n, a, o, s), a;
  }, e.positionCluster = function(n, a, o, s) {
    var u = n[o], f = u.cbox.copy();
    u.codePoints.length > 1 && (f.minX += (u.codePoints.length - 1) * f.width / u.codePoints.length);
    for (var l = -a[o].xAdvance, c = 0, p = this.font.unitsPerEm / 16, y = o + 1; y <= s; y++) {
      var v = n[y], m = v.cbox, w = a[y], F = this.getCombiningClass(v.codePoints[0]);
      if (F !== "Not_Reordered") {
        switch (w.xOffset = w.yOffset = 0, F) {
          case "Double_Above":
          case "Double_Below":
            w.xOffset += f.minX - m.width / 2 - m.minX;
            break;
          case "Attached_Below_Left":
          case "Below_Left":
          case "Above_Left":
            w.xOffset += f.minX - m.minX;
            break;
          case "Attached_Above_Right":
          case "Below_Right":
          case "Above_Right":
            w.xOffset += f.maxX - m.width - m.minX;
            break;
          default:
            w.xOffset += f.minX + (f.width - m.width) / 2 - m.minX;
        }
        switch (F) {
          case "Double_Below":
          case "Below_Left":
          case "Below":
          case "Below_Right":
          case "Attached_Below_Left":
          case "Attached_Below":
            (F === "Attached_Below_Left" || F === "Attached_Below") && (f.minY += p), w.yOffset = -f.minY - m.maxY, f.minY += m.height;
            break;
          case "Double_Above":
          case "Above_Left":
          case "Above":
          case "Above_Right":
          case "Attached_Above":
          case "Attached_Above_Right":
            (F === "Attached_Above" || F === "Attached_Above_Right") && (f.maxY += p), w.yOffset = f.maxY - m.minY, f.maxY += m.height;
            break;
        }
        w.xAdvance = w.yAdvance = 0, w.xOffset += l, w.yOffset += c;
      } else
        l -= w.xAdvance, c -= w.yAdvance;
    }
  }, e.getCombiningClass = function(n) {
    var a = St.getCombiningClass(n);
    if ((n & -256) === 3584) {
      if (a === "Not_Reordered")
        switch (n) {
          case 3633:
          case 3636:
          case 3637:
          case 3638:
          case 3639:
          case 3655:
          case 3660:
          case 3645:
          case 3662:
            return "Above_Right";
          case 3761:
          case 3764:
          case 3765:
          case 3766:
          case 3767:
          case 3771:
          case 3788:
          case 3789:
            return "Above";
          case 3772:
            return "Below";
        }
      else if (n === 3642)
        return "Below_Right";
    }
    switch (a) {
      // Hebrew
      case "CCC10":
      // sheva
      case "CCC11":
      // hataf segol
      case "CCC12":
      // hataf patah
      case "CCC13":
      // hataf qamats
      case "CCC14":
      // hiriq
      case "CCC15":
      // tsere
      case "CCC16":
      // segol
      case "CCC17":
      // patah
      case "CCC18":
      // qamats
      case "CCC20":
      // qubuts
      case "CCC22":
        return "Below";
      case "CCC23":
        return "Attached_Above";
      case "CCC24":
        return "Above_Right";
      case "CCC25":
      // sin dot
      case "CCC19":
        return "Above_Left";
      case "CCC26":
        return "Above";
      case "CCC21":
        break;
      // Arabic and Syriac
      case "CCC27":
      // fathatan
      case "CCC28":
      // dammatan
      case "CCC30":
      // fatha
      case "CCC31":
      // damma
      case "CCC33":
      // shadda
      case "CCC34":
      // sukun
      case "CCC35":
      // superscript alef
      case "CCC36":
        return "Above";
      case "CCC29":
      // kasratan
      case "CCC32":
        return "Below";
      // Thai
      case "CCC103":
        return "Below_Right";
      case "CCC107":
        return "Above_Right";
      // Lao
      case "CCC118":
        return "Below";
      case "CCC122":
        return "Above";
      // Tibetan
      case "CCC129":
      // sign aa
      case "CCC132":
        return "Below";
      case "CCC130":
        return "Above";
    }
    return a;
  }, t;
})();
function My(t, e) {
  for (var r = 0; r < e.length; r++) {
    var n = e[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(t, n.key, n);
  }
}
function Uy(t, e, r) {
  return e && My(t.prototype, e), t;
}
var zr = /* @__PURE__ */ (function() {
  function t(r, n, a, o) {
    r === void 0 && (r = 1 / 0), n === void 0 && (n = 1 / 0), a === void 0 && (a = -1 / 0), o === void 0 && (o = -1 / 0), this.minX = r, this.minY = n, this.maxX = a, this.maxY = o;
  }
  var e = t.prototype;
  return e.addPoint = function(n, a) {
    Math.abs(n) !== 1 / 0 && (n < this.minX && (this.minX = n), n > this.maxX && (this.maxX = n)), Math.abs(a) !== 1 / 0 && (a < this.minY && (this.minY = a), a > this.maxY && (this.maxY = a));
  }, e.copy = function() {
    return new t(this.minX, this.minY, this.maxX, this.maxY);
  }, Uy(t, [{
    key: "width",
    get: function() {
      return this.maxX - this.minX;
    }
    /**
     * The height of the bounding box
     * @type {number}
     */
  }, {
    key: "height",
    get: function() {
      return this.maxY - this.minY;
    }
  }]), t;
})();
function Ny(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = Ry(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function Ry(t, e) {
  if (t) {
    if (typeof t == "string") return Is(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Is(t, e);
  }
}
function Is(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
var jr = {
  Caucasian_Albanian: "aghb",
  Arabic: "arab",
  Imperial_Aramaic: "armi",
  Armenian: "armn",
  Avestan: "avst",
  Balinese: "bali",
  Bamum: "bamu",
  Bassa_Vah: "bass",
  Batak: "batk",
  Bengali: ["bng2", "beng"],
  Bopomofo: "bopo",
  Brahmi: "brah",
  Braille: "brai",
  Buginese: "bugi",
  Buhid: "buhd",
  Chakma: "cakm",
  Canadian_Aboriginal: "cans",
  Carian: "cari",
  Cham: "cham",
  Cherokee: "cher",
  Coptic: "copt",
  Cypriot: "cprt",
  Cyrillic: "cyrl",
  Devanagari: ["dev2", "deva"],
  Deseret: "dsrt",
  Duployan: "dupl",
  Egyptian_Hieroglyphs: "egyp",
  Elbasan: "elba",
  Ethiopic: "ethi",
  Georgian: "geor",
  Glagolitic: "glag",
  Gothic: "goth",
  Grantha: "gran",
  Greek: "grek",
  Gujarati: ["gjr2", "gujr"],
  Gurmukhi: ["gur2", "guru"],
  Hangul: "hang",
  Han: "hani",
  Hanunoo: "hano",
  Hebrew: "hebr",
  Hiragana: "hira",
  Pahawh_Hmong: "hmng",
  Katakana_Or_Hiragana: "hrkt",
  Old_Italic: "ital",
  Javanese: "java",
  Kayah_Li: "kali",
  Katakana: "kana",
  Kharoshthi: "khar",
  Khmer: "khmr",
  Khojki: "khoj",
  Kannada: ["knd2", "knda"],
  Kaithi: "kthi",
  Tai_Tham: "lana",
  Lao: "lao ",
  Latin: "latn",
  Lepcha: "lepc",
  Limbu: "limb",
  Linear_A: "lina",
  Linear_B: "linb",
  Lisu: "lisu",
  Lycian: "lyci",
  Lydian: "lydi",
  Mahajani: "mahj",
  Mandaic: "mand",
  Manichaean: "mani",
  Mende_Kikakui: "mend",
  Meroitic_Cursive: "merc",
  Meroitic_Hieroglyphs: "mero",
  Malayalam: ["mlm2", "mlym"],
  Modi: "modi",
  Mongolian: "mong",
  Mro: "mroo",
  Meetei_Mayek: "mtei",
  Myanmar: ["mym2", "mymr"],
  Old_North_Arabian: "narb",
  Nabataean: "nbat",
  Nko: "nko ",
  Ogham: "ogam",
  Ol_Chiki: "olck",
  Old_Turkic: "orkh",
  Oriya: ["ory2", "orya"],
  Osmanya: "osma",
  Palmyrene: "palm",
  Pau_Cin_Hau: "pauc",
  Old_Permic: "perm",
  Phags_Pa: "phag",
  Inscriptional_Pahlavi: "phli",
  Psalter_Pahlavi: "phlp",
  Phoenician: "phnx",
  Miao: "plrd",
  Inscriptional_Parthian: "prti",
  Rejang: "rjng",
  Runic: "runr",
  Samaritan: "samr",
  Old_South_Arabian: "sarb",
  Saurashtra: "saur",
  Shavian: "shaw",
  Sharada: "shrd",
  Siddham: "sidd",
  Khudawadi: "sind",
  Sinhala: "sinh",
  Sora_Sompeng: "sora",
  Sundanese: "sund",
  Syloti_Nagri: "sylo",
  Syriac: "syrc",
  Tagbanwa: "tagb",
  Takri: "takr",
  Tai_Le: "tale",
  New_Tai_Lue: "talu",
  Tamil: ["tml2", "taml"],
  Tai_Viet: "tavt",
  Telugu: ["tel2", "telu"],
  Tifinagh: "tfng",
  Tagalog: "tglg",
  Thaana: "thaa",
  Thai: "thai",
  Tibetan: "tibt",
  Tirhuta: "tirh",
  Ugaritic: "ugar",
  Vai: "vai ",
  Warang_Citi: "wara",
  Old_Persian: "xpeo",
  Cuneiform: "xsux",
  Yi: "yi  ",
  Inherited: "zinh",
  Common: "zyyy",
  Unknown: "zzzz"
}, ba = {};
for (var Yi in jr) {
  var Ki = jr[Yi];
  if (Array.isArray(Ki))
    for (var zy = Ny(Ki), Os; !(Os = zy()).done; ) {
      var jy = Os.value;
      ba[jy] = Yi;
    }
  else
    ba[Ki] = Yi;
}
function Vy(t) {
  return ba[t];
}
function Gy(t) {
  for (var e = t.length, r = 0; r < e; ) {
    var n = t.charCodeAt(r++);
    if (55296 <= n && n <= 56319 && r < e) {
      var a = t.charCodeAt(r);
      56320 <= a && a <= 57343 && (r++, n = ((n & 1023) << 10) + (a & 1023) + 65536);
    }
    var o = St.getScript(n);
    if (o !== "Common" && o !== "Inherited" && o !== "Unknown")
      return jr[o];
  }
  return jr.Unknown;
}
function qy(t) {
  for (var e = 0; e < t.length; e++) {
    var r = t[e], n = St.getScript(r);
    if (n !== "Common" && n !== "Inherited" && n !== "Unknown")
      return jr[n];
  }
  return jr.Unknown;
}
var Hy = {
  arab: !0,
  // Arabic
  hebr: !0,
  // Hebrew
  syrc: !0,
  // Syriac
  thaa: !0,
  // Thaana
  cprt: !0,
  // Cypriot Syllabary
  khar: !0,
  // Kharosthi
  phnx: !0,
  // Phoenician
  "nko ": !0,
  // N'Ko
  lydi: !0,
  // Lydian
  avst: !0,
  // Avestan
  armi: !0,
  // Imperial Aramaic
  phli: !0,
  // Inscriptional Pahlavi
  prti: !0,
  // Inscriptional Parthian
  sarb: !0,
  // Old South Arabian
  orkh: !0,
  // Old Turkic, Orkhon Runic
  samr: !0,
  // Samaritan
  mand: !0,
  // Mandaic, Mandaean
  merc: !0,
  // Meroitic Cursive
  mero: !0,
  // Meroitic Hieroglyphs
  // Unicode 7.0 (not listed on http://www.microsoft.com/typography/otspec/scripttags.htm)
  mani: !0,
  // Manichaean
  mend: !0,
  // Mende Kikakui
  nbat: !0,
  // Nabataean
  narb: !0,
  // Old North Arabian
  palm: !0,
  // Palmyrene
  phlp: !0
  // Psalter Pahlavi
};
function cl(t) {
  return Hy[t] ? "rtl" : "ltr";
}
function Zi(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = Wy(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function Wy(t, e) {
  if (t) {
    if (typeof t == "string") return Ds(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Ds(t, e);
  }
}
function Ds(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
function Xy(t, e) {
  for (var r = 0; r < e.length; r++) {
    var n = e[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(t, n.key, n);
  }
}
function Yy(t, e, r) {
  return e && Xy(t.prototype, e), t;
}
var Ky = /* @__PURE__ */ (function() {
  function t(e, r, n, a, o) {
    if (this.glyphs = e, this.positions = null, this.script = n, this.language = a || null, this.direction = o || cl(n), this.features = {}, Array.isArray(r))
      for (var s = Zi(r), u; !(u = s()).done; ) {
        var f = u.value;
        this.features[f] = !0;
      }
    else typeof r == "object" && (this.features = r);
  }
  return Yy(t, [{
    key: "advanceWidth",
    get: function() {
      for (var r = 0, n = Zi(this.positions), a; !(a = n()).done; ) {
        var o = a.value;
        r += o.xAdvance;
      }
      return r;
    }
    /**
     * The total advance height of the run.
     * @type {number}
     */
  }, {
    key: "advanceHeight",
    get: function() {
      for (var r = 0, n = Zi(this.positions), a; !(a = n()).done; ) {
        var o = a.value;
        r += o.yAdvance;
      }
      return r;
    }
    /**
     * The bounding box containing all glyphs in the run.
     * @type {BBox}
     */
  }, {
    key: "bbox",
    get: function() {
      for (var r = new zr(), n = 0, a = 0, o = 0; o < this.glyphs.length; o++) {
        var s = this.glyphs[o], u = this.positions[o], f = s.bbox;
        r.addPoint(f.minX + n + u.xOffset, f.minY + a + u.yOffset), r.addPoint(f.maxX + n + u.xOffset, f.maxY + a + u.yOffset), n += u.xAdvance, a += u.yAdvance;
      }
      return r;
    }
  }]), t;
})(), Zy = function(e, r, n, a) {
  e === void 0 && (e = 0), r === void 0 && (r = 0), n === void 0 && (n = 0), a === void 0 && (a = 0), this.xAdvance = e, this.yAdvance = r, this.xOffset = n, this.yOffset = a;
}, or = {
  allTypographicFeatures: {
    code: 0,
    exclusive: !1,
    allTypeFeatures: 0
  },
  ligatures: {
    code: 1,
    exclusive: !1,
    requiredLigatures: 0,
    commonLigatures: 2,
    rareLigatures: 4,
    // logos: 6
    rebusPictures: 8,
    diphthongLigatures: 10,
    squaredLigatures: 12,
    abbrevSquaredLigatures: 14,
    symbolLigatures: 16,
    contextualLigatures: 18,
    historicalLigatures: 20
  },
  cursiveConnection: {
    code: 2,
    exclusive: !0,
    unconnected: 0,
    partiallyConnected: 1,
    cursive: 2
  },
  letterCase: {
    code: 3,
    exclusive: !0
  },
  // upperAndLowerCase: 0          # deprecated
  // allCaps: 1                    # deprecated
  // allLowerCase: 2               # deprecated
  // smallCaps: 3                  # deprecated
  // initialCaps: 4                # deprecated
  // initialCapsAndSmallCaps: 5    # deprecated
  verticalSubstitution: {
    code: 4,
    exclusive: !1,
    substituteVerticalForms: 0
  },
  linguisticRearrangement: {
    code: 5,
    exclusive: !1,
    linguisticRearrangement: 0
  },
  numberSpacing: {
    code: 6,
    exclusive: !0,
    monospacedNumbers: 0,
    proportionalNumbers: 1,
    thirdWidthNumbers: 2,
    quarterWidthNumbers: 3
  },
  smartSwash: {
    code: 8,
    exclusive: !1,
    wordInitialSwashes: 0,
    wordFinalSwashes: 2,
    // lineInitialSwashes: 4
    // lineFinalSwashes: 6
    nonFinalSwashes: 8
  },
  diacritics: {
    code: 9,
    exclusive: !0,
    showDiacritics: 0,
    hideDiacritics: 1,
    decomposeDiacritics: 2
  },
  verticalPosition: {
    code: 10,
    exclusive: !0,
    normalPosition: 0,
    superiors: 1,
    inferiors: 2,
    ordinals: 3,
    scientificInferiors: 4
  },
  fractions: {
    code: 11,
    exclusive: !0,
    noFractions: 0,
    verticalFractions: 1,
    diagonalFractions: 2
  },
  overlappingCharacters: {
    code: 13,
    exclusive: !1,
    preventOverlap: 0
  },
  typographicExtras: {
    code: 14,
    exclusive: !1,
    // hyphensToEmDash: 0
    // hyphenToEnDash: 2
    slashedZero: 4
  },
  // formInterrobang: 6
  // smartQuotes: 8
  // periodsToEllipsis: 10
  mathematicalExtras: {
    code: 15,
    exclusive: !1,
    // hyphenToMinus: 0
    // asteristoMultiply: 2
    // slashToDivide: 4
    // inequalityLigatures: 6
    // exponents: 8
    mathematicalGreek: 10
  },
  ornamentSets: {
    code: 16,
    exclusive: !0,
    noOrnaments: 0,
    dingbats: 1,
    piCharacters: 2,
    fleurons: 3,
    decorativeBorders: 4,
    internationalSymbols: 5,
    mathSymbols: 6
  },
  characterAlternatives: {
    code: 17,
    exclusive: !0,
    noAlternates: 0
  },
  // user defined options
  designComplexity: {
    code: 18,
    exclusive: !0,
    designLevel1: 0,
    designLevel2: 1,
    designLevel3: 2,
    designLevel4: 3,
    designLevel5: 4
  },
  styleOptions: {
    code: 19,
    exclusive: !0,
    noStyleOptions: 0,
    displayText: 1,
    engravedText: 2,
    illuminatedCaps: 3,
    titlingCaps: 4,
    tallCaps: 5
  },
  characterShape: {
    code: 20,
    exclusive: !0,
    traditionalCharacters: 0,
    simplifiedCharacters: 1,
    JIS1978Characters: 2,
    JIS1983Characters: 3,
    JIS1990Characters: 4,
    traditionalAltOne: 5,
    traditionalAltTwo: 6,
    traditionalAltThree: 7,
    traditionalAltFour: 8,
    traditionalAltFive: 9,
    expertCharacters: 10,
    JIS2004Characters: 11,
    hojoCharacters: 12,
    NLCCharacters: 13,
    traditionalNamesCharacters: 14
  },
  numberCase: {
    code: 21,
    exclusive: !0,
    lowerCaseNumbers: 0,
    upperCaseNumbers: 1
  },
  textSpacing: {
    code: 22,
    exclusive: !0,
    proportionalText: 0,
    monospacedText: 1,
    halfWidthText: 2,
    thirdWidthText: 3,
    quarterWidthText: 4,
    altProportionalText: 5,
    altHalfWidthText: 6
  },
  transliteration: {
    code: 23,
    exclusive: !0,
    noTransliteration: 0
  },
  // hanjaToHangul: 1
  // hiraganaToKatakana: 2
  // katakanaToHiragana: 3
  // kanaToRomanization: 4
  // romanizationToHiragana: 5
  // romanizationToKatakana: 6
  // hanjaToHangulAltOne: 7
  // hanjaToHangulAltTwo: 8
  // hanjaToHangulAltThree: 9
  annotation: {
    code: 24,
    exclusive: !0,
    noAnnotation: 0,
    boxAnnotation: 1,
    roundedBoxAnnotation: 2,
    circleAnnotation: 3,
    invertedCircleAnnotation: 4,
    parenthesisAnnotation: 5,
    periodAnnotation: 6,
    romanNumeralAnnotation: 7,
    diamondAnnotation: 8,
    invertedBoxAnnotation: 9,
    invertedRoundedBoxAnnotation: 10
  },
  kanaSpacing: {
    code: 25,
    exclusive: !0,
    fullWidthKana: 0,
    proportionalKana: 1
  },
  ideographicSpacing: {
    code: 26,
    exclusive: !0,
    fullWidthIdeographs: 0,
    proportionalIdeographs: 1,
    halfWidthIdeographs: 2
  },
  unicodeDecomposition: {
    code: 27,
    exclusive: !1,
    canonicalComposition: 0,
    compatibilityComposition: 2,
    transcodingComposition: 4
  },
  rubyKana: {
    code: 28,
    exclusive: !1,
    // noRubyKana: 0     # deprecated - use rubyKanaOff instead
    // rubyKana: 1     # deprecated - use rubyKanaOn instead
    rubyKana: 2
  },
  CJKSymbolAlternatives: {
    code: 29,
    exclusive: !0,
    noCJKSymbolAlternatives: 0,
    CJKSymbolAltOne: 1,
    CJKSymbolAltTwo: 2,
    CJKSymbolAltThree: 3,
    CJKSymbolAltFour: 4,
    CJKSymbolAltFive: 5
  },
  ideographicAlternatives: {
    code: 30,
    exclusive: !0,
    noIdeographicAlternatives: 0,
    ideographicAltOne: 1,
    ideographicAltTwo: 2,
    ideographicAltThree: 3,
    ideographicAltFour: 4,
    ideographicAltFive: 5
  },
  CJKVerticalRomanPlacement: {
    code: 31,
    exclusive: !0,
    CJKVerticalRomanCentered: 0,
    CJKVerticalRomanHBaseline: 1
  },
  italicCJKRoman: {
    code: 32,
    exclusive: !1,
    // noCJKItalicRoman: 0     # deprecated - use CJKItalicRomanOff instead
    // CJKItalicRoman: 1     # deprecated - use CJKItalicRomanOn instead
    CJKItalicRoman: 2
  },
  caseSensitiveLayout: {
    code: 33,
    exclusive: !1,
    caseSensitiveLayout: 0,
    caseSensitiveSpacing: 2
  },
  alternateKana: {
    code: 34,
    exclusive: !1,
    alternateHorizKana: 0,
    alternateVertKana: 2
  },
  stylisticAlternatives: {
    code: 35,
    exclusive: !1,
    noStylisticAlternates: 0,
    stylisticAltOne: 2,
    stylisticAltTwo: 4,
    stylisticAltThree: 6,
    stylisticAltFour: 8,
    stylisticAltFive: 10,
    stylisticAltSix: 12,
    stylisticAltSeven: 14,
    stylisticAltEight: 16,
    stylisticAltNine: 18,
    stylisticAltTen: 20,
    stylisticAltEleven: 22,
    stylisticAltTwelve: 24,
    stylisticAltThirteen: 26,
    stylisticAltFourteen: 28,
    stylisticAltFifteen: 30,
    stylisticAltSixteen: 32,
    stylisticAltSeventeen: 34,
    stylisticAltEighteen: 36,
    stylisticAltNineteen: 38,
    stylisticAltTwenty: 40
  },
  contextualAlternates: {
    code: 36,
    exclusive: !1,
    contextualAlternates: 0,
    swashAlternates: 2,
    contextualSwashAlternates: 4
  },
  lowerCase: {
    code: 37,
    exclusive: !0,
    defaultLowerCase: 0,
    lowerCaseSmallCaps: 1,
    lowerCasePetiteCaps: 2
  },
  upperCase: {
    code: 38,
    exclusive: !0,
    defaultUpperCase: 0,
    upperCaseSmallCaps: 1,
    upperCasePetiteCaps: 2
  },
  languageTag: {
    // indices into ltag table
    code: 39,
    exclusive: !0
  },
  CJKRomanSpacing: {
    code: 103,
    exclusive: !0,
    halfWidthCJKRoman: 0,
    proportionalCJKRoman: 1,
    defaultCJKRoman: 2,
    fullWidthCJKRoman: 3
  }
}, D = function(e, r) {
  return [or[e].code, or[e][r]];
}, Hn = {
  rlig: D("ligatures", "requiredLigatures"),
  clig: D("ligatures", "contextualLigatures"),
  dlig: D("ligatures", "rareLigatures"),
  hlig: D("ligatures", "historicalLigatures"),
  liga: D("ligatures", "commonLigatures"),
  hist: D("ligatures", "historicalLigatures"),
  // ??
  smcp: D("lowerCase", "lowerCaseSmallCaps"),
  pcap: D("lowerCase", "lowerCasePetiteCaps"),
  frac: D("fractions", "diagonalFractions"),
  dnom: D("fractions", "diagonalFractions"),
  // ??
  numr: D("fractions", "diagonalFractions"),
  // ??
  afrc: D("fractions", "verticalFractions"),
  // aalt
  // abvf, abvm, abvs, akhn, blwf, blwm, blws, cfar, cjct, cpsp, falt, isol, jalt, ljmo, mset?
  // ltra, ltrm, nukt, pref, pres, pstf, psts, rand, rkrf, rphf, rtla, rtlm, size, tjmo, tnum?
  // unic, vatu, vhal, vjmo, vpal, vrt2
  // dist -> trak table?
  // kern, vkrn -> kern table
  // lfbd + opbd + rtbd -> opbd table?
  // mark, mkmk -> acnt table?
  // locl -> languageTag + ltag table
  case: D("caseSensitiveLayout", "caseSensitiveLayout"),
  // also caseSensitiveSpacing
  ccmp: D("unicodeDecomposition", "canonicalComposition"),
  // compatibilityComposition?
  cpct: D("CJKVerticalRomanPlacement", "CJKVerticalRomanCentered"),
  // guess..., probably not given below
  valt: D("CJKVerticalRomanPlacement", "CJKVerticalRomanCentered"),
  swsh: D("contextualAlternates", "swashAlternates"),
  cswh: D("contextualAlternates", "contextualSwashAlternates"),
  curs: D("cursiveConnection", "cursive"),
  // ??
  c2pc: D("upperCase", "upperCasePetiteCaps"),
  c2sc: D("upperCase", "upperCaseSmallCaps"),
  init: D("smartSwash", "wordInitialSwashes"),
  // ??
  fin2: D("smartSwash", "wordFinalSwashes"),
  // ??
  medi: D("smartSwash", "nonFinalSwashes"),
  // ??
  med2: D("smartSwash", "nonFinalSwashes"),
  // ??
  fin3: D("smartSwash", "wordFinalSwashes"),
  // ??
  fina: D("smartSwash", "wordFinalSwashes"),
  // ??
  pkna: D("kanaSpacing", "proportionalKana"),
  half: D("textSpacing", "halfWidthText"),
  // also HalfWidthCJKRoman, HalfWidthIdeographs?
  halt: D("textSpacing", "altHalfWidthText"),
  hkna: D("alternateKana", "alternateHorizKana"),
  vkna: D("alternateKana", "alternateVertKana"),
  // hngl: feature 'transliteration', 'hanjaToHangulSelector' # deprecated
  ital: D("italicCJKRoman", "CJKItalicRoman"),
  lnum: D("numberCase", "upperCaseNumbers"),
  onum: D("numberCase", "lowerCaseNumbers"),
  mgrk: D("mathematicalExtras", "mathematicalGreek"),
  // nalt: not enough info. what type of annotation?
  // ornm: ditto, which ornament style?
  calt: D("contextualAlternates", "contextualAlternates"),
  // or more?
  vrt2: D("verticalSubstitution", "substituteVerticalForms"),
  // oh... below?
  vert: D("verticalSubstitution", "substituteVerticalForms"),
  tnum: D("numberSpacing", "monospacedNumbers"),
  pnum: D("numberSpacing", "proportionalNumbers"),
  sups: D("verticalPosition", "superiors"),
  subs: D("verticalPosition", "inferiors"),
  ordn: D("verticalPosition", "ordinals"),
  pwid: D("textSpacing", "proportionalText"),
  hwid: D("textSpacing", "halfWidthText"),
  qwid: D("textSpacing", "quarterWidthText"),
  // also QuarterWidthNumbers?
  twid: D("textSpacing", "thirdWidthText"),
  // also ThirdWidthNumbers?
  fwid: D("textSpacing", "proportionalText"),
  //??
  palt: D("textSpacing", "altProportionalText"),
  trad: D("characterShape", "traditionalCharacters"),
  smpl: D("characterShape", "simplifiedCharacters"),
  jp78: D("characterShape", "JIS1978Characters"),
  jp83: D("characterShape", "JIS1983Characters"),
  jp90: D("characterShape", "JIS1990Characters"),
  jp04: D("characterShape", "JIS2004Characters"),
  expt: D("characterShape", "expertCharacters"),
  hojo: D("characterShape", "hojoCharacters"),
  nlck: D("characterShape", "NLCCharacters"),
  tnam: D("characterShape", "traditionalNamesCharacters"),
  ruby: D("rubyKana", "rubyKana"),
  titl: D("styleOptions", "titlingCaps"),
  zero: D("typographicExtras", "slashedZero"),
  ss01: D("stylisticAlternatives", "stylisticAltOne"),
  ss02: D("stylisticAlternatives", "stylisticAltTwo"),
  ss03: D("stylisticAlternatives", "stylisticAltThree"),
  ss04: D("stylisticAlternatives", "stylisticAltFour"),
  ss05: D("stylisticAlternatives", "stylisticAltFive"),
  ss06: D("stylisticAlternatives", "stylisticAltSix"),
  ss07: D("stylisticAlternatives", "stylisticAltSeven"),
  ss08: D("stylisticAlternatives", "stylisticAltEight"),
  ss09: D("stylisticAlternatives", "stylisticAltNine"),
  ss10: D("stylisticAlternatives", "stylisticAltTen"),
  ss11: D("stylisticAlternatives", "stylisticAltEleven"),
  ss12: D("stylisticAlternatives", "stylisticAltTwelve"),
  ss13: D("stylisticAlternatives", "stylisticAltThirteen"),
  ss14: D("stylisticAlternatives", "stylisticAltFourteen"),
  ss15: D("stylisticAlternatives", "stylisticAltFifteen"),
  ss16: D("stylisticAlternatives", "stylisticAltSixteen"),
  ss17: D("stylisticAlternatives", "stylisticAltSeventeen"),
  ss18: D("stylisticAlternatives", "stylisticAltEighteen"),
  ss19: D("stylisticAlternatives", "stylisticAltNineteen"),
  ss20: D("stylisticAlternatives", "stylisticAltTwenty")
};
for (var En = 1; En <= 99; En++)
  Hn["cv" + ("00" + En).slice(-2)] = [or.characterAlternatives.code, En];
var sr = {};
for (var Ts in Hn) {
  var Cn = Hn[Ts];
  sr[Cn[0]] == null && (sr[Cn[0]] = {}), sr[Cn[0]][Cn[1]] = Ts;
}
function Jy(t) {
  var e = {};
  for (var r in t) {
    var n = void 0;
    (n = Hn[r]) && (e[n[0]] == null && (e[n[0]] = {}), e[n[0]][n[1]] = t[r]);
  }
  return e;
}
function Ps(t) {
  var e = t[0], r = t[1];
  if (isNaN(e))
    var n = or[e] && or[e].code;
  else
    var n = e;
  if (isNaN(r))
    var a = or[e] && or[e][r];
  else
    var a = r;
  return [n, a];
}
function Qy(t) {
  var e = {};
  if (Array.isArray(t))
    for (var r = 0; r < t.length; r++) {
      var n = void 0, a = Ps(t[r]);
      (n = sr[a[0]] && sr[a[0]][a[1]]) && (e[n] = !0);
    }
  else if (typeof t == "object")
    for (var o in t) {
      var s = t[o];
      for (var u in s) {
        var f = void 0, l = Ps([o, u]);
        s[u] && (f = sr[l[0]] && sr[l[0]][l[1]]) && (e[f] = !0);
      }
    }
  return Object.keys(e);
}
var Kr;
function Bs(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = _y(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function _y(t, e) {
  if (t) {
    if (typeof t == "string") return ks(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return ks(t, e);
  }
}
function ks(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
function $y(t, e, r, n, a) {
  var o = {};
  return Object.keys(n).forEach(function(s) {
    o[s] = n[s];
  }), o.enumerable = !!o.enumerable, o.configurable = !!o.configurable, ("value" in o || o.initializer) && (o.writable = !0), o = r.slice().reverse().reduce(function(s, u) {
    return u(t, e, s) || s;
  }, o), a && o.initializer !== void 0 && (o.value = o.initializer ? o.initializer.call(a) : void 0, o.initializer = void 0), o.initializer === void 0 && (Object.defineProperty(t, e, o), o = null), o;
}
var Un = (Kr = /* @__PURE__ */ (function() {
  function t(r) {
    this.table = r;
  }
  var e = t.prototype;
  return e.lookup = function(n) {
    switch (this.table.version) {
      case 0:
        return this.table.values.getItem(n);
      case 2:
      // segment format
      case 4: {
        for (var a = 0, o = this.table.binarySearchHeader.nUnits - 1; a <= o; ) {
          var s = a + o >> 1, u = this.table.segments[s];
          if (u.firstGlyph === 65535)
            return null;
          if (n < u.firstGlyph)
            o = s - 1;
          else if (n > u.lastGlyph)
            a = s + 1;
          else
            return this.table.version === 2 ? u.value : u.values[n - u.firstGlyph];
        }
        return null;
      }
      case 6: {
        for (var f = 0, l = this.table.binarySearchHeader.nUnits - 1; f <= l; ) {
          var s = f + l >> 1, u = this.table.segments[s];
          if (u.glyph === 65535)
            return null;
          if (n < u.glyph)
            l = s - 1;
          else if (n > u.glyph)
            f = s + 1;
          else
            return u.value;
        }
        return null;
      }
      case 8:
        return this.table.values[n - this.table.firstGlyph];
      default:
        throw new Error("Unknown lookup table format: " + this.table.version);
    }
  }, e.glyphsForValue = function(n) {
    var a = [];
    switch (this.table.version) {
      case 2:
      // segment format
      case 4: {
        for (var o = Bs(this.table.segments), s; !(s = o()).done; ) {
          var u = s.value;
          if (this.table.version === 2 && u.value === n)
            a.push.apply(a, Cr(u.firstGlyph, u.lastGlyph + 1));
          else
            for (var f = 0; f < u.values.length; f++)
              u.values[f] === n && a.push(u.firstGlyph + f);
        }
        break;
      }
      case 6: {
        for (var l = Bs(this.table.segments), c; !(c = l()).done; ) {
          var p = c.value;
          p.value === n && a.push(p.glyph);
        }
        break;
      }
      case 8: {
        for (var y = 0; y < this.table.values.length; y++)
          this.table.values[y] === n && a.push(this.table.firstGlyph + y);
        break;
      }
      default:
        throw new Error("Unknown lookup table format: " + this.table.version);
    }
    return a;
  }, t;
})(), $y(Kr.prototype, "glyphsForValue", [Ne], Object.getOwnPropertyDescriptor(Kr.prototype, "glyphsForValue"), Kr.prototype), Kr);
function eg(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = tg(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function tg(t, e) {
  if (t) {
    if (typeof t == "string") return Ls(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Ls(t, e);
  }
}
function Ls(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
var rg = 0, Ms = 0, Us = 1, Ns = 2, ng = 16384, ig = /* @__PURE__ */ (function() {
  function t(r) {
    this.stateTable = r, this.lookupTable = new Un(r.classTable);
  }
  var e = t.prototype;
  return e.process = function(n, a, o) {
    for (var s = rg, u = a ? n.length - 1 : 0, f = a ? -1 : 1; f === 1 && u <= n.length || f === -1 && u >= -1; ) {
      var l = null, c = Us, p = !0;
      u === n.length || u === -1 ? c = Ms : (l = n[u], l.id === 65535 ? c = Ns : (c = this.lookupTable.lookup(l.id), c == null && (c = Us)));
      var y = this.stateTable.stateArray.getItem(s), v = y[c], m = this.stateTable.entryTable.getItem(v);
      c !== Ms && c !== Ns && (o(l, m, u), p = !(m.flags & ng)), s = m.newState, p && (u += f);
    }
    return n;
  }, e.traverse = function(n, a, o) {
    if (a === void 0 && (a = 0), o === void 0 && (o = /* @__PURE__ */ new Set()), !o.has(a)) {
      o.add(a);
      for (var s = this.stateTable, u = s.nClasses, f = s.stateArray, l = s.entryTable, c = f.getItem(a), p = 4; p < u; p++)
        for (var y = c[p], v = l.getItem(y), m = eg(this.lookupTable.glyphsForValue(p)), w; !(w = m()).done; ) {
          var F = w.value;
          n.enter && n.enter(F, v), v.newState !== 0 && this.traverse(n, v.newState, o), n.exit && n.exit(F, v);
        }
    }
  }, t;
})(), Zr;
function $t(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = ag(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function ag(t, e) {
  if (t) {
    if (typeof t == "string") return Rs(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Rs(t, e);
  }
}
function Rs(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
function og(t, e, r, n, a) {
  var o = {};
  return Object.keys(n).forEach(function(s) {
    o[s] = n[s];
  }), o.enumerable = !!o.enumerable, o.configurable = !!o.configurable, ("value" in o || o.initializer) && (o.writable = !0), o = r.slice().reverse().reduce(function(s, u) {
    return u(t, e, s) || s;
  }, o), a && o.initializer !== void 0 && (o.value = o.initializer ? o.initializer.call(a) : void 0, o.initializer = void 0), o.initializer === void 0 && (Object.defineProperty(t, e, o), o = null), o;
}
var sg = 32768, ug = 8192, fg = 15, zs = 32768, lg = 32768, cg = 8192, hg = 2147483648, pg = 1073741824, dg = 1073741823, js = 4194304, vg = 2048, yg = 1024, gg = 992, mg = 31, bg = (Zr = /* @__PURE__ */ (function() {
  function t(r) {
    this.processIndicRearragement = this.processIndicRearragement.bind(this), this.processContextualSubstitution = this.processContextualSubstitution.bind(this), this.processLigature = this.processLigature.bind(this), this.processNoncontextualSubstitutions = this.processNoncontextualSubstitutions.bind(this), this.processGlyphInsertion = this.processGlyphInsertion.bind(this), this.font = r, this.morx = r.morx, this.inputCache = null;
  }
  var e = t.prototype;
  return e.process = function(n, a) {
    a === void 0 && (a = {});
    for (var o = $t(this.morx.chains), s; !(s = o()).done; ) {
      for (var u = s.value, f = u.defaultFlags, l = $t(u.features), c; !(c = l()).done; ) {
        var p = c.value, y = void 0;
        (y = a[p.featureType]) && y[p.featureSetting] && (f &= p.disableFlags, f |= p.enableFlags);
      }
      for (var v = $t(u.subtables), m; !(m = v()).done; ) {
        var w = m.value;
        w.subFeatureFlags & f && this.processSubtable(w, n);
      }
    }
    for (var F = n.length - 1; F >= 0; )
      n[F].id === 65535 && n.splice(F, 1), F--;
    return n;
  }, e.processSubtable = function(n, a) {
    if (this.subtable = n, this.glyphs = a, this.subtable.type === 4) {
      this.processNoncontextualSubstitutions(this.subtable, this.glyphs);
      return;
    }
    this.ligatureStack = [], this.markedGlyph = null, this.firstGlyph = null, this.lastGlyph = null, this.markedIndex = null;
    var o = this.getStateMachine(n), s = this.getProcessor(), u = !!(this.subtable.coverage & js);
    return o.process(this.glyphs, u, s);
  }, e.getStateMachine = function(n) {
    return new ig(n.table.stateTable);
  }, e.getProcessor = function() {
    switch (this.subtable.type) {
      case 0:
        return this.processIndicRearragement;
      case 1:
        return this.processContextualSubstitution;
      case 2:
        return this.processLigature;
      case 4:
        return this.processNoncontextualSubstitutions;
      case 5:
        return this.processGlyphInsertion;
      default:
        throw new Error("Invalid morx subtable type: " + this.subtable.type);
    }
  }, e.processIndicRearragement = function(n, a, o) {
    a.flags & sg && (this.firstGlyph = o), a.flags & ug && (this.lastGlyph = o), wg(this.glyphs, a.flags & fg, this.firstGlyph, this.lastGlyph);
  }, e.processContextualSubstitution = function(n, a, o) {
    var s = this.subtable.table.substitutionTable.items;
    if (a.markIndex !== 65535) {
      var u = s.getItem(a.markIndex), f = new Un(u);
      n = this.glyphs[this.markedGlyph];
      var l = f.lookup(n.id);
      l && (this.glyphs[this.markedGlyph] = this.font.getGlyph(l, n.codePoints));
    }
    if (a.currentIndex !== 65535) {
      var c = s.getItem(a.currentIndex), p = new Un(c);
      n = this.glyphs[o];
      var l = p.lookup(n.id);
      l && (this.glyphs[o] = this.font.getGlyph(l, n.codePoints));
    }
    a.flags & zs && (this.markedGlyph = o);
  }, e.processLigature = function(n, a, o) {
    if (a.flags & lg && this.ligatureStack.push(o), a.flags & cg) {
      for (var s, u = this.subtable.table.ligatureActions, f = this.subtable.table.components, l = this.subtable.table.ligatureList, c = a.action, p = !1, y = 0, v = [], m = []; !p; ) {
        var w, F = this.ligatureStack.pop();
        (w = v).unshift.apply(w, this.glyphs[F].codePoints);
        var S = u.getItem(c++);
        p = !!(S & hg);
        var I = !!(S & pg), A = (S & dg) << 2 >> 2;
        A += this.glyphs[F].id;
        var M = f.getItem(A);
        if (y += M, p || I) {
          var L = l.getItem(y);
          this.glyphs[F] = this.font.getGlyph(L, v), m.push(F), y = 0, v = [];
        } else
          this.glyphs[F] = this.font.getGlyph(65535);
      }
      (s = this.ligatureStack).push.apply(s, m);
    }
  }, e.processNoncontextualSubstitutions = function(n, a, o) {
    var s = new Un(n.table.lookupTable);
    for (o = 0; o < a.length; o++) {
      var u = a[o];
      if (u.id !== 65535) {
        var f = s.lookup(u.id);
        f && (a[o] = this.font.getGlyph(f, u.codePoints));
      }
    }
  }, e._insertGlyphs = function(n, a, o, s) {
    for (var u, f = []; o--; ) {
      var l = this.subtable.table.insertionActions.getItem(a++);
      f.push(this.font.getGlyph(l));
    }
    s || n++, (u = this.glyphs).splice.apply(u, [n, 0].concat(f));
  }, e.processGlyphInsertion = function(n, a, o) {
    if (a.flags & zs && (this.markedIndex = o), a.markedInsertIndex !== 65535) {
      var s = (a.flags & mg) >>> 5, u = !!(a.flags & yg);
      this._insertGlyphs(this.markedIndex, a.markedInsertIndex, s, u);
    }
    if (a.currentInsertIndex !== 65535) {
      var f = (a.flags & gg) >>> 5, l = !!(a.flags & vg);
      this._insertGlyphs(o, a.currentInsertIndex, f, l);
    }
  }, e.getSupportedFeatures = function() {
    for (var n = [], a = $t(this.morx.chains), o; !(o = a()).done; )
      for (var s = o.value, u = $t(s.features), f; !(f = u()).done; ) {
        var l = f.value;
        n.push([l.featureType, l.featureSetting]);
      }
    return n;
  }, e.generateInputs = function(n) {
    return this.inputCache || this.generateInputCache(), this.inputCache[n] || [];
  }, e.generateInputCache = function() {
    this.inputCache = {};
    for (var n = $t(this.morx.chains), a; !(a = n()).done; )
      for (var o = a.value, s = o.defaultFlags, u = $t(o.subtables), f; !(f = u()).done; ) {
        var l = f.value;
        l.subFeatureFlags & s && this.generateInputsForSubtable(l);
      }
  }, e.generateInputsForSubtable = function(n) {
    var a = this;
    if (n.type === 2) {
      var o = !!(n.coverage & js);
      if (o)
        throw new Error("Reverse subtable, not supported.");
      this.subtable = n, this.ligatureStack = [];
      var s = this.getStateMachine(n), u = this.getProcessor(), f = [], l = [];
      this.glyphs = [], s.traverse({
        enter: function(p, y) {
          var v = a.glyphs;
          l.push({
            glyphs: v.slice(),
            ligatureStack: a.ligatureStack.slice()
          });
          var m = a.font.getGlyph(p);
          f.push(m), v.push(f[f.length - 1]), u(v[v.length - 1], y, v.length - 1);
          for (var w = 0, F = 0, S = 0; S < v.length && w <= 1; S++)
            v[S].id !== 65535 && (w++, F = v[S].id);
          if (w === 1) {
            var I = f.map(function(M) {
              return M.id;
            }), A = a.inputCache[F];
            A ? A.push(I) : a.inputCache[F] = [I];
          }
        },
        exit: function() {
          var p = l.pop();
          a.glyphs = p.glyphs, a.ligatureStack = p.ligatureStack, f.pop();
        }
      });
    }
  }, t;
})(), og(Zr.prototype, "getStateMachine", [Ne], Object.getOwnPropertyDescriptor(Zr.prototype, "getStateMachine"), Zr.prototype), Zr);
function ze(t, e, r, n, a) {
  n === void 0 && (n = !1), a === void 0 && (a = !1);
  var o = t.splice(r[0] - (r[1] - 1), r[1]);
  a && o.reverse();
  var s = t.splice.apply(t, [e[0], e[1]].concat(o));
  return n && s.reverse(), t.splice.apply(t, [r[0] - (e[1] - 1), 0].concat(s)), t;
}
function wg(t, e, r, n) {
  switch (e) {
    case 0:
      return t;
    case 1:
      return ze(t, [r, 1], [n, 0]);
    case 2:
      return ze(t, [r, 0], [n, 1]);
    case 3:
      return ze(t, [r, 1], [n, 1]);
    case 4:
      return ze(t, [r, 2], [n, 0]);
    case 5:
      return ze(t, [r, 2], [n, 0], !0, !1);
    case 6:
      return ze(t, [r, 0], [n, 2]);
    case 7:
      return ze(t, [r, 0], [n, 2], !1, !0);
    case 8:
      return ze(t, [r, 1], [n, 2]);
    case 9:
      return ze(t, [r, 1], [n, 2], !1, !0);
    case 10:
      return ze(t, [r, 2], [n, 1]);
    case 11:
      return ze(t, [r, 2], [n, 1], !0, !1);
    case 12:
      return ze(t, [r, 2], [n, 2]);
    case 13:
      return ze(t, [r, 2], [n, 2], !0, !1);
    case 14:
      return ze(t, [r, 2], [n, 2], !1, !0);
    case 15:
      return ze(t, [r, 2], [n, 2], !0, !0);
    default:
      throw new Error("Unknown verb: " + e);
  }
}
function Vs(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = Fg(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function Fg(t, e) {
  if (t) {
    if (typeof t == "string") return Gs(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Gs(t, e);
  }
}
function Gs(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
var xg = /* @__PURE__ */ (function() {
  function t(r) {
    this.font = r, this.morxProcessor = new bg(r), this.fallbackPosition = !1;
  }
  var e = t.prototype;
  return e.substitute = function(n) {
    n.direction === "rtl" && n.glyphs.reverse(), this.morxProcessor.process(n.glyphs, Jy(n.features));
  }, e.getAvailableFeatures = function(n, a) {
    return Qy(this.morxProcessor.getSupportedFeatures());
  }, e.stringsForGlyph = function(n) {
    for (var a = this.morxProcessor.generateInputs(n), o = /* @__PURE__ */ new Set(), s = Vs(a), u; !(u = s()).done; ) {
      var f = u.value;
      this._addStrings(f, 0, o, "");
    }
    return o;
  }, e._addStrings = function(n, a, o, s) {
    for (var u = this.font._cmapProcessor.codePointsForGlyph(n[a]), f = Vs(u), l; !(l = f()).done; ) {
      var c = l.value, p = s + String.fromCodePoint(c);
      a < n.length - 1 ? this._addStrings(n, a + 1, o, p) : o.add(p);
    }
  }, t;
})();
function Ji(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = Sg(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function Sg(t, e) {
  if (t) {
    if (typeof t == "string") return qs(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return qs(t, e);
  }
}
function qs(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
var Ag = /* @__PURE__ */ (function() {
  function t(r, n, a) {
    this.font = r, this.script = n, this.direction = a, this.stages = [], this.globalFeatures = {}, this.allFeatures = {};
  }
  var e = t.prototype;
  return e._addFeatures = function(n, a) {
    for (var o = this.stages.length - 1, s = this.stages[o], u = Ji(n), f; !(f = u()).done; ) {
      var l = f.value;
      this.allFeatures[l] == null && (s.push(l), this.allFeatures[l] = o, a && (this.globalFeatures[l] = !0));
    }
  }, e.add = function(n, a) {
    if (a === void 0 && (a = !0), this.stages.length === 0 && this.stages.push([]), typeof n == "string" && (n = [n]), Array.isArray(n))
      this._addFeatures(n, a);
    else if (typeof n == "object")
      this._addFeatures(n.global || [], !0), this._addFeatures(n.local || [], !1);
    else
      throw new Error("Unsupported argument to ShapingPlan#add");
  }, e.addStage = function(n, a) {
    typeof n == "function" ? this.stages.push(n, []) : (this.stages.push([]), this.add(n, a));
  }, e.setFeatureOverrides = function(n) {
    if (Array.isArray(n))
      this.add(n);
    else if (typeof n == "object") {
      for (var a in n)
        if (n[a])
          this.add(a);
        else if (this.allFeatures[a] != null) {
          var o = this.stages[this.allFeatures[a]];
          o.splice(o.indexOf(a), 1), delete this.allFeatures[a], delete this.globalFeatures[a];
        }
    }
  }, e.assignGlobalFeatures = function(n) {
    for (var a = Ji(n), o; !(o = a()).done; ) {
      var s = o.value;
      for (var u in this.globalFeatures)
        s.features[u] = !0;
    }
  }, e.process = function(n, a, o) {
    for (var s = Ji(this.stages), u; !(u = s()).done; ) {
      var f = u.value;
      typeof f == "function" ? o || f(this.font, a, this) : f.length > 0 && n.applyFeatures(f, a, o);
    }
  }, t;
})();
function Eg(t, e, r) {
  return e in t ? Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : t[e] = r, t;
}
var Cg = ["rvrn"], Ig = ["ccmp", "locl", "rlig", "mark", "mkmk"], Og = ["frac", "numr", "dnom"], Dg = ["calt", "clig", "liga", "rclt", "curs", "kern"], Tg = {
  ltr: ["ltra", "ltrm"],
  rtl: ["rtla", "rtlm"]
}, Ht = /* @__PURE__ */ (function() {
  function t() {
  }
  return t.plan = function(r, n, a) {
    this.planPreprocessing(r), this.planFeatures(r), this.planPostprocessing(r, a), r.assignGlobalFeatures(n), this.assignFeatures(r, n);
  }, t.planPreprocessing = function(r) {
    r.add({
      global: [].concat(Cg, Tg[r.direction]),
      local: Og
    });
  }, t.planFeatures = function(r) {
  }, t.planPostprocessing = function(r, n) {
    r.add([].concat(Ig, Dg)), r.setFeatureOverrides(n);
  }, t.assignFeatures = function(r, n) {
    for (var a = 0; a < n.length; a++) {
      var o = n[a];
      if (o.codePoints[0] === 8260) {
        for (var s = a, u = a + 1; s > 0 && St.isDigit(n[s - 1].codePoints[0]); )
          n[s - 1].features.numr = !0, n[s - 1].features.frac = !0, s--;
        for (; u < n.length && St.isDigit(n[u].codePoints[0]); )
          n[u].features.dnom = !0, n[u].features.frac = !0, u++;
        o.features.frac = !0, a = u - 1;
      }
    }
  }, t;
})();
Eg(Ht, "zeroMarkWidths", "AFTER_GPOS");
var Pg = "eJwBDgLx/QAB8AAAAAAAAAA4AAH9AQL+7ZotTMQwFMe77b44QIHA4JBIBAJ5lxASDAmGhHMoBIqgUOBQJAhOIpFIDIogSUgIEolEEgzJ/S/Xkpem3XXXboPbe8kv7a3r63vt69u6XDcWYhvsgn3Qlb//S3kMTsEZuACXoA9uwC24A/fgATyRfs/gTf4e8g4+ZP1Tll+knZlOfsC1pJ4IMQ8WkvLtKool+Los/V2pkN8MwzAMwzAMwzAMw1SP4fefVf7+wTAMwzAMwzC5cjUzYjEnXsFcW4gOOAeP4Ls9alufFWJTCNFrCdFvjepF8NLKbz7XcIbZMJxjOri2leF8s4N79zzPQz30P7DoOMT1o4qct9T/C06m1N9OHP3CwlJliSzQdlM9lNSk3kSjZih1TH2yQvv9JaE2UR/1uXLxLwSTzG0RJFrdxQ9TXKl2QUqbhNgHdDwXoT7Taz7SBHWD/oYkbf1dYyIhOvV+DU/7lWSNz1BxPW5uTO3jxnWVsvedb+zZ+o/L9Vlij95rerbZ7IoMelTe1XNFaJkkhqltphjT9ZrmT5ey34zVGijRbQxlX9n7xPTu1ZQUuY9993Oaf3nqDqnLNUf4SKg1iye005ZLIq1U9UiO5fJOGKfoN42nxnK1NUTOpfbYfNFzqZ5Tfe2wzWOIuLOtQdEov4qWtLhzJes6hI5RXwmZv0zPCps0A45rkwGaMQXv";
function Bg(t, e) {
  t.prototype = Object.create(e.prototype), t.prototype.constructor = t, t.__proto__ = e;
}
var kg = Wt.inflate(Yt(Pg)), Lg = new hi(kg), Hs = ["isol", "fina", "fin2", "fin3", "medi", "med2", "init"], wa = {
  Non_Joining: 0,
  Transparent: 6
}, me = "isol", Pt = "fina", Qi = "fin2", Mg = "fin3", In = "medi", On = "med2", Dn = "init", se = null, Ug = [
  //   Non_Joining,        Left_Joining,       Right_Joining,     Dual_Joining,           ALAPH,            DALATH RISH
  // State 0: prev was U,  not willing to join.
  [[se, se, 0], [se, me, 2], [se, me, 1], [se, me, 2], [se, me, 1], [se, me, 6]],
  // State 1: prev was R or ISOL/ALAPH,  not willing to join.
  [[se, se, 0], [se, me, 2], [se, me, 1], [se, me, 2], [se, Qi, 5], [se, me, 6]],
  // State 2: prev was D/L in ISOL form,  willing to join.
  [[se, se, 0], [se, me, 2], [Dn, Pt, 1], [Dn, Pt, 3], [Dn, Pt, 4], [Dn, Pt, 6]],
  // State 3: prev was D in FINA form,  willing to join.
  [[se, se, 0], [se, me, 2], [In, Pt, 1], [In, Pt, 3], [In, Pt, 4], [In, Pt, 6]],
  // State 4: prev was FINA ALAPH,  not willing to join.
  [[se, se, 0], [se, me, 2], [On, me, 1], [On, me, 2], [On, Qi, 5], [On, me, 6]],
  // State 5: prev was FIN2/FIN3 ALAPH,  not willing to join.
  [[se, se, 0], [se, me, 2], [me, me, 1], [me, me, 2], [me, Qi, 5], [me, me, 6]],
  // State 6: prev was DALATH/RISH,  not willing to join.
  [[se, se, 0], [se, me, 2], [se, me, 1], [se, me, 2], [se, Mg, 5], [se, me, 6]]
], Bt = /* @__PURE__ */ (function(t) {
  Bg(e, t);
  function e() {
    return t.apply(this, arguments) || this;
  }
  return e.planFeatures = function(n) {
    n.add(["ccmp", "locl"]);
    for (var a = 0; a < Hs.length; a++) {
      var o = Hs[a];
      n.addStage(o, !1);
    }
    n.addStage("mset");
  }, e.assignFeatures = function(n, a) {
    t.assignFeatures.call(this, n, a);
    for (var o = -1, s = 0, u = [], f = 0; f < a.length; f++) {
      var l = void 0, c = void 0, p = a[f], y = Ng(p.codePoints[0]);
      if (y === wa.Transparent) {
        u[f] = se;
        continue;
      }
      var v = Ug[s][y];
      c = v[0], l = v[1], s = v[2], c !== se && o !== -1 && (u[o] = c), u[f] = l, o = f;
    }
    for (var m = 0; m < a.length; m++) {
      var w = void 0, p = a[m];
      (w = u[m]) && (p.features[w] = !0);
    }
  }, e;
})(Ht);
function Ng(t) {
  var e = Lg.get(t);
  if (e)
    return e - 1;
  var r = St.getCategory(t);
  return r === "Mn" || r === "Me" || r === "Cf" ? wa.Transparent : wa.Non_Joining;
}
function Rg(t, e) {
  for (var r = 0; r < e.length; r++) {
    var n = e[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(t, n.key, n);
  }
}
function zg(t, e, r) {
  return e && Rg(t.prototype, e), t;
}
var jg = /* @__PURE__ */ (function() {
  function t(r, n) {
    this.glyphs = r, this.reset(n);
  }
  var e = t.prototype;
  return e.reset = function(n, a) {
    n === void 0 && (n = {}), a === void 0 && (a = 0), this.options = n, this.flags = n.flags || {}, this.markAttachmentType = n.markAttachmentType || 0, this.index = a;
  }, e.shouldIgnore = function(n) {
    return this.flags.ignoreMarks && n.isMark || this.flags.ignoreBaseGlyphs && n.isBase || this.flags.ignoreLigatures && n.isLigature || this.markAttachmentType && n.isMark && n.markAttachmentType !== this.markAttachmentType;
  }, e.move = function(n) {
    for (this.index += n; 0 <= this.index && this.index < this.glyphs.length && this.shouldIgnore(this.glyphs[this.index]); )
      this.index += n;
    return 0 > this.index || this.index >= this.glyphs.length ? null : this.glyphs[this.index];
  }, e.next = function() {
    return this.move(1);
  }, e.prev = function() {
    return this.move(-1);
  }, e.peek = function(n) {
    n === void 0 && (n = 1);
    var a = this.index, o = this.increment(n);
    return this.index = a, o;
  }, e.peekIndex = function(n) {
    n === void 0 && (n = 1);
    var a = this.index;
    this.increment(n);
    var o = this.index;
    return this.index = a, o;
  }, e.increment = function(n) {
    n === void 0 && (n = 1);
    var a = n < 0 ? -1 : 1;
    for (n = Math.abs(n); n--; )
      this.move(a);
    return this.glyphs[this.index];
  }, zg(t, [{
    key: "cur",
    get: function() {
      return this.glyphs[this.index] || null;
    }
  }]), t;
})();
function Ue(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = Vg(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function Vg(t, e) {
  if (t) {
    if (typeof t == "string") return Ws(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Ws(t, e);
  }
}
function Ws(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
var Gg = ["DFLT", "dflt", "latn"], Wn = /* @__PURE__ */ (function() {
  function t(r, n) {
    this.font = r, this.table = n, this.script = null, this.scriptTag = null, this.language = null, this.languageTag = null, this.features = {}, this.lookups = {}, this.variationsIndex = r._variationProcessor ? this.findVariationsIndex(r._variationProcessor.normalizedCoords) : -1, this.selectScript(), this.glyphs = [], this.positions = [], this.ligatureID = 1, this.currentFeature = null;
  }
  var e = t.prototype;
  return e.findScript = function(n) {
    if (this.table.scriptList == null)
      return null;
    Array.isArray(n) || (n = [n]);
    for (var a = Ue(n), o; !(o = a()).done; )
      for (var s = o.value, u = Ue(this.table.scriptList), f; !(f = u()).done; ) {
        var l = f.value;
        if (l.tag === s)
          return l;
      }
    return null;
  }, e.selectScript = function(n, a, o) {
    var s = !1, u;
    if (!this.script || n !== this.scriptTag) {
      if (u = this.findScript(n), u || (u = this.findScript(Gg)), !u)
        return this.scriptTag;
      this.scriptTag = u.tag, this.script = u.script, this.language = null, this.languageTag = null, s = !0;
    }
    if ((!o || o !== this.direction) && (this.direction = o || cl(n)), a && a.length < 4 && (a += " ".repeat(4 - a.length)), !a || a !== this.languageTag) {
      this.language = null;
      for (var f = Ue(this.script.langSysRecords), l; !(l = f()).done; ) {
        var c = l.value;
        if (c.tag === a) {
          this.language = c.langSys, this.languageTag = c.tag;
          break;
        }
      }
      this.language || (this.language = this.script.defaultLangSys, this.languageTag = null), s = !0;
    }
    if (s && (this.features = {}, this.language))
      for (var p = Ue(this.language.featureIndexes), y; !(y = p()).done; ) {
        var v = y.value, m = this.table.featureList[v], w = this.substituteFeatureForVariations(v);
        this.features[m.tag] = w || m.feature;
      }
    return this.scriptTag;
  }, e.lookupsForFeatures = function(n, a) {
    n === void 0 && (n = []);
    for (var o = [], s = Ue(n), u; !(u = s()).done; ) {
      var f = u.value, l = this.features[f];
      if (l)
        for (var c = Ue(l.lookupListIndexes), p; !(p = c()).done; ) {
          var y = p.value;
          a && a.indexOf(y) !== -1 || o.push({
            feature: f,
            index: y,
            lookup: this.table.lookupList.get(y)
          });
        }
    }
    return o.sort(function(v, m) {
      return v.index - m.index;
    }), o;
  }, e.substituteFeatureForVariations = function(n) {
    if (this.variationsIndex === -1)
      return null;
    for (var a = this.table.featureVariations.featureVariationRecords[this.variationsIndex], o = a.featureTableSubstitution.substitutions, s = Ue(o), u; !(u = s()).done; ) {
      var f = u.value;
      if (f.featureIndex === n)
        return f.alternateFeatureTable;
    }
    return null;
  }, e.findVariationsIndex = function(n) {
    var a = this.table.featureVariations;
    if (!a)
      return -1;
    for (var o = a.featureVariationRecords, s = 0; s < o.length; s++) {
      var u = o[s].conditionSet.conditionTable;
      if (this.variationConditionsMatch(u, n))
        return s;
    }
    return -1;
  }, e.variationConditionsMatch = function(n, a) {
    return n.every(function(o) {
      var s = o.axisIndex < a.length ? a[o.axisIndex] : 0;
      return o.filterRangeMinValue <= s && s <= o.filterRangeMaxValue;
    });
  }, e.applyFeatures = function(n, a, o) {
    var s = this.lookupsForFeatures(n);
    this.applyLookups(s, a, o);
  }, e.applyLookups = function(n, a, o) {
    this.glyphs = a, this.positions = o, this.glyphIterator = new jg(a);
    for (var s = Ue(n), u; !(u = s()).done; ) {
      var f = u.value, l = f.feature, c = f.lookup;
      for (this.currentFeature = l, this.glyphIterator.reset(c.flags); this.glyphIterator.index < a.length; ) {
        if (!(l in this.glyphIterator.cur.features)) {
          this.glyphIterator.next();
          continue;
        }
        for (var p = Ue(c.subTables), y; !(y = p()).done; ) {
          var v = y.value, m = this.applyLookup(c.lookupType, v);
          if (m)
            break;
        }
        this.glyphIterator.next();
      }
    }
  }, e.applyLookup = function(n, a) {
    throw new Error("applyLookup must be implemented by subclasses");
  }, e.applyLookupList = function(n) {
    for (var a = this.glyphIterator.options, o = this.glyphIterator.index, s = Ue(n), u; !(u = s()).done; ) {
      var f = u.value;
      this.glyphIterator.reset(a, o), this.glyphIterator.increment(f.sequenceIndex);
      var l = this.table.lookupList.get(f.lookupListIndex);
      this.glyphIterator.reset(l.flags, this.glyphIterator.index);
      for (var c = Ue(l.subTables), p; !(p = c()).done; ) {
        var y = p.value;
        if (this.applyLookup(l.lookupType, y))
          break;
      }
    }
    return this.glyphIterator.reset(a, o), !0;
  }, e.coverageIndex = function(n, a) {
    switch (a == null && (a = this.glyphIterator.cur.id), n.version) {
      case 1:
        return n.glyphs.indexOf(a);
      case 2:
        for (var o = Ue(n.rangeRecords), s; !(s = o()).done; ) {
          var u = s.value;
          if (u.start <= a && a <= u.end)
            return u.startCoverageIndex + a - u.start;
        }
        break;
    }
    return -1;
  }, e.match = function(n, a, o, s) {
    for (var u = this.glyphIterator.index, f = this.glyphIterator.increment(n), l = 0; l < a.length && f && o(a[l], f); )
      s && s.push(this.glyphIterator.index), l++, f = this.glyphIterator.next();
    return this.glyphIterator.index = u, l < a.length ? !1 : s || !0;
  }, e.sequenceMatches = function(n, a) {
    return this.match(n, a, function(o, s) {
      return o === s.id;
    });
  }, e.sequenceMatchIndices = function(n, a) {
    var o = this;
    return this.match(n, a, function(s, u) {
      return o.currentFeature in u.features ? s === u.id : !1;
    }, []);
  }, e.coverageSequenceMatches = function(n, a) {
    var o = this;
    return this.match(n, a, function(s, u) {
      return o.coverageIndex(s, u.id) >= 0;
    });
  }, e.getClassID = function(n, a) {
    switch (a.version) {
      case 1:
        var o = n - a.startGlyph;
        if (o >= 0 && o < a.classValueArray.length)
          return a.classValueArray[o];
        break;
      case 2:
        for (var s = Ue(a.classRangeRecord), u; !(u = s()).done; ) {
          var f = u.value;
          if (f.start <= n && n <= f.end)
            return f.class;
        }
        break;
    }
    return 0;
  }, e.classSequenceMatches = function(n, a, o) {
    var s = this;
    return this.match(n, a, function(u, f) {
      return u === s.getClassID(f.id, o);
    });
  }, e.applyContext = function(n) {
    switch (n.version) {
      case 1:
        var a = this.coverageIndex(n.coverage);
        if (a === -1)
          return !1;
        for (var o = n.ruleSets[a], s = Ue(o), u; !(u = s()).done; ) {
          var f = u.value;
          if (this.sequenceMatches(1, f.input))
            return this.applyLookupList(f.lookupRecords);
        }
        break;
      case 2:
        if (this.coverageIndex(n.coverage) === -1 || (a = this.getClassID(this.glyphIterator.cur.id, n.classDef), a === -1))
          return !1;
        o = n.classSet[a];
        for (var l = Ue(o), c; !(c = l()).done; ) {
          var p = c.value;
          if (this.classSequenceMatches(1, p.classes, n.classDef))
            return this.applyLookupList(p.lookupRecords);
        }
        break;
      case 3:
        if (this.coverageSequenceMatches(0, n.coverages))
          return this.applyLookupList(n.lookupRecords);
        break;
    }
    return !1;
  }, e.applyChainingContext = function(n) {
    switch (n.version) {
      case 1:
        var a = this.coverageIndex(n.coverage);
        if (a === -1)
          return !1;
        for (var o = n.chainRuleSets[a], s = Ue(o), u; !(u = s()).done; ) {
          var f = u.value;
          if (this.sequenceMatches(-f.backtrack.length, f.backtrack) && this.sequenceMatches(1, f.input) && this.sequenceMatches(1 + f.input.length, f.lookahead))
            return this.applyLookupList(f.lookupRecords);
        }
        break;
      case 2:
        if (this.coverageIndex(n.coverage) === -1)
          return !1;
        a = this.getClassID(this.glyphIterator.cur.id, n.inputClassDef);
        var l = n.chainClassSet[a];
        if (!l)
          return !1;
        for (var c = Ue(l), p; !(p = c()).done; ) {
          var y = p.value;
          if (this.classSequenceMatches(-y.backtrack.length, y.backtrack, n.backtrackClassDef) && this.classSequenceMatches(1, y.input, n.inputClassDef) && this.classSequenceMatches(1 + y.input.length, y.lookahead, n.lookaheadClassDef))
            return this.applyLookupList(y.lookupRecords);
        }
        break;
      case 3:
        if (this.coverageSequenceMatches(-n.backtrackGlyphCount, n.backtrackCoverage) && this.coverageSequenceMatches(0, n.inputCoverage) && this.coverageSequenceMatches(n.inputGlyphCount, n.lookaheadCoverage))
          return this.applyLookupList(n.lookupRecords);
        break;
    }
    return !1;
  }, t;
})();
function qg(t, e) {
  for (var r = 0; r < e.length; r++) {
    var n = e[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(t, n.key, n);
  }
}
function Hg(t, e, r) {
  return e && qg(t.prototype, e), t;
}
var At = /* @__PURE__ */ (function() {
  function t(r, n, a, o) {
    if (a === void 0 && (a = []), this._font = r, this.codePoints = a, this.id = n, this.features = {}, Array.isArray(o))
      for (var s = 0; s < o.length; s++) {
        var u = o[s];
        this.features[u] = !0;
      }
    else typeof o == "object" && Object.assign(this.features, o);
    this.ligatureID = null, this.ligatureComponent = null, this.isLigated = !1, this.cursiveAttachment = null, this.markAttachment = null, this.shaperInfo = null, this.substituted = !1, this.isMultiplied = !1;
  }
  var e = t.prototype;
  return e.copy = function() {
    return new t(this._font, this.id, this.codePoints, this.features);
  }, Hg(t, [{
    key: "id",
    get: function() {
      return this._id;
    },
    set: function(n) {
      this._id = n, this.substituted = !0;
      var a = this._font.GDEF;
      if (a && a.glyphClassDef) {
        var o = Wn.prototype.getClassID(n, a.glyphClassDef);
        this.isBase = o === 1, this.isLigature = o === 2, this.isMark = o === 3, this.markAttachmentType = a.markAttachClassDef ? Wn.prototype.getClassID(n, a.markAttachClassDef) : 0;
      } else
        this.isMark = this.codePoints.length > 0 && this.codePoints.every(St.isMark), this.isBase = !this.isMark, this.isLigature = this.codePoints.length > 1, this.markAttachmentType = 0;
    }
  }]), t;
})();
function Wg(t, e) {
  t.prototype = Object.create(e.prototype), t.prototype.constructor = t, t.__proto__ = e;
}
function Xg(t, e, r) {
  return e in t ? Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : t[e] = r, t;
}
var hl = /* @__PURE__ */ (function(t) {
  Wg(e, t);
  function e() {
    return t.apply(this, arguments) || this;
  }
  return e.planFeatures = function(n) {
    n.add(["ljmo", "vjmo", "tjmo"], !1);
  }, e.assignFeatures = function(n, a) {
    for (var o = 0, s = 0; s < a.length; ) {
      var u = void 0, f = a[s], l = f.codePoints[0], c = Zn(l), p = lm[o][c];
      switch (u = p[0], o = p[1], u) {
        case mt:
          n.font.hasGlyphForCodePoint(l) || (s = vl(a, s, n.font));
          break;
        case Fa:
          s = cm(a, s, n.font);
          break;
        case xa:
          pm(a, s, n.font);
          break;
        case Sa:
          s = dm(a, s, n.font);
          break;
      }
      s++;
    }
  }, e;
})(Ht);
Xg(hl, "zeroMarkWidths", "NONE");
var Vr = 44032, pl = 55204, Yg = pl - Vr + 1, vi = 4352, yi = 4449, lr = 4519, Kg = 19, Xn = 21, ln = 28, Zg = vi + Kg - 1, Jg = yi + Xn - 1, Qg = lr + ln - 1, Xs = 9676, _g = function(e) {
  return 4352 <= e && e <= 4447 || 43360 <= e && e <= 43388;
}, $g = function(e) {
  return 4448 <= e && e <= 4519 || 55216 <= e && e <= 55238;
}, em = function(e) {
  return 4520 <= e && e <= 4607 || 55243 <= e && e <= 55291;
}, tm = function(e) {
  return 12334 <= e && e <= 12335;
}, rm = function(e) {
  return Vr <= e && e <= pl;
}, nm = function(e) {
  return e - Vr < Yg && (e - Vr) % ln === 0;
}, im = function(e) {
  return vi <= e && e <= Zg;
}, am = function(e) {
  return yi <= e && e <= Jg;
}, om = function(e) {
  return 1 <= e && e <= Qg;
}, sm = 0, um = 1, Yn = 2, yo = 3, Kn = 4, dl = 5, fm = 6;
function Zn(t) {
  return _g(t) ? um : $g(t) ? Yn : em(t) ? yo : nm(t) ? Kn : rm(t) ? dl : tm(t) ? fm : sm;
}
var Ge = 0, mt = 1, Fa = 2, xa = 4, Sa = 5, lm = [
  //       X                 L                 V                T                  LV                LVT               M
  // State 0: start state
  [[Ge, 0], [Ge, 1], [Ge, 0], [Ge, 0], [mt, 2], [mt, 3], [Sa, 0]],
  // State 1: <L>
  [[Ge, 0], [Ge, 1], [Fa, 2], [Ge, 0], [mt, 2], [mt, 3], [Sa, 0]],
  // State 2: <L,V> or <LV>
  [[Ge, 0], [Ge, 1], [Ge, 0], [Fa, 3], [mt, 2], [mt, 3], [xa, 0]],
  // State 3: <L,V,T> or <LVT>
  [[Ge, 0], [Ge, 1], [Ge, 0], [Ge, 0], [mt, 2], [mt, 3], [xa, 0]]
];
function en(t, e, r) {
  return new At(t, t.glyphForCodePoint(e).id, [e], r);
}
function vl(t, e, r) {
  var n = t[e], a = n.codePoints[0], o = a - Vr, s = lr + o % ln;
  o = o / ln | 0;
  var u = vi + o / Xn | 0, f = yi + o % Xn;
  if (!r.hasGlyphForCodePoint(u) || !r.hasGlyphForCodePoint(f) || s !== lr && !r.hasGlyphForCodePoint(s))
    return e;
  var l = en(r, u, n.features);
  l.features.ljmo = !0;
  var c = en(r, f, n.features);
  c.features.vjmo = !0;
  var p = [l, c];
  if (s > lr) {
    var y = en(r, s, n.features);
    y.features.tjmo = !0, p.push(y);
  }
  return t.splice.apply(t, [e, 1].concat(p)), e + p.length - 1;
}
function cm(t, e, r) {
  var n = t[e], a = t[e].codePoints[0], o = Zn(a), s = t[e - 1].codePoints[0], u = Zn(s), f, l, c, p;
  if (u === Kn && o === yo)
    f = s, p = n;
  else {
    o === Yn ? (l = t[e - 1], c = n) : (l = t[e - 2], c = t[e - 1], p = n);
    var y = l.codePoints[0], v = c.codePoints[0];
    im(y) && am(v) && (f = Vr + ((y - vi) * Xn + (v - yi)) * ln);
  }
  var m = p && p.codePoints[0] || lr;
  if (f != null && (m === lr || om(m))) {
    var w = f + (m - lr);
    if (r.hasGlyphForCodePoint(w)) {
      var F = u === Yn ? 3 : 2;
      return t.splice(e - F + 1, F, en(r, w, n.features)), e - F + 1;
    }
  }
  return l && (l.features.ljmo = !0), c && (c.features.vjmo = !0), p && (p.features.tjmo = !0), u === Kn ? (vl(t, e - 1, r), e + 1) : e;
}
function hm(t) {
  switch (Zn(t)) {
    case Kn:
    case dl:
      return 1;
    case Yn:
      return 2;
    case yo:
      return 3;
  }
}
function pm(t, e, r) {
  var n = t[e], a = t[e].codePoints[0];
  if (r.glyphForCodePoint(a).advanceWidth !== 0) {
    var o = t[e - 1].codePoints[0], s = hm(o);
    return t.splice(e, 1), t.splice(e - s, 0, n);
  }
}
function dm(t, e, r) {
  var n = t[e], a = t[e].codePoints[0];
  if (r.hasGlyphForCodePoint(Xs)) {
    var o = en(r, Xs, n.features), s = r.glyphForCodePoint(a).advanceWidth === 0 ? e : e + 1;
    t.splice(s, 0, o), e++;
  }
  return e;
}
function Ys(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = vm(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function vm(t, e) {
  if (t) {
    if (typeof t == "string") return Ks(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Ks(t, e);
  }
}
function Ks(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
var _i = 1, $i = 0, ym = /* @__PURE__ */ (function() {
  function t(r) {
    this.stateTable = r.stateTable, this.accepting = r.accepting, this.tags = r.tags;
  }
  var e = t.prototype;
  return e.match = function(n) {
    var a, o = this;
    return a = {}, a[Symbol.iterator] = /* @__PURE__ */ regeneratorRuntime.mark(function s() {
      var u, f, l, c, p, y;
      return regeneratorRuntime.wrap(function(m) {
        for (; ; )
          switch (m.prev = m.next) {
            case 0:
              u = _i, f = null, l = null, c = null, p = 0;
            case 5:
              if (!(p < n.length)) {
                m.next = 21;
                break;
              }
              if (y = n[p], c = u, u = o.stateTable[u][y], u !== $i) {
                m.next = 15;
                break;
              }
              if (!(f != null && l != null && l >= f)) {
                m.next = 13;
                break;
              }
              return m.next = 13, [f, l, o.tags[c]];
            case 13:
              u = o.stateTable[_i][y], f = null;
            case 15:
              u !== $i && f == null && (f = p), o.accepting[u] && (l = p), u === $i && (u = _i);
            case 18:
              p++, m.next = 5;
              break;
            case 21:
              if (!(f != null && l != null && l >= f)) {
                m.next = 24;
                break;
              }
              return m.next = 24, [f, l, o.tags[u]];
            case 24:
            case "end":
              return m.stop();
          }
      }, s);
    }), a;
  }, e.apply = function(n, a) {
    for (var o = Ys(this.match(n)), s; !(s = o()).done; )
      for (var u = s.value, f = u[0], l = u[1], c = u[2], p = Ys(c), y; !(y = p()).done; ) {
        var v = y.value;
        typeof a[v] == "function" && a[v](f, l, n.slice(f, l + 1));
      }
  }, t;
})(), yl = ym, $ = {
  X: 1,
  C: 2,
  V: 4,
  N: 8,
  H: 16,
  ZWNJ: 32,
  ZWJ: 64,
  M: 128,
  Placeholder: 2048,
  Dotted_Circle: 4096,
  RS: 8192,
  // Register Shifter, used in Khmer OT spec.
  Coeng: 16384,
  // Khmer-style Virama.
  Repha: 32768,
  // Atomically-encoded logical or visual repha.
  Ra: 65536,
  CM: 1 << 17
}, R = {
  Start: 1,
  Ra_To_Become_Reph: 2,
  Pre_M: 4,
  Pre_C: 8,
  Base_C: 16,
  After_Main: 32,
  Before_Sub: 128,
  Below_C: 256,
  After_Sub: 512,
  Before_Post: 1024,
  Post_C: 2048,
  After_Post: 4096,
  Final_C: 8192,
  SMVD: 16384,
  End: 32768
}, gm = $.C | $.Ra | $.CM | $.V | $.Placeholder | $.Dotted_Circle, gl = $.ZWJ | $.ZWNJ, tn = $.H | $.Coeng, Zs = {
  Default: {
    hasOldSpec: !1,
    virama: 0,
    basePos: "Last",
    rephPos: R.Before_Post,
    rephMode: "Implicit",
    blwfMode: "Pre_And_Post"
  },
  Devanagari: {
    hasOldSpec: !0,
    virama: 2381,
    basePos: "Last",
    rephPos: R.Before_Post,
    rephMode: "Implicit",
    blwfMode: "Pre_And_Post"
  },
  Bengali: {
    hasOldSpec: !0,
    virama: 2509,
    basePos: "Last",
    rephPos: R.After_Sub,
    rephMode: "Implicit",
    blwfMode: "Pre_And_Post"
  },
  Gurmukhi: {
    hasOldSpec: !0,
    virama: 2637,
    basePos: "Last",
    rephPos: R.Before_Sub,
    rephMode: "Implicit",
    blwfMode: "Pre_And_Post"
  },
  Gujarati: {
    hasOldSpec: !0,
    virama: 2765,
    basePos: "Last",
    rephPos: R.Before_Post,
    rephMode: "Implicit",
    blwfMode: "Pre_And_Post"
  },
  Oriya: {
    hasOldSpec: !0,
    virama: 2893,
    basePos: "Last",
    rephPos: R.After_Main,
    rephMode: "Implicit",
    blwfMode: "Pre_And_Post"
  },
  Tamil: {
    hasOldSpec: !0,
    virama: 3021,
    basePos: "Last",
    rephPos: R.After_Post,
    rephMode: "Implicit",
    blwfMode: "Pre_And_Post"
  },
  Telugu: {
    hasOldSpec: !0,
    virama: 3149,
    basePos: "Last",
    rephPos: R.After_Post,
    rephMode: "Explicit",
    blwfMode: "Post_Only"
  },
  Kannada: {
    hasOldSpec: !0,
    virama: 3277,
    basePos: "Last",
    rephPos: R.After_Post,
    rephMode: "Implicit",
    blwfMode: "Post_Only"
  },
  Malayalam: {
    hasOldSpec: !0,
    virama: 3405,
    basePos: "Last",
    rephPos: R.After_Main,
    rephMode: "Log_Repha",
    blwfMode: "Pre_And_Post"
  },
  // Handled by UniversalShaper
  // Sinhala: {
  //   hasOldSpec: false,
  //   virama: 0x0DCA,
  //   basePos: 'Last_Sinhala',
  //   rephPos: POSITIONS.After_Main,
  //   rephMode: 'Explicit',
  //   blwfMode: 'Pre_And_Post'
  // },
  Khmer: {
    hasOldSpec: !1,
    virama: 6098,
    basePos: "First",
    rephPos: R.Ra_To_Become_Reph,
    rephMode: "Vis_Repha",
    blwfMode: "Pre_And_Post"
  }
}, mm = {
  // Khmer
  6078: [6081, 6078],
  6079: [6081, 6079],
  6080: [6081, 6080],
  6084: [6081, 6084],
  6085: [6081, 6085]
}, bm = "eJzlXduO5DiO/Zd69oPutuc79q3RGGT35DYWk1O16KrZRWOx/z6k5IskUjblcGRWTUOhjCoHKVEUJZLHCsf/ffr67eXb63+8/PL2+ukvP/2kBkH5eQA6M9jBDX4IwzhMwwzXNbx0fJlB20G7QftBh0GPkQGLngY9Dwa49WDMYCxcMy5+ZPxgQvrXuHQR/zMNZh6sGqweLPSJHDZxWD/YxGFzDjuBVGMu1dK3TW9hobXz8oGDl4b3gtqZYSXZWoarMGaHr9T20rDB67luDogVR+v84MLgxsFNg5sZQeqm1eCXN53TKpY0YzJNQm8HD9PpBx8GPw5+wmtJ7AAvnf5lcqFlag52CO5Ez8HKzQpJtsYXmwq+y6agwzCEEV+V8GEiiglIMMYX/EH5x7YWR4v2PTp8VbIoIsrolw9GGOyInxTkI8qSaDLJx3mYFL7W5tU60nEm4mzLjYrTUM2kh8kMkx0mMFvPSUTta0rtTGNOe2aK09QkTFILlTjBcjnV4lSv41kPs8EXaX+mq3N2uAXNntmCFNmB5rA2NA4z9l2SzyhJosnE0QqrjnXtYWnexw+pLtssiuXQCpaNAvNUsC0rbDVwotEp02pc3qec+mx+tZqblGlPFypUx/Wvz3SqNdEQ7hfoh6CSXrR2RCwl29ASO2gQXZseoU4liwbr1UZRrnjB6Fi5bXAXJzoebUz8a2Odjv2TBgsOZHLyCUkmXrq+JI1npSHOD8lDrGTtEk32ujMkHqXEGlY/1oX8SA4NtiYm12CV2uKMg1YsehsrkieT7EiWzWkLKDPCgyWnYXtArx0Yr02dtrZhaxM0YiNxwaGT3VmyPzmsOta1m6WP9CGj+CYLz6FBt9ph1Aj7E8RDGiyIE46xBrdsUK4gP9Wra1MuwZBQrR6rlijWEy1BRKahN6ykI+3pHqX9svF4rNVepf3UvfGUg4dwI4VfGqTQMLnQYByvDnEvSkFYDNdGT/vAOY+b0Pmq0RCzcdExXs+ps33toPV8c1uLNGbLODRjJ5UWQ1jeR2mribwd7qiOaGeRk48BFRsCQvyqQQ8aBqdHEvBojFhHx/WCH/pY2ZiqMBqkDfHvGCsZSB3Margwc5ra+57KDnaBZl4gEipjJJmqIfNE5qA/6rXxJaTWEFhjXemPRNEgi5xegxQa5NZAqiEU1xCHi0Tay0nQPgUpZT7eo/h+MckZK0naNITl3SbJywM2qWNAL1CIhjCfX1X4SU6f2e5RB7kFL9oTB71Lx70xPrSuZxQJViEEylU3esZcUHE9gWzQB1Y2uN67iamLUSb+tbGSwdQ5jsGUQ7N769a5K3vYJfK8RCSFQvoQqz1f7BcTIbdUIYOBzAnrxnAkkoH0qoPBQHplNGIeoCTwyQaTHIlQezlJ5da8T0CaDVm3KY1O1mk01rG2G6Onfuvk5QHzN3omxKxGjGmvMWPK9nNDPuojN+fUjo5Bm8GdBWqdYNYhm9m2H4f/4UOehagYChdSYTZqTBlUpet7CkuEaqawK5d8KCEL39pjoct50SdjZGwOKwRwFRt0MsZqIpSESIWZy6aNZUVZs/UuYbCcJ9PYp46V5iwMMZI39sByF7yQ6iZ6LaY3QId1pT+Sx8AqktMbi6ERWKLFeAfmycrAg4OSI0Hi9C/KgrYNia6BPo0jqZwBgzPOU770YYiVTxl3uVJWblxCWadYacpIEngDJrNmp3wxbq462cSK+aoMIkBEWcfqR76jAhy4lui7pUo5DKTXWDeOQ/ODHLyDwYCJGMjGjUdFgQ0CvUyqvZyAFSuyISDNx3wAvIbFTgNWQ+wUEvtuO22IjqsybvwSnZjgm2CRqQCB3KCPe8kNO7bU6YZXLtar+on3qhk+Q71qC59Zufokg0VkQoh1hWnWFAqaCWMh3JakR65pqXPJpxY2JpU24/q+w0Eic2xgJGYEOcazG4NIlbft0ujaiDhjiXhbcOQh7iPBT7CdFQgSkObKCE1KE6ETfJ9SrSEUkhObDe6BZs0UP6Np6EKVWzTiCkymi1gQflZLlkNIjGRNCGnl6xjRZLLMuj2kyTSUfICVVCBSA9ViLJ8HBZgJnGJzE7iFqW7dZBgKA5r1CRQbPE9ysdcx1skLiJG8EYpW6NQFrCkxeDmDmeZYN4YjkczcxWAQc8J7vzPYe7y5KwTxDsoDy3gdcGNRoqDcosxANG5RtkC0la9PPgG4y0w62K5JgNEZuYmIFSz5eYqVYEoEGTBbNg+sNn7KZeJzvfnZJden+T7CY1Yxms5QNUa2Jqq28snHZPEe/Y4vNEdlVWv/O0CNKlytgfQxuFoLHaG2b1VsUDmoNW5nVb0DFlBin0ixQckOaNUYq1bE8TLUSC/ZAi8Bb4lByxmsmmPdGI5EsrqLwYIgFqS3SKphvrTvhQ/bjfcv5nXAraWJ2CC3NAtIkfbUhBQ3vi4J55h6H6LezLTjYDBwl5DflZ0oNjexCLqiJjXYiVFlD9ag0k3ZR8IYbfx7FHXnWOQOXurYpAy9tMYn2QwC+GMt20RlwxJTP9GN7bLsmqJgXtLeiv6Rho8YuiURwnlccXRXtHhQNh5hYRc/3exss/kClevH2BL9KKa3eE8sQpznJ3psXHlSegu6cIspWsnJBIuwokPqECuB2AhAYu2aaSMcYZunPxa6YihzA/ZAxNAyUEkONDLSNYHGla9jVKi1DGY5GJfjjEut1PzcVEBjE//kgMYWUsTMfoQVLCornrrOe7DODZxMK8LaK1Uc8Dn0iR37WLUTxiQtugq9vAJFJo7QwWFBPVg3jiOhrJt6GCzsh9bjoVewVA+ThqeiOiHVg9a7V/bK11ylwfKrNINZuVXagllXvj4JtRXcEmCmHszKeilCq7KznwfptQUrnFf6g6OlnqIa1odYEZQ8SeAtDNKC1BaEtgFPT+jimFqkCWcA3xmGuSKeEtpsGIHIvssdXAzxbMBvroTqcB1+PrbP79kwxarIUGlHbp+As5PGgpIHqDciG4rFNSxMvx0x8oZ1QM+r2RGWHA+E2gVSOwIpcjB0h08RqLBjA6io8VMLjScBYT7GmQg4KSoglnntSX58adFSlgcRGDFdXYFH2vQRR78wQiCRKwxka2H6bTznJnGbSC+5q30J2UsMVs5gQYNYN4YjkSxMTQeDBTXjwTK0ykkEn53DyLVI9+bnis3OLcyrnaD9CZb0rMjX92ZoZjZlTwmws+lM3WGqnUN7OxgY0+14Xk+ABlo8jYcCgjLsTE4kWdRNLWBUXsTo+s4kLT1m3+whgFi6ukJotOkjjn5hpJAYV7Sqzx6htuZYjZZln0412y9wrQsgVWKwcgYHmnMRqPHnUJtTpofBga4QOY4cDcMsORacSXQeM/WQsBMHM4q1QmgIcuK2k3144zUinjRCWIiKcc8M1IS4kVNUqBxsIkKxYFPOJR6KVvm3S1tjyb4bVsJTrfiIAlorCCbjuTItx1qeeC1nsBmj5QZstnL1SbZoTQgucUVbSulgL8Vq9rTjsF2nJUFAF+SDja6DOj2jdmsCqdj00cFe52BjcTABDhZE1Y/DmdNz2VMCl5xJYhymgjkOtWNXmA66aNkS7MqBiUQRweYdRBq1iIhK1yLG1rwe2uDKkS1lWqPITbq6Yj206SOOfmGkwA1XtKOe0+HiNQmEkbTrTCNeLq3uEpCSOHQHh8OtCXealeNIKGfmHgZnE7wRjdO2jLPkWeEQ2anK1IuJablDrNg6kpY7/BJ282t161eMwvn+dRWziDyRT87jbIh15zmcF1BaD4ezMIcWPRUeqIYdHL+9eSKZc/uJL744ZnEclF0al3AVh8/RgFpPoOjuWT5kBGLYO2gZgMN11ARwVsZuCTczO5sQRPNGfB9jJfAHwSScW9ceHgqMd6KYvHGhyk3F80eiEJlxnkqWAzqMZCygk/N1jAj2rVkwpHRXg8GAmtkzhY1WsEnIdG2KThQ+KV7hGUDFKbwFUK18vfIt+hOCOFzBI2U1pQO3hRXxEkm7zjfi0oKyD1bBVjdM5CTL8wlKcD7ESr/hVwMJbrtZBPme843HWixUhUhz61khs46fEoPIcBhGNhaHyfk6xhRUfoCpPaqwS1hiN82Ul8I9K0gkZLo2S+c6n3idZ9ASq/MGtLTy9Uq4aFCIvXDFkAeo4DzpWBHmkLTr6D0JhrIPDcFW11EJjkHdk28rNtt24MUduv4APdQPj3IBul6CwApqcfFO0tEBmhxt2eEZTGHdyKMNNT7jRpNkQzc8ukq20VPZiskXZt+s4bA3wx096k71CR4nZpHoqUYmYSU5pNv9NUas8YA4F+A7cujdTbqRhMd8mrkTVaThVDo2DS/45KPCL/xnZy0OxpXdRilz93ayQ/P9FSaQcl2bq1O9Y/DN6T3HFhi9t7CFja9TwkWHwuSbXQHM7Ww32VhtKy6p18vUzIwyyt5kGNtdt+6zXPvuJArTZi6JKtJtpqNmur0x9idRDgI+rJZPo5jZkEAsvRnwxufW2sGDQQHWjedQMgz1OjjcjBW/XwxrCOIqNzuRZC5G5w6DnHjXoprJeWKlu9XMFGtk6tZUi0+0HEQrXuFTvWBrU+SoglcWKpt1e3V+VCHPvPdcHbMXrxrZS52se4gRkoCwGypyVMFrRQXMizT34oqZue8o+PZjQPKpuzVEV2yA7rWBCjME3trjXbyyHw/W5/VY9pSSMa9jdn94czpP2/ZED6Ne33poRJ3peaOSgBAEepi5WkBjqYB5kcbsXLGanTx6QoSqFVcphKHehFjrYLcOQv2GZTv8D3//biHKxPGGi9oxBPfmOG4nQrFxe84lHorN70U2x5LdAysj/dZ9RZobrPmEjOfKtBxqGbcgTstZBkK13MpAVq4+yVqFHEW+N2RVbMDqIRjzsDw9rE9vyc0wjw9pXI47V4mMlxzdzHOZPf/BKNA3z2TX+Y+Hq1FEtMxsWKuIzlAR8yKNYrliyVMPU5cSvG5pQRi18b3XADb27WJ1rgFXEFkbW2lpNhfip8Rnlirn8Tj7mAdsPEeSeQiBejg8GiOexcb9NM6eRK50b6fnmOpeiryBjRr3SJNr/YinRyKPzy/BiMmbWEloRuIlv62MERQc4WImMluo8jmBnJELNWPU6JmsKQ82qWRssFnwdYwoZLdRDoa0wz5lfNq8I0JD2jUQFjJdm6IThWvFKrwInhmFt4Lnja9TvlYZS3TN49aNYSF+ncIzhzdJUOg33wApmo/IOxN+LlS5wkLruGcMjgPjCPOYmsrGxtQFn3xMofimdHtUYQ9kyzi8ec+Ahu5rwC9kujZLpzrHeJ/TeZ4mMDpvpQkbX6eErTKT+1Q3hZuKDTY9/qwEWiE+p8uXHXj8dYep7CGlED6kr2m2gfg81dhzEwyzfZAlJx4Gh5JBjO5HXUkGwW4tWbpuU3g2uqVWUR0Jzvz+OBOLJ8RaMK4nzw/xiDqw0W0MVMfysUHpehbfUunY+Lbg6xjVVADhR+PKXEkRFLchbRpIe8FZIRJKd8/Vqd4x+mb1ngXtjN5bQfvG1ylhq2jyxdXF/IXhM1cc8zBED5rG6uYGzlCH5VOz/SL47Q1k0/VW0Mhz+C0vFITjN0YvjdgFn6MEZjbhCTvyWHE/+fVnTqow1k/nz3nJQ9k9+I24ZPoFmPPo109TEg/me1ZEPPxxlkq8he9Wj6p4f4oPzsF4BETwYIi1P8WHumhX9pRiJ7880OQIF8yjrD0ui7hgdKCCwMxDqpMEBD+jVN1RwLHWAqYPzNnPHlX+mH9EP3rX+iH96frmkesOOIecsYhEKp1xC/ei7nt1+TKeWxU1moaitgCBKKoVHySWDpHu9VCK9U8Bn6INe1iALSsoT382LGw/YVHFLUEJcK88dNnDHXTUQbVwrzrcCWpOIuL3RDTBvQL+mkUtYl6krogriAdRytA6opNLDev39Beqqr2x9fh63OzrB9in65uLoJ1wHiJjEgpWeodmgk8dyuqGhEy3qwwa4lW2uS1GZQ2vtTB1CBbiI7YFv11Vebr2k8zRadXPMk/Xd1/H9MT6upxPLmHp65ppNHWPq1MVMj1Hf+hTef3trpjpqemKV75eCXtcQIgPoRX8ulC177UfxYv7ef0w3nR9dwNMT6wbyPnkEpZeoJ2yUc+xOhwp15M0GJ/Ly2lw91KcBlteauXrlbBVfPXAZMHvJNZb6gWrlo/g5+HTy6+/vv73t//6/Nunv/z0ny9vX1+Hb7//k/+TPj4hEvy50MJDnWbMdTvyIT02eL5fySBvEf6SDDd393Cfj87du+nwzmVxv246FfaBonR+TIV4VJT3HPFBX1dt5z1V9aS+LlvsYa9yXT9VcUdyXfr/nYr5QM2fq/d9JHpkgrtH997q6O70quk/Y12/gwKeY3LXRXnCxzfa6JVOHrMOiSFAevPt5bevkNn8BOnRp19+//L3189//fXtn1+/vf7+CS/9+uXz1y+fXz5/++vXP97eXn55e42X/+fL/76+lZcYZnopvWS03KWv314+/+3l7cvn1wvM8uFxPf/xj1++vEmY+cvdDB9xmZlWeklM+OxLl2edtUvx1SeYtdzS+ctL/108T718efUNj8wXs0gbS1e8mu9aWjf28INsJl3bzCP7wIMtfkc72oOe9WN3v+dslk/cpK588qPsv93jesSgHt4t2E3/unOQmpbILXwvcd/tDuQj/c6zPdLT49hbfM57uai7Hde9zudm93anP7prc/1Yt/SR3uwdHBpvK3d7me+d7hHE4tm78d1u630810cAH/0O5Dk+5OkZx4f7gQ/bsm7f299nexfuQ0/Y2vpafY4A79Tk97ZFv+POff8W+T3uy++ykV7fFn4IpOLydvjhS/6HafXxbez5O9DhGrt36fcs0ZvX8v1B0YclavT1YyyGd1pfH7aWnu/7/00c+zus9j+pw/53ck1/dvz1g/3Ld7WHfo/G80gP38ts37gHddxB4tr4+f//BVoTYdo=", ml = "eJzNmVtv2zYUx7+LnvnA+6Vva4a0K5BsWLcWmBEEsqMG3mw5kJUOQ9HvvsOLLUp2owsVwGBCmj8d/nl0DkkzyLdsldfF465aF/vszSL7NUPZL7c/Q/0Rft+9hcr+Xt9AdfXuA9Sfbn5afnXtb/vatqHre1c3bzf/um5V2Mb33jt7//kqjD907Ty/2/n+tBMF0Rs//NqbXnt47UeUz5uNtQ86Hw8zhjF/fb794Bpbu8r6/slOc2tdsZUbeoeyh2K12z7t9ut6vSvh/b9lVGAFcYCGIcoNByP4rI9IEGOR1g5prRA1mDpkyBFppT2ikRUDxDCxA6HhiGEsPTIeiQZR3FgxYhHh3CLCKWJEWHlGpUNUMsSoFg4p4pDCEaIRkh7xBsmARIyOozl2o5nRCCrsEfPIRIgfrThxAwWXFgkObyUY9khHKFiZGDWmAjdcuABI5jyUkiD4bBPDlHSeKA2eKGmzwIxwVkZATIzgHqkISY+sJxySAUhqj0yDnGngEntuIkQa1DI1zUQOSePyAQ1G0kjhEfOIRkh6xCOkPBIRMh7pBhnGHTNMATRUBSoC1UeqMHcpti1BULt42Z6Mqfa2mjNHNbdUcxoojyk7UNmytZ4pgo0NsW0lgtrrQs8EqgL9jrJ9DUfQH/lyU8CzBUazlTu0oAj2C+JQBBBwBWlkEMGIEEQoIgzBHoOdRyQ8JgpB+u0TgyhGlCBKgxZlvvE1txW85yzOUnn0dqKAPXHa/VNBaqBi8APbB0ICSxTOFthdsNUVYnbRI+4tIY3wAM4ZDoGDyImgwOVRjBlP1EwhaPLV9A75ii0I7756O0v9irijeBLLsYKHJeXcowN8DCup/7XN4NceKHlm5WO/8HHfuo+mFi+EwEvPHoN0TaK7D8eX3rWUvjp7zqdXTRPAMTEdeKTO4zLXLXHbHSzOzciAkMM5NygiZ3T7yoRDq1eS/PjhNLmRqza2SNz904twFXnxlE5I9Vxupqp1v+/TvZtZru9lo7tIbMS6XnQuIANETzS7ZbxkfGdyE8gBrkZ3pd4AsGadzSd79o6HR1zxAlB9AfH6rxKRdF3+8mIYVAYsshkW7lw386S0MTEyvmekBW05D93hzgs2xXs+yv1z4n1lyjnUq9n9kkzXG7/eYqO5z56kLP34G7xzFZz1D5iUa+ZZ8bRycpNJEuP9Kevs3fm/LlIOh7MzJMTjGOE7lOWrVfFUr8vH7M3iS77ZF6iunidX6QqXVkGI6vzR/oNgAeHPltXun6K8X22e93VRZRaty4fiqYCqrFt8/992udu0UZ2XD3n10IJnJC8BXYof01H5vC2qfNNnNiZ/A1N6gfDrusq3+T10t+syr4tL8u014PQlAmxZVPd/79YlNMkBO5ni7vv/LbyJLg==", wm = "eJwBdw+I8AARAAAAAAAAAADYYAFmD5nw7Z17jFxVHcfv7s7OzO7M7nQLRAhiUSDEUG1AIrYUFpBgColYTaRVUUQJiEFQg5A2CAhqLSAPQUws/CHlL4r+wUNjwbQSESwQUCFgFLCoNQSsUQKiIH7P3HPmnjlz3o97Z2V+ySf3cc4953d+v/O+d2eX1LLsYLAMHAFOBqeAT4DPgneD90Y4ng7OBl8C6xyeWw8uAxvANeC74GawGWwBd4J7NM9fAC4GPwe/AveDR8AT4GmwBPwF/A28DObBf0F9Mg+bxXFP8FZwIFgKDgMrwHHgRPAhsAacBs4CXwBfAV8F3wBXguvBJrAZbAF3gq3gPvAgeAw8Bf4IdoHd4BXwBpisZ9kM2AvsBw4ES8HhYCU4Fqyq57qvxnENOI1en4XjeeBCcBG4HFwBvkPDv4/jLeA2cAfYWs/LfR892vIgjf8Yjr8ET9Hrx+nxOvAMzh/intnlmIcNz3Bp7sb5K+AN0GhkWQe8BSwBB4Nl4IhGf3xynKf3HgYfwPnJ4BTwqUZurzNxPJfGuYDeuxjHb4KrG3l9mqfciOtNYDO4DdwBttJn7qPHHTj+hqb3VIPaCsc/N/RlfdEQztv4JcTdQe/dDV7Dda2ZZe1mEXcPnO9Lr08CBzQH0ztEci+Uw5p523N5ZkUCPVJzNHQ+XqL38+BaSfwTaVzWFlfjei34NIWPeyStb5/j7q/Q6ELq9he5uN+mxw1CvAubef/L67qOPve1plxvhi5sxIgRfjw8BDqMGDFixIgRI0aMWHgcOQQ6iDxH17rfcljfr1TcX6555lqkfz3YBDaDLeBOcA/YDh4Aj4InwbNgVzPfW9qN4z/Bf8DEVJa1wBzYB7x9Kt/PeSeOh4Ll4FhwBi3LZi7/Vbi/eqp6e48YMWLEmwmyb7kWfe/7asU+fVVUbYsRI0bE4QRuzkrec86D09DPnAXOE+Z6FzrO/U6ix3max1HgkqnifeoGnF8tpHnDVPFeh4e8l7kJYbcOwfzztUU5K+dgI/CTRWY2IN4Dirgv4P7+i7NsDbgGPLq4P/z3CG/ukWV7gzXgkuks2wayVpYdAy4hR3KPHnfSI8872ln2vbGc03H+g/ZgnJ24Nz5TXB+H80vBdjA2i3UBuHS2SCcW22mar+K4vJOfH9/pj7Ouk+v0086g3iNGjBgxohz+XXEfHHv8cWHFourzn6+9ubkc3I554F1Tg+tR8p3Pvbi/jZsn3o/zR6by+egOSXrs+7sn6PqanD89lX9TR9LbSdN6XpLfEprmPxD2Mvc82zd9fcpv/Uy+mSLfTBwl0XcSbaAJFk0Xc+O9p/Ow/XE8GCyb7s/viOliHj6P8xPAB6eL/Fi8j9J7n5zOv/s6A8fPgy9PD+q/frq4XkbTvow+v3Ha7Md5qrvMPsR+D0nCiF2uQ9o3gpvBLeA28CPwY3Av+AV4CPwW/A7sBLvAbvAKeAPUWkWabZzvCfYFB4BDwKFgOTi2NajDvdBhFe6vpmFrcTwVnCGJy+Kfg7DzW8X1RTj/OrgK/AzXN+B4Ew2/FcfbFWkRSPy7WoM2I5wqqW/dPBF/O3gQPAYeB39o5Xv/f8LxhVb+/O662WcvIe6rYAzrhTpogbl2Eb4PzvcDB4F3gfe0i7KZOLKtDiP6vb9d/npPrId82EkafY62KK8PZZdfxkc0fiqLWGUh3/JWlT9pb6QP/DhnTzJOfYarV2fi/Jx28b1sKjuua8rvn091Wc/peHRE+y9EdO9pY7DMs06WiakMbGy/DPVmo2O/PQzvOVzKfw3Kd0M7XZ/van/2ve2VivD13Nxvk6Qv57/DJ3Mu2byAhd9Nj+TvmjYjrS3U13fg+EOw1cH3L1r8fc0xCf6OYht0fGAIxjRbHoWuTxrmSs+2+8cV2zq1zHLuXiUqP/613R/+9xJ8+i9av1/n8iLvMGRrTQZpI5MzWTYD9gL7gYNm8rClM3bl5/+uibTXjeDwmbztP8e1I3Z+FZ2Dr0Sc42fyPvbEGXn7V9k3NUT3D8/03+P7ItIPreTKvpH2Y2S9+DHObpdzz5xO0zsbxytqg2mfi/vnW9h8mKjKP6lZ2/z/Lh/P65pxcUdJOgwrv644/0cU+yhlEloG3fizELhIGAdc7JNqrbyQ/L+QIXX3bbWxLp0sW3CQ/WX+3IaqdR5W3uxStf2j1U36exYLQtchhokp3BSvw4Wb4vnqWbWtFlo5bHw2TMj0XUj668qkkip18dW5Kv2HvU5UaZOy646tVK33QvV/jLSqsD+vt2v+KSRVGRdKWWab/dTGIzAWkUV28aYaOc0JlGNxfj7eKO670KwVz3ZtNE2hNuLjGnWjNpni0iO4rtO9bd3q92+mS4vCRHXt6sPusxr/snBeZGkQYf5tU/+2Jf5jMk7jMGnT+MS/Yn4yaTcG7w2USfBvL56lf1n9dmmv5MjnZevfgbKU7F8xrnhOhPiX2Z75lyHzT1vhX15I29WJqjzaZyz92+tXxwo/1+bcxgDX9st8qrwuyb+27VeE1W3WppiPZf4NHUuZTcS65No/a/MY48YQUJ8oINJYIP2zq38nLfrnSYv2K5NJRZ8Qu3/uZEW7DZnHsX67m7dF/6xry6qxkp2L92TxxHvK+5bzL1H4tizrv9nYPC60bULdsn3L/K+SFO9FZCLOp23m1F39DP6O2Z5d/UnaM/l9aBG+TfH3xeu6oT3zz+nqFG8X/hkX/+rEZ72knZsPgX9VcZmw/trGv/w1O7fxr9j3yqSnawT/djo5PiL6l9epLP9qsWy/BGZ3Nh6rIGLqj7s2VfiN0W7o2w5vk9D5lglTv+Y6n7adc8vsEgOrNCVrads+XtaGVfsjLIwd2V6JbL9FJa79Nb9/4iqxfeELW7fbIgp5nm+n443+fSpy5NcWhG77bxZxYqxrxDqpsnEK25vyDLF3dz9vLoeJzN7MF0REe9ezol/JHOytqqsp9qd5mhRlP2q7j+VQr/j62qE2FPMlJpmw8HGKOqbrJzOPOsXaIGuHZDwm9aSu0n3Onm75HeKngLUHHfzet2wd5VN3ZVJ1H9/Fcr6gqiuycZTUne5cnaw5Zvv7qh4kb5d9Da6f5/c6ZGUY6Cd1dXYsj9OayGFx2LPsPg+fljEvG+YGbSnLl9Ck+Xf1sLQfe1Z8r2Oq4zLpCOehyNKxST8LfD40/9Tl80m3DHhJnYdveKryiuKzbu4+J9yzWYPEyl8Gn79NuVPl7yox7E/EO/+yxmibfZQIewLM97r9FxF+rdHbg6Fjf/d8Jofdl6VB5gim/RgC2xvq2T9wHzW0Dyir/46Rf2z9CV37ltUGJO3YZY3Mr5OZsPvd9x6aNYNuj0NmT+s1ZkybeOz9uY53A/bz8BkvqvUEv1ekWmPI/CvC5r1K/R32AqR+Tli/ZWWPkr+qXrBwiR27a3/ZOnrWb39BtS9I2uHAHtVE/7N83Qnt/0Of59+9sDHPe/xNUIdE25n8Id5v1fTp+9rTZ6whdbCZFXtRMlzHQWu/pRzLJOOMzBekrfXtnYzZ25vMm6R5KvoG23pjGh9FGZg/KGyhq5O6/p7ft2xO6PN2Gaf76jinb+j8yTTepkybCP+dV0e4tmaxgOQesxcJ488Zqj42hn1t7WTa89XpY6tvZjjqngnxf4q0bfOzzcNLl0lQL65jjDU+evTKbbGGldLInP8G2Nd3vIT62/StsklCdI+hvy7tFOKqU60dt4zKepuYVPmE2lgnofWiLJv66lB1eGxb+NpIJ2XXx9T1I9Q+w1R/XfJIUTdcxUZf/v01v/6sS9bh/N/ppNx/kr0bUtkw1PdJ19k6TOv9cc2aWbaGHSu+t3apc9H+rjXhXoXLPh/52xj++zKV9Op/6H6cz/rVZk1L0bVbl/3I0uuzhOZEQa8cifsP3T6O6/vXDtdetHt4KrtEtrluz4zfy+p7P1HzH9dC2ovO36yftyp3QH3PMk39TN0+LOqpuP8oe/9hkpBvFDMP/w70S4G2GUhDsa9Cwlr0XY34fVxs36jeDYr32Xe67JhadPM5m7LKyiRLk31TGaKXaW7sEq4Tb9/zdrPtDwxtyjQekTKxbyR7+gfOR1zmwKFrHd85t4vurmWMrb/ufqaIW6aOvraWSRX5hpa3DH+HPG9T3tjlCLGlya4pwk32sbWTrfjWJ1N4SH0JTdtGf9fnbeyWqi7GyM8nDVmZq5TYNg3NvyydU/k+lq62EppeCru4pO8iMdqKSQ+db1PVH1UZq6i/Lv6JWY9D8gi1eYq8XHSqIv+qym/Kk6x7J4VvY8mR/50qXlg88Xfe+vbkNNepYFLn9qQHyj4bthaX2S9mG/bJyzZf3zSHqV2lLI+LzVwl1Ge+acfKIzT/FD7wLWtoOn2/hdXJGbp3rIb9bxl1w3skUazf2wT0tSbpfpfu81vOke1r+t1l8g6bf0ca2kY7wvkwtzutf0qo/6a2oPMd+9skIr5/l8LnayNl9hNinbSRKL+dntC/rr+BTt6f677LILC/BeHf8/T85VkveJvH6kt9+tRYvuqmlWB8IvWM+Ih9n6GyI/uOXKc/01Gmq6/+Ps/r2lrVbcgF9ndSxvFvQt3/hdZp39+v5OMN2D6y7/lwVVwibN3K/p+DCibi7/3zfRoTXV1T+aSTDfbxYt66b9/6/GMIN0mKeuszTrDvEBnMT6Z5kUv9Zr5iY47t7+2m7CNsbKUK77NXTW4zo/8D+4dUZWcihsvKHHONPFC/BJ+L+sXwvyt8+dl8yXetk/L7mRhrMaP+juOp7ZjaqhW/46bNv4R1eKzyh9LL0+KbLVO7drWfbv2XamyS9TMD+jvOhcreI2GiKxs/ZoxLfJRS+D7VROr6LRtj+n6XX/xmUbHu7N23+AbUpfwyGyjHLcfvmfvKOius/RTzsCrEZl4mjZewvujWEaY5W6htY+9n+ParLmOG63f2pm+GVXPE0PrEh/fOS6xHvIj1iZ3z6yUW1m2/ncJ+MeqPq/2ktku8N6lrf/y52M9p7RNLx9bg3Mimrcdax/hIjDxDdUmRv4s+vvaNNUaG+ju0PsS2dYx6GyutVPqVlb6NhKblqs8w+j6Gvqb4ZYtMJ/Gav+9jM5tnfdKOVTdcfWSrs204L6lsFCIp/BUqZdQl17xUcVNIqM1T2CQ0bRd7haYZ+lwMiVFHQ+0o0yfL+p/X1W1Tm5ClqdNNZXPVUZanTn+b9GTPm8pnW36dTXxtG6tu2OSTMn8XiZFOqP4pyh/DtmX4InW+of4N1Se0HFW1i9D8beq5az6muCn0NuWts5ePxPBnTP+Hyv8AKXRL6A==";
function bl(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = Fm(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function Fm(t, e) {
  if (t) {
    if (typeof t == "string") return Js(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Js(t, e);
  }
}
function Js(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
function xm(t, e) {
  t.prototype = Object.create(e.prototype), t.prototype.constructor = t, t.__proto__ = e;
}
function Sm(t, e, r) {
  return e in t ? Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : t[e] = r, t;
}
var Am = JSON.parse(String.fromCharCode.apply(String, Wt.inflate(Yt(bm)))), Em = JSON.parse(String.fromCharCode.apply(String, Wt.inflate(Yt(ml)))), Cm = Wt.inflate(Yt(wm)), Im = Em.decompositions, wl = new hi(Cm), Om = new yl(Am), Te = /* @__PURE__ */ (function(t) {
  xm(e, t);
  function e() {
    return t.apply(this, arguments) || this;
  }
  return e.planFeatures = function(n) {
    n.addStage(Dm), n.addStage(["locl", "ccmp"]), n.addStage(Pm), n.addStage("nukt"), n.addStage("akhn"), n.addStage("rphf", !1), n.addStage("rkrf"), n.addStage("pref", !1), n.addStage("blwf", !1), n.addStage("abvf", !1), n.addStage("half", !1), n.addStage("pstf", !1), n.addStage("vatu"), n.addStage("cjct"), n.addStage("cfar", !1), n.addStage(Bm), n.addStage({
      local: ["init"],
      global: ["pres", "abvs", "blws", "psts", "haln", "dist", "abvm", "blwm", "calt", "clig"]
    }), n.unicodeScript = Vy(n.script), n.indicConfig = Zs[n.unicodeScript] || Zs.Default, n.isOldSpec = n.indicConfig.hasOldSpec && n.script[n.script.length - 1] !== "2";
  }, e.assignFeatures = function(n, a) {
    for (var o = function(f) {
      var l = a[f].codePoints[0], c = mm[l] || Im[l];
      if (c) {
        var p = c.map(function(y) {
          var v = n.font.glyphForCodePoint(y);
          return new At(n.font, v.id, [y], a[f].features);
        });
        a.splice.apply(a, [f, 1].concat(p));
      }
    }, s = a.length - 1; s >= 0; s--)
      o(s);
  }, e;
})(Ht);
Sm(Te, "zeroMarkWidths", "NONE");
function Aa(t) {
  return wl.get(t.codePoints[0]) >> 8;
}
function Fl(t) {
  return 1 << (wl.get(t.codePoints[0]) & 255);
}
var Nn = function(e, r, n, a) {
  this.category = e, this.position = r, this.syllableType = n, this.syllable = a;
};
function Dm(t, e) {
  for (var r = 0, n = 0, a = bl(Om.match(e.map(Aa))), o; !(o = a()).done; ) {
    var s = o.value, u = s[0], f = s[1], l = s[2];
    if (u > n) {
      ++r;
      for (var c = n; c < u; c++)
        e[c].shaperInfo = new Nn($.X, R.End, "non_indic_cluster", r);
    }
    ++r;
    for (var p = u; p <= f; p++)
      e[p].shaperInfo = new Nn(1 << Aa(e[p]), Fl(e[p]), l[0], r);
    n = f + 1;
  }
  if (n < e.length) {
    ++r;
    for (var y = n; y < e.length; y++)
      e[y].shaperInfo = new Nn($.X, R.End, "non_indic_cluster", r);
  }
}
function nr(t) {
  return t.shaperInfo.category & gm;
}
function ut(t) {
  return t.shaperInfo.category & gl;
}
function gt(t) {
  return t.shaperInfo.category & tn;
}
function wt(t, e) {
  for (var r = bl(t), n; !(n = r()).done; ) {
    var a, o = n.value;
    o.features = (a = {}, a[e] = !0, a);
  }
  var s = t[0]._font._layoutEngine.engine.GSUBProcessor;
  return s.applyFeatures([e], t), t.length === 1;
}
function Tm(t, e, r) {
  var n = [r, e, r];
  return wt(n.slice(0, 2), "blwf") || wt(n.slice(1, 3), "blwf") ? R.Below_C : wt(n.slice(0, 2), "pstf") || wt(n.slice(1, 3), "pstf") || wt(n.slice(0, 2), "pref") || wt(n.slice(1, 3), "pref") ? R.Post_C : R.Base_C;
}
function Pm(t, e, r) {
  var n = r.indicConfig, a = t._layoutEngine.engine.GSUBProcessor.features, o = t.glyphForCodePoint(9676).id, s = t.glyphForCodePoint(n.virama).id;
  if (s)
    for (var u = new At(t, s, [n.virama]), f = 0; f < e.length; f++)
      e[f].shaperInfo.position === R.Base_C && (e[f].shaperInfo.position = Tm(t, e[f].copy(), u));
  for (var l = 0, c = Jn(e, 0); l < e.length; l = c, c = Jn(e, l)) {
    var p = e[l].shaperInfo;
    p.category;
    var y = p.syllableType;
    if (!(y === "symbol_cluster" || y === "non_indic_cluster")) {
      if (y === "broken_cluster" && o) {
        var v = new At(t, o, [9676]);
        v.shaperInfo = new Nn(1 << Aa(v), Fl(v), e[l].shaperInfo.syllableType, e[l].shaperInfo.syllable);
        for (var m = l; m < c && e[m].shaperInfo.category === $.Repha; )
          m++;
        e.splice(m++, 0, v), c++;
      }
      var w = c, F = l, S = !1;
      if (n.rephPos !== R.Ra_To_Become_Reph && a.rphf && l + 3 <= c && (n.rephMode === "Implicit" && !ut(e[l + 2]) || n.rephMode === "Explicit" && e[l + 2].shaperInfo.category === $.ZWJ)) {
        var I = [e[l].copy(), e[l + 1].copy(), e[l + 2].copy()];
        if (wt(I.slice(0, 2), "rphf") || n.rephMode === "Explicit" && wt(I, "rphf")) {
          for (F += 2; F < c && ut(e[F]); )
            F++;
          w = l, S = !0;
        }
      } else if (n.rephMode === "Log_Repha" && e[l].shaperInfo.category === $.Repha) {
        for (F++; F < c && ut(e[F]); )
          F++;
        w = l, S = !0;
      }
      switch (n.basePos) {
        case "Last": {
          var A = c, M = !1;
          do {
            var L = e[--A].shaperInfo;
            if (nr(e[A])) {
              if (L.position !== R.Below_C && (L.position !== R.Post_C || M)) {
                w = A;
                break;
              }
              L.position === R.Below_C && (M = !0), w = A;
            } else if (l < A && L.category === $.ZWJ && e[A - 1].shaperInfo.category === $.H)
              break;
          } while (A > F);
          break;
        }
        case "First": {
          w = l;
          for (var P = w + 1; P < c; P++)
            nr(e[P]) && (e[P].shaperInfo.position = R.Below_C);
        }
      }
      S && w === l && F - w <= 2 && (S = !1);
      for (var G = l; G < w; G++) {
        var W = e[G].shaperInfo;
        W.position = Math.min(R.Pre_C, W.position);
      }
      w < c && (e[w].shaperInfo.position = R.Base_C);
      for (var ne = w + 1; ne < c; ne++)
        if (e[ne].shaperInfo.category === $.M) {
          for (var q = ne + 1; q < c; q++)
            if (nr(e[q])) {
              e[q].shaperInfo.position = R.Final_C;
              break;
            }
          break;
        }
      if (S && (e[l].shaperInfo.position = R.Ra_To_Become_Reph), r.isOldSpec) {
        for (var N = r.unicodeScript !== "Malayalam", Q = w + 1; Q < c; Q++)
          if (e[Q].shaperInfo.category === $.H) {
            var te = void 0;
            for (te = c - 1; te > Q && !(nr(e[te]) || N && e[te].shaperInfo.category === $.H); te--)
              ;
            if (e[te].shaperInfo.category !== $.H && te > Q) {
              var ce = e[Q];
              e.splice.apply(e, [Q, 0].concat(e.splice(Q + 1, te - Q))), e[te] = ce;
            }
            break;
          }
      }
      for (var j = R.Start, le = l; le < c; le++) {
        var K = e[le].shaperInfo;
        if (K.category & (gl | $.N | $.RS | $.CM | tn & K.category)) {
          if (K.position = j, K.category === $.H && K.position === R.Pre_M) {
            for (var re = le; re > l; re--)
              if (e[re - 1].shaperInfo.position !== R.Pre_M) {
                K.position = e[re - 1].shaperInfo.position;
                break;
              }
          }
        } else K.position !== R.SMVD && (j = K.position);
      }
      for (var de = w, X = w + 1; X < c; X++)
        if (nr(e[X])) {
          for (var ae = de + 1; ae < X; ae++)
            e[ae].shaperInfo.position < R.SMVD && (e[ae].shaperInfo.position = e[X].shaperInfo.position);
          de = X;
        } else e[X].shaperInfo.category === $.M && (de = X);
      var we = e.slice(l, c);
      we.sort(function(h, d) {
        return h.shaperInfo.position - d.shaperInfo.position;
      }), e.splice.apply(e, [l, we.length].concat(we));
      for (var Ee = l; Ee < c; Ee++)
        if (e[Ee].shaperInfo.position === R.Base_C) {
          w = Ee;
          break;
        }
      for (var Le = l; Le < c && e[Le].shaperInfo.position === R.Ra_To_Become_Reph; Le++)
        e[Le].features.rphf = !0;
      for (var ke = !r.isOldSpec && n.blwfMode === "Pre_And_Post", ye = l; ye < w; ye++)
        e[ye].features.half = !0, ke && (e[ye].features.blwf = !0);
      for (var Oe = w + 1; Oe < c; Oe++)
        e[Oe].features.abvf = !0, e[Oe].features.pstf = !0, e[Oe].features.blwf = !0;
      if (r.isOldSpec && r.unicodeScript === "Devanagari")
        for (var Ce = l; Ce + 1 < w; Ce++)
          e[Ce].shaperInfo.category === $.Ra && e[Ce + 1].shaperInfo.category === $.H && (Ce + 1 === w || e[Ce + 2].shaperInfo.category === $.ZWJ) && (e[Ce].features.blwf = !0, e[Ce + 1].features.blwf = !0);
      var _ = 2;
      if (a.pref && w + _ < c)
        for (var V = w + 1; V + _ - 1 < c; V++) {
          var ie = [e[V].copy(), e[V + 1].copy()];
          if (wt(ie, "pref")) {
            for (var H = 0; H < _; H++)
              e[V++].features.pref = !0;
            if (a.cfar)
              for (; V < c; V++)
                e[V].features.cfar = !0;
            break;
          }
        }
      for (var J = l + 1; J < c; J++)
        if (ut(e[J])) {
          var xe = e[J].shaperInfo.category === $.ZWNJ, g = J;
          do
            g--, xe && delete e[g].features.half;
          while (g > l && !nr(e[g]));
        }
    }
  }
}
function Bm(t, e, r) {
  for (var n = r.indicConfig, a = t._layoutEngine.engine.GSUBProcessor.features, o = 0, s = Jn(e, 0); o < e.length; o = s, s = Jn(e, o)) {
    for (var u = !!a.pref, f = o; f < s; f++)
      if (e[f].shaperInfo.position >= R.Base_C) {
        if (u && f + 1 < s) {
          for (var l = f + 1; l < s; l++)
            if (e[l].features.pref) {
              if (!(e[l].substituted && e[l].isLigated && !e[l].isMultiplied)) {
                for (f = l; f < s && gt(e[f]); )
                  f++;
                e[f].shaperInfo.position = R.BASE_C, u = !1;
              }
              break;
            }
        }
        if (r.unicodeScript === "Malayalam")
          for (var c = f + 1; c < s; c++) {
            for (; c < s && ut(e[c]); )
              c++;
            if (c === s || !gt(e[c]))
              break;
            for (c++; c < s && ut(e[c]); )
              c++;
            c < s && nr(e[c]) && e[c].shaperInfo.position === R.Below_C && (f = c, e[f].shaperInfo.position = R.Base_C);
          }
        o < f && e[f].shaperInfo.position > R.Base_C && f--;
        break;
      }
    if (f === s && o < f && e[f - 1].shaperInfo.category === $.ZWJ && f--, f < s)
      for (; o < f && e[f].shaperInfo.category & ($.N | tn); )
        f--;
    if (o + 1 < s && o < f) {
      var p = f === s ? f - 2 : f - 1;
      if (r.unicodeScript !== "Malayalam" && r.unicodeScript !== "Tamil") {
        for (; p > o && !(e[p].shaperInfo.category & ($.M | tn)); )
          p--;
        gt(e[p]) && e[p].shaperInfo.position !== R.Pre_M ? p + 1 < s && ut(e[p + 1]) && p++ : p = o;
      }
      if (o < p && e[p].shaperInfo.position !== R.Pre_M) {
        for (var y = p; y > o; y--)
          if (e[y - 1].shaperInfo.position === R.Pre_M) {
            var v = y - 1;
            v < f && f <= p && f--;
            var m = e[v];
            e.splice.apply(e, [v, 0].concat(e.splice(v + 1, p - v))), e[p] = m, p--;
          }
      }
    }
    if (o + 1 < s && e[o].shaperInfo.position === R.Ra_To_Become_Reph && e[o].shaperInfo.category === $.Repha !== (e[o].isLigated && !e[o].isMultiplied)) {
      var w = void 0, F = n.rephPos, S = !1;
      if (F !== R.After_Post) {
        for (w = o + 1; w < f && !gt(e[w]); )
          w++;
        if (w < f && gt(e[w]) && (w + 1 < f && ut(e[w + 1]) && w++, S = !0), !S && F === R.After_Main) {
          for (w = f; w + 1 < s && e[w + 1].shaperInfo.position <= R.After_Main; )
            w++;
          S = w < s;
        }
        if (!S && F === R.After_Sub) {
          for (w = f; w + 1 < s && !(e[w + 1].shaperInfo.position & (R.Post_C | R.After_Post | R.SMVD)); )
            w++;
          S = w < s;
        }
      }
      if (!S) {
        for (w = o + 1; w < f && !gt(e[w]); )
          w++;
        w < f && gt(e[w]) && (w + 1 < f && ut(e[w + 1]) && w++, S = !0);
      }
      if (!S) {
        for (w = s - 1; w > o && e[w].shaperInfo.position === R.SMVD; )
          w--;
        if (gt(e[w]))
          for (var I = f + 1; I < w; I++)
            e[I].shaperInfo.category === $.M && w--;
      }
      var A = e[o];
      e.splice.apply(e, [o, 0].concat(e.splice(o + 1, w - o))), e[w] = A, o < f && f <= w && f--;
    }
    if (u && f + 1 < s) {
      for (var M = f + 1; M < s; M++)
        if (e[M].features.pref) {
          if (e[M].isLigated && !e[M].isMultiplied) {
            var L = f;
            if (r.unicodeScript !== "Malayalam" && r.unicodeScript !== "Tamil") {
              for (; L > o && !(e[L - 1].shaperInfo.category & ($.M | tn)); )
                L--;
              if (L > o && e[L - 1].shaperInfo.category === $.M) {
                for (var P = M, G = f + 1; G < P; G++)
                  if (e[G].shaperInfo.category === $.M) {
                    L--;
                    break;
                  }
              }
            }
            L > o && gt(e[L - 1]) && L < s && ut(e[L]) && L++;
            var W = M, ne = e[W];
            e.splice.apply(e, [L + 1, 0].concat(e.splice(L, W - L))), e[L] = ne, L <= f && f < W && f++;
          }
          break;
        }
    }
    e[o].shaperInfo.position === R.Pre_M && (!o || !/Cf|Mn/.test(St.getCategory(e[o - 1].codePoints[0]))) && (e[o].features.init = !0);
  }
}
function Jn(t, e) {
  if (e >= t.length) return e;
  for (var r = t[e].shaperInfo.syllable; ++e < t.length && t[e].shaperInfo.syllable === r; )
    ;
  return e;
}
var km = "eJwBFg7p8QACAAAAAAAAAAC6EAEFDvrx7Zx7jF9FFcdnd7v7e213uxZaoLwfpqUIRZoYpDEQINGUJmpDFPnD1gc2YrBBjY1KaIiGAhIJhlBjhBqjlTT1GVBjQPkDSAVNikRBBRUjAVGESEjFxPgd75z8zs6eed7XFn4n+WTuY57nzMydmTv3rppQ6hSwFpwDLgQbwWZwubl2XgXuFrANbAc7PP52gl3C9RvBrWA32AO+Db4H7gH3GR5k/n8BHgW/A08L8T0FngGrwAsmb6vM/VWMV8AhoJYo1QXLwApwPHgjOBOsBxvAReAS8G7wPvAB8FGwHewAO8EucAvYDe4Ee8F+cDe4FzwAHga/Br8HfwHPghfBIaAmleqAWbASnABOBWdMFnlfD/c8cKE53wh3M7gcbAHbwMfBp839a+F+AdwMbgNfmxyW/ZuT83VRlv2I7/sVx8n5sRX3fTh/EPwK/AY8NVmU9xnwAngF/DeQn6kppWbACrBqqgh/Ctw14Gxwrrl2Adx3gHeBy6YK3Wq24vhD4GPgk+Bz4PMmzE3G/TLcr4IbWLrfwPm+KX/efhC4H8NPEMf94AA4CJ4w5dL3noT7V/AP8LK59irc8Q7qIFjaCcd/JPwc1yniPBHuanAWWA/WmbQ24PgME9fbjF/NxeyYswnXLwWXWfe3OvwTHzFpn8305vPP/eWi4/gw0rwKXA12dOLj32np90zBzy74uQXs7hT1bQ+Lf6lHH3txbz+4G9zrsKPU/h/oDMv1CI4fA38AT5u09PHfzPFjAXtUod8RI16PjNrPiBEjRowYMWLEiNcC6zrDNYEbIvz/k81d/2XNY78YEf4/CDPRLdZhBnCXgxXgOHCauf4muOu7hf8NcM8HbwfvNPffC3cL2GbOt8PdAXZ23elqf7s890eMGDFiRL2c0zJtl3/EiBH1UHf7/hLGj7d3i/dCd8D9ljCe/E63eLevj++x7t+3CMaff58umF6q1CXgkekwO+Hv55ZfNTM8Xo3jLWAPeBwcMvdWz2KMPjv0twPHe6CDP4ETewgD9vSKsfwdU4X7sDnnDPrwNzZkY3+hn5twbR+7/jyO1w6UuhLsA8+DtdPtP3/aJtReHoTuDph6ehDu48Zeep74bDf9ebrfuGdG+ue8mJGe1CdI4V9G3K925/uj/O73pDeO+tkDc71h2bS/o3B+bK84P7k39H96b34+YvurWFu6yvfmnnzvrbi+AVwENoLN4D3gSXP//Ti+AlwFrjb3PwOuAzeCW8HtLO47cbwX7AM/BD8F94MD4KCQBz0PfwLX/2zu6f00z+H4JcEv+f837o31h+c9HM+Bo/vF+Un9Ym+Jvr8Gx2f33TrT/s/tyzpz6f0C+L8YbAKXgsvAVpP2tn7RZmLtth3+PwWuAdeB68HNLD+34fgr4OvgLvBdVrYQP/KU+1Hk8Wf9dp45Ll0/FMjPYuorq9RBG+n/sj8/3oNG97+F+8d+uXzGluNpT7uz07+r4vIvxvpVhf3L1JO2y5da/uf6zebbt49qr1k3f6lfuIfgKowxpwbF+fRg6PeIgVw2ur+mI5er7vofIrSXLGav2cpB4R4P97TB4VHvbP2H7p8u2DcU70PC2HaxEdvv3NBgXs4azL92TUb+z5mIq4e6Dr+FtWO9v3MDzs8fFO1/HdtvebHxNzD52wT30kGx7/ZyuB8U6oiv7ayO2MuZi877lYP51/je1edQN6/oDMv+CeN+Fu5dnWH+T2VhrjV+rod7sxD3rbi2O7GdtM0xE2NqMcgYY9w6537InWD3l0Rix6cc1+qWxaHxkZBQXRoXIFuNC+HGLXfSQBJTt+quCxM1x1+1TLWdgRISY8vXU9uX2szrScYcLAax88H7vMNdpDGDfXy4SG6dkcZSOfa19Xc46bCpdhcbd4ruq26H3PaufinEa11c8w5+vwq75Oqf8tRhYBobPf+pmh4wS4L/P9fH08ZdatGz6FvMsLBUxlmmsx6LKzZ/5D9nnqhK6GWC2aYbGZey/NnnqYTCKjU/Hck/SYx9SaYN9rm2b0wf0heuucpkp52qo1B7pvtUJ/jcjrc/X9q+suTkOdW+oWMtA+NK9rWF2q99PmP5m1V+iamPoTAutF2WqaId0vx3TqU9w2Lt67NJSp6rsm9u+yWb8j5aqfn9c1VStv3SWDaUBn9OLmModfj0z6n2pWdrTv8cErvt2zqw85lr33E1v3y5om0cepZL5XDpXPKrBP8uf650pOuxdYgLtVU+vuIyrebbn5/Htm/p+eySnHJIa7ChtQnelrvmPLX9peQ3pz2n6kGf+8bLSi3sq/l5yJ40npb0YEvZ9uyT0DOZ+gJu45ixvFSupuzr8kti99d12Fdq/7bYeS1j3zcYcoSPtVKex1W3vxzIHmRPG67TUP+7XMl9HJ//x9i0zvZKYq+VSOsmKfbMyVvVtoyNU6n5eYnNr9RmeV2hukQ2W8r8TDvw1YdUnVI+ctb62mh7Ptv02DV77UkaF5OMK3/cOnxHLZxbdMy9svsRbH0qy82tszk6jImb/MTqW5/PsbC+cpHY+lbMTSm/y78W+51/LuPMtcesrjFt1fbTcU5aLs17JYm1cZ3YwteMXWvINjSG4OcdNVwD9pX3iARUov860BKaK0167vHwrnostQlJ6q4bKUjPUs20kuuLXqfUdWbGXDsSrFBFHzWXmLa9L42OQ3l1vdeYU/Pz0VfDMZUdR1eAx2WXPUe3c2o4FqF4pHS7Rq9LhHz4oLBkvzb2I0h1vO13o6F2XoWe+F63KqUOHeU+X+xrvH+oO30Jnn6KjqpOP1Wq0L9qOP1Q3rTw54Y0dnXNwQgaf/TVcOyhn8ErVTH+mmTQGo4+ttuI/RwmW6WWvy7x9YFN9Iv6uVp1HUjRKa8b9niDsMdqXI4yzLJjm6NNPJNCeLuvT93fUHW7KVv3ctPNDW/D16nK5o9L7HO7buqsA9QOaC2K91N11ksao+v2tdJwjJLnSTMsb672yueY1K6lPl5a/yGovfI2O5lQJpeUDR8at9Y9puU60nZqes+afvZKc0J7XUGyNT2n6+iPQutIMawCxxrXRercoS07cXgblvoYasszzF/d9cZeqyeX+p+Yd25abFu7ym73QXy9YKWH4wy676G9Xa60U/pnLjH9TqyUnVvz/kX7n3VAfqTrXU84aS+bdI3yq+Oj96G0H0HTxrdY0vgxJMeDE9j5hINY+9jrYan2TVl/ibmeGrf9rEwJp+XEiDKmSI5NKZw9PmlCOmEvXpHWrKVrKfHFhAutnUuulE5KvsqWo8r10pT8+MYUIZv57OsKVwVSOetIxzfWipHU+OrKb1k/deqzjXRzbBkjbZeh6fKGpE1bpKRfZ91NycdEzXn26d0eI5bVXxX6b0JCaTWh/6bsnKPvqm2T8+7BNS9wxRlaL3OFzy1DztxC8q8y4kqZj4WkyX6nifretD4k4fbJzVtuuerqQ0PlrcoOrniargex0lT7KVvWtvJQ1iaLoW+osr+14031S+u49r4w6b1HzLdVZeBr3LTGnqv72HBVlyH1eSrt12sSvedR+nbFha4XMWt6VP6c9wtcXO9bU3Gl4xo7SW2CI+1B5u8MUssfg/3e0n6Xyd8D6X0kKd9rUtnbfFdrQ+/gXHt66T2t3gug6/FJavividxxb2599dmb9kXUra/YNKT9D/wdOF2z90PHCE9nZUReqK5K4WP0b9uxah3y9Qz+PNH36P1ele2kx1yyg203Vzjq58htUnL0r+sar3t9JT83aY9+jPD4pW/i+b69MRN3Xd9J1iH2eObkksSuMfgkZk1Cuhfy60rH54/mjnWMr6V8jCu/zqR1o5Q07GtKybpuSuz6Z4+xfXPtKtKra+6UI4tl/aDMHFayX5m5cFNldkld6xJN2LjuOl13/DH60M9O+xts37cg5I/2aoXGa/Z5XZDoOcpALdxrpyW0dzRmLFH1mn3d7bPOdwuHSx6aTjOlnHzOQvsUm2gv9hzGtR/b9b13aF5vyyklaWIecKpq/1+u0n8B7T3PWve6f5PG7dIaW1tI9Ur69pvu0XffKiENab0hdu93Sjox2DZpOn3fPyV97ViHXW5QaqFOae862Sp3fU6aY1atA0orVqpMM9dm9nsW+78I2kb0v0xXf0vvAGLyKPkrq4uU8L72UXVdSEHr0Nf/EgPlHh+XraO5/19TnvOqbWmn5fJD43Bez+1vd3g/XeZ/qEr5+3xXuyPxvatSAX8pUke9Ten37feGVNfITlykfialDvH+PuXby7JlpTEG/1aL/glA5aUxlJ3XkJRt33WVnUT6D4Jd5pg5bC52nsv+F97VblPqOi9/z8pvqpS1f45Oq5QUXfN/eIWeiXZ7qiL9spDod6X6velpKvxPKrtsZfPP7TieEd7X5qWxot3OU/OfW86q+zG7DdN4iOYrVDY+XmhClqiF/yiQkP4hVjWTJh17PKL1pOdycxaubz7pesw4y1d+qV+287zcwdGJUDmXqYVrUUuU+3nkqvNN9Ee+/x7wtXe7TfN2bfcpbaw3cEkdF8bGXeZfjL771NfzPY0p4/jYehTyWwZXf8Olx1x+TGXl6zn0v+uYPUU5dSQmvHIc19kWff95V0oeP1alnxATauG/NmLaepvvUKsYq9Y1/q3z3U9b77FoTOmz25jjehNS5zwmVuy9Kql7MJran9DEHpWY+Jsq82Lc7yGJlEZb7amqcsfoM0X3dFz32oVUjqrjKBvnYmwXZeOosn3W1dar1FvZvPik7nTL5M2Xv6akyfqVk35V+c8NX1X6MemU1XPIbx35Tkm/jrhtSbGdJLn1wCX/A8o3qJ4=";
function gi(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = Lm(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function Lm(t, e) {
  if (t) {
    if (typeof t == "string") return Qs(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Qs(t, e);
  }
}
function Qs(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
function Mm(t, e) {
  t.prototype = Object.create(e.prototype), t.prototype.constructor = t, t.__proto__ = e;
}
function Um(t, e, r) {
  return e in t ? Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : t[e] = r, t;
}
var go = JSON.parse(String.fromCharCode.apply(String, Wt.inflate(Yt(ml)))), Nm = Wt.inflate(Yt(km)), Rm = go.categories, _s = go.decompositions, zm = new hi(Nm), jm = new yl(go), Z = /* @__PURE__ */ (function(t) {
  Mm(e, t);
  function e() {
    return t.apply(this, arguments) || this;
  }
  return e.planFeatures = function(n) {
    n.addStage(Gm), n.addStage(["locl", "ccmp", "nukt", "akhn"]), n.addStage(eu), n.addStage(["rphf"], !1), n.addStage(qm), n.addStage(eu), n.addStage(["pref"]), n.addStage(Hm), n.addStage(["rkrf", "abvf", "blwf", "half", "pstf", "vatu", "cjct"]), n.addStage(Wm), n.addStage(["abvs", "blws", "pres", "psts", "dist", "abvm", "blwm"]);
  }, e.assignFeatures = function(n, a) {
    for (var o = function(f) {
      var l = a[f].codePoints[0];
      if (_s[l]) {
        var c = _s[l].map(function(p) {
          var y = n.font.glyphForCodePoint(p);
          return new At(n.font, y.id, [p], a[f].features);
        });
        a.splice.apply(a, [f, 1].concat(c));
      }
    }, s = a.length - 1; s >= 0; s--)
      o(s);
  }, e;
})(Ht);
Um(Z, "zeroMarkWidths", "BEFORE_GPOS");
function $s(t) {
  return zm.get(t.codePoints[0]);
}
var Vm = function(e, r, n) {
  this.category = e, this.syllableType = r, this.syllable = n;
};
function Gm(t, e) {
  for (var r = 0, n = gi(jm.match(e.map($s))), a; !(a = n()).done; ) {
    var o = a.value, s = o[0], u = o[1], f = o[2];
    ++r;
    for (var l = s; l <= u; l++)
      e[l].shaperInfo = new Vm(Rm[$s(e[l])], f[0], r);
    for (var c = e[s].shaperInfo.category === "R" ? 1 : Math.min(3, u - s), p = s; p < s + c; p++)
      e[p].features.rphf = !0;
  }
}
function eu(t, e) {
  for (var r = gi(e), n; !(n = r()).done; ) {
    var a = n.value;
    a.substituted = !1;
  }
}
function qm(t, e) {
  for (var r = gi(e), n; !(n = r()).done; ) {
    var a = n.value;
    a.substituted && a.features.rphf && (a.shaperInfo.category = "R");
  }
}
function Hm(t, e) {
  for (var r = gi(e), n; !(n = r()).done; ) {
    var a = n.value;
    a.substituted && (a.shaperInfo.category = "VPre");
  }
}
function Wm(t, e) {
  for (var r = t.glyphForCodePoint(9676).id, n = 0, a = tu(e, 0); n < e.length; n = a, a = tu(e, n)) {
    var o = void 0, s = void 0, u = e[n].shaperInfo, f = u.syllableType;
    if (!(f !== "virama_terminated_cluster" && f !== "standard_cluster" && f !== "broken_cluster")) {
      if (f === "broken_cluster" && r) {
        var l = new At(t, r, [9676]);
        for (l.shaperInfo = u, o = n; o < a && e[o].shaperInfo.category === "R"; o++)
          ;
        e.splice(++o, 0, l), a++;
      }
      if (u.category === "R" && a - n > 1) {
        for (o = n + 1; o < a; o++)
          if (u = e[o].shaperInfo, ru(u) || Tn(e[o])) {
            Tn(e[o]) && o--, e.splice.apply(e, [n, 0].concat(e.splice(n + 1, o - n), [e[o]]));
            break;
          }
      }
      for (o = n, s = a; o < a; o++)
        u = e[o].shaperInfo, ru(u) || Tn(e[o]) ? s = Tn(e[o]) ? o + 1 : o : (u.category === "VPre" || u.category === "VMPre") && s < o && e.splice.apply(e, [s, 1, e[o]].concat(e.splice(s, o - s)));
    }
  }
}
function tu(t, e) {
  if (e >= t.length) return e;
  for (var r = t[e].shaperInfo.syllable; ++e < t.length && t[e].shaperInfo.syllable === r; )
    ;
  return e;
}
function Tn(t) {
  return t.shaperInfo.category === "H" && !t.isLigated;
}
function ru(t) {
  return t.category === "B" || t.category === "GB";
}
function Xm(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = Ym(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function Ym(t, e) {
  if (t) {
    if (typeof t == "string") return nu(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return nu(t, e);
  }
}
function nu(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
var Km = {
  arab: Bt,
  // Arabic
  mong: Bt,
  // Mongolian
  syrc: Bt,
  // Syriac
  "nko ": Bt,
  // N'Ko
  phag: Bt,
  // Phags Pa
  mand: Bt,
  // Mandaic
  mani: Bt,
  // Manichaean
  phlp: Bt,
  // Psalter Pahlavi
  hang: hl,
  // Hangul
  bng2: Te,
  // Bengali
  beng: Te,
  // Bengali
  dev2: Te,
  // Devanagari
  deva: Te,
  // Devanagari
  gjr2: Te,
  // Gujarati
  gujr: Te,
  // Gujarati
  guru: Te,
  // Gurmukhi
  gur2: Te,
  // Gurmukhi
  knda: Te,
  // Kannada
  knd2: Te,
  // Kannada
  mlm2: Te,
  // Malayalam
  mlym: Te,
  // Malayalam
  ory2: Te,
  // Oriya
  orya: Te,
  // Oriya
  taml: Te,
  // Tamil
  tml2: Te,
  // Tamil
  telu: Te,
  // Telugu
  tel2: Te,
  // Telugu
  khmr: Te,
  // Khmer
  bali: Z,
  // Balinese
  batk: Z,
  // Batak
  brah: Z,
  // Brahmi
  bugi: Z,
  // Buginese
  buhd: Z,
  // Buhid
  cakm: Z,
  // Chakma
  cham: Z,
  // Cham
  dupl: Z,
  // Duployan
  egyp: Z,
  // Egyptian Hieroglyphs
  gran: Z,
  // Grantha
  hano: Z,
  // Hanunoo
  java: Z,
  // Javanese
  kthi: Z,
  // Kaithi
  kali: Z,
  // Kayah Li
  khar: Z,
  // Kharoshthi
  khoj: Z,
  // Khojki
  sind: Z,
  // Khudawadi
  lepc: Z,
  // Lepcha
  limb: Z,
  // Limbu
  mahj: Z,
  // Mahajani
  // mand: UniversalShaper, // Mandaic
  // mani: UniversalShaper, // Manichaean
  mtei: Z,
  // Meitei Mayek
  modi: Z,
  // Modi
  // mong: UniversalShaper, // Mongolian
  // 'nko ': UniversalShaper, // N’Ko
  hmng: Z,
  // Pahawh Hmong
  // phag: UniversalShaper, // Phags-pa
  // phlp: UniversalShaper, // Psalter Pahlavi
  rjng: Z,
  // Rejang
  saur: Z,
  // Saurashtra
  shrd: Z,
  // Sharada
  sidd: Z,
  // Siddham
  sinh: Z,
  // Sinhala
  sund: Z,
  // Sundanese
  sylo: Z,
  // Syloti Nagri
  tglg: Z,
  // Tagalog
  tagb: Z,
  // Tagbanwa
  tale: Z,
  // Tai Le
  lana: Z,
  // Tai Tham
  tavt: Z,
  // Tai Viet
  takr: Z,
  // Takri
  tibt: Z,
  // Tibetan
  tfng: Z,
  // Tifinagh
  tirh: Z,
  // Tirhuta
  latn: Ht,
  // Latin
  DFLT: Ht
  // Default
};
function Zm(t) {
  Array.isArray(t) || (t = [t]);
  for (var e = Xm(t), r; !(r = e()).done; ) {
    var n = r.value, a = Km[n];
    if (a)
      return a;
  }
  return Ht;
}
function ea(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = Jm(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function Jm(t, e) {
  if (t) {
    if (typeof t == "string") return iu(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return iu(t, e);
  }
}
function iu(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
function Qm(t, e) {
  t.prototype = Object.create(e.prototype), t.prototype.constructor = t, t.__proto__ = e;
}
var _m = /* @__PURE__ */ (function(t) {
  Qm(e, t);
  function e() {
    return t.apply(this, arguments) || this;
  }
  var r = e.prototype;
  return r.applyLookup = function(a, o) {
    var s = this;
    switch (a) {
      case 1: {
        var u = this.coverageIndex(o.coverage);
        if (u === -1)
          return !1;
        var f = this.glyphIterator.cur;
        switch (o.version) {
          case 1:
            f.id = f.id + o.deltaGlyphID & 65535;
            break;
          case 2:
            f.id = o.substitute.get(u);
            break;
        }
        return !0;
      }
      case 2: {
        var l = this.coverageIndex(o.coverage);
        if (l !== -1) {
          var c, p = o.sequences.get(l);
          this.glyphIterator.cur.id = p[0], this.glyphIterator.cur.ligatureComponent = 0;
          var y = this.glyphIterator.cur.features, v = this.glyphIterator.cur, m = p.slice(1).map(function(Le, ke) {
            var ye = new At(s.font, Le, void 0, y);
            return ye.shaperInfo = v.shaperInfo, ye.isLigated = v.isLigated, ye.ligatureComponent = ke + 1, ye.substituted = !0, ye.isMultiplied = !0, ye;
          });
          return (c = this.glyphs).splice.apply(c, [this.glyphIterator.index + 1, 0].concat(m)), !0;
        }
        return !1;
      }
      case 3: {
        var w = this.coverageIndex(o.coverage);
        if (w !== -1) {
          var F = 0;
          return this.glyphIterator.cur.id = o.alternateSet.get(w)[F], !0;
        }
        return !1;
      }
      case 4: {
        var S = this.coverageIndex(o.coverage);
        if (S === -1)
          return !1;
        for (var I = ea(o.ligatureSets.get(S)), A; !(A = I()).done; ) {
          var M = A.value, L = this.sequenceMatchIndices(1, M.components);
          if (L) {
            for (var P = this.glyphIterator.cur, G = P.codePoints.slice(), W = ea(L), ne; !(ne = W()).done; ) {
              var q = ne.value;
              G.push.apply(G, this.glyphs[q].codePoints);
            }
            var N = new At(this.font, M.glyph, G, P.features);
            N.shaperInfo = P.shaperInfo, N.isLigated = !0, N.substituted = !0;
            for (var Q = P.isMark, te = 0; te < L.length && Q; te++)
              Q = this.glyphs[L[te]].isMark;
            N.ligatureID = Q ? null : this.ligatureID++;
            for (var ce = P.ligatureID, j = P.codePoints.length, le = j, K = this.glyphIterator.index + 1, re = ea(L), de; !(de = re()).done; ) {
              var X = de.value;
              if (Q)
                K = X;
              else
                for (; K < X; ) {
                  var ae = le - j + Math.min(this.glyphs[K].ligatureComponent || 1, j);
                  this.glyphs[K].ligatureID = N.ligatureID, this.glyphs[K].ligatureComponent = ae, K++;
                }
              ce = this.glyphs[K].ligatureID, j = this.glyphs[K].codePoints.length, le += j, K++;
            }
            if (ce && !Q)
              for (var we = K; we < this.glyphs.length && this.glyphs[we].ligatureID === ce; we++) {
                var ae = le - j + Math.min(this.glyphs[we].ligatureComponent || 1, j);
                this.glyphs[we].ligatureComponent = ae;
              }
            for (var Ee = L.length - 1; Ee >= 0; Ee--)
              this.glyphs.splice(L[Ee], 1);
            return this.glyphs[this.glyphIterator.index] = N, !0;
          }
        }
        return !1;
      }
      case 5:
        return this.applyContext(o);
      case 6:
        return this.applyChainingContext(o);
      case 7:
        return this.applyLookup(o.lookupType, o.extension);
      default:
        throw new Error("GSUB lookupType " + a + " is not supported");
    }
  }, e;
})(Wn);
function $m(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = eb(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function eb(t, e) {
  if (t) {
    if (typeof t == "string") return au(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return au(t, e);
  }
}
function au(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
function tb(t, e) {
  t.prototype = Object.create(e.prototype), t.prototype.constructor = t, t.__proto__ = e;
}
var rb = /* @__PURE__ */ (function(t) {
  tb(e, t);
  function e() {
    return t.apply(this, arguments) || this;
  }
  var r = e.prototype;
  return r.applyPositionValue = function(a, o) {
    var s = this.positions[this.glyphIterator.peekIndex(a)];
    o.xAdvance != null && (s.xAdvance += o.xAdvance), o.yAdvance != null && (s.yAdvance += o.yAdvance), o.xPlacement != null && (s.xOffset += o.xPlacement), o.yPlacement != null && (s.yOffset += o.yPlacement);
    var u = this.font._variationProcessor, f = this.font.GDEF && this.font.GDEF.itemVariationStore;
    u && f && (o.xPlaDevice && (s.xOffset += u.getDelta(f, o.xPlaDevice.a, o.xPlaDevice.b)), o.yPlaDevice && (s.yOffset += u.getDelta(f, o.yPlaDevice.a, o.yPlaDevice.b)), o.xAdvDevice && (s.xAdvance += u.getDelta(f, o.xAdvDevice.a, o.xAdvDevice.b)), o.yAdvDevice && (s.yAdvance += u.getDelta(f, o.yAdvDevice.a, o.yAdvDevice.b)));
  }, r.applyLookup = function(a, o) {
    switch (a) {
      case 1: {
        var s = this.coverageIndex(o.coverage);
        if (s === -1)
          return !1;
        switch (o.version) {
          case 1:
            this.applyPositionValue(0, o.value);
            break;
          case 2:
            this.applyPositionValue(0, o.values.get(s));
            break;
        }
        return !0;
      }
      case 2: {
        var u = this.glyphIterator.peek();
        if (!u)
          return !1;
        var f = this.coverageIndex(o.coverage);
        if (f === -1)
          return !1;
        switch (o.version) {
          case 1:
            for (var l = o.pairSets.get(f), c = $m(l), p; !(p = c()).done; ) {
              var y = p.value;
              if (y.secondGlyph === u.id)
                return this.applyPositionValue(0, y.value1), this.applyPositionValue(1, y.value2), !0;
            }
            return !1;
          case 2:
            var v = this.getClassID(this.glyphIterator.cur.id, o.classDef1), m = this.getClassID(u.id, o.classDef2);
            if (v === -1 || m === -1)
              return !1;
            var w = o.classRecords.get(v).get(m);
            return this.applyPositionValue(0, w.value1), this.applyPositionValue(1, w.value2), !0;
        }
      }
      case 3: {
        var F = this.glyphIterator.peekIndex(), S = this.glyphs[F];
        if (!S)
          return !1;
        var I = o.entryExitRecords[this.coverageIndex(o.coverage)];
        if (!I || !I.exitAnchor)
          return !1;
        var A = o.entryExitRecords[this.coverageIndex(o.coverage, S.id)];
        if (!A || !A.entryAnchor)
          return !1;
        var M = this.getAnchor(A.entryAnchor), L = this.getAnchor(I.exitAnchor), P = this.positions[this.glyphIterator.index], G = this.positions[F];
        switch (this.direction) {
          case "ltr":
            P.xAdvance = L.x + P.xOffset;
            var W = M.x + G.xOffset;
            G.xAdvance -= W, G.xOffset -= W;
            break;
          case "rtl":
            W = L.x + P.xOffset, P.xAdvance -= W, P.xOffset -= W, G.xAdvance = M.x + G.xOffset;
            break;
        }
        return this.glyphIterator.flags.rightToLeft ? (this.glyphIterator.cur.cursiveAttachment = F, P.yOffset = M.y - L.y) : (S.cursiveAttachment = this.glyphIterator.index, P.yOffset = L.y - M.y), !0;
      }
      case 4: {
        var ne = this.coverageIndex(o.markCoverage);
        if (ne === -1)
          return !1;
        for (var q = this.glyphIterator.index; --q >= 0 && (this.glyphs[q].isMark || this.glyphs[q].ligatureComponent > 0); )
          ;
        if (q < 0)
          return !1;
        var N = this.coverageIndex(o.baseCoverage, this.glyphs[q].id);
        if (N === -1)
          return !1;
        var Q = o.markArray[ne], te = o.baseArray[N][Q.class];
        return this.applyAnchor(Q, te, q), !0;
      }
      case 5: {
        var ce = this.coverageIndex(o.markCoverage);
        if (ce === -1)
          return !1;
        for (var j = this.glyphIterator.index; --j >= 0 && this.glyphs[j].isMark; )
          ;
        if (j < 0)
          return !1;
        var le = this.coverageIndex(o.ligatureCoverage, this.glyphs[j].id);
        if (le === -1)
          return !1;
        var K = o.ligatureArray[le], re = this.glyphIterator.cur, de = this.glyphs[j], X = de.ligatureID && de.ligatureID === re.ligatureID && re.ligatureComponent > 0 ? Math.min(re.ligatureComponent, de.codePoints.length) - 1 : de.codePoints.length - 1, ae = o.markArray[ce], we = K[X][ae.class];
        return this.applyAnchor(ae, we, j), !0;
      }
      case 6: {
        var Ee = this.coverageIndex(o.mark1Coverage);
        if (Ee === -1)
          return !1;
        var Le = this.glyphIterator.peekIndex(-1), ke = this.glyphs[Le];
        if (!ke || !ke.isMark)
          return !1;
        var ye = this.glyphIterator.cur, Oe = !1;
        if (ye.ligatureID === ke.ligatureID ? ye.ligatureID ? ye.ligatureComponent === ke.ligatureComponent && (Oe = !0) : Oe = !0 : (ye.ligatureID && !ye.ligatureComponent || ke.ligatureID && !ke.ligatureComponent) && (Oe = !0), !Oe)
          return !1;
        var Ce = this.coverageIndex(o.mark2Coverage, ke.id);
        if (Ce === -1)
          return !1;
        var _ = o.mark1Array[Ee], V = o.mark2Array[Ce][_.class];
        return this.applyAnchor(_, V, Le), !0;
      }
      case 7:
        return this.applyContext(o);
      case 8:
        return this.applyChainingContext(o);
      case 9:
        return this.applyLookup(o.lookupType, o.extension);
      default:
        throw new Error("Unsupported GPOS table: " + a);
    }
  }, r.applyAnchor = function(a, o, s) {
    var u = this.getAnchor(o), f = this.getAnchor(a.markAnchor);
    this.positions[s];
    var l = this.positions[this.glyphIterator.index];
    l.xOffset = u.x - f.x, l.yOffset = u.y - f.y, this.glyphIterator.cur.markAttachment = s;
  }, r.getAnchor = function(a) {
    var o = a.xCoordinate, s = a.yCoordinate, u = this.font._variationProcessor, f = this.font.GDEF && this.font.GDEF.itemVariationStore;
    return u && f && (a.xDeviceTable && (o += u.getDelta(f, a.xDeviceTable.a, a.xDeviceTable.b)), a.yDeviceTable && (s += u.getDelta(f, a.yDeviceTable.a, a.yDeviceTable.b))), {
      x: o,
      y: s
    };
  }, r.applyFeatures = function(a, o, s) {
    t.prototype.applyFeatures.call(this, a, o, s);
    for (var u = 0; u < this.glyphs.length; u++)
      this.fixCursiveAttachment(u);
    this.fixMarkAttachment();
  }, r.fixCursiveAttachment = function(a) {
    var o = this.glyphs[a];
    if (o.cursiveAttachment != null) {
      var s = o.cursiveAttachment;
      o.cursiveAttachment = null, this.fixCursiveAttachment(s), this.positions[a].yOffset += this.positions[s].yOffset;
    }
  }, r.fixMarkAttachment = function() {
    for (var a = 0; a < this.glyphs.length; a++) {
      var o = this.glyphs[a];
      if (o.markAttachment != null) {
        var s = o.markAttachment;
        if (this.positions[a].xOffset += this.positions[s].xOffset, this.positions[a].yOffset += this.positions[s].yOffset, this.direction === "ltr")
          for (var u = s; u < a; u++)
            this.positions[a].xOffset -= this.positions[u].xAdvance, this.positions[a].yOffset -= this.positions[u].yAdvance;
        else
          for (var f = s + 1; f < a + 1; f++)
            this.positions[a].xOffset += this.positions[f].xAdvance, this.positions[a].yOffset += this.positions[f].yAdvance;
      }
    }
  }, e;
})(Wn), nb = /* @__PURE__ */ (function() {
  function t(r) {
    this.font = r, this.glyphInfos = null, this.plan = null, this.GSUBProcessor = null, this.GPOSProcessor = null, this.fallbackPosition = !0, r.GSUB && (this.GSUBProcessor = new _m(r, r.GSUB)), r.GPOS && (this.GPOSProcessor = new rb(r, r.GPOS));
  }
  var e = t.prototype;
  return e.setup = function(n) {
    var a = this;
    this.glyphInfos = n.glyphs.map(function(u) {
      return new At(a.font, u.id, [].concat(u.codePoints));
    });
    var o = null;
    this.GPOSProcessor && (o = this.GPOSProcessor.selectScript(n.script, n.language, n.direction)), this.GSUBProcessor && (o = this.GSUBProcessor.selectScript(n.script, n.language, n.direction)), this.shaper = Zm(o), this.plan = new Ag(this.font, o, n.direction), this.shaper.plan(this.plan, this.glyphInfos, n.features);
    for (var s in this.plan.allFeatures)
      n.features[s] = !0;
  }, e.substitute = function(n) {
    var a = this;
    this.GSUBProcessor && (this.plan.process(this.GSUBProcessor, this.glyphInfos), n.glyphs = this.glyphInfos.map(function(o) {
      return a.font.getGlyph(o.id, o.codePoints);
    }));
  }, e.position = function(n) {
    return this.shaper.zeroMarkWidths === "BEFORE_GPOS" && this.zeroMarkAdvances(n.positions), this.GPOSProcessor && this.plan.process(this.GPOSProcessor, this.glyphInfos, n.positions), this.shaper.zeroMarkWidths === "AFTER_GPOS" && this.zeroMarkAdvances(n.positions), n.direction === "rtl" && (n.glyphs.reverse(), n.positions.reverse()), this.GPOSProcessor && this.GPOSProcessor.features;
  }, e.zeroMarkAdvances = function(n) {
    for (var a = 0; a < this.glyphInfos.length; a++)
      this.glyphInfos[a].isMark && (n[a].xAdvance = 0, n[a].yAdvance = 0);
  }, e.cleanup = function() {
    this.glyphInfos = null, this.plan = null, this.shaper = null;
  }, e.getAvailableFeatures = function(n, a) {
    var o = [];
    return this.GSUBProcessor && (this.GSUBProcessor.selectScript(n, a), o.push.apply(o, Object.keys(this.GSUBProcessor.features))), this.GPOSProcessor && (this.GPOSProcessor.selectScript(n, a), o.push.apply(o, Object.keys(this.GPOSProcessor.features))), o;
  }, t;
})();
function ta(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = ib(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function ib(t, e) {
  if (t) {
    if (typeof t == "string") return ou(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return ou(t, e);
  }
}
function ou(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
var ab = /* @__PURE__ */ (function() {
  function t(r) {
    this.font = r, this.unicodeLayoutEngine = null, this.kernProcessor = null, this.font.morx ? this.engine = new xg(this.font) : (this.font.GSUB || this.font.GPOS) && (this.engine = new nb(this.font));
  }
  var e = t.prototype;
  return e.layout = function(n, a, o, s, u) {
    if (typeof a == "string" && (u = s, s = o, o = a, a = []), typeof n == "string") {
      o == null && (o = Gy(n));
      var f = this.font.glyphsForString(n);
    } else {
      if (o == null) {
        for (var l = [], c = ta(n), p; !(p = c()).done; ) {
          var y = p.value;
          l.push.apply(l, y.codePoints);
        }
        o = qy(l);
      }
      var f = n;
    }
    var v = new Ky(f, a, o, s, u);
    return f.length === 0 ? (v.positions = [], v) : (this.engine && this.engine.setup && this.engine.setup(v), this.substitute(v), this.position(v), this.hideDefaultIgnorables(v.glyphs, v.positions), this.engine && this.engine.cleanup && this.engine.cleanup(), v);
  }, e.substitute = function(n) {
    this.engine && this.engine.substitute && this.engine.substitute(n);
  }, e.position = function(n) {
    n.positions = n.glyphs.map(function(o) {
      return new Zy(o.advanceWidth);
    });
    var a = null;
    this.engine && this.engine.position && (a = this.engine.position(n)), !a && (!this.engine || this.engine.fallbackPosition) && (this.unicodeLayoutEngine || (this.unicodeLayoutEngine = new Ly(this.font)), this.unicodeLayoutEngine.positionGlyphs(n.glyphs, n.positions)), (!a || !a.kern) && n.features.kern !== !1 && this.font.kern && (this.kernProcessor || (this.kernProcessor = new _v(this.font)), this.kernProcessor.process(n.glyphs, n.positions), n.features.kern = !0);
  }, e.hideDefaultIgnorables = function(n, a) {
    for (var o = this.font.glyphForCodePoint(32), s = 0; s < n.length; s++)
      this.isDefaultIgnorable(n[s].codePoints[0]) && (n[s] = o, a[s].xAdvance = 0, a[s].yAdvance = 0);
  }, e.isDefaultIgnorable = function(n) {
    var a = n >> 16;
    if (a === 0)
      switch (n >> 8) {
        case 0:
          return n === 173;
        case 3:
          return n === 847;
        case 6:
          return n === 1564;
        case 23:
          return 6068 <= n && n <= 6069;
        case 24:
          return 6155 <= n && n <= 6158;
        case 32:
          return 8203 <= n && n <= 8207 || 8234 <= n && n <= 8238 || 8288 <= n && n <= 8303;
        case 254:
          return 65024 <= n && n <= 65039 || n === 65279;
        case 255:
          return 65520 <= n && n <= 65528;
        default:
          return !1;
      }
    else
      switch (a) {
        case 1:
          return 113824 <= n && n <= 113827 || 119155 <= n && n <= 119162;
        case 14:
          return 917504 <= n && n <= 921599;
        default:
          return !1;
      }
  }, e.getAvailableFeatures = function(n, a) {
    var o = [];
    return this.engine && o.push.apply(o, this.engine.getAvailableFeatures(n, a)), this.font.kern && o.indexOf("kern") === -1 && o.push("kern"), o;
  }, e.stringsForGlyph = function(n) {
    for (var a = /* @__PURE__ */ new Set(), o = this.font._cmapProcessor.codePointsForGlyph(n), s = ta(o), u; !(u = s()).done; ) {
      var f = u.value;
      a.add(String.fromCodePoint(f));
    }
    if (this.engine && this.engine.stringsForGlyph)
      for (var l = ta(this.engine.stringsForGlyph(n)), c; !(c = l()).done; ) {
        var p = c.value;
        a.add(p);
      }
    return Array.from(a);
  }, t;
})();
function ra(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = ob(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function ob(t, e) {
  if (t) {
    if (typeof t == "string") return su(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return su(t, e);
  }
}
function su(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
function sb(t, e) {
  for (var r = 0; r < e.length; r++) {
    var n = e[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(t, n.key, n);
  }
}
function ub(t, e, r) {
  return e && sb(t.prototype, e), t;
}
var fb = {
  moveTo: "M",
  lineTo: "L",
  quadraticCurveTo: "Q",
  bezierCurveTo: "C",
  closePath: "Z"
}, mi = /* @__PURE__ */ (function() {
  function t() {
    this.commands = [], this._bbox = null, this._cbox = null;
  }
  var e = t.prototype;
  return e.toFunction = function() {
    var n = this;
    return function(a) {
      return n.commands.forEach(function(o) {
        return a[o.command].apply(a, o.args);
      });
    };
  }, e.toSVG = function() {
    var n = this.commands.map(function(a) {
      var o = a.args.map(function(s) {
        return Math.round(s * 100) / 100;
      });
      return "" + fb[a.command] + o.join(" ");
    });
    return n.join("");
  }, e.mapPoints = function(n) {
    for (var a = new t(), o = ra(this.commands), s; !(s = o()).done; ) {
      for (var u = s.value, f = [], l = 0; l < u.args.length; l += 2) {
        var c = n(u.args[l], u.args[l + 1]), p = c[0], y = c[1];
        f.push(p, y);
      }
      a[u.command].apply(a, f);
    }
    return a;
  }, e.transform = function(n, a, o, s, u, f) {
    return this.mapPoints(function(l, c) {
      return l = n * l + o * c + u, c = a * l + s * c + f, [l, c];
    });
  }, e.translate = function(n, a) {
    return this.transform(1, 0, 0, 1, n, a);
  }, e.rotate = function(n) {
    var a = Math.cos(n), o = Math.sin(n);
    return this.transform(a, o, -o, a, 0, 0);
  }, e.scale = function(n, a) {
    return a === void 0 && (a = n), this.transform(n, 0, 0, a, 0, 0);
  }, ub(t, [{
    key: "cbox",
    get: function() {
      if (!this._cbox) {
        for (var n = new zr(), a = ra(this.commands), o; !(o = a()).done; )
          for (var s = o.value, u = 0; u < s.args.length; u += 2)
            n.addPoint(s.args[u], s.args[u + 1]);
        this._cbox = Object.freeze(n);
      }
      return this._cbox;
    }
    /**
     * Gets the exact bounding box of the path by evaluating curve segments.
     * Slower to compute than the control box, but more accurate.
     * @type {BBox}
     */
  }, {
    key: "bbox",
    get: function() {
      if (this._bbox)
        return this._bbox;
      for (var n = new zr(), a = 0, o = 0, s = function(de) {
        return Math.pow(1 - de, 3) * G[N] + 3 * Math.pow(1 - de, 2) * de * W[N] + 3 * (1 - de) * Math.pow(de, 2) * ne[N] + Math.pow(de, 3) * q[N];
      }, u = ra(this.commands), f; !(f = u()).done; ) {
        var l = f.value;
        switch (l.command) {
          case "moveTo":
          case "lineTo":
            var c = l.args, p = c[0], y = c[1];
            n.addPoint(p, y), a = p, o = y;
            break;
          case "quadraticCurveTo":
          case "bezierCurveTo":
            if (l.command === "quadraticCurveTo")
              var v = l.args, m = v[0], w = v[1], F = v[2], S = v[3], I = a + 2 / 3 * (m - a), A = o + 2 / 3 * (w - o), M = F + 2 / 3 * (m - F), L = S + 2 / 3 * (w - S);
            else
              var P = l.args, I = P[0], A = P[1], M = P[2], L = P[3], F = P[4], S = P[5];
            n.addPoint(F, S);
            for (var G = [a, o], W = [I, A], ne = [M, L], q = [F, S], N = 0; N <= 1; N++) {
              var Q = 6 * G[N] - 12 * W[N] + 6 * ne[N], te = -3 * G[N] + 9 * W[N] - 9 * ne[N] + 3 * q[N];
              if (l = 3 * W[N] - 3 * G[N], te === 0) {
                if (Q === 0)
                  continue;
                var ce = -l / Q;
                0 < ce && ce < 1 && (N === 0 ? n.addPoint(s(ce), n.maxY) : N === 1 && n.addPoint(n.maxX, s(ce)));
                continue;
              }
              var j = Math.pow(Q, 2) - 4 * l * te;
              if (!(j < 0)) {
                var le = (-Q + Math.sqrt(j)) / (2 * te);
                0 < le && le < 1 && (N === 0 ? n.addPoint(s(le), n.maxY) : N === 1 && n.addPoint(n.maxX, s(le)));
                var K = (-Q - Math.sqrt(j)) / (2 * te);
                0 < K && K < 1 && (N === 0 ? n.addPoint(s(K), n.maxY) : N === 1 && n.addPoint(n.maxX, s(K)));
              }
            }
            a = F, o = S;
            break;
        }
      }
      return this._bbox = Object.freeze(n);
    }
  }]), t;
})(), lb = function() {
  var e = xl[Ea];
  mi.prototype[e] = function() {
    this._bbox = this._cbox = null;
    for (var r = arguments.length, n = new Array(r), a = 0; a < r; a++)
      n[a] = arguments[a];
    return this.commands.push({
      command: e,
      args: n
    }), this;
  };
};
for (var Ea = 0, xl = ["moveTo", "lineTo", "quadraticCurveTo", "bezierCurveTo", "closePath"]; Ea < xl.length; Ea++)
  lb();
var Jr = [".notdef", ".null", "nonmarkingreturn", "space", "exclam", "quotedbl", "numbersign", "dollar", "percent", "ampersand", "quotesingle", "parenleft", "parenright", "asterisk", "plus", "comma", "hyphen", "period", "slash", "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "colon", "semicolon", "less", "equal", "greater", "question", "at", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "bracketleft", "backslash", "bracketright", "asciicircum", "underscore", "grave", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "braceleft", "bar", "braceright", "asciitilde", "Adieresis", "Aring", "Ccedilla", "Eacute", "Ntilde", "Odieresis", "Udieresis", "aacute", "agrave", "acircumflex", "adieresis", "atilde", "aring", "ccedilla", "eacute", "egrave", "ecircumflex", "edieresis", "iacute", "igrave", "icircumflex", "idieresis", "ntilde", "oacute", "ograve", "ocircumflex", "odieresis", "otilde", "uacute", "ugrave", "ucircumflex", "udieresis", "dagger", "degree", "cent", "sterling", "section", "bullet", "paragraph", "germandbls", "registered", "copyright", "trademark", "acute", "dieresis", "notequal", "AE", "Oslash", "infinity", "plusminus", "lessequal", "greaterequal", "yen", "mu", "partialdiff", "summation", "product", "pi", "integral", "ordfeminine", "ordmasculine", "Omega", "ae", "oslash", "questiondown", "exclamdown", "logicalnot", "radical", "florin", "approxequal", "Delta", "guillemotleft", "guillemotright", "ellipsis", "nonbreakingspace", "Agrave", "Atilde", "Otilde", "OE", "oe", "endash", "emdash", "quotedblleft", "quotedblright", "quoteleft", "quoteright", "divide", "lozenge", "ydieresis", "Ydieresis", "fraction", "currency", "guilsinglleft", "guilsinglright", "fi", "fl", "daggerdbl", "periodcentered", "quotesinglbase", "quotedblbase", "perthousand", "Acircumflex", "Ecircumflex", "Aacute", "Edieresis", "Egrave", "Iacute", "Icircumflex", "Idieresis", "Igrave", "Oacute", "Ocircumflex", "apple", "Ograve", "Uacute", "Ucircumflex", "Ugrave", "dotlessi", "circumflex", "tilde", "macron", "breve", "dotaccent", "ring", "cedilla", "hungarumlaut", "ogonek", "caron", "Lslash", "lslash", "Scaron", "scaron", "Zcaron", "zcaron", "brokenbar", "Eth", "eth", "Yacute", "yacute", "Thorn", "thorn", "minus", "multiply", "onesuperior", "twosuperior", "threesuperior", "onehalf", "onequarter", "threequarters", "franc", "Gbreve", "gbreve", "Idotaccent", "Scedilla", "scedilla", "Cacute", "cacute", "Ccaron", "ccaron", "dcroat"], De;
function cb(t, e) {
  for (var r = 0; r < e.length; r++) {
    var n = e[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(t, n.key, n);
  }
}
function hb(t, e, r) {
  return e && cb(t.prototype, e), t;
}
function xr(t, e, r, n, a) {
  var o = {};
  return Object.keys(n).forEach(function(s) {
    o[s] = n[s];
  }), o.enumerable = !!o.enumerable, o.configurable = !!o.configurable, ("value" in o || o.initializer) && (o.writable = !0), o = r.slice().reverse().reduce(function(s, u) {
    return u(t, e, s) || s;
  }, o), a && o.initializer !== void 0 && (o.value = o.initializer ? o.initializer.call(a) : void 0, o.initializer = void 0), o.initializer === void 0 && (Object.defineProperty(t, e, o), o = null), o;
}
var Qn = (De = /* @__PURE__ */ (function() {
  function t(r, n, a) {
    this.id = r, this.codePoints = n, this._font = a, this.isMark = this.codePoints.length > 0 && this.codePoints.every(St.isMark), this.isLigature = this.codePoints.length > 1;
  }
  var e = t.prototype;
  return e._getPath = function() {
    return new mi();
  }, e._getCBox = function() {
    return this.path.cbox;
  }, e._getBBox = function() {
    return this.path.bbox;
  }, e._getTableMetrics = function(n) {
    if (this.id < n.metrics.length)
      return n.metrics.get(this.id);
    var a = n.metrics.get(n.metrics.length - 1), o = {
      advance: a ? a.advance : 0,
      bearing: n.bearings.get(this.id - n.metrics.length) || 0
    };
    return o;
  }, e._getMetrics = function(n) {
    if (this._metrics)
      return this._metrics;
    var a = this._getTableMetrics(this._font.hmtx), o = a.advance, s = a.bearing;
    if (this._font.vmtx)
      var u = this._getTableMetrics(this._font.vmtx), f = u.advance, l = u.bearing;
    else {
      var c;
      if ((typeof n > "u" || n === null) && (n = this.cbox), (c = this._font["OS/2"]) && c.version > 0)
        var f = Math.abs(c.typoAscender - c.typoDescender), l = c.typoAscender - n.maxY;
      else
        var p = this._font.hhea, f = Math.abs(p.ascent - p.descent), l = p.ascent - n.maxY;
    }
    return this._font._variationProcessor && this._font.HVAR && (o += this._font._variationProcessor.getAdvanceAdjustment(this.id, this._font.HVAR)), this._metrics = {
      advanceWidth: o,
      advanceHeight: f,
      leftBearing: s,
      topBearing: l
    };
  }, e.getScaledPath = function(n) {
    var a = 1 / this._font.unitsPerEm * n;
    return this.path.scale(a);
  }, e._getName = function() {
    var n = this._font.post;
    if (!n)
      return null;
    switch (n.version) {
      case 1:
        return Jr[this.id];
      case 2:
        var a = n.glyphNameIndex[this.id];
        return a < Jr.length ? Jr[a] : n.names[a - Jr.length];
      case 2.5:
        return Jr[this.id + n.offsets[this.id]];
      case 4:
        return String.fromCharCode(n.map[this.id]);
    }
  }, e.render = function(n, a) {
    n.save();
    var o = 1 / this._font.head.unitsPerEm * a;
    n.scale(o, o);
    var s = this.path.toFunction();
    s(n), n.fill(), n.restore();
  }, hb(t, [{
    key: "cbox",
    get: function() {
      return this._getCBox();
    }
    /**
     * The glyph’s bounding box, i.e. the rectangle that encloses the
     * glyph outline as tightly as possible.
     * @type {BBox}
     */
  }, {
    key: "bbox",
    get: function() {
      return this._getBBox();
    }
    /**
     * A vector Path object representing the glyph outline.
     * @type {Path}
     */
  }, {
    key: "path",
    get: function() {
      return this._getPath();
    }
  }, {
    key: "advanceWidth",
    get: function() {
      return this._getMetrics().advanceWidth;
    }
    /**
     * The glyph's advance height.
     * @type {number}
     */
  }, {
    key: "advanceHeight",
    get: function() {
      return this._getMetrics().advanceHeight;
    }
  }, {
    key: "ligatureCaretPositions",
    get: function() {
    }
  }, {
    key: "name",
    get: function() {
      return this._getName();
    }
  }]), t;
})(), xr(De.prototype, "cbox", [Ne], Object.getOwnPropertyDescriptor(De.prototype, "cbox"), De.prototype), xr(De.prototype, "bbox", [Ne], Object.getOwnPropertyDescriptor(De.prototype, "bbox"), De.prototype), xr(De.prototype, "path", [Ne], Object.getOwnPropertyDescriptor(De.prototype, "path"), De.prototype), xr(De.prototype, "advanceWidth", [Ne], Object.getOwnPropertyDescriptor(De.prototype, "advanceWidth"), De.prototype), xr(De.prototype, "advanceHeight", [Ne], Object.getOwnPropertyDescriptor(De.prototype, "advanceHeight"), De.prototype), xr(De.prototype, "name", [Ne], Object.getOwnPropertyDescriptor(De.prototype, "name"), De.prototype), De);
function pb(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = db(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function db(t, e) {
  if (t) {
    if (typeof t == "string") return uu(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return uu(t, e);
  }
}
function uu(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
function vb(t, e) {
  t.prototype = Object.create(e.prototype), t.prototype.constructor = t, t.__proto__ = e;
}
var fu = new i.Struct({
  numberOfContours: i.int16,
  // if negative, this is a composite glyph
  xMin: i.int16,
  yMin: i.int16,
  xMax: i.int16,
  yMax: i.int16
}), yb = 1, gb = 2, mb = 4, bb = 8, wb = 16, Fb = 32, xb = 1, Sb = 8, lu = 32, Ab = 64, Eb = 128, Cb = 256, bt = /* @__PURE__ */ (function() {
  function t(r, n, a, o) {
    a === void 0 && (a = 0), o === void 0 && (o = 0), this.onCurve = r, this.endContour = n, this.x = a, this.y = o;
  }
  var e = t.prototype;
  return e.copy = function() {
    return new t(this.onCurve, this.endContour, this.x, this.y);
  }, t;
})(), Ib = function(e, r, n) {
  this.glyphID = e, this.dx = r, this.dy = n, this.pos = 0, this.scaleX = this.scaleY = 1, this.scale01 = this.scale10 = 0;
}, bi = /* @__PURE__ */ (function(t) {
  vb(e, t);
  function e() {
    return t.apply(this, arguments) || this;
  }
  var r = e.prototype;
  return r._getCBox = function(a) {
    if (this._font._variationProcessor && !a)
      return this.path.cbox;
    var o = this._font._getTableStream("glyf");
    o.pos += this._font.loca.offsets[this.id];
    var s = fu.decode(o), u = new zr(s.xMin, s.yMin, s.xMax, s.yMax);
    return Object.freeze(u);
  }, r._parseGlyphCoord = function(a, o, s, u) {
    if (s) {
      var f = a.readUInt8();
      u || (f = -f), f += o;
    } else if (u)
      var f = o;
    else
      var f = o + a.readInt16BE();
    return f;
  }, r._decode = function() {
    var a = this._font.loca.offsets[this.id], o = this._font.loca.offsets[this.id + 1];
    if (a === o)
      return null;
    var s = this._font._getTableStream("glyf");
    s.pos += a;
    var u = s.pos, f = fu.decode(s);
    return f.numberOfContours > 0 ? this._decodeSimple(f, s) : f.numberOfContours < 0 && this._decodeComposite(f, s, u), f;
  }, r._decodeSimple = function(a, o) {
    a.points = [];
    var s = new i.Array(i.uint16, a.numberOfContours).decode(o);
    a.instructions = new i.Array(i.uint8, i.uint16).decode(o);
    for (var u = [], f = s[s.length - 1] + 1; u.length < f; ) {
      var l = o.readUInt8();
      if (u.push(l), l & bb)
        for (var c = o.readUInt8(), p = 0; p < c; p++)
          u.push(l);
    }
    for (var y = 0; y < u.length; y++) {
      var l = u[y], v = new bt(!!(l & yb), s.indexOf(y) >= 0, 0, 0);
      a.points.push(v);
    }
    for (var m = 0, y = 0; y < u.length; y++) {
      var l = u[y];
      a.points[y].x = m = this._parseGlyphCoord(o, m, l & gb, l & wb);
    }
    for (var w = 0, y = 0; y < u.length; y++) {
      var l = u[y];
      a.points[y].y = w = this._parseGlyphCoord(o, w, l & mb, l & Fb);
    }
    if (this._font._variationProcessor) {
      var F = a.points.slice();
      F.push.apply(F, this._getPhantomPoints(a)), this._font._variationProcessor.transformPoints(this.id, F), a.phantomPoints = F.slice(-4);
    }
  }, r._decodeComposite = function(a, o, s) {
    s === void 0 && (s = 0), a.components = [];
    for (var u = !1, f = lu; f & lu; ) {
      f = o.readUInt16BE();
      var l = o.pos - s, c = o.readUInt16BE();
      if (u || (u = (f & Cb) !== 0), f & xb)
        var p = o.readInt16BE(), y = o.readInt16BE();
      else
        var p = o.readInt8(), y = o.readInt8();
      var v = new Ib(c, p, y);
      v.pos = l, f & Sb ? v.scaleX = v.scaleY = (o.readUInt8() << 24 | o.readUInt8() << 16) / 1073741824 : f & Ab ? (v.scaleX = (o.readUInt8() << 24 | o.readUInt8() << 16) / 1073741824, v.scaleY = (o.readUInt8() << 24 | o.readUInt8() << 16) / 1073741824) : f & Eb && (v.scaleX = (o.readUInt8() << 24 | o.readUInt8() << 16) / 1073741824, v.scale01 = (o.readUInt8() << 24 | o.readUInt8() << 16) / 1073741824, v.scale10 = (o.readUInt8() << 24 | o.readUInt8() << 16) / 1073741824, v.scaleY = (o.readUInt8() << 24 | o.readUInt8() << 16) / 1073741824), a.components.push(v);
    }
    if (this._font._variationProcessor) {
      for (var m = [], w = 0; w < a.components.length; w++) {
        var v = a.components[w];
        m.push(new bt(!0, !0, v.dx, v.dy));
      }
      m.push.apply(m, this._getPhantomPoints(a)), this._font._variationProcessor.transformPoints(this.id, m), a.phantomPoints = m.splice(-4, 4);
      for (var F = 0; F < m.length; F++) {
        var S = m[F];
        a.components[F].dx = S.x, a.components[F].dy = S.y;
      }
    }
    return u;
  }, r._getPhantomPoints = function(a) {
    var o = this._getCBox(!0);
    this._metrics == null && (this._metrics = Qn.prototype._getMetrics.call(this, o));
    var s = this._metrics, u = s.advanceWidth, f = s.advanceHeight, l = s.leftBearing, c = s.topBearing;
    return [new bt(!1, !0, a.xMin - l, 0), new bt(!1, !0, a.xMin - l + u, 0), new bt(!1, !0, 0, a.yMax + c), new bt(!1, !0, 0, a.yMax + c + f)];
  }, r._getContours = function() {
    var a = this._decode();
    if (!a)
      return [];
    var o = [];
    if (a.numberOfContours < 0)
      for (var s = pb(a.components), u; !(u = s()).done; )
        for (var f = u.value, l = this._font.getGlyph(f.glyphID)._getContours(), c = 0; c < l.length; c++)
          for (var p = l[c], y = 0; y < p.length; y++) {
            var v = p[y], m = v.x * f.scaleX + v.y * f.scale01 + f.dx, w = v.y * f.scaleY + v.x * f.scale10 + f.dy;
            o.push(new bt(v.onCurve, v.endContour, m, w));
          }
    else
      o = a.points || [];
    a.phantomPoints && !this._font.directory.tables.HVAR && (this._metrics.advanceWidth = a.phantomPoints[1].x - a.phantomPoints[0].x, this._metrics.advanceHeight = a.phantomPoints[3].y - a.phantomPoints[2].y, this._metrics.leftBearing = a.xMin - a.phantomPoints[0].x, this._metrics.topBearing = a.phantomPoints[2].y - a.yMax);
    for (var F = [], S = [], I = 0; I < o.length; I++) {
      var A = o[I];
      S.push(A), A.endContour && (F.push(S), S = []);
    }
    return F;
  }, r._getMetrics = function() {
    if (this._metrics)
      return this._metrics;
    var a = this._getCBox(!0);
    return t.prototype._getMetrics.call(this, a), this._font._variationProcessor && !this._font.HVAR && this.path, this._metrics;
  }, r._getPath = function() {
    for (var a = this._getContours(), o = new mi(), s = 0; s < a.length; s++) {
      var u = a[s], f = u[0], l = u[u.length - 1], c = 0;
      if (f.onCurve) {
        var p = null;
        c = 1;
      } else {
        l.onCurve ? f = l : f = new bt(!1, !1, (f.x + l.x) / 2, (f.y + l.y) / 2);
        var p = f;
      }
      o.moveTo(f.x, f.y);
      for (var y = c; y < u.length; y++) {
        var v = u[y], m = y === 0 ? f : u[y - 1];
        if (m.onCurve && v.onCurve)
          o.lineTo(v.x, v.y);
        else if (m.onCurve && !v.onCurve)
          var p = v;
        else if (!m.onCurve && !v.onCurve) {
          var w = (m.x + v.x) / 2, F = (m.y + v.y) / 2;
          o.quadraticCurveTo(m.x, m.y, w, F);
          var p = v;
        } else if (!m.onCurve && v.onCurve) {
          o.quadraticCurveTo(p.x, p.y, v.x, v.y);
          var p = null;
        } else
          throw new Error("Unknown TTF path state");
      }
      p && o.quadraticCurveTo(p.x, p.y, f.x, f.y), o.closePath();
    }
    return o;
  }, e;
})(Qn);
function Ob(t, e) {
  t.prototype = Object.create(e.prototype), t.prototype.constructor = t, t.__proto__ = e;
}
var Db = /* @__PURE__ */ (function(t) {
  Ob(e, t);
  function e() {
    return t.apply(this, arguments) || this;
  }
  var r = e.prototype;
  return r._getName = function() {
    return this._font.CFF2 ? t.prototype._getName.call(this) : this._font["CFF "].getGlyphName(this.id);
  }, r.bias = function(a) {
    return a.length < 1240 ? 107 : a.length < 33900 ? 1131 : 32768;
  }, r._getPath = function() {
    var a = this._font.stream;
    a.pos;
    var o = this._font.CFF2 || this._font["CFF "], s = o.topDict.CharStrings[this.id], u = s.offset + s.length;
    a.pos = s.offset;
    var f = new mi(), l = [], c = [], p = null, y = 0, v = 0, m = 0, w, F, S = !1;
    this._usedGsubrs = w = {}, this._usedSubrs = F = {};
    var I = o.globalSubrIndex || [], A = this.bias(I), M = o.privateDictForGlyph(this.id), L = M.Subrs || [], P = this.bias(L), G = o.topDict.vstore && o.topDict.vstore.itemVariationStore, W = M.vsindex, ne = this._font._variationProcessor;
    function q() {
      p == null && (p = l.shift() + M.nominalWidthX);
    }
    function N() {
      return l.length % 2 !== 0 && q(), y += l.length >> 1, l.length = 0;
    }
    function Q(ce, j) {
      S && f.closePath(), f.moveTo(ce, j), S = !0;
    }
    var te = function ce() {
      for (; a.pos < u; ) {
        var j = a.readUInt8();
        if (j < 32)
          switch (j) {
            case 1:
            // hstem
            case 3:
            // vstem
            case 18:
            // hstemhm
            case 23:
              N();
              break;
            case 4:
              l.length > 1 && q(), m += l.shift(), Q(v, m);
              break;
            case 5:
              for (; l.length >= 2; )
                v += l.shift(), m += l.shift(), f.lineTo(v, m);
              break;
            case 6:
            // hlineto
            case 7:
              for (var le = j === 6; l.length >= 1; )
                le ? v += l.shift() : m += l.shift(), f.lineTo(v, m), le = !le;
              break;
            case 8:
              for (; l.length > 0; ) {
                var _ = v + l.shift(), V = m + l.shift(), ie = _ + l.shift(), H = V + l.shift();
                v = ie + l.shift(), m = H + l.shift(), f.bezierCurveTo(_, V, ie, H, v, m);
              }
              break;
            case 10:
              var K = l.pop() + P, re = L[K];
              if (re) {
                F[K] = !0;
                var de = a.pos, X = u;
                a.pos = re.offset, u = re.offset + re.length, ce(), a.pos = de, u = X;
              }
              break;
            case 11:
              if (o.version >= 2)
                break;
              return;
            case 14:
              if (o.version >= 2)
                break;
              l.length > 0 && q(), S && (f.closePath(), S = !1);
              break;
            case 15: {
              if (o.version < 2)
                throw new Error("vsindex operator not supported in CFF v1");
              W = l.pop();
              break;
            }
            case 16: {
              if (o.version < 2)
                throw new Error("blend operator not supported in CFF v1");
              if (!ne)
                throw new Error("blend operator in non-variation font");
              for (var ae = ne.getBlendVector(G, W), we = l.pop(), Ee = we * ae.length, Le = l.length - Ee, ke = Le - we, ye = 0; ye < we; ye++) {
                for (var Oe = l[ke + ye], Ce = 0; Ce < ae.length; Ce++)
                  Oe += ae[Ce] * l[Le++];
                l[ke + ye] = Oe;
              }
              for (; Ee--; )
                l.pop();
              break;
            }
            case 19:
            // hintmask
            case 20:
              N(), a.pos += y + 7 >> 3;
              break;
            case 21:
              l.length > 2 && q(), v += l.shift(), m += l.shift(), Q(v, m);
              break;
            case 22:
              l.length > 1 && q(), v += l.shift(), Q(v, m);
              break;
            case 24:
              for (; l.length >= 8; ) {
                var _ = v + l.shift(), V = m + l.shift(), ie = _ + l.shift(), H = V + l.shift();
                v = ie + l.shift(), m = H + l.shift(), f.bezierCurveTo(_, V, ie, H, v, m);
              }
              v += l.shift(), m += l.shift(), f.lineTo(v, m);
              break;
            case 25:
              for (; l.length >= 8; )
                v += l.shift(), m += l.shift(), f.lineTo(v, m);
              var _ = v + l.shift(), V = m + l.shift(), ie = _ + l.shift(), H = V + l.shift();
              v = ie + l.shift(), m = H + l.shift(), f.bezierCurveTo(_, V, ie, H, v, m);
              break;
            case 26:
              for (l.length % 2 && (v += l.shift()); l.length >= 4; )
                _ = v, V = m + l.shift(), ie = _ + l.shift(), H = V + l.shift(), v = ie, m = H + l.shift(), f.bezierCurveTo(_, V, ie, H, v, m);
              break;
            case 27:
              for (l.length % 2 && (m += l.shift()); l.length >= 4; )
                _ = v + l.shift(), V = m, ie = _ + l.shift(), H = V + l.shift(), v = ie + l.shift(), m = H, f.bezierCurveTo(_, V, ie, H, v, m);
              break;
            case 28:
              l.push(a.readInt16BE());
              break;
            case 29:
              if (K = l.pop() + A, re = I[K], re) {
                w[K] = !0;
                var de = a.pos, X = u;
                a.pos = re.offset, u = re.offset + re.length, ce(), a.pos = de, u = X;
              }
              break;
            case 30:
            // vhcurveto
            case 31:
              for (le = j === 31; l.length >= 4; )
                le ? (_ = v + l.shift(), V = m, ie = _ + l.shift(), H = V + l.shift(), m = H + l.shift(), v = ie + (l.length === 1 ? l.shift() : 0)) : (_ = v, V = m + l.shift(), ie = _ + l.shift(), H = V + l.shift(), v = ie + l.shift(), m = H + (l.length === 1 ? l.shift() : 0)), f.bezierCurveTo(_, V, ie, H, v, m), le = !le;
              break;
            case 12:
              switch (j = a.readUInt8(), j) {
                case 3:
                  var J = l.pop(), xe = l.pop();
                  l.push(J && xe ? 1 : 0);
                  break;
                case 4:
                  J = l.pop(), xe = l.pop(), l.push(J || xe ? 1 : 0);
                  break;
                case 5:
                  J = l.pop(), l.push(J ? 0 : 1);
                  break;
                case 9:
                  J = l.pop(), l.push(Math.abs(J));
                  break;
                case 10:
                  J = l.pop(), xe = l.pop(), l.push(J + xe);
                  break;
                case 11:
                  J = l.pop(), xe = l.pop(), l.push(J - xe);
                  break;
                case 12:
                  J = l.pop(), xe = l.pop(), l.push(J / xe);
                  break;
                case 14:
                  J = l.pop(), l.push(-J);
                  break;
                case 15:
                  J = l.pop(), xe = l.pop(), l.push(J === xe ? 1 : 0);
                  break;
                case 18:
                  l.pop();
                  break;
                case 20:
                  var g = l.pop(), h = l.pop();
                  c[h] = g;
                  break;
                case 21:
                  h = l.pop(), l.push(c[h] || 0);
                  break;
                case 22:
                  var d = l.pop(), b = l.pop(), x = l.pop(), O = l.pop();
                  l.push(x <= O ? d : b);
                  break;
                case 23:
                  l.push(Math.random());
                  break;
                case 24:
                  J = l.pop(), xe = l.pop(), l.push(J * xe);
                  break;
                case 26:
                  J = l.pop(), l.push(Math.sqrt(J));
                  break;
                case 27:
                  J = l.pop(), l.push(J, J);
                  break;
                case 28:
                  J = l.pop(), xe = l.pop(), l.push(xe, J);
                  break;
                case 29:
                  h = l.pop(), h < 0 ? h = 0 : h > l.length - 1 && (h = l.length - 1), l.push(l[h]);
                  break;
                case 30:
                  var C = l.pop(), U = l.pop();
                  if (U >= 0)
                    for (; U > 0; ) {
                      for (var Y = l[C - 1], oe = C - 2; oe >= 0; oe--)
                        l[oe + 1] = l[oe];
                      l[0] = Y, U--;
                    }
                  else
                    for (; U < 0; ) {
                      for (var Y = l[0], ge = 0; ge <= C; ge++)
                        l[ge] = l[ge + 1];
                      l[C - 1] = Y, U++;
                    }
                  break;
                case 34:
                  _ = v + l.shift(), V = m, ie = _ + l.shift(), H = V + l.shift();
                  var ue = ie + l.shift(), je = H, et = ue + l.shift(), Ve = je, It = et + l.shift(), Ot = Ve, Zt = It + l.shift(), Jt = Ot;
                  v = Zt, m = Jt, f.bezierCurveTo(_, V, ie, H, ue, je), f.bezierCurveTo(et, Ve, It, Ot, Zt, Jt);
                  break;
                case 35:
                  for (var tt = [], gr = 0; gr <= 5; gr++)
                    v += l.shift(), m += l.shift(), tt.push(v, m);
                  f.bezierCurveTo.apply(f, tt.slice(0, 6)), f.bezierCurveTo.apply(f, tt.slice(6)), l.shift();
                  break;
                case 36:
                  _ = v + l.shift(), V = m + l.shift(), ie = _ + l.shift(), H = V + l.shift(), ue = ie + l.shift(), je = H, et = ue + l.shift(), Ve = je, It = et + l.shift(), Ot = Ve + l.shift(), Zt = It + l.shift(), Jt = Ot, v = Zt, m = Jt, f.bezierCurveTo(_, V, ie, H, ue, je), f.bezierCurveTo(et, Ve, It, Ot, Zt, Jt);
                  break;
                case 37:
                  var Qt = v, Fo = m;
                  tt = [];
                  for (var xo = 0; xo <= 4; xo++)
                    v += l.shift(), m += l.shift(), tt.push(v, m);
                  Math.abs(v - Qt) > Math.abs(m - Fo) ? (v += l.shift(), m = Fo) : (v = Qt, m += l.shift()), tt.push(v, m), f.bezierCurveTo.apply(f, tt.slice(0, 6)), f.bezierCurveTo.apply(f, tt.slice(6));
                  break;
                default:
                  throw new Error("Unknown op: 12 " + j);
              }
              break;
            default:
              throw new Error("Unknown op: " + j);
          }
        else if (j < 247)
          l.push(j - 139);
        else if (j < 251) {
          var wi = a.readUInt8();
          l.push((j - 247) * 256 + wi + 108);
        } else if (j < 255) {
          var wi = a.readUInt8();
          l.push(-(j - 251) * 256 - wi - 108);
        } else
          l.push(a.readInt32BE() / 65536);
      }
    };
    return te(), S && f.closePath(), f;
  }, e;
})(Qn);
function Tb(t, e) {
  t.prototype = Object.create(e.prototype), t.prototype.constructor = t, t.__proto__ = e;
}
var Pb = new i.Struct({
  originX: i.uint16,
  originY: i.uint16,
  type: new i.String(4),
  data: new i.Buffer(function(t) {
    return t.parent.buflen - t._currentOffset;
  })
}), Bb = /* @__PURE__ */ (function(t) {
  Tb(e, t);
  function e() {
    return t.apply(this, arguments) || this;
  }
  var r = e.prototype;
  return r.getImageForSize = function(a) {
    for (var o = 0; o < this._font.sbix.imageTables.length; o++) {
      var s = this._font.sbix.imageTables[o];
      if (s.ppem >= a)
        break;
    }
    var u = s.imageOffsets, f = u[this.id], l = u[this.id + 1];
    return f === l ? null : (this._font.stream.pos = f, Pb.decode(this._font.stream, {
      buflen: l - f
    }));
  }, r.render = function(a, o) {
    var s = this.getImageForSize(o);
    if (s != null) {
      var u = o / this._font.unitsPerEm;
      a.image(s.data, {
        height: o,
        x: s.originX,
        y: (this.bbox.minY - s.originY) * u
      });
    }
    this._font.sbix.flags.renderOutlines && t.prototype.render.call(this, a, o);
  }, e;
})(bi);
function kb(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = Lb(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function Lb(t, e) {
  if (t) {
    if (typeof t == "string") return cu(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return cu(t, e);
  }
}
function cu(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
function Mb(t, e) {
  for (var r = 0; r < e.length; r++) {
    var n = e[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(t, n.key, n);
  }
}
function Ub(t, e, r) {
  return e && Mb(t.prototype, e), t;
}
function Nb(t, e) {
  t.prototype = Object.create(e.prototype), t.prototype.constructor = t, t.__proto__ = e;
}
var hu = function(e, r) {
  this.glyph = e, this.color = r;
}, Rb = /* @__PURE__ */ (function(t) {
  Nb(e, t);
  function e() {
    return t.apply(this, arguments) || this;
  }
  var r = e.prototype;
  return r._getBBox = function() {
    for (var a = new zr(), o = 0; o < this.layers.length; o++) {
      var s = this.layers[o], u = s.glyph.bbox;
      a.addPoint(u.minX, u.minY), a.addPoint(u.maxX, u.maxY);
    }
    return a;
  }, r.render = function(a, o) {
    for (var s = kb(this.layers), u; !(u = s()).done; ) {
      var f = u.value, l = f.glyph, c = f.color;
      a.fillColor([c.red, c.green, c.blue], c.alpha / 255 * 100), l.render(a, o);
    }
  }, Ub(e, [{
    key: "layers",
    get: function() {
      for (var a = this._font.CPAL, o = this._font.COLR, s = 0, u = o.baseGlyphRecord.length - 1; s <= u; ) {
        var f = s + u >> 1, l = o.baseGlyphRecord[f];
        if (this.id < l.gid)
          u = f - 1;
        else if (this.id > l.gid)
          s = f + 1;
        else {
          var c = l;
          break;
        }
      }
      if (c == null) {
        var p = this._font._getBaseGlyph(this.id), y = {
          red: 0,
          green: 0,
          blue: 0,
          alpha: 255
        };
        return [new hu(p, y)];
      }
      for (var v = [], m = c.firstLayerIndex; m < c.firstLayerIndex + c.numLayers; m++) {
        var l = o.layerRecords[m], y = a.colorRecords[l.paletteIndex], p = this._font._getBaseGlyph(l.gid);
        v.push(new hu(p, y));
      }
      return v;
    }
  }]), e;
})(Qn), zb = 32768, jb = 4095, Vb = 32768, pu = 16384, Gb = 8192, du = 4095, vu = 128, yu = 127, qb = 128, Hb = 64, Wb = 63, Xb = /* @__PURE__ */ (function() {
  function t(r, n) {
    this.font = r, this.normalizedCoords = this.normalizeCoords(n), this.blendVectors = /* @__PURE__ */ new Map();
  }
  var e = t.prototype;
  return e.normalizeCoords = function(n) {
    for (var a = [], o = 0; o < this.font.fvar.axis.length; o++) {
      var s = this.font.fvar.axis[o];
      n[o] < s.defaultValue ? a.push((n[o] - s.defaultValue + Number.EPSILON) / (s.defaultValue - s.minValue + Number.EPSILON)) : a.push((n[o] - s.defaultValue + Number.EPSILON) / (s.maxValue - s.defaultValue + Number.EPSILON));
    }
    if (this.font.avar)
      for (var o = 0; o < this.font.avar.segment.length; o++)
        for (var u = this.font.avar.segment[o], f = 0; f < u.correspondence.length; f++) {
          var l = u.correspondence[f];
          if (f >= 1 && a[o] < l.fromCoord) {
            var c = u.correspondence[f - 1];
            a[o] = ((a[o] - c.fromCoord) * (l.toCoord - c.toCoord) + Number.EPSILON) / (l.fromCoord - c.fromCoord + Number.EPSILON) + c.toCoord;
            break;
          }
        }
    return a;
  }, e.transformPoints = function(n, a) {
    if (!(!this.font.fvar || !this.font.gvar)) {
      var o = this.font.gvar;
      if (!(n >= o.glyphCount)) {
        var s = o.offsets[n];
        if (s !== o.offsets[n + 1]) {
          var u = this.font.stream;
          if (u.pos = s, !(u.pos >= u.length)) {
            var f = u.readUInt16BE(), l = s + u.readUInt16BE();
            if (f & zb) {
              var c = u.pos;
              u.pos = l;
              var p = this.decodePoints();
              l = u.pos, u.pos = c;
            }
            var y = a.map(function(ae) {
              return ae.copy();
            });
            f &= jb;
            for (var v = 0; v < f; v++) {
              var m = u.readUInt16BE(), w = u.readUInt16BE();
              if (w & Vb)
                for (var F = [], S = 0; S < o.axisCount; S++)
                  F.push(u.readInt16BE() / 16384);
              else {
                if ((w & du) >= o.globalCoordCount)
                  throw new Error("Invalid gvar table");
                var F = o.globalCoords[w & du];
              }
              if (w & pu) {
                for (var I = [], A = 0; A < o.axisCount; A++)
                  I.push(u.readInt16BE() / 16384);
                for (var M = [], L = 0; L < o.axisCount; L++)
                  M.push(u.readInt16BE() / 16384);
              }
              var P = this.tupleFactor(w, F, I, M);
              if (P === 0) {
                l += m;
                continue;
              }
              var c = u.pos;
              if (u.pos = l, w & Gb)
                var G = this.decodePoints();
              else
                var G = p;
              var W = G.length === 0 ? a.length : G.length, ne = this.decodeDeltas(W), q = this.decodeDeltas(W);
              if (G.length === 0)
                for (var N = 0; N < a.length; N++) {
                  var Q = a[N];
                  Q.x += Math.round(ne[N] * P), Q.y += Math.round(q[N] * P);
                }
              else {
                for (var te = y.map(function(we) {
                  return we.copy();
                }), ce = a.map(function() {
                  return !1;
                }), j = 0; j < G.length; j++) {
                  var le = G[j];
                  if (le < a.length) {
                    var K = te[le];
                    ce[le] = !0, K.x += Math.round(ne[j] * P), K.y += Math.round(q[j] * P);
                  }
                }
                this.interpolateMissingDeltas(te, y, ce);
                for (var re = 0; re < a.length; re++) {
                  var de = te[re].x - y[re].x, X = te[re].y - y[re].y;
                  a[re].x += de, a[re].y += X;
                }
              }
              l += m, u.pos = c;
            }
          }
        }
      }
    }
  }, e.decodePoints = function() {
    var n = this.font.stream, a = n.readUInt8();
    a & vu && (a = (a & yu) << 8 | n.readUInt8());
    for (var o = new Uint16Array(a), s = 0, u = 0; s < a; )
      for (var f = n.readUInt8(), l = (f & yu) + 1, c = f & vu ? n.readUInt16 : n.readUInt8, p = 0; p < l && s < a; p++)
        u += c.call(n), o[s++] = u;
    return o;
  }, e.decodeDeltas = function(n) {
    for (var a = this.font.stream, o = 0, s = new Int16Array(n); o < n; ) {
      var u = a.readUInt8(), f = (u & Wb) + 1;
      if (u & qb)
        o += f;
      else
        for (var l = u & Hb ? a.readInt16BE : a.readInt8, c = 0; c < f && o < n; c++)
          s[o++] = l.call(a);
    }
    return s;
  }, e.tupleFactor = function(n, a, o, s) {
    for (var u = this.normalizedCoords, f = this.font.gvar, l = 1, c = 0; c < f.axisCount; c++)
      if (a[c] !== 0) {
        if (u[c] === 0)
          return 0;
        if ((n & pu) === 0) {
          if (u[c] < Math.min(0, a[c]) || u[c] > Math.max(0, a[c]))
            return 0;
          l = (l * u[c] + Number.EPSILON) / (a[c] + Number.EPSILON);
        } else {
          if (u[c] < o[c] || u[c] > s[c])
            return 0;
          u[c] < a[c] ? l = l * (u[c] - o[c] + Number.EPSILON) / (a[c] - o[c] + Number.EPSILON) : l = l * (s[c] - u[c] + Number.EPSILON) / (s[c] - a[c] + Number.EPSILON);
        }
      }
    return l;
  }, e.interpolateMissingDeltas = function(n, a, o) {
    if (n.length !== 0)
      for (var s = 0; s < n.length; ) {
        for (var u = s, f = s, l = n[f]; !l.endContour; )
          l = n[++f];
        for (; s <= f && !o[s]; )
          s++;
        if (!(s > f)) {
          var c = s, p = s;
          for (s++; s <= f; )
            o[s] && (this.deltaInterpolate(p + 1, s - 1, p, s, a, n), p = s), s++;
          p === c ? this.deltaShift(u, f, p, a, n) : (this.deltaInterpolate(p + 1, f, p, c, a, n), c > 0 && this.deltaInterpolate(u, c - 1, p, c, a, n)), s = f + 1;
        }
      }
  }, e.deltaInterpolate = function(n, a, o, s, u, f) {
    if (!(n > a))
      for (var l = ["x", "y"], c = 0; c < l.length; c++) {
        var p = l[c];
        if (u[o][p] > u[s][p]) {
          var y = o;
          o = s, s = y;
        }
        var v = u[o][p], m = u[s][p], w = f[o][p], F = f[s][p];
        if (v !== m || w === F)
          for (var S = v === m ? 0 : (F - w) / (m - v), I = n; I <= a; I++) {
            var A = u[I][p];
            A <= v ? A += w - v : A >= m ? A += F - m : A = w + (A - v) * S, f[I][p] = A;
          }
      }
  }, e.deltaShift = function(n, a, o, s, u) {
    var f = u[o].x - s[o].x, l = u[o].y - s[o].y;
    if (!(f === 0 && l === 0))
      for (var c = n; c <= a; c++)
        c !== o && (u[c].x += f, u[c].y += l);
  }, e.getAdvanceAdjustment = function(n, a) {
    var o, s;
    if (a.advanceWidthMapping) {
      var u = n;
      u >= a.advanceWidthMapping.mapCount && (u = a.advanceWidthMapping.mapCount - 1), a.advanceWidthMapping.entryFormat;
      var f = a.advanceWidthMapping.mapData[u];
      o = f.outerIndex, s = f.innerIndex;
    } else
      o = 0, s = n;
    return this.getDelta(a.itemVariationStore, o, s);
  }, e.getDelta = function(n, a, o) {
    if (a >= n.itemVariationData.length)
      return 0;
    var s = n.itemVariationData[a];
    if (o >= s.deltaSets.length)
      return 0;
    for (var u = s.deltaSets[o], f = this.getBlendVector(n, a), l = 0, c = 0; c < s.regionIndexCount; c++)
      l += u.deltas[c] * f[c];
    return l;
  }, e.getBlendVector = function(n, a) {
    var o = n.itemVariationData[a];
    if (this.blendVectors.has(o))
      return this.blendVectors.get(o);
    for (var s = this.normalizedCoords, u = [], f = 0; f < o.regionIndexCount; f++) {
      for (var l = 1, c = o.regionIndexes[f], p = n.variationRegionList.variationRegions[c], y = 0; y < p.length; y++) {
        var v = p[y], m = void 0;
        v.startCoord > v.peakCoord || v.peakCoord > v.endCoord || v.startCoord < 0 && v.endCoord > 0 && v.peakCoord !== 0 || v.peakCoord === 0 ? m = 1 : s[y] < v.startCoord || s[y] > v.endCoord ? m = 0 : s[y] === v.peakCoord ? m = 1 : s[y] < v.peakCoord ? m = (s[y] - v.startCoord + Number.EPSILON) / (v.peakCoord - v.startCoord + Number.EPSILON) : m = (v.endCoord - s[y] + Number.EPSILON) / (v.endCoord - v.peakCoord + Number.EPSILON), l *= m;
      }
      u[f] = l;
    }
    return this.blendVectors.set(o, u), u;
  }, t;
})(), na = be(function(t) {
  var e = (function() {
    function r(f, l, c, p) {
      typeof l == "object" && (c = l.depth, p = l.prototype, l.filter, l = l.circular);
      var y = [], v = [], m = typeof pe < "u";
      typeof l > "u" && (l = !0), typeof c > "u" && (c = 1 / 0);
      function w(F, S) {
        if (F === null) return null;
        if (S == 0) return F;
        var I, A;
        if (typeof F != "object")
          return F;
        if (r.__isArray(F))
          I = [];
        else if (r.__isRegExp(F))
          I = new RegExp(F.source, u(F)), F.lastIndex && (I.lastIndex = F.lastIndex);
        else if (r.__isDate(F))
          I = new Date(F.getTime());
        else {
          if (m && pe.isBuffer(F))
            return pe.allocUnsafe ? I = pe.allocUnsafe(F.length) : I = new pe(F.length), F.copy(I), I;
          typeof p > "u" ? (A = Object.getPrototypeOf(F), I = Object.create(A)) : (I = Object.create(p), A = p);
        }
        if (l) {
          var M = y.indexOf(F);
          if (M != -1)
            return v[M];
          y.push(F), v.push(I);
        }
        for (var L in F) {
          var P;
          A && (P = Object.getOwnPropertyDescriptor(A, L)), !(P && P.set == null) && (I[L] = w(F[L], S - 1));
        }
        return I;
      }
      return w(f, c);
    }
    r.clonePrototype = function(l) {
      if (l === null) return null;
      var c = function() {
      };
      return c.prototype = l, new c();
    };
    function n(f) {
      return Object.prototype.toString.call(f);
    }
    r.__objToStr = n;
    function a(f) {
      return typeof f == "object" && n(f) === "[object Date]";
    }
    r.__isDate = a;
    function o(f) {
      return typeof f == "object" && n(f) === "[object Array]";
    }
    r.__isArray = o;
    function s(f) {
      return typeof f == "object" && n(f) === "[object RegExp]";
    }
    r.__isRegExp = s;
    function u(f) {
      var l = "";
      return f.global && (l += "g"), f.ignoreCase && (l += "i"), f.multiline && (l += "m"), l;
    }
    return r.__getRegExpFlags = u, r;
  })();
  t.exports && (t.exports = e);
}), Sl = /* @__PURE__ */ (function() {
  function t(r) {
    this.font = r, this.glyphs = [], this.mapping = {}, this.includeGlyph(0);
  }
  var e = t.prototype;
  return e.includeGlyph = function(n) {
    return typeof n == "object" && (n = n.id), this.mapping[n] == null && (this.glyphs.push(n), this.mapping[n] = this.glyphs.length - 1), this.mapping[n];
  }, e.encodeStream = function() {
    var n = this, a = new i.EncodeStream();
    return He(function() {
      return n.encode(a), a.end();
    }), a;
  }, t;
})(), Yb = 1, Kb = 2, Zb = 4, Jb = 8, Qb = 16, _b = 32, gu = /* @__PURE__ */ (function() {
  function t() {
  }
  return t.size = function(r) {
    return r >= 0 && r <= 255 ? 1 : 2;
  }, t.encode = function(r, n) {
    n >= 0 && n <= 255 ? r.writeUInt8(n) : r.writeInt16BE(n);
  }, t;
})(), mu = new i.Struct({
  numberOfContours: i.int16,
  // if negative, this is a composite glyph
  xMin: i.int16,
  yMin: i.int16,
  xMax: i.int16,
  yMax: i.int16,
  endPtsOfContours: new i.Array(i.uint16, "numberOfContours"),
  instructions: new i.Array(i.uint8, i.uint16),
  flags: new i.Array(i.uint8, 0),
  xPoints: new i.Array(gu, 0),
  yPoints: new i.Array(gu, 0)
}), $b = /* @__PURE__ */ (function() {
  function t() {
  }
  var e = t.prototype;
  return e.encodeSimple = function(n, a) {
    a === void 0 && (a = []);
    for (var o = [], s = [], u = [], f = [], l = 0, c = 0, p = 0, y = 0, v = 0, m = 0; m < n.commands.length; m++) {
      for (var w = n.commands[m], F = 0; F < w.args.length; F += 2) {
        var S = w.args[F], I = w.args[F + 1], A = 0;
        if (w.command === "quadraticCurveTo" && F === 2) {
          var M = n.commands[m + 1];
          if (M && M.command === "quadraticCurveTo") {
            var L = (c + M.args[0]) / 2, P = (p + M.args[1]) / 2;
            if (S === L && I === P)
              continue;
          }
        }
        w.command === "quadraticCurveTo" && F === 0 || (A |= Yb), A = this._encodePoint(S, c, s, A, Kb, Qb), A = this._encodePoint(I, p, u, A, Zb, _b), A === y && l < 255 ? (f[f.length - 1] |= Jb, l++) : (l > 0 && (f.push(l), l = 0), f.push(A), y = A), c = S, p = I, v++;
      }
      w.command === "closePath" && o.push(v - 1);
    }
    n.commands.length > 1 && n.commands[n.commands.length - 1].command !== "closePath" && o.push(v - 1);
    var G = n.bbox, W = {
      numberOfContours: o.length,
      xMin: G.minX,
      yMin: G.minY,
      xMax: G.maxX,
      yMax: G.maxY,
      endPtsOfContours: o,
      instructions: a,
      flags: f,
      xPoints: s,
      yPoints: u
    }, ne = mu.size(W), q = 4 - ne % 4, N = new i.EncodeStream(ne + q);
    return mu.encode(N, W), q !== 0 && N.fill(0, q), N.buffer;
  }, e._encodePoint = function(n, a, o, s, u, f) {
    var l = n - a;
    return n === a ? s |= f : (-255 <= l && l <= 255 && (s |= u, l < 0 ? l = -l : s |= f), o.push(l)), s;
  }, t;
})();
function e2(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = t2(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function t2(t, e) {
  if (t) {
    if (typeof t == "string") return bu(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return bu(t, e);
  }
}
function bu(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
function r2(t, e) {
  t.prototype = Object.create(e.prototype), t.prototype.constructor = t, t.__proto__ = e;
}
var n2 = /* @__PURE__ */ (function(t) {
  r2(e, t);
  function e(n) {
    var a;
    return a = t.call(this, n) || this, a.glyphEncoder = new $b(), a;
  }
  var r = e.prototype;
  return r._addGlyph = function(a) {
    var o = this.font.getGlyph(a), s = o._decode(), u = this.font.loca.offsets[a], f = this.font.loca.offsets[a + 1], l = this.font._getTableStream("glyf");
    l.pos += u;
    var c = l.readBuffer(f - u);
    if (s && s.numberOfContours < 0) {
      c = new pe(c);
      for (var p = e2(s.components), y; !(y = p()).done; ) {
        var v = y.value;
        a = this.includeGlyph(v.glyphID), c.writeUInt16BE(a, v.pos);
      }
    } else s && this.font._variationProcessor && (c = this.glyphEncoder.encodeSimple(o.path, s.instructions));
    return this.glyf.push(c), this.loca.offsets.push(this.offset), this.hmtx.metrics.push({
      advance: o.advanceWidth,
      bearing: o._getMetrics().leftBearing
    }), this.offset += c.length, this.glyf.length - 1;
  }, r.encode = function(a) {
    this.glyf = [], this.offset = 0, this.loca = {
      offsets: []
    }, this.hmtx = {
      metrics: [],
      bearings: []
    };
    for (var o = 0; o < this.glyphs.length; )
      this._addGlyph(this.glyphs[o++]);
    var s = na(this.font.maxp);
    s.numGlyphs = this.glyf.length, this.loca.offsets.push(this.offset), z.loca.preEncode.call(this.loca);
    var u = na(this.font.head);
    u.indexToLocFormat = this.loca.version;
    var f = na(this.font.hhea);
    f.numberOfMetrics = this.hmtx.metrics.length, ci.encode(a, {
      tables: {
        head: u,
        hhea: f,
        loca: this.loca,
        maxp: s,
        "cvt ": this.font["cvt "],
        prep: this.font.prep,
        glyf: this.glyf,
        hmtx: this.hmtx,
        fpgm: this.font.fpgm
        // name: clone @font.name
        // 'OS/2': clone @font['OS/2']
        // post: clone @font.post
        // cmap: cmap
      }
    });
  }, e;
})(Sl);
function ia(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = i2(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function i2(t, e) {
  if (t) {
    if (typeof t == "string") return wu(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return wu(t, e);
  }
}
function wu(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
function a2(t, e) {
  t.prototype = Object.create(e.prototype), t.prototype.constructor = t, t.__proto__ = e;
}
var o2 = /* @__PURE__ */ (function(t) {
  a2(e, t);
  function e(n) {
    var a;
    if (a = t.call(this, n) || this, a.cff = a.font["CFF "], !a.cff)
      throw new Error("Not a CFF Font");
    return a;
  }
  var r = e.prototype;
  return r.subsetCharstrings = function() {
    this.charstrings = [];
    for (var a = {}, o = ia(this.glyphs), s; !(s = o()).done; ) {
      var u = s.value;
      this.charstrings.push(this.cff.getCharString(u));
      var f = this.font.getGlyph(u);
      f.path;
      for (var l in f._usedGsubrs)
        a[l] = !0;
    }
    this.gsubrs = this.subsetSubrs(this.cff.globalSubrIndex, a);
  }, r.subsetSubrs = function(a, o) {
    for (var s = [], u = 0; u < a.length; u++) {
      var f = a[u];
      o[u] ? (this.cff.stream.pos = f.offset, s.push(this.cff.stream.readBuffer(f.length))) : s.push(new pe([11]));
    }
    return s;
  }, r.subsetFontdict = function(a) {
    a.FDArray = [], a.FDSelect = {
      version: 0,
      fds: []
    };
    for (var o = {}, s = [], u = ia(this.glyphs), f; !(f = u()).done; ) {
      var l = f.value, c = this.cff.fdForGlyph(l);
      if (c != null) {
        o[c] || (a.FDArray.push(Object.assign({}, this.cff.topDict.FDArray[c])), s.push({})), o[c] = !0, a.FDSelect.fds.push(a.FDArray.length - 1);
        var p = this.font.getGlyph(l);
        p.path;
        for (var y in p._usedSubrs)
          s[s.length - 1][y] = !0;
      }
    }
    for (var v = 0; v < a.FDArray.length; v++) {
      var m = a.FDArray[v];
      delete m.FontName, m.Private && m.Private.Subrs && (m.Private = Object.assign({}, m.Private), m.Private.Subrs = this.subsetSubrs(m.Private.Subrs, s[v]));
    }
  }, r.createCIDFontdict = function(a) {
    for (var o = {}, s = ia(this.glyphs), u; !(u = s()).done; ) {
      var f = u.value, l = this.font.getGlyph(f);
      l.path;
      for (var c in l._usedSubrs)
        o[c] = !0;
    }
    var p = Object.assign({}, this.cff.topDict.Private);
    return this.cff.topDict.Private && this.cff.topDict.Private.Subrs && (p.Subrs = this.subsetSubrs(this.cff.topDict.Private.Subrs, o)), a.FDArray = [{
      Private: p
    }], a.FDSelect = {
      version: 3,
      nRanges: 1,
      ranges: [{
        first: 0,
        fd: 0
      }],
      sentinel: this.charstrings.length
    };
  }, r.addString = function(a) {
    return a ? (this.strings || (this.strings = []), this.strings.push(a), Ln.length + this.strings.length - 1) : null;
  }, r.encode = function(a) {
    this.subsetCharstrings();
    var o = {
      version: this.charstrings.length > 255 ? 2 : 1,
      ranges: [{
        first: 1,
        nLeft: this.charstrings.length - 2
      }]
    }, s = Object.assign({}, this.cff.topDict);
    s.Private = null, s.charset = o, s.Encoding = null, s.CharStrings = this.charstrings;
    for (var u = 0, f = ["version", "Notice", "Copyright", "FullName", "FamilyName", "Weight", "PostScript", "BaseFontName", "FontName"]; u < f.length; u++) {
      var l = f[u];
      s[l] = this.addString(this.cff.string(s[l]));
    }
    s.ROS = [this.addString("Adobe"), this.addString("Identity"), 0], s.CIDCount = this.charstrings.length, this.cff.isCIDFont ? this.subsetFontdict(s) : this.createCIDFontdict(s);
    var c = {
      version: 1,
      hdrSize: this.cff.hdrSize,
      offSize: this.cff.length,
      header: this.cff.header,
      nameIndex: [this.cff.postscriptName],
      topDictIndex: [s],
      stringIndex: this.strings,
      globalSubrIndex: this.gsubrs
    };
    Qf.encode(a, c);
  }, e;
})(Sl), Fe;
function Fu(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = s2(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function s2(t, e) {
  if (t) {
    if (typeof t == "string") return xu(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return xu(t, e);
  }
}
function xu(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
function u2(t, e) {
  for (var r = 0; r < e.length; r++) {
    var n = e[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(t, n.key, n);
  }
}
function f2(t, e, r) {
  return e && u2(t.prototype, e), t;
}
function er(t, e, r, n, a) {
  var o = {};
  return Object.keys(n).forEach(function(s) {
    o[s] = n[s];
  }), o.enumerable = !!o.enumerable, o.configurable = !!o.configurable, ("value" in o || o.initializer) && (o.writable = !0), o = r.slice().reverse().reduce(function(s, u) {
    return u(t, e, s) || s;
  }, o), a && o.initializer !== void 0 && (o.value = o.initializer ? o.initializer.call(a) : void 0, o.initializer = void 0), o.initializer === void 0 && (Object.defineProperty(t, e, o), o = null), o;
}
var pr = (Fe = /* @__PURE__ */ (function() {
  t.probe = function(n) {
    var a = n.toString("ascii", 0, 4);
    return a === "true" || a === "OTTO" || a === "\0\0\0";
  };
  function t(r, n) {
    n === void 0 && (n = null), this.stream = r, this.variationCoords = n, this._directoryPos = this.stream.pos, this._tables = {}, this._glyphs = {}, this._decodeDirectory();
    for (var a in this.directory.tables) {
      var o = this.directory.tables[a];
      z[a] && o.length > 0 && Object.defineProperty(this, a, {
        get: this._getTable.bind(this, o)
      });
    }
  }
  var e = t.prototype;
  return e._getTable = function(n) {
    if (!(n.tag in this._tables))
      try {
        this._tables[n.tag] = this._decodeTable(n);
      } catch (a) {
        Hr.logErrors && (console.error("Error decoding table " + n.tag), console.error(a.stack));
      }
    return this._tables[n.tag];
  }, e._getTableStream = function(n) {
    var a = this.directory.tables[n];
    return a ? (this.stream.pos = a.offset, this.stream) : null;
  }, e._decodeDirectory = function() {
    return this.directory = ci.decode(this.stream, {
      _startOffset: 0
    });
  }, e._decodeTable = function(n) {
    var a = this.stream.pos, o = this._getTableStream(n.tag), s = z[n.tag].decode(o, this, n.length);
    return this.stream.pos = a, s;
  }, e.getName = function(n, a) {
    a === void 0 && (a = "en");
    var o = this.name.records[n];
    return o ? o[a] : null;
  }, e.hasGlyphForCodePoint = function(n) {
    return !!this._cmapProcessor.lookup(n);
  }, e.glyphForCodePoint = function(n) {
    return this.getGlyph(this._cmapProcessor.lookup(n), [n]);
  }, e.glyphsForString = function(n) {
    for (var a = [], o = n.length, s = 0, u = -1, f = -1; s <= o; ) {
      var l = 0, c = 0;
      if (s < o) {
        if (l = n.charCodeAt(s++), 55296 <= l && l <= 56319 && s < o) {
          var p = n.charCodeAt(s);
          56320 <= p && p <= 57343 && (s++, l = ((l & 1023) << 10) + (p & 1023) + 65536);
        }
        c = 65024 <= l && l <= 65039 || 917760 <= l && l <= 917999 ? 1 : 0;
      } else
        s++;
      f === 0 && c === 1 ? a.push(this.getGlyph(this._cmapProcessor.lookup(u, l), [u, l])) : f === 0 && c === 0 && a.push(this.glyphForCodePoint(u)), u = l, f = c;
    }
    return a;
  }, e.layout = function(n, a, o, s, u) {
    return this._layoutEngine.layout(n, a, o, s, u);
  }, e.stringsForGlyph = function(n) {
    return this._layoutEngine.stringsForGlyph(n);
  }, e.getAvailableFeatures = function(n, a) {
    return this._layoutEngine.getAvailableFeatures(n, a);
  }, e._getBaseGlyph = function(n, a) {
    return a === void 0 && (a = []), this._glyphs[n] || (this.directory.tables.glyf ? this._glyphs[n] = new bi(n, a, this) : (this.directory.tables["CFF "] || this.directory.tables.CFF2) && (this._glyphs[n] = new Db(n, a, this))), this._glyphs[n] || null;
  }, e.getGlyph = function(n, a) {
    return a === void 0 && (a = []), this._glyphs[n] || (this.directory.tables.sbix ? this._glyphs[n] = new Bb(n, a, this) : this.directory.tables.COLR && this.directory.tables.CPAL ? this._glyphs[n] = new Rb(n, a, this) : this._getBaseGlyph(n, a)), this._glyphs[n] || null;
  }, e.createSubset = function() {
    return this.directory.tables["CFF "] ? new o2(this) : new n2(this);
  }, e.getVariation = function(n) {
    if (!(this.directory.tables.fvar && (this.directory.tables.gvar && this.directory.tables.glyf || this.directory.tables.CFF2)))
      throw new Error("Variations require a font with the fvar, gvar and glyf, or CFF2 tables.");
    if (typeof n == "string" && (n = this.namedVariations[n]), typeof n != "object")
      throw new Error("Variation settings must be either a variation name or settings object.");
    var a = this.fvar.axis.map(function(u, f) {
      var l = u.axisTag.trim();
      return l in n ? Math.max(u.minValue, Math.min(u.maxValue, n[l])) : u.defaultValue;
    }), o = new i.DecodeStream(this.stream.buffer);
    o.pos = this._directoryPos;
    var s = new t(o, a);
    return s._tables = this._tables, s;
  }, e.getFont = function(n) {
    return this.getVariation(n);
  }, f2(t, [{
    key: "postscriptName",
    get: function() {
      var n = this.name.records.postscriptName;
      if (n) {
        var a = Object.keys(n)[0];
        return n[a];
      }
      return null;
    }
  }, {
    key: "fullName",
    get: function() {
      return this.getName("fullName");
    }
    /**
     * The font's family name, e.g. "Helvetica"
     * @type {string}
     */
  }, {
    key: "familyName",
    get: function() {
      return this.getName("fontFamily");
    }
    /**
     * The font's sub-family, e.g. "Bold".
     * @type {string}
     */
  }, {
    key: "subfamilyName",
    get: function() {
      return this.getName("fontSubfamily");
    }
    /**
     * The font's copyright information
     * @type {string}
     */
  }, {
    key: "copyright",
    get: function() {
      return this.getName("copyright");
    }
    /**
     * The font's version number
     * @type {string}
     */
  }, {
    key: "version",
    get: function() {
      return this.getName("version");
    }
    /**
     * The font’s [ascender](https://en.wikipedia.org/wiki/Ascender_(typography))
     * @type {number}
     */
  }, {
    key: "ascent",
    get: function() {
      return this.hhea.ascent;
    }
    /**
     * The font’s [descender](https://en.wikipedia.org/wiki/Descender)
     * @type {number}
     */
  }, {
    key: "descent",
    get: function() {
      return this.hhea.descent;
    }
    /**
     * The amount of space that should be included between lines
     * @type {number}
     */
  }, {
    key: "lineGap",
    get: function() {
      return this.hhea.lineGap;
    }
    /**
     * The offset from the normal underline position that should be used
     * @type {number}
     */
  }, {
    key: "underlinePosition",
    get: function() {
      return this.post.underlinePosition;
    }
    /**
     * The weight of the underline that should be used
     * @type {number}
     */
  }, {
    key: "underlineThickness",
    get: function() {
      return this.post.underlineThickness;
    }
    /**
     * If this is an italic font, the angle the cursor should be drawn at to match the font design
     * @type {number}
     */
  }, {
    key: "italicAngle",
    get: function() {
      return this.post.italicAngle;
    }
    /**
     * The height of capital letters above the baseline.
     * See [here](https://en.wikipedia.org/wiki/Cap_height) for more details.
     * @type {number}
     */
  }, {
    key: "capHeight",
    get: function() {
      var n = this["OS/2"];
      return n ? n.capHeight : this.ascent;
    }
    /**
     * The height of lower case letters in the font.
     * See [here](https://en.wikipedia.org/wiki/X-height) for more details.
     * @type {number}
     */
  }, {
    key: "xHeight",
    get: function() {
      var n = this["OS/2"];
      return n ? n.xHeight : 0;
    }
    /**
     * The number of glyphs in the font.
     * @type {number}
     */
  }, {
    key: "numGlyphs",
    get: function() {
      return this.maxp.numGlyphs;
    }
    /**
     * The size of the font’s internal coordinate grid
     * @type {number}
     */
  }, {
    key: "unitsPerEm",
    get: function() {
      return this.head.unitsPerEm;
    }
    /**
     * The font’s bounding box, i.e. the box that encloses all glyphs in the font.
     * @type {BBox}
     */
  }, {
    key: "bbox",
    get: function() {
      return Object.freeze(new zr(this.head.xMin, this.head.yMin, this.head.xMax, this.head.yMax));
    }
  }, {
    key: "_cmapProcessor",
    get: function() {
      return new Zv(this.cmap);
    }
    /**
     * An array of all of the unicode code points supported by the font.
     * @type {number[]}
     */
  }, {
    key: "characterSet",
    get: function() {
      return this._cmapProcessor.getCharacterSet();
    }
  }, {
    key: "_layoutEngine",
    get: function() {
      return new ab(this);
    }
  }, {
    key: "availableFeatures",
    get: function() {
      return this._layoutEngine.getAvailableFeatures();
    }
  }, {
    key: "variationAxes",
    get: function() {
      var n = {};
      if (!this.fvar)
        return n;
      for (var a = Fu(this.fvar.axis), o; !(o = a()).done; ) {
        var s = o.value;
        n[s.axisTag.trim()] = {
          name: s.name.en,
          min: s.minValue,
          default: s.defaultValue,
          max: s.maxValue
        };
      }
      return n;
    }
    /**
     * Returns an object describing the named variation instances
     * that the font designer has specified. Keys are variation names
     * and values are the variation settings for this instance.
     *
     * @type {object}
     */
  }, {
    key: "namedVariations",
    get: function() {
      var n = {};
      if (!this.fvar)
        return n;
      for (var a = Fu(this.fvar.instance), o; !(o = a()).done; ) {
        for (var s = o.value, u = {}, f = 0; f < this.fvar.axis.length; f++) {
          var l = this.fvar.axis[f];
          u[l.axisTag.trim()] = s.coord[f];
        }
        n[s.name.en] = u;
      }
      return n;
    }
  }, {
    key: "_variationProcessor",
    get: function() {
      if (!this.fvar)
        return null;
      var n = this.variationCoords;
      return !n && !this.CFF2 ? null : (n || (n = this.fvar.axis.map(function(a) {
        return a.defaultValue;
      })), new Xb(this, n));
    }
  }]), t;
})(), er(Fe.prototype, "bbox", [Ne], Object.getOwnPropertyDescriptor(Fe.prototype, "bbox"), Fe.prototype), er(Fe.prototype, "_cmapProcessor", [Ne], Object.getOwnPropertyDescriptor(Fe.prototype, "_cmapProcessor"), Fe.prototype), er(Fe.prototype, "characterSet", [Ne], Object.getOwnPropertyDescriptor(Fe.prototype, "characterSet"), Fe.prototype), er(Fe.prototype, "_layoutEngine", [Ne], Object.getOwnPropertyDescriptor(Fe.prototype, "_layoutEngine"), Fe.prototype), er(Fe.prototype, "variationAxes", [Ne], Object.getOwnPropertyDescriptor(Fe.prototype, "variationAxes"), Fe.prototype), er(Fe.prototype, "namedVariations", [Ne], Object.getOwnPropertyDescriptor(Fe.prototype, "namedVariations"), Fe.prototype), er(Fe.prototype, "_variationProcessor", [Ne], Object.getOwnPropertyDescriptor(Fe.prototype, "_variationProcessor"), Fe.prototype), Fe);
function l2(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = c2(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function c2(t, e) {
  if (t) {
    if (typeof t == "string") return Su(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Su(t, e);
  }
}
function Su(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
var h2 = new i.Struct({
  tag: new i.String(4),
  offset: new i.Pointer(i.uint32, "void", {
    type: "global"
  }),
  compLength: i.uint32,
  length: i.uint32,
  origChecksum: i.uint32
}), Al = new i.Struct({
  tag: new i.String(4),
  // should be 'wOFF'
  flavor: i.uint32,
  length: i.uint32,
  numTables: i.uint16,
  reserved: new i.Reserved(i.uint16),
  totalSfntSize: i.uint32,
  majorVersion: i.uint16,
  minorVersion: i.uint16,
  metaOffset: i.uint32,
  metaLength: i.uint32,
  metaOrigLength: i.uint32,
  privOffset: i.uint32,
  privLength: i.uint32,
  tables: new i.Array(h2, "numTables")
});
Al.process = function() {
  for (var t = {}, e = l2(this.tables), r; !(r = e()).done; ) {
    var n = r.value;
    t[n.tag] = n;
  }
  this.tables = t;
};
var mo = 0, El = -3;
function cn() {
  this.table = new Uint16Array(16), this.trans = new Uint16Array(288);
}
function p2(t, e) {
  this.source = t, this.sourceIndex = 0, this.tag = 0, this.bitcount = 0, this.dest = e, this.destLen = 0, this.ltree = new cn(), this.dtree = new cn();
}
var Cl = new cn(), Il = new cn(), bo = new Uint8Array(30), wo = new Uint16Array(30), Ol = new Uint8Array(30), Dl = new Uint16Array(30), d2 = new Uint8Array([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]), Au = new cn(), it = new Uint8Array(320);
function Tl(t, e, r, n) {
  var a, o;
  for (a = 0; a < r; ++a)
    t[a] = 0;
  for (a = 0; a < 30 - r; ++a)
    t[a + r] = a / r | 0;
  for (o = n, a = 0; a < 30; ++a)
    e[a] = o, o += 1 << t[a];
}
function v2(t, e) {
  var r;
  for (r = 0; r < 7; ++r)
    t.table[r] = 0;
  for (t.table[7] = 24, t.table[8] = 152, t.table[9] = 112, r = 0; r < 24; ++r)
    t.trans[r] = 256 + r;
  for (r = 0; r < 144; ++r)
    t.trans[24 + r] = r;
  for (r = 0; r < 8; ++r)
    t.trans[168 + r] = 280 + r;
  for (r = 0; r < 112; ++r)
    t.trans[176 + r] = 144 + r;
  for (r = 0; r < 5; ++r)
    e.table[r] = 0;
  for (e.table[5] = 32, r = 0; r < 32; ++r)
    e.trans[r] = r;
}
var Eu = new Uint16Array(16);
function aa(t, e, r, n) {
  var a, o;
  for (a = 0; a < 16; ++a)
    t.table[a] = 0;
  for (a = 0; a < n; ++a)
    t.table[e[r + a]]++;
  for (t.table[0] = 0, o = 0, a = 0; a < 16; ++a)
    Eu[a] = o, o += t.table[a];
  for (a = 0; a < n; ++a)
    e[r + a] && (t.trans[Eu[e[r + a]]++] = a);
}
function y2(t) {
  t.bitcount-- || (t.tag = t.source[t.sourceIndex++], t.bitcount = 7);
  var e = t.tag & 1;
  return t.tag >>>= 1, e;
}
function st(t, e, r) {
  if (!e) return r;
  for (; t.bitcount < 24; )
    t.tag |= t.source[t.sourceIndex++] << t.bitcount, t.bitcount += 8;
  var n = t.tag & 65535 >>> 16 - e;
  return t.tag >>>= e, t.bitcount -= e, n + r;
}
function Ca(t, e) {
  for (; t.bitcount < 24; )
    t.tag |= t.source[t.sourceIndex++] << t.bitcount, t.bitcount += 8;
  var r = 0, n = 0, a = 0, o = t.tag;
  do
    n = 2 * n + (o & 1), o >>>= 1, ++a, r += e.table[a], n -= e.table[a];
  while (n >= 0);
  return t.tag = o, t.bitcount -= a, e.trans[r + n];
}
function g2(t, e, r) {
  var n, a, o, s, u, f;
  for (n = st(t, 5, 257), a = st(t, 5, 1), o = st(t, 4, 4), s = 0; s < 19; ++s)
    it[s] = 0;
  for (s = 0; s < o; ++s) {
    var l = st(t, 3, 0);
    it[d2[s]] = l;
  }
  for (aa(Au, it, 0, 19), u = 0; u < n + a; ) {
    var c = Ca(t, Au);
    switch (c) {
      case 16:
        var p = it[u - 1];
        for (f = st(t, 2, 3); f; --f)
          it[u++] = p;
        break;
      case 17:
        for (f = st(t, 3, 3); f; --f)
          it[u++] = 0;
        break;
      case 18:
        for (f = st(t, 7, 11); f; --f)
          it[u++] = 0;
        break;
      default:
        it[u++] = c;
        break;
    }
  }
  aa(e, it, 0, n), aa(r, it, n, a);
}
function Cu(t, e, r) {
  for (; ; ) {
    var n = Ca(t, e);
    if (n === 256)
      return mo;
    if (n < 256)
      t.dest[t.destLen++] = n;
    else {
      var a, o, s, u;
      for (n -= 257, a = st(t, bo[n], wo[n]), o = Ca(t, r), s = t.destLen - st(t, Ol[o], Dl[o]), u = s; u < s + a; ++u)
        t.dest[t.destLen++] = t.dest[u];
    }
  }
}
function m2(t) {
  for (var e, r, n; t.bitcount > 8; )
    t.sourceIndex--, t.bitcount -= 8;
  if (e = t.source[t.sourceIndex + 1], e = 256 * e + t.source[t.sourceIndex], r = t.source[t.sourceIndex + 3], r = 256 * r + t.source[t.sourceIndex + 2], e !== (~r & 65535)) return El;
  for (t.sourceIndex += 4, n = e; n; --n)
    t.dest[t.destLen++] = t.source[t.sourceIndex++];
  return t.bitcount = 0, mo;
}
function b2(t, e) {
  var r = new p2(t, e), n, a, o;
  do {
    switch (n = y2(r), a = st(r, 2, 0), a) {
      case 0:
        o = m2(r);
        break;
      case 1:
        o = Cu(r, Cl, Il);
        break;
      case 2:
        g2(r, r.ltree, r.dtree), o = Cu(r, r.ltree, r.dtree);
        break;
      default:
        o = El;
    }
    if (o !== mo) throw new Error("Data error");
  } while (!n);
  return r.destLen < r.dest.length ? typeof r.dest.slice == "function" ? r.dest.slice(0, r.destLen) : r.dest.subarray(0, r.destLen) : r.dest;
}
v2(Cl, Il);
Tl(bo, wo, 4, 3);
Tl(Ol, Dl, 2, 1);
bo[28] = 0;
wo[28] = 258;
var w2 = b2;
function F2(t, e) {
  t.prototype = Object.create(e.prototype), t.prototype.constructor = t, t.__proto__ = e;
}
var x2 = /* @__PURE__ */ (function(t) {
  F2(e, t);
  function e() {
    return t.apply(this, arguments) || this;
  }
  e.probe = function(a) {
    return a.toString("ascii", 0, 4) === "wOFF";
  };
  var r = e.prototype;
  return r._decodeDirectory = function() {
    this.directory = Al.decode(this.stream, {
      _startOffset: 0
    });
  }, r._getTableStream = function(a) {
    var o = this.directory.tables[a];
    if (o)
      if (this.stream.pos = o.offset, o.compLength < o.length) {
        this.stream.pos += 2;
        var s = new pe(o.length), u = w2(this.stream.readBuffer(o.compLength - 2), s);
        return new i.DecodeStream(u);
      } else
        return this.stream;
    return null;
  }, e;
})(pr);
function Pl(t) {
  this.buffer = t, this.pos = 0;
}
Pl.prototype.read = function(t, e, r) {
  this.pos + r > this.buffer.length && (r = this.buffer.length - this.pos);
  for (var n = 0; n < r; n++)
    t[e + n] = this.buffer[this.pos + n];
  return this.pos += r, r;
};
var S2 = Pl;
function Bl(t) {
  this.buffer = t, this.pos = 0;
}
Bl.prototype.write = function(t, e) {
  if (this.pos + e > this.buffer.length) throw new Error("Output buffer is not large enough");
  return this.buffer.set(t.subarray(0, e), this.pos), this.pos += e, e;
};
var A2 = Bl, kl = {
  BrotliInput: S2,
  BrotliOutput: A2
}, ur = 4096, E2 = 2 * ur + 32, Ll = 2 * ur - 1, C2 = new Uint32Array([0, 1, 3, 7, 15, 31, 63, 127, 255, 511, 1023, 2047, 4095, 8191, 16383, 32767, 65535, 131071, 262143, 524287, 1048575, 2097151, 4194303, 8388607, 16777215]);
function yr(t) {
  this.buf_ = new Uint8Array(E2), this.input_ = t, this.reset();
}
yr.READ_SIZE = ur;
yr.IBUF_MASK = Ll;
yr.prototype.reset = function() {
  this.buf_ptr_ = 0, this.val_ = 0, this.pos_ = 0, this.bit_pos_ = 0, this.bit_end_pos_ = 0, this.eos_ = 0, this.readMoreInput();
  for (var t = 0; t < 4; t++)
    this.val_ |= this.buf_[this.pos_] << 8 * t, ++this.pos_;
  return this.bit_end_pos_ > 0;
};
yr.prototype.readMoreInput = function() {
  if (!(this.bit_end_pos_ > 256))
    if (this.eos_) {
      if (this.bit_pos_ > this.bit_end_pos_) throw new Error("Unexpected end of input " + this.bit_pos_ + " " + this.bit_end_pos_);
    } else {
      var t = this.buf_ptr_, e = this.input_.read(this.buf_, t, ur);
      if (e < 0)
        throw new Error("Unexpected end of input");
      if (e < ur) {
        this.eos_ = 1;
        for (var r = 0; r < 32; r++)
          this.buf_[t + e + r] = 0;
      }
      if (t === 0) {
        for (var r = 0; r < 32; r++)
          this.buf_[(ur << 1) + r] = this.buf_[r];
        this.buf_ptr_ = ur;
      } else
        this.buf_ptr_ = 0;
      this.bit_end_pos_ += e << 3;
    }
};
yr.prototype.fillBitWindow = function() {
  for (; this.bit_pos_ >= 8; )
    this.val_ >>>= 8, this.val_ |= this.buf_[this.pos_ & Ll] << 24, ++this.pos_, this.bit_pos_ = this.bit_pos_ - 8 >>> 0, this.bit_end_pos_ = this.bit_end_pos_ - 8 >>> 0;
};
yr.prototype.readBits = function(t) {
  32 - this.bit_pos_ < t && this.fillBitWindow();
  var e = this.val_ >>> this.bit_pos_ & C2[t];
  return this.bit_pos_ += t, e;
};
var Lr = yr, I2 = B2, O2 = L2, D2 = N2, ct = [], Ze = [], T2 = typeof Uint8Array < "u" ? Uint8Array : Array, oa = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
for (var Sr = 0, P2 = oa.length; Sr < P2; ++Sr)
  ct[Sr] = oa[Sr], Ze[oa.charCodeAt(Sr)] = Sr;
Ze[45] = 62;
Ze[95] = 63;
function Ml(t) {
  var e = t.length;
  if (e % 4 > 0)
    throw new Error("Invalid string. Length must be a multiple of 4");
  var r = t.indexOf("=");
  r === -1 && (r = e);
  var n = r === e ? 0 : 4 - r % 4;
  return [r, n];
}
function B2(t) {
  var e = Ml(t), r = e[0], n = e[1];
  return (r + n) * 3 / 4 - n;
}
function k2(t, e, r) {
  return (e + r) * 3 / 4 - r;
}
function L2(t) {
  for (var e, r = Ml(t), n = r[0], a = r[1], o = new T2(k2(t, n, a)), s = 0, u = a > 0 ? n - 4 : n, f = 0; f < u; f += 4)
    e = Ze[t.charCodeAt(f)] << 18 | Ze[t.charCodeAt(f + 1)] << 12 | Ze[t.charCodeAt(f + 2)] << 6 | Ze[t.charCodeAt(f + 3)], o[s++] = e >> 16 & 255, o[s++] = e >> 8 & 255, o[s++] = e & 255;
  return a === 2 && (e = Ze[t.charCodeAt(f)] << 2 | Ze[t.charCodeAt(f + 1)] >> 4, o[s++] = e & 255), a === 1 && (e = Ze[t.charCodeAt(f)] << 10 | Ze[t.charCodeAt(f + 1)] << 4 | Ze[t.charCodeAt(f + 2)] >> 2, o[s++] = e >> 8 & 255, o[s++] = e & 255), o;
}
function M2(t) {
  return ct[t >> 18 & 63] + ct[t >> 12 & 63] + ct[t >> 6 & 63] + ct[t & 63];
}
function U2(t, e, r) {
  for (var n, a = [], o = e; o < r; o += 3)
    n = (t[o] << 16 & 16711680) + (t[o + 1] << 8 & 65280) + (t[o + 2] & 255), a.push(M2(n));
  return a.join("");
}
function N2(t) {
  for (var e, r = t.length, n = r % 3, a = [], o = 16383, s = 0, u = r - n; s < u; s += o)
    a.push(U2(t, s, s + o > u ? u : s + o));
  return n === 1 ? (e = t[r - 1], a.push(ct[e >> 2] + ct[e << 4 & 63] + "==")) : n === 2 && (e = (t[r - 2] << 8) + t[r - 1], a.push(ct[e >> 10] + ct[e >> 4 & 63] + ct[e << 2 & 63] + "=")), a.join("");
}
var R2 = {
  byteLength: I2,
  toByteArray: O2,
  fromByteArray: D2
}, z2 = "W5/fcQLn5gKf2XUbAiQ1XULX+TZz6ADToDsgqk6qVfeC0e4m6OO2wcQ1J76ZBVRV1fRkEsdu//62zQsFEZWSTCnMhcsQKlS2qOhuVYYMGCkV0fXWEoMFbESXrKEZ9wdUEsyw9g4bJlEt1Y6oVMxMRTEVbCIwZzJzboK5j8m4YH02qgXYhv1V+PM435sLVxyHJihaJREEhZGqL03txGFQLm76caGO/ovxKvzCby/3vMTtX/459f0igi7WutnKiMQ6wODSoRh/8Lx1V3Q99MvKtwB6bHdERYRY0hStJoMjNeTsNX7bn+Y7e4EQ3bf8xBc7L0BsyfFPK43dGSXpL6clYC/I328h54/VYrQ5i0648FgbGtl837svJ35L3Mot/+nPlNpWgKx1gGXQYqX6n+bbZ7wuyCHKcUok12Xjqub7NXZGzqBx0SD+uziNf87t7ve42jxSKQoW3nyxVrWIGlFShhCKxjpZZ5MeGna0+lBkk+kaN8F9qFBAFgEogyMBdcX/T1W/WnMOi/7ycWUQloEBKGeC48MkiwqJkJO+12eQiOFHMmck6q/IjWW3RZlany23TBm+cNr/84/oi5GGmGBZWrZ6j+zykVozz5fT/QH/Da6WTbZYYPynVNO7kxzuNN2kxKKWche5WveitPKAecB8YcAHz/+zXLjcLzkdDSktNIDwZE9J9X+tto43oJy65wApM3mDzYtCwX9lM+N5VR3kXYo0Z3t0TtXfgBFg7gU8oN0Dgl7fZlUbhNll+0uuohRVKjrEd8egrSndy5/Tgd2gqjA4CAVuC7ESUmL3DZoGnfhQV8uwnpi8EGvAVVsowNRxPudck7+oqAUDkwZopWqFnW1riss0t1z6iCISVKreYGNvQcXv+1L9+jbP8cd/dPUiqBso2q+7ZyFBvENCkkVr44iyPbtOoOoCecWsiuqMSML5lv+vN5MzUr+Dnh73G7Q1YnRYJVYXHRJaNAOByiaK6CusgFdBPE40r0rvqXV7tksKO2DrHYXBTv8P5ysqxEx8VDXUDDqkPH6NNOV/a2WH8zlkXRELSa8P+heNyJBBP7PgsG1EtWtNef6/i+lcayzQwQCsduidpbKfhWUDgAEmyhGu/zVTacI6RS0zTABrOYueemnVa19u9fT23N/Ta6RvTpof5DWygqreCqrDAgM4LID1+1T/taU6yTFVLqXOv+/MuQOFnaF8vLMKD7tKWDoBdALgxF33zQccCcdHx8fKIVdW69O7qHtXpeGr9jbbpFA+qRMWr5hp0s67FPc7HAiLV0g0/peZlW7hJPYEhZyhpSwahnf93/tZgfqZWXFdmdXBzqxGHLrQKxoAY6fRoBhgCRPmmGueYZ5JexTVDKUIXzkG/fqp/0U3hAgQdJ9zumutK6nqWbaqvm1pgu03IYR+G+8s0jDBBz8cApZFSBeuWasyqo2OMDKAZCozS+GWSvL/HsE9rHxooe17U3s/lTE+VZAk4j3dp6uIGaC0JMiqR5CUsabPyM0dOYDR7Ea7ip4USZlya38YfPtvrX/tBlhHilj55nZ1nfN24AOAi9BVtz/Mbn8AEDJCqJgsVUa6nQnSxv2Fs7l/NlCzpfYEjmPrNyib/+t0ei2eEMjvNhLkHCZlci4WhBe7ePZTmzYqlY9+1pxtS4GB+5lM1BHT9tS270EWUDYFq1I0yY/fNiAk4bk9yBgmef/f2k6AlYQZHsNFnW8wBQxCd68iWv7/35bXfz3JZmfGligWAKRjIs3IpzxQ27vAglHSiOzCYzJ9L9A1CdiyFvyR66ucA4jKifu5ehwER26yV7HjKqn5Mfozo7Coxxt8LWWPT47BeMxX8p0Pjb7hZn+6bw7z3Lw+7653j5sI8CLu5kThpMlj1m4c2ch3jGcP1FsT13vuK3qjecKTZk2kHcOZY40UX+qdaxstZqsqQqgXz+QGF99ZJLqr3VYu4aecl1Ab5GmqS8k/GV5b95zxQ5d4EfXUJ6kTS/CXF/aiqKDOT1T7Jz5z0PwDUcwr9clLN1OJGCiKfqvah+h3XzrBOiLOW8wvn8gW6qE8vPxi+Efv+UH55T7PQFVMh6cZ1pZQlzJpKZ7P7uWvwPGJ6DTlR6wbyj3Iv2HyefnRo/dv7dNx+qaa0N38iBsR++Uil7Wd4afwDNsrzDAK4fXZwvEY/jdKuIKXlfrQd2C39dW7ntnRbIp9OtGy9pPBn/V2ASoi/2UJZfS+xuGLH8bnLuPlzdTNS6zdyk8Dt/h6sfOW5myxh1f+zf3zZ3MX/mO9cQPp5pOx967ZA6/pqHvclNfnUFF+rq+Vd7alKr6KWPcIDhpn6v2K6NlUu6LrKo8b/pYpU/Gazfvtwhn7tEOUuXht5rUJdSf6sLjYf0VTYDgwJ81yaqKTUYej/tbHckSRb/HZicwGJqh1mAHB/IuNs9dc9yuvF3D5Xocm3elWFdq5oEy70dYFit79yaLiNjPj5UUcVmZUVhQEhW5V2Z6Cm4HVH/R8qlamRYwBileuh07CbEce3TXa2JmXWBf+ozt319psboobeZhVnwhMZzOeQJzhpTDbP71Tv8HuZxxUI/+ma3XW6DFDDs4+qmpERwHGBd2edxwUKlODRdUWZ/g0GOezrbzOZauFMai4QU6GVHV6aPNBiBndHSsV4IzpvUiiYyg6OyyrL4Dj5q/Lw3N5kAwftEVl9rNd7Jk5PDij2hTH6wIXnsyXkKePxbmHYgC8A6an5Fob/KH5GtC0l4eFso+VpxedtJHdHpNm+Bvy4C79yVOkrZsLrQ3OHCeB0Ra+kBIRldUGlDCEmq2RwXnfyh6Dz+alk6eftI2n6sastRrGwbwszBeDRS/Fa/KwRJkCzTsLr/JCs5hOPE/MPLYdZ1F1fv7D+VmysX6NpOC8aU9F4Qs6HvDyUy9PvFGDKZ/P5101TYHFl8pjj6wm/qyS75etZhhfg0UEL4OYmHk6m6dO192AzoIyPSV9QedDA4Ml23rRbqxMPMxf7FJnDc5FTElVS/PyqgePzmwVZ26NWhRDQ+oaT7ly7ell4s3DypS1s0g+tOr7XHrrkZj9+x/mJBttrLx98lFIaRZzHz4aC7r52/JQ4VjHahY2/YVXZn/QC2ztQb/sY3uRlyc5vQS8nLPGT/n27495i8HPA152z7Fh5aFpyn1GPJKHuPL8Iw94DuW3KjkURAWZXn4EQy89xiKEHN1mk/tkM4gYDBxwNoYvRfE6LFqsxWJtPrDGbsnLMap3Ka3MUoytW0cvieozOmdERmhcqzG+3HmZv2yZeiIeQTKGdRT4HHNxekm1tY+/n06rGmFleqLscSERzctTKM6G9P0Pc1RmVvrascIxaO1CQCiYPE15bD7c3xSeW7gXxYjgxcrUlcbIvO0r+Yplhx0kTt3qafDOmFyMjgGxXu73rddMHpV1wMubyAGcf/v5dLr5P72Ta9lBF+fzMJrMycwv+9vnU3ANIl1cH9tfW7af8u0/HG0vV47jNFXzFTtaha1xvze/s8KMtCYucXc1nzfd/MQydUXn/b72RBt5wO/3jRcMH9BdhC/yctKBIveRYPrNpDWqBsO8VMmP+WvRaOcA4zRMR1PvSoO92rS7pYEv+fZfEfTMzEdM+6X5tLlyxExhqLRkms5EuLovLfx66de5fL2/yX02H52FPVwahrPqmN/E0oVXnsCKhbi/yRxX83nRbUKWhzYceXOntfuXn51NszJ6MO73pQf5Pl4in3ec4JU8hF7ppV34+mm9r1LY0ee/i1O1wpd8+zfLztE0cqBxggiBi5Bu95v9l3r9r/U5hweLn+TbfxowrWDqdJauKd8+q/dH8sbPkc9ttuyO94f7/XK/nHX46MPFLEb5qQlNPvhJ50/59t9ft3LXu7uVaWaO2bDrDCnRSzZyWvFKxO1+vT8MwwunR3bX0CkfPjqb4K9O19tn5X50PvmYpEwHtiW9WtzuV/s76B1zvLLNkViNd8ySxIl/3orfqP90TyTGaf7/rx8jQzeHJXdmh/N6YDvbvmTBwCdxfEQ1NcL6wNMdSIXNq7b1EUzRy1/Axsyk5p22GMG1b+GxFgbHErZh92wuvco0AuOLXct9hvw2nw/LqIcDRRmJmmZzcgUa7JpM/WV/S9IUfbF56TL2orzqwebdRD8nIYNJ41D/hz37Fo11p2Y21wzPcn713qVGhqtevStYfGH4n69OEJtPvbbLYWvscDqc3Hgnu166+tAyLnxrX0Y5zoYjV++1sI7t5kMr02KT/+uwtkc+rZLOf/qn/s3nYCf13Dg8/sB2diJgjGqjQ+TLhxbzyue2Ob7X6/9lUwW7a+lbznHzOYy8LKW1C/uRPbQY3KW/0gO9LXunHLvPL97afba9bFtc9hmz7GAttjVYlCvQAiOwAk/gC5+hkLEs6tr3AZKxLJtOEwk2dLxTYWsIB/j/ToWtIWzo906FrSG8iaqqqqqqiIiIiAgzMzMzNz+AyK+01/zi8n8S+Y1MjoRaQ80WU/G8MBlO+53VPXANrWm4wzGUVZUjjBJZVdhpcfkjsmcWaO+UEldXi1e+zq+HOsCpknYshuh8pOLISJun7TN0EIGW2xTnlOImeecnoGW4raxe2G1T3HEvfYUYMhG+gAFOAwh5nK8mZhwJMmN7r224QVsNFvZ87Z0qatvknklyPDK3Hy45PgVKXji52Wen4d4PlFVVYGnNap+fSpFbK90rYnhUc6n91Q3AY9E0tJOFrcfZtm/491XbcG/jsViUPPX76qmeuiz+qY1Hk7/1VPM405zWVuoheLUimpWYdVzCmUdKHebMdzgrYrb8mL2eeLSnRWHdonfZa8RsOU9F37w+591l5FLYHiOqWeHtE/lWrBHcRKp3uhtr8yXm8LU/5ms+NM6ZKsqu90cFZ4o58+k4rdrtB97NADFbwmEG7lXqvirhOTOqU14xuUF2myIjURcPHrPOQ4lmM3PeMg7bUuk0nnZi67bXsU6H8lhqIo8TaOrEafCO1ARK9PjC0QOoq2BxmMdgYB9G/lIb9++fqNJ2s7BHGFyBNmZAR8J3KCo012ikaSP8BCrf6VI0X5xdnbhHIO+B5rbOyB54zXkzfObyJ4ecwxfqBJMLFc7m59rNcw7hoHnFZ0b00zee+gTqvjm61Pb4xn0kcDX4jvHM0rBXZypG3DCKnD/Waa/ZtHmtFPgO5eETx+k7RrVg3aSwm2YoNXnCs3XPQDhNn+Fia6IlOOuIG6VJH7TP6ava26ehKHQa2T4N0tcZ9dPCGo3ZdnNltsHQbeYt5vPnJezV/cAeNypdml1vCHI8M81nSRP5Qi2+mI8v/sxiZru9187nRtp3f/42NemcONa+4eVC3PCZzc88aZh851CqSsshe70uPxeN/dmYwlwb3trwMrN1Gq8jbnApcVDx/yDPeYs5/7r62tsQ6lLg+DiFXTEhzR9dHqv0iT4tgj825W+H3XiRUNUZT2kR9Ri0+lp+UM3iQtS8uOE23Ly4KYtvqH13jghUntJRAewuzNLDXp8RxdcaA3cMY6TO2IeSFRXezeWIjCqyhsUdMYuCgYTZSKpBype1zRfq8FshvfBPc6BAQWl7/QxIDp3VGo1J3vn42OEs3qznws+YLRXbymyB19a9XBx6n/owcyxlEYyFWCi+kG9F+EyD/4yn80+agaZ9P7ay2Dny99aK2o91FkfEOY8hBwyfi5uwx2y5SaHmG+oq/zl1FX/8irOf8Y3vAcX/6uLP6A6nvMO24edSGPjQc827Rw2atX+z2bKq0CmW9mOtYnr5/AfDa1ZfPaXnKtlWborup7QYx+Or2uWb+N3N//2+yDcXMqIJdf55xl7/vsj4WoPPlxLxtVrkJ4w/tTe3mLdATOOYwxcq52w5Wxz5MbPdVs5O8/lhfE7dPj0bIiPQ3QV0iqm4m3YX8hRfc6jQ3fWepevMqUDJd86Z4vwM40CWHnn+WphsGHfieF02D3tmZvpWD+kBpNCFcLnZhcmmrhpGzzbdA+sQ1ar18OJD87IOKOFoRNznaHPNHUfUNhvY1iU+uhvEvpKHaUn3qK3exVVyX4joipp3um7FmYJWmA+WbIDshRpbVRx5/nqstCgy87FGbfVB8yDGCqS+2qCsnRwnSAN6zgzxfdB2nBT/vZ4/6uxb6oH8b4VBRxiIB93wLa47hG3w2SL/2Z27yOXJFwZpSJaBYyvajA7vRRYNKqljXKpt/CFD/tSMr18DKKbwB0xggBePatl1nki0yvqW5zchlyZmJ0OTxJ3D+fsYJs/mxYN5+Le5oagtcl+YsVvy8kSjI2YGvGjvmpkRS9W2dtXqWnVuxUhURm1lKtou/hdEq19VBp9OjGvHEQSmrpuf2R24mXGheil8KeiANY8fW1VERUfBImb64j12caBZmRViZHbeVMjCrPDg9A90IXrtnsYCuZtRQ0PyrKDjBNOsPfKsg1pA02gHlVr0OXiFhtp6nJqXVzcbfM0KnzC3ggOENPE9VBdmHKN6LYaijb4wXxJn5A0FSDF5j+h1ooZx885Jt3ZKzO5n7Z5WfNEOtyyPqQEnn7WLv5Fis3PdgMshjF1FRydbNyeBbyKI1oN1TRVrVK7kgsb/zjX4NDPIRMctVeaxVB38Vh1x5KbeJbU138AM5KzmZu3uny0ErygxiJF7GVXUrPzFxrlx1uFdAaZFDN9cvIb74qD9tzBMo7L7WIEYK+sla1DVMHpF0F7b3+Y6S+zjvLeDMCpapmJo1weBWuxKF3rOocih1gun4BoJh1kWnV/Jmiq6uOhK3VfKxEHEkafjLgK3oujaPzY6SXg8phhL4TNR1xvJd1Wa0aYFfPUMLrNBDCh4AuGRTbtKMc6Z1Udj8evY/ZpCuMAUefdo69DZUngoqE1P9A3PJfOf7WixCEj+Y6t7fYeHbbxUAoFV3M89cCKfma3fc1+jKRe7MFWEbQqEfyzO2x/wrO2VYH7iYdQ9BkPyI8/3kXBpLaCpU7eC0Yv/am/tEDu7HZpqg0EvHo0nf/R/gRzUWy33/HXMJQeu1GylKmOkXzlCfGFruAcPPhaGqZOtu19zsJ1SO2Jz4Ztth5cBX6mRQwWmDwryG9FUMlZzNckMdK+IoMJv1rOWnBamS2w2KHiaPMPLC15hCZm4KTpoZyj4E2TqC/P6r7/EhnDMhKicZZ1ZwxuC7DPzDGs53q8gXaI9kFTK+2LTq7bhwsTbrMV8Rsfua5lMS0FwbTitUVnVa1yTb5IX51mmYnUcP9wPr8Ji1tiYJeJV9GZTrQhF7vvdU2OTU42ogJ9FDwhmycI2LIg++03C6scYhUyUuMV5tkw6kGUoL+mjNC38+wMdWNljn6tGPpRES7veqrSn5TRuv+dh6JVL/iDHU1db4c9WK3++OrH3PqziF916UMUKn8G67nN60GfWiHrXYhUG3yVWmyYak59NHj8t1smG4UDiWz2rPHNrKnN4Zo1LBbr2/eF9YZ0n0blx2nG4X+EKFxvS3W28JESD+FWk61VCD3z/URGHiJl++7TdBwkCj6tGOH3qDb0QqcOF9Kzpj0HUb/KyFW3Yhj2VMKJqGZleFBH7vqvf7WqLC3XMuHV8q8a4sTFuxUtkD/6JIBvKaVjv96ndgruKZ1k/BHzqf2K9fLk7HGXANyLDd1vxkK/i055pnzl+zw6zLnwXlVYVtfmacJgEpRP1hbGgrYPVN6v2lG+idQNGmwcKXu/8xEj/P6qe/sB2WmwNp6pp8jaISMkwdleFXYK55NHWLTTbutSUqjBfDGWo/Yg918qQ+8BRZSAHZbfuNZz2O0sov1Ue4CWlVg3rFhM3Kljj9ksGd/NUhk4nH+a5UN2+1i8+NM3vRNp7uQ6sqexSCukEVlVZriHNqFi5rLm9TMWa4qm3idJqppQACol2l4VSuvWLfta4JcXy3bROPNbXOgdOhG47LC0CwW/dMlSx4Jf17aEU3yA1x9p+Yc0jupXgcMuYNku64iYOkGToVDuJvlbEKlJqsmiHbvNrIVZEH+yFdF8DbleZ6iNiWwMqvtMp/mSpwx5KxRrT9p3MAPTHGtMbfvdFhyj9vhaKcn3At8Lc16Ai+vBcSp1ztXi7rCJZx/ql7TXcclq6Q76UeKWDy9boS0WHIjUuWhPG8LBmW5y2rhuTpM5vsLt+HOLh1Yf0DqXa9tsfC+kaKt2htA0ai/L2i7RKoNjEwztkmRU0GfgW1TxUvPFhg0V7DdfWJk5gfrccpYv+MA9M0dkGTLECeYwUixRzjRFdmjG7zdZIl3XKB9YliNKI31lfa7i2JG5C8Ss+rHe0D7Z696/V3DEAOWHnQ9yNahMUl5kENWS6pHKKp2D1BaSrrHdE1w2qNxIztpXgUIrF0bm15YML4b6V1k+GpNysTahKMVrrS85lTVo9OGJ96I47eAy5rYWpRf/mIzeoYU1DKaQCTUVwrhHeyNoDqHel+lLxr9WKzhSYw7vrR6+V5q0pfi2k3L1zqkubY6rrd9ZLvSuWNf0uqnkY+FpTvFzSW9Fp0b9l8JA7THV9eCi/PY/SCZIUYx3BU2alj7Cm3VV6eYpios4b6WuNOJdYXUK3zTqj5CVG2FqYM4Z7CuIU0qO05XR0d71FHM0YhZmJmTRfLlXEumN82BGtzdX0S19t1e+bUieK8zRmqpa4Qc5TSjifmaQsY2ETLjhI36gMR1+7qpjdXXHiceUekfBaucHShAOiFXmv3sNmGQyU5iVgnoocuonQXEPTFwslHtS8R+A47StI9wj0iSrtbi5rMysczFiImsQ+bdFClnFjjpXXwMy6O7qfjOr8Fb0a7ODItisjnn3EQO16+ypd1cwyaAW5Yzxz5QknfMO7643fXW/I9y3U2xH27Oapqr56Z/tEzglj6IbT6HEHjopiXqeRbe5mQQvxtcbDOVverN0ZgMdzqRYRjaXtMRd56Q4cZSmdPvZJdSrhJ1D9zNXPqAEqPIavPdfubt5oke2kmv0dztIszSv2VYuoyf1UuopbsYb+uX9h6WpwjpgtZ6fNNawNJ4q8O3CFoSbioAaOSZMx2GYaPYB+rEb6qjQiNRFQ76TvwNFVKD+BhH9VhcKGsXzmMI7BptU/CNWolM7YzROvpFAntsiWJp6eR2d3GarcYShVYSUqhmYOWj5E96NK2WvmYNTeY7Zs4RUEdv9h9QT4EseKt6LzLrqEOs3hxAY1MaNWpSa6zZx8F3YOVeCYMS88W+CYHDuWe4yoc6YK+djDuEOrBR5lvh0r+Q9uM88lrjx9x9AtgpQVNE8r+3O6Gvw59D+kBF/UMXyhliYUtPjmvXGY6Dk3x+kEOW+GtdMVC4EZTqoS/jmR0P0LS75DOc/w2vnri97M4SdbZ8qeU7gg8DVbERkU5geaMQO3mYrSYyAngeUQqrN0C0/vsFmcgWNXNeidsTAj7/4MncJR0caaBUpbLK1yBCBNRjEv6KvuVSdpPnEMJdsRRtqJ+U8tN1gXA4ePHc6ZT0eviI73UOJF0fEZ8YaneAQqQdGphNvwM4nIqPnXxV0xA0fnCT+oAhJuyw/q8jO0y8CjSteZExwBpIN6SvNp6A5G/abi6egeND/1GTguhuNjaUbbnSbGd4L8937Ezm34Eyi6n1maeOBxh3PI0jzJDf5mh/BsLD7F2GOKvlA/5gtvxI3/eV4sLfKW5Wy+oio+es/u6T8UU+nsofy57Icb/JlZHPFtCgd/x+bwt3ZT+xXTtTtTrGAb4QehC6X9G+8YT+ozcLxDsdCjsuOqwPFnrdLYaFc92Ui0m4fr39lYmlCaqTit7G6O/3kWDkgtXjNH4BiEm/+jegQnihOtfffn33WxsFjhfMd48HT+f6o6X65j7XR8WLSHMFkxbvOYsrRsF1bowDuSQ18Mkxk4qz2zoGPL5fu9h2Hqmt1asl3Q3Yu3szOc+spiCmX4AETBM3pLoTYSp3sVxahyhL8eC4mPN9k2x3o0xkiixIzM3CZFzf5oR4mecQ5+ax2wCah3/crmnHoqR0+KMaOPxRif1oEFRFOO/kTPPmtww+NfMXxEK6gn6iU32U6fFruIz8Q4WgljtnaCVTBgWx7diUdshC9ZEa5yKpRBBeW12r/iNc/+EgNqmhswNB8SBoihHXeDF7rrWDLcmt3V8GYYN7pXRy4DZjj4DJuUBL5iC3DQAaoo4vkftqVTYRGLS3mHZ7gdmdTTqbgNN/PTdTCOTgXolc88MhXAEUMdX0iy1JMuk5wLsgeu0QUYlz2S4skTWwJz6pOm/8ihrmgGfFgri+ZWUK2gAPHgbWa8jaocdSuM4FJYoKicYX/ZSENkg9Q1ZzJfwScfVnR2DegOGwCvmogaWJCLQepv9WNlU6QgsmOwICquU28Mlk3d9W5E81lU/5Ez0LcX6lwKMWDNluNKfBDUy/phJgBcMnfkh9iRxrdOzgs08JdPB85Lwo+GUSb4t3nC+0byqMZtO2fQJ4U2zGIr49t/28qmmGv2RanDD7a3FEcdtutkW8twwwlUSpb8QalodddbBfNHKDQ828BdE7OBgFdiKYohLawFYqpybQoxATZrheLhdI7+0Zlu9Q1myRcd15r9UIm8K2LGJxqTegntqNVMKnf1a8zQiyUR1rxoqjiFxeHxqFcYUTHfDu7rhbWng6qOxOsI+5A1p9mRyEPdVkTlE24vY54W7bWc6jMgZvNXdfC9/9q7408KDsbdL7Utz7QFSDetz2picArzrdpL8OaCHC9V26RroemtDZ5yNM/KGkWMyTmfnInEvwtSD23UcFcjhaE3VKzkoaEMKGBft4XbIO6forTY1lmGQwVmKicBCiArDzE+1oIxE08fWeviIOD5TznqH+OoHadvoOP20drMPe5Irg3XBQziW2XDuHYzjqQQ4wySssjXUs5H+t3FWYMHppUnBHMx/nYIT5d7OmjDbgD9F6na3m4l7KdkeSO3kTEPXafiWinogag7b52taiZhL1TSvBFmEZafFq2H8khQaZXuitCewT5FBgVtPK0j4xUHPfUz3Q28eac1Z139DAP23dgki94EC8vbDPTQC97HPPSWjUNG5tWKMsaxAEMKC0665Xvo1Ntd07wCLNf8Q56mrEPVpCxlIMVlQlWRxM3oAfpgIc+8KC3rEXUog5g06vt7zgXY8grH7hhwVSaeuvC06YYRAwpbyk/Unzj9hLEZNs2oxPQB9yc+GnL6zTgq7rI++KDJwX2SP8Sd6YzTuw5lV/kU6eQxRD12omfQAW6caTR4LikYkBB1CMOrvgRr/VY75+NSB40Cni6bADAtaK+vyxVWpf9NeKJxN2KYQ8Q2xPB3K1s7fuhvWbr2XpgW044VD6DRs0qXoqKf1NFsaGvKJc47leUV3pppP/5VTKFhaGuol4Esfjf5zyCyUHmHthChcYh4hYLQF+AFWsuq4t0wJyWgdwQVOZiV0efRHPoK5+E1vjz9wTJmVkITC9oEstAsyZSgE/dbicwKr89YUxKZI+owD205Tm5lnnmDRuP/JnzxX3gMtlrcX0UesZdxyQqYQuEW4R51vmQ5xOZteUd8SJruMlTUzhtVw/Nq7eUBcqN2/HVotgfngif60yKEtoUx3WYOZlVJuJOh8u59fzSDPFYtQgqDUAGyGhQOAvKroXMcOYY0qjnStJR/G3aP+Jt1sLVlGV8POwr/6OGsqetnyF3TmTqZjENfnXh51oxe9qVUw2M78EzAJ+IM8lZ1MBPQ9ZWSVc4J3mWSrLKrMHReA5qdGoz0ODRsaA+vwxXA2cAM4qlfzBJA6581m4hzxItQw5dxrrBL3Y6kCbUcFxo1S8jyV44q//+7ASNNudZ6xeaNOSIUffqMn4A9lIjFctYn2gpEPAb3f7p3iIBN8H14FUGQ9ct2hPsL+cEsTgUrR47uJVN4n4wt/wgfwwHuOnLd4yobkofy8JvxSQTA7rMpDIc608SlZFJfZYcmbT0tAHpPE8MrtQ42siTUNWxqvWZOmvu9f0JPoQmg+6l7sZWwyfi6PXkxJnwBraUG0MYG4zYHQz3igy/XsFkx5tNQxw43qvI9dU3f0DdhOUlHKjmi1VAr2Kiy0HZwD8VeEbhh0OiDdMYspolQsYdSwjCcjeowIXNZVUPmL2wwIkYhmXKhGozdCJ4lRKbsf4NBh/XnQoS92NJEWOVOFs2YhN8c5QZFeK0pRdAG40hqvLbmoSA8xQmzOOEc7wLcme9JOsjPCEgpCwUs9E2DohMHRhUeyGIN6TFvrbny8nDuilsDpzrH5mS76APoIEJmItS67sQJ+nfwddzmjPxcBEBBCw0kWDwd0EZCkNeOD7NNQhtBm7KHL9mRxj6U1yWU2puzlIDtpYxdH4ZPeXBJkTGAJfUr/oTCz/iypY6uXaR2V1doPxJYlrw2ghH0D5gbrhFcIxzYwi4a/4hqVdf2DdxBp6vGYDjavxMAAoy+1+3aiO6S3W/QAKNVXagDtvsNtx7Ks+HKgo6U21B+QSZgIogV5Bt+BnXisdVfy9VyXV+2P5fMuvdpAjM1o/K9Z+XnE4EOCrue+kcdYHqAQ0/Y/OmNlQ6OI33jH/uD1RalPaHpJAm2av0/xtpqdXVKNDrc9F2izo23Wu7firgbURFDNX9eGGeYBhiypyXZft2j3hTvzE6PMWKsod//rEILDkzBXfi7xh0eFkfb3/1zzPK/PI5Nk3FbZyTl4mq5BfBoVoqiPHO4Q4QKZAlrQ3MdNfi3oxIjvsM3kAFv3fdufurqYR3PSwX/mpGy/GFI/B2MNPiNdOppWVbs/gjF3YH+QA9jMhlAbhvasAHstB0IJew09iAkmXHl1/TEj+jvHOpOGrPRQXbPADM+Ig2/OEcUcpgPTItMtW4DdqgfYVI/+4hAFWYjUGpOP/UwNuB7+BbKOcALbjobdgzeBQfjgNSp2GOpxzGLj70Vvq5cw2AoYENwKLUtJUX8sGRox4dVa/TN4xKwaKcl9XawQR/uNus700Hf17pyNnezrUgaY9e4MADhEDBpsJT6y1gDJs1q6wlwGhuUzGR7C8kgpjPyHWwsvrf3yn1zJEIRa5eSxoLAZOCR9xbuztxFRJW9ZmMYfCFJ0evm9F2fVnuje92Rc4Pl6A8bluN8MZyyJGZ0+sNSb//DvAFxC2BqlEsFwccWeAl6CyBcQV1bx4mQMBP1Jxqk1EUADNLeieS2dUFbQ/c/kvwItbZ7tx0st16viqd53WsRmPTKv2AD8CUnhtPWg5aUegNpsYgasaw2+EVooeNKmrW3MFtj76bYHJm5K9gpAXZXsE5U8DM8XmVOSJ1F1WnLy6nQup+jx52bAb+rCq6y9WXl2B2oZDhfDkW7H3oYfT/4xx5VncBuxMXP2lNfhUVQjSSzSRbuZFE4vFawlzveXxaYKVs8LpvAb8IRYF3ZHiRnm0ADeNPWocwxSzNseG7NrSEVZoHdKWqaGEBz1N8Pt7kFbqh3LYmAbm9i1IChIpLpM5AS6mr6OAPHMwwznVy61YpBYX8xZDN/a+lt7n+x5j4bNOVteZ8lj3hpAHSx1VR8vZHec4AHO9XFCdjZ9eRkSV65ljMmZVzaej2qFn/qt1lvWzNZEfHxK3qOJrHL6crr0CRzMox5f2e8ALBB4UGFZKA3tN6F6IXd32GTJXGQ7DTi9j/dNcLF9jCbDcWGKxoKTYblIwbLDReL00LRcDPMcQuXLMh5YzgtfjkFK1DP1iDzzYYVZz5M/kWYRlRpig1htVRjVCknm+h1M5LiEDXOyHREhvzCGpFZjHS0RsK27o2avgdilrJkalWqPW3D9gmwV37HKmfM3F8YZj2ar+vHFvf3B8CRoH4kDHIK9mrAg+owiEwNjjd9V+FsQKYR8czJrUkf7Qoi2YaW6EVDZp5zYlqiYtuXOTHk4fAcZ7qBbdLDiJq0WNV1l2+Hntk1mMWvxrYmc8kIx8G3rW36J6Ra4lLrTOCgiOihmow+YnzUT19jbV2B3RWqSHyxkhmgsBqMYWvOcUom1jDQ436+fcbu3xf2bbeqU/ca+C4DOKE+e3qvmeMqW3AxejfzBRFVcwVYPq4L0APSWWoJu+5UYX4qg5U6YTioqQGPG9XrnuZ/BkxuYpe6Li87+18EskyQW/uA+uk2rpHpr6hut2TlVbKgWkFpx+AZffweiw2+VittkEyf/ifinS/0ItRL2Jq3tQOcxPaWO2xrG68GdFoUpZgFXaP2wYVtRc6xYCfI1CaBqyWpg4bx8OHBQwsV4XWMibZZ0LYjWEy2IxQ1mZrf1/UNbYCJplWu3nZ4WpodIGVA05d+RWSS+ET9tH3RfGGmNI1cIY7evZZq7o+a0bjjygpmR3mVfalkT/SZGT27Q8QGalwGlDOS9VHCyFAIL0a1Q7JiW3saz9gqY8lqKynFrPCzxkU4SIfLc9VfCI5edgRhDXs0edO992nhTKHriREP1NJC6SROMgQ0xO5kNNZOhMOIT99AUElbxqeZF8A3xrfDJsWtDnUenAHdYWSwAbYjFqQZ+D5gi3hNK8CSxU9i6f6ClL9IGlj1OPMQAsr84YG6ijsJpCaGWj75c3yOZKBB9mNpQNPUKkK0D6wgLH8MGoyRxTX6Y05Q4AnYNXMZwXM4eij/9WpsM/9CoRnFQXGR6MEaY+FXvXEO3RO0JaStk6OXuHVATHJE+1W+TU3bSZ2ksMtqjO0zfSJCdBv7y2d8DMx6TfVme3q0ZpTKMMu4YL/t7ciTNtdDkwPogh3Cnjx7qk08SHwf+dksZ7M2vCOlfsF0hQ6J4ehPCaHTNrM/zBSOqD83dBEBCW/F/LEmeh0nOHd7oVl3/Qo/9GUDkkbj7yz+9cvvu+dDAtx8NzCDTP4iKdZvk9MWiizvtILLepysflSvTLFBZ37RLwiriqyRxYv/zrgFd/9XVHh/OmzBvDX4mitMR/lUavs2Vx6cR94lzAkplm3IRNy4TFfu47tuYs9EQPIPVta4P64tV+sZ7n3ued3cgEx2YK+QL5+xms6osk8qQbTyuKVGdaX9FQqk6qfDnT5ykxk0VK7KZ62b6DNDUfQlqGHxSMKv1P0XN5BqMeKG1P4Wp5QfZDUCEldppoX0U6ss2jIko2XpURKCIhfaOqLPfShdtS37ZrT+jFRSH2xYVV1rmT/MBtRQhxiO4MQ3iAGlaZi+9PWBEIXOVnu9jN1f921lWLZky9bqbM3J2MAAI9jmuAx3gyoEUa6P2ivs0EeNv/OR+AX6q5SW6l5HaoFuS6jr6yg9limu+P0KYKzfMXWcQSfTXzpOzKEKpwI3YGXZpSSy2LTlMgfmFA3CF6R5c9xWEtRuCg2ZPUQ2Nb6dRFTNd4TfGHrnEWSKHPuRyiJSDAZ+KX0VxmSHjGPbQTLVpqixia2uyhQ394gBMt7C3ZAmxn/DJS+l1fBsAo2Eir/C0jG9csd4+/tp12pPc/BVJGaK9mfvr7M/CeztrmCO5qY06Edi4xAGtiEhnWAbzLy2VEyazE1J5nPmgU4RpW4Sa0TnOT6w5lgt3/tMpROigHHmexBGAMY0mdcDbDxWIz41NgdD6oxgHsJRgr5RnT6wZAkTOcStU4NMOQNemSO7gxGahdEsC+NRVGxMUhQmmM0llWRbbmFGHzEqLM4Iw0H7577Kyo+Zf+2cUFIOw93gEY171vQaM0HLwpjpdRR6Jz7V0ckE7XzYJ0TmY9znLdzkva0vNrAGGT5SUZ5uaHDkcGvI0ySpwkasEgZPMseYcu85w8HPdSNi+4T6A83iAwDbxgeFcB1ZM2iGXzFcEOUlYVrEckaOyodfvaYSQ7GuB4ISE0nYJc15X/1ciDTPbPCgYJK55VkEor4LvzL9S2WDy4xj+6FOqVyTAC2ZNowheeeSI5hA/02l8UYkv4nk9iaVn+kCVEUstgk5Hyq+gJm6R9vG3rhuM904he/hFmNQaUIATB1y3vw+OmxP4X5Yi6A5I5jJufHCjF9+AGNwnEllZjUco6XhsO5T5+R3yxz5yLVOnAn0zuS+6zdj0nTJbEZCbXJdtpfYZfCeCOqJHoE2vPPFS6eRLjIJlG69X93nfR0mxSFXzp1Zc0lt/VafDaImhUMtbnqWVb9M4nGNQLN68BHP7AR8Il9dkcxzmBv8PCZlw9guY0lurbBsmNYlwJZsA/B15/HfkbjbwPddaVecls/elmDHNW2r4crAx43feNkfRwsaNq/yyJ0d/p5hZ6AZajz7DBfUok0ZU62gCzz7x8eVfJTKA8IWn45vINLSM1q+HF9CV9qF3zP6Ml21kPPL3CXzkuYUlnSqT+Ij4tI/od5KwIs+tDajDs64owN7tOAd6eucGz+KfO26iNcBFpbWA5732bBNWO4kHNpr9D955L61bvHCF/mwSrz6eQaDjfDEANqGMkFc+NGxpKZzCD2sj/JrHd+zlPQ8Iz7Q+2JVIiVCuCKoK/hlAEHzvk/Piq3mRL1rT/fEh9hoT5GJmeYswg1otiKydizJ/fS2SeKHVu6Z3JEHjiW8NaTQgP5xdBli8nC57XiN9hrquBu99hn9zqwo92+PM2JXtpeVZS0PdqR5mDyDreMMtEws+CpwaRyyzoYtfcvt9PJIW0fJVNNi/FFyRsea7peLvJrL+5b4GOXJ8tAr+ATk9f8KmiIsRhqRy0vFzwRV3Z5dZ3QqIU8JQ/uQpkJbjMUMFj2F9sCFeaBjI4+fL/oN3+LQgjI4zuAfQ+3IPIPFQBccf0clJpsfpnBxD84atwtupkGqKvrH7cGNl/QcWcSi6wcVDML6ljOgYbo+2BOAWNNjlUBPiyitUAwbnhFvLbnqw42kR3Yp2kv2dMeDdcGOX5kT4S6M44KHEB/SpCfl7xgsUvs+JNY9G3O2X/6FEt9FyAn57lrbiu+tl83sCymSvq9eZbe9mchL7MTf/Ta78e80zSf0hYY5eUU7+ff14jv7Xy8qjzfzzzvaJnrIdvFb5BLWKcWGy5/w7+vV2cvIfwHqdTB+RuJK5oj9mbt0Hy94AmjMjjwYNZlNS6uiyxNnwNyt3gdreLb64p/3+08nXkb92LTkkRgFOwk1oGEVllcOj5lv1hfAZywDows0944U8vUFw+A/nuVq/UCygsrmWIBnHyU01d0XJPwriEOvx/ISK6Pk4y2w0gmojZs7lU8TtakBAdne4v/aNxmMpK4VcGMp7si0yqsiolXRuOi1Z1P7SqD3Zmp0CWcyK4Ubmp2SXiXuI5nGLCieFHKHNRIlcY3Pys2dwMTYCaqlyWSITwr2oGXvyU3h1Pf8eQ3w1bnD7ilocVjYDkcXR3Oo1BXgMLTUjNw2xMVwjtp99NhSVc5aIWrDQT5DHPKtCtheBP4zHcw4dz2eRdTMamhlHhtfgqJJHI7NGDUw1XL8vsSeSHyKqDtqoAmrQqsYwvwi7HW3ojWyhIa5oz5xJTaq14NAzFLjVLR12rRNUQ6xohDnrWFb5bG9yf8aCD8d5phoackcNJp+Dw3Due3RM+5Rid7EuIgsnwgpX0rUWh/nqPtByMhMZZ69NpgvRTKZ62ViZ+Q7Dp5r4K0d7EfJuiy06KuIYauRh5Ecrhdt2QpTS1k1AscEHvapNbU3HL1F2TFyR33Wxb5MvH5iZsrn3SDcsxlnnshO8PLwmdGN+paWnQuORtZGX37uhFT64SeuPsx8UOokY6ON85WdQ1dki5zErsJGazcBOddWJEKqNPiJpsMD1GrVLrVY+AOdPWQneTyyP1hRX/lMM4ZogGGOhYuAdr7F/DOiAoc++cn5vlf0zkMUJ40Z1rlgv9BelPqVOpxKeOpzKdF8maK+1Vv23MO9k/8+qpLoxrIGH2EDQlnGmH8CD31G8QqlyQIcpmR5bwmSVw9/Ns6IHgulCRehvZ/+VrM60Cu/r3AontFfrljew74skYe2uyn7JKQtFQBQRJ9ryGic/zQOsbS4scUBctA8cPToQ3x6ZBQu6DPu5m1bnCtP8TllLYA0UTQNVqza5nfew3Mopy1GPUwG5jsl0OVXniPmAcmLqO5HG8Hv3nSLecE9oOjPDXcsTxoCBxYyzBdj4wmnyEV4kvFDunipS8SSkvdaMnTBN9brHUR8xdmmEAp/Pdqk9uextp1t+JrtXwpN/MG2w/qhRMpSNxQ1uhg/kKO30eQ/FyHUDkWHT8V6gGRU4DhDMxZu7xXij9Ui6jlpWmQCqJg3FkOTq3WKneCRYZxBXMNAVLQgHXSCGSqNdjebY94oyIpVjMYehAiFx/tqzBXFHZaL5PeeD74rW5OysFoUXY8sebUZleFTUa/+zBKVTFDopTReXNuZq47QjkWnxjirCommO4L/GrFtVV21EpMyw8wyThL5Y59d88xtlx1g1ttSICDwnof6lt/6zliPzgVUL8jWBjC0o2D6Kg+jNuThkAlaDJsq/AG2aKA//A76avw2KNqtv223P+Wq3StRDDNKFFgtsFukYt1GFDWooFVXitaNhb3RCyJi4cMeNjROiPEDb4k+G3+hD8tsg+5hhmSc/8t2JTSwYoCzAI75doq8QTHe+E/Tw0RQSUDlU+6uBeNN3h6jJGX/mH8oj0i3caCNsjvTnoh73BtyZpsflHLq6AfwJNCDX4S98h4+pCOhGKDhV3rtkKHMa3EG4J9y8zFWI4UsfNzC/Rl5midNn7gwoN9j23HGCQQ+OAZpTTPMdiVow740gIyuEtd0qVxMyNXhHcnuXRKdw5wDUSL358ktjMXmAkvIB73BLa1vfF9BAUZInPYJiwxqFWQQBVk7gQH4ojfUQ/KEjn+A/WR6EEe4CtbpoLe1mzHkajgTIoE0SLDHVauKhrq12zrAXBGbPPWKCt4DGedq3JyGRbmPFW32bE7T20+73BatV/qQhhBWfWBFHfhYWXjALts38FemnoT+9bn1jDBMcUMmYgSc0e7GQjv2MUBwLU8ionCpgV+Qrhg7iUIfUY6JFxR0Y+ZTCPM+rVuq0GNLyJXX6nrUTt8HzFBRY1E/FIm2EeVA9NcXrj7S6YYIChVQCWr/m2fYUjC4j0XLkzZ8GCSLfmkW3PB/xq+nlXsKVBOj7vTvqKCOMq7Ztqr3cQ+N8gBnPaAps+oGwWOkbuxnRYj/x/WjiDclVrs22xMK4qArE1Ztk1456kiJriw6abkNeRHogaPRBgbgF9Z8i/tbzWELN4CvbqtrqV9TtGSnmPS2F9kqOIBaazHYaJ9bi3AoDBvlZasMluxt0BDXfhp02Jn411aVt6S4TUB8ZgFDkI6TP6gwPY85w+oUQSsjIeXVminrwIdK2ZAawb8Se6XOJbOaliQxHSrnAeONDLuCnFejIbp4YDtBcQCwMsYiRZfHefuEJqJcwKTTJ8sx5hjHmJI1sPFHOr6W9AhZ2NAod38mnLQk1gOz2LCAohoQbgMbUK9RMEA3LkiF7Sr9tLZp6lkciIGhE2V546w3Mam53VtVkGbB9w0Yk2XiRnCmbpxmHr2k4eSC0RuNbjNsUfDIfc8DZvRvgUDe1IlKdZTzcT4ZGEb53dp8VtsoZlyXzLHOdAbsp1LPTVaHvLA0GYDFMbAW/WUBfUAdHwqLFAV+3uHvYWrCfhUOR2i89qvCBoOb48usAGdcF2M4aKn79k/43WzBZ+xR1L0uZfia70XP9soQReeuhZiUnXFDG1T8/OXNmssTSnYO+3kVLAgeiY719uDwL9FQycgLPessNihMZbAKG7qwPZyG11G1+ZA3jAX2yddpYfmaKBlmfcK/V0mwIRUDC0nJSOPUl2KB8h13F4dlVZiRhdGY5farwN+f9hEb1cRi41ZcGDn6Xe9MMSTOY81ULJyXIHSWFIQHstVYLiJEiUjktlHiGjntN5/btB8Fu+vp28zl2fZXN+dJDyN6EXhS+0yzqpl/LSJNEUVxmu7BsNdjAY0jVsAhkNuuY0E1G48ej25mSt+00yPbQ4SRCVkIwb6ISvYtmJRPz9Zt5dk76blf+lJwAPH5KDF+vHAmACLoCdG2Adii6dOHnNJnTmZtoOGO8Q1jy1veMw6gbLFToQmfJa7nT7Al89mRbRkZZQxJTKgK5Kc9INzmTJFp0tpAPzNmyL/F08bX3nhCumM/cR/2RPn9emZ3VljokttZD1zVWXlUIqEU7SLk5I0lFRU0AcENXBYazNaVzsVHA/sD3o9hm42wbHIRb/BBQTKzAi8s3+bMtpOOZgLdQzCYPfX3UUxKd1WYVkGH7lh/RBBgMZZwXzU9+GYxdBqlGs0LP+DZ5g2BWNh6FAcR944B+K/JTWI3t9YyVyRhlP4CCoUk/mmF7+r2pilVBjxXBHFaBfBtr9hbVn2zDuI0kEOG3kBx8CGdPOjX1ph1POOZJUO1JEGG0jzUy2tK4X0CgVNYhmkqqQysRNtKuPdCJqK3WW57kaV17vXgiyPrl4KEEWgiGF1euI4QkSFHFf0TDroQiLNKJiLbdhH0YBhriRNCHPxSqJmNNoketaioohqMglh6wLtEGWSM1EZbQg72h0UJAIPVFCAJOThpQGGdKfFovcwEeiBuZHN2Ob4uVM7+gwZLz1D9E7ta4RmMZ24OBBAg7Eh6dLXGofZ4U2TFOCQMKjwhVckjrydRS+YaqCw1kYt6UexuzbNEDyYLTZnrY1PzsHZJT4U+awO2xlqTSYu6n/U29O2wPXgGOEKDMSq+zTUtyc8+6iLp0ivav4FKx+xxVy4FxhIF/pucVDqpsVe2jFOfdZhTzLz2QjtzvsTCvDPU7bzDH2eXVKUV9TZ+qFtaSSxnYgYdXKwVreIgvWhT9eGDB2OvnWyPLfIIIfNnfIxU8nW7MbcH05nhlsYtaW9EZRsxWcKdEqInq1DiZPKCz7iGmAU9/ccnnQud2pNgIGFYOTAWjhIrd63aPDgfj8/sdlD4l+UTlcxTI9jbaMqqN0gQxSHs60IAcW3cH4p3V1aSciTKB29L1tz2eUQhRiTgTvmqc+sGtBNh4ky0mQJGsdycBREP+fAaSs1EREDVo5gvgi5+aCN7NECw30owbCc1mSpjiahyNVwJd1jiGgzSwfTpzf2c5XJvG/g1n0fH88KHNnf+u7ZiRMlXueSIsloJBUtW9ezvsx9grfsX/FNxnbxU1Lvg0hLxixypHKGFAaPu0xCD8oDTeFSyfRT6s8109GMUZL8m2xXp8X2dpPCWWdX84iga4BrTlOfqox4shqEgh/Ht4qRst52cA1xOIUuOxgfUivp6v5f8IVyaryEdpVk72ERAwdT4aoY1usBgmP+0m06Q216H/nubtNYxHaOIYjcach3A8Ez/zc0KcShhel0HCYjFsA0FjYqyJ5ZUH1aZw3+zWC0hLpM6GDfcAdn9fq2orPmZbW6XXrf+Krc9RtvII5jeD3dFoT1KwZJwxfUMvc5KLfn8rROW23Jw89sJ2a5dpB3qWDUBWF2iX8OCuKprHosJ2mflBR+Wqs86VvgI/XMnsqb97+VlKdPVysczPj8Jhzf+WCvGBHijAqYlavbF60soMWlHbvKT+ScvhprgeTln51xX0sF+Eadc/l2s2a5BgkVbHYyz0E85p0LstqH+gEGiR84nBRRFIn8hLSZrGwqjZ3E29cuGi+5Z5bp7EM8MWFa9ssS/vy4VrDfECSv7DSU84DaP0sXI3Ap4lWznQ65nQoTKRWU30gd7Nn8ZowUvGIx4aqyXGwmA/PB4qN8msJUODezUHEl0VP9uo+cZ8vPFodSIB4C7lQYjEFj8yu49C2KIV3qxMFYTevG8KqAr0TPlkbzHHnTpDpvpzziAiNFh8xiT7C/TiyH0EguUw4vxAgpnE27WIypV+uFN2zW7xniF/n75trs9IJ5amB1zXXZ1LFkJ6GbS/dFokzl4cc2mamVwhL4XU0Av5gDWAl+aEWhAP7t2VIwU+EpvfOPDcLASX7H7lZpXA2XQfbSlD4qU18NffNPoAKMNSccBfO9YVVgmlW4RydBqfHAV7+hrZ84WJGho6bNT0YMhxxLdOx/dwGj0oyak9aAkNJ8lRJzUuA8sR+fPyiyTgUHio5+Pp+YaKlHrhR41jY5NESPS3x+zTMe0S2HnLOKCOQPpdxKyviBvdHrCDRqO+l96HhhNBLXWv4yEMuEUYo8kXnYJM8oIgVM4XJ+xXOev4YbWeqsvgq0lmw4/PiYr9sYLt+W5EAuYSFnJEan8CwJwbtASBfLBBpJZiRPor/aCJBZsM+MhvS7ZepyHvU8m5WSmaZnxuLts8ojl6KkS8oSAHkq5GWlCB/NgJ5W3rO2Cj1MK7ahxsCrbTT3a0V/QQH+sErxV4XUWDHx0kkFy25bPmBMBQ6BU3HoHhhYcJB9JhP6NXUWKxnE0raXHB6U9KHpWdQCQI72qevp5fMzcm+AvC85rsynVQhruDA9fp9COe7N56cg1UKGSas89vrN+WlGLYTwi5W+0xYdKEGtGCeNJwXKDU0XqU5uQYnWsMwTENLGtbQMvoGjIFIEMzCRal4rnBAg7D/CSn8MsCvS+FDJJAzoiioJEhZJgAp9n2+1Yznr7H+6eT4YkJ9Mpj60ImcW4i4iHDLn9RydB8dx3QYm3rsX6n4VRrZDsYK6DCGwkwd5n3/INFEpk16fYpP6JtMQpqEMzcOfQGAHXBTEGzuLJ03GYQL9bmV2/7ExDlRf+Uvf1sM2frRtCWmal12pMgtonvSCtR4n1CLUZRdTHDHP1Otwqd+rcdlavnKjUB/OYXQHUJzpNyFoKpQK+2OgrEKpGyIgIBgn2y9QHnTJihZOpEvOKIoHAMGAXHmj21Lym39Mbiow4IF+77xNuewziNVBxr6KD5e+9HzZSBIlUa/AmsDFJFXeyrQakR3FwowTGcADJHcEfhGkXYNGSYo4dh4bxwLM+28xjiqkdn0/3R4UEkvcBrBfn/SzBc1XhKM2VPlJgKSorjDac96V2UnQYXl1/yZPT4DVelgO+soMjexXwYO58VLl5xInQUZI8jc3H2CPnCNb9X05nOxIy4MlecasTqGK6s2az4RjpF2cQP2G28R+7wDPsZDZC/kWtjdoHC7SpdPmqQrUAhMwKVuxCmYTiD9q/O7GHtZvPSN0CAUQN/rymXZNniYLlJDE70bsk6Xxsh4kDOdxe7A2wo7P9F5YvqqRDI6brf79yPCSp4I0jVoO4YnLYtX5nzspR5WB4AKOYtR1ujXbOQpPyYDvfRE3FN5zw0i7reehdi7yV0YDRKRllGCGRk5Yz+Uv1fYl2ZwrnGsqsjgAVo0xEUba8ohjaNMJNwTwZA/wBDWFSCpg1eUH8MYL2zdioxRTqgGQrDZxQyNzyBJPXZF0+oxITJAbj7oNC5JwgDMUJaM5GqlGCWc//KCIrI+aclEe4IA0uzv7cuj6GCdaJONpi13O544vbtIHBF+A+JeDFUQNy61Gki3rtyQ4aUywn6ru314/dkGiP8Iwjo0J/2Txs49ZkwEl4mx+iYUUO55I6pJzU4P+7RRs+DXZkyKUYZqVWrPF4I94m4Wx1tXeE74o9GuX977yvJ/jkdak8+AmoHVjI15V+WwBdARFV2IPirJgVMdsg1Pez2VNHqa7EHWdTkl3XTcyjG9BiueWFvQfXI8aWSkuuRmqi/HUuzqyvLJfNfs0txMqldYYflWB1BS31WkuPJGGwXUCpjiQSktkuBMWwHjSkQxeehqw1Kgz0Trzm7QbtgxiEPDVmWCNCAeCfROTphd1ZNOhzLy6XfJyG6Xgd5MCAZw4xie0Sj5AnY1/akDgNS9YFl3Y06vd6FAsg2gVQJtzG7LVq1OH2frbXNHWH/NY89NNZ4QUSJqL2yEcGADbT38X0bGdukqYlSoliKOcsSTuqhcaemUeYLLoI8+MZor2RxXTRThF1LrHfqf/5LcLAjdl4EERgUysYS2geE+yFdasU91UgUDsc2cSQ1ZoT9+uLOwdgAmifwQqF028INc2IQEDfTmUw3eZxvz7Ud1z3xc1PQfeCvfKsB9jOhRj7rFyb9XcDWLcYj0bByosychMezMLVkFiYcdBBQtvI6K0KRuOZQH2kBsYHJaXTkup8F0eIhO1/GcIwWKpr2mouB7g5TUDJNvORXPXa/mU8bh27TAZYBe2sKx4NSv5OjnHIWD2RuysCzBlUfeNXhDd2jxnHoUlheJ3jBApzURy0fwm2FwwsSU0caQGl0Kv8hopRQE211NnvtLRsmCNrhhpEDoNiZEzD2QdJWKbRRWnaFedXHAELSN0t0bfsCsMf0ktfBoXBoNA+nZN9+pSlmuzspFevmsqqcMllzzvkyXrzoA+Ryo1ePXpdGOoJvhyru+EBRsmOp7MXZ0vNUMUqHLUoKglg1p73sWeZmPc+KAw0pE2zIsFFE5H4192KwDvDxdxEYoDBDNZjbg2bmADTeUKK57IPD4fTYF4c6EnXx/teYMORBDtIhPJneiZny7Nv/zG+YmekIKCoxr6kauE2bZtBLufetNG0BtBY7f+/ImUypMBvdWu/Q7vTMRzw5aQGZWuc1V0HEsItFYMIBnoKGZ0xcarba/TYZq50kCaflFysYjA4EDKHqGdpYWdKYmm+a7TADmW35yfnOYpZYrkpVEtiqF0EujI00aeplNs2k+qyFZNeE3CDPL9P6b4PQ/kataHkVpLSEVGK7EX6rAa7IVNrvZtFvOA6okKvBgMtFDAGZOx88MeBcJ8AR3AgUUeIznAN6tjCUipGDZONm1FjWJp4A3QIzSaIOmZ7DvF/ysYYbM/fFDOV0jntAjRdapxJxL0eThpEhKOjCDDq2ks+3GrwxqIFKLe1WdOzII8XIOPGnwy6LKXVfpSDOTEfaRsGujhpS4hBIsMOqHbl16PJxc4EkaVu9wpEYlF/84NSv5Zum4drMfp9yXbzzAOJqqS4YkI4cBrFrC7bMPiCfgI3nNZAqkk3QOZqR+yyqx+nDQKBBBZ7QKrfGMCL+XpqFaBJU0wpkBdAhbR4hJsmT5aynlvkouoxm/NjD5oe6BzVIO9uktM+/5dEC5P7vZvarmuO/lKXz4sBabVPIATuKTrwbJP8XUkdM6uEctHKXICUJGjaZIWRbZp8czquQYfY6ynBUCfIU+gG6wqSIBmYIm9pZpXdaL121V7q0VjDjmQnXvMe7ysoEZnZL15B0SpxS1jjd83uNIOKZwu5MPzg2NhOx3xMOPYwEn2CUzbSrwAs5OAtrz3GAaUkJOU74XwjaYUmGJdZBS1NJVkGYrToINLKDjxcuIlyfVsKQSG/G4DyiO2SlQvJ0d0Ot1uOG5IFSAkq+PRVMgVMDvOIJMdqjeCFKUGRWBW9wigYvcbU7CQL/7meF2KZAaWl+4y9uhowAX7elogAvItAAxo2+SFxGRsHGEW9BnhlTuWigYxRcnVUBRQHV41LV+Fr5CJYV7sHfeywswx4XMtUx6EkBhR+q8AXXUA8uPJ73Pb49i9KG9fOljvXeyFj9ixgbo6CcbAJ7WHWqKHy/h+YjBwp6VcN7M89FGzQ04qbrQtgrOFybg3gQRTYG5xn73ArkfQWjCJROwy3J38Dx/D7jOa6BBNsitEw1wGq780EEioOeD+ZGp2J66ADiVGMayiHYucMk8nTK2zzT9CnEraAk95kQjy4k0GRElLL5YAKLQErJ5rp1eay9O4Fb6yJGm9U4FaMwPGxtKD6odIIHKoWnhKo1U8KIpFC+MVn59ZXmc7ZTBZfsg6FQ8W10YfTr4u0nYrpHZbZ1jXiLmooF0cOm0+mPnJBXQtepc7n0BqOipNCqI6yyloTeRShNKH04FIo0gcMk0H/xThyN4pPAWjDDkEp3lNNPRNVfpMI44CWRlRgViP64eK0JSRp0WUvCWYumlW/c58Vcz/yMwVcW5oYb9+26TEhwvbxiNg48hl1VI1UXTU//Eta+BMKnGUivctfL5wINDD0giQL1ipt6U7C9cd4+lgqY2lMUZ02Uv6Prs+ZEZer7ZfWBXVghlfOOrClwsoOFKzWEfz6RZu1eCs+K8fLvkts5+BX0gyrFYve0C3qHrn5U/Oh6D/CihmWIrY7HUZRhJaxde+tldu6adYJ+LeXupQw0XExC36RETdNFxcq9glMu4cNQSX9cqR/GQYp+IxUkIcNGWVU7ZtGa6P3XAyodRt0XeS3Tp01AnCh0ZbUh4VrSZeV9RWfSoWyxnY3hzcZ30G/InDq4wxRrEejreBxnhIQbkxenxkaxl+k7eLUQkUR6vKJ2iDFNGX3WmVA1yaOH+mvhBd+sE6vacQzFobwY5BqEAFmejwW5ne7HtVNolOUgJc8CsUxmc/LBi8N5mu9VsIA5HyErnS6zeCz7VLI9+n/hbT6hTokMXTVyXJRKSG2hd2labXTbtmK4fNH3IZBPreSA4FMeVouVN3zG5x9CiGpLw/3pceo4qGqp+rVp+z+7yQ98oEf+nyH4F3+J9IheDBa94Wi63zJbLBCIZm7P0asHGpIJt3PzE3m0S4YIWyXBCVXGikj8MudDPB/6Nm2v4IxJ5gU0ii0guy5SUHqGUYzTP0jIJU5E82RHUXtX4lDdrihBLdP1YaG1AGUC12rQKuIaGvCpMjZC9bWSCYnjDlvpWbkdXMTNeBHLKiuoozMGIvkczmP0aRJSJ8PYnLCVNhKHXBNckH79e8Z8Kc2wUej4sQZoH8qDRGkg86maW/ZQWGNnLcXmq3FlXM6ssR/3P6E/bHMvm6HLrv1yRixit25JsH3/IOr2UV4BWJhxXW5BJ6Xdr07n9kF3ZNAk6/Xpc5MSFmYJ2R7bdL8Kk7q1OU9Elg/tCxJ8giT27wSTySF0GOxg4PbYJdi/Nyia9Nn89CGDulfJemm1aiEr/eleGSN+5MRrVJ4K6lgyTTIW3i9cQ0dAi6FHt0YMbH3wDSAtGLSAccezzxHitt1QdhW36CQgPcA8vIIBh3/JNjf/Obmc2yzpk8edSlS4lVdwgW5vzbYEyFoF4GCBBby1keVNueHAH+evi+H7oOVfS3XuPQSNTXOONAbzJeSb5stwdQHl1ZjrGoE49I8+A9j3t+ahhQj74FCSWpZrj7wRSFJJnnwi1T9HL5qrCFW/JZq6P62XkMWTb+u4lGpKfmmwiJWx178GOG7KbrZGqyWwmuyKWPkNswkZ1q8uptUlviIi+AXh2bOOTOLsrtNkfqbQJeh24reebkINLkjut5r4d9GR/r8CBa9SU0UQhsnZp5cP+RqWCixRm7i4YRFbtZ4EAkhtNa6jHb6gPYQv7MKqkPLRmX3dFsK8XsRLVZ6IEVrCbmNDc8o5mqsogjAQfoC9Bc7R6gfw03m+lQpv6kTfhxscDIX6s0w+fBxtkhjXAXr10UouWCx3C/p/FYwJRS/AXRKkjOb5CLmK4XRe0+xeDDwVkJPZau52bzLEDHCqV0f44pPgKOkYKgTZJ33fmk3Tu8SdxJ02SHM8Fem5SMsWqRyi2F1ynfRJszcFKykdWlNqgDA/L9lKYBmc7Zu/q9ii1FPF47VJkqhirUob53zoiJtVVRVwMR34gV9iqcBaHbRu9kkvqk3yMpfRFG49pKKjIiq7h/VpRwPGTHoY4cg05X5028iHsLvUW/uz+kjPyIEhhcKUwCkJAwbR9pIEGOn8z6svAO8i89sJ3dL5qDWFYbS+HGPRMxYwJItFQN86YESeJQhn2urGiLRffQeLptDl8dAgb+Tp47UQPxWOw17OeChLN1WnzlkPL1T5O+O3Menpn4C3IY5LEepHpnPeZHbvuWfeVtPlkH4LZjPbBrkJT3NoRJzBt86CO0Xq59oQ+8dsm0ymRcmQyn8w71mhmcuEI5byuF+C88VPYly2sEzjlzAQ3vdn/1+Hzguw6qFNNbqenhZGbdiG6RwZaTG7jTA2X9RdXjDN9yj1uQpyO4Lx8KRAcZcbZMafp4wPOd5MdXoFY52V1A8M9hi3sso93+uprE0qYNMjkE22CvK4HuUxqN7oIz5pWuETq1lQAjqlSlqdD2Rnr/ggp/TVkQYjn9lMfYelk2sH5HPdopYo7MHwlV1or9Bxf+QCyLzm92vzG2wjiIjC/ZHEJzeroJl6bdFPTpZho5MV2U86fLQqxNlGIMqCGy+9WYhJ8ob1r0+Whxde9L2PdysETv97O+xVw+VNN1TZSQN5I6l9m5Ip6pLIqLm4a1B1ffH6gHyqT9p82NOjntRWGIofO3bJz5GhkvSWbsXueTAMaJDou99kGLqDlhwBZNEQ4mKPuDvVwSK4WmLluHyhA97pZiVe8g+JxmnJF8IkV/tCs4Jq/HgOoAEGR9tCDsDbDmi3OviUQpG5D8XmKcSAUaFLRXb2lmJTNYdhtYyfjBYZQmN5qT5CNuaD3BVnlkCk7bsMW3AtXkNMMTuW4HjUERSJnVQ0vsBGa1wo3Qh7115XGeTF3NTz8w0440AgU7c3bSXO/KMINaIWXd0oLpoq/0/QJxCQSJ9XnYy1W7TYLBJpHsVWD1ahsA7FjNvRd6mxCiHsm8g6Z0pnzqIpF1dHUtP2ITU5Z1hZHbu+L3BEEStBbL9XYvGfEakv1bmf+bOZGnoiuHEdlBnaChxYKNzB23b8sw8YyT7Ajxfk49eJIAvdbVkdFCe2J0gMefhQ0bIZxhx3fzMIysQNiN8PgOUKxOMur10LduigREDRMZyP4oGWrP1GFY4t6groASsZ421os48wAdnrbovNhLt7ScNULkwZ5AIZJTrbaKYTLjA1oJ3sIuN/aYocm/9uoQHEIlacF1s/TM1fLcPTL38O9fOsjMEIwoPKfvt7opuI9G2Hf/PR4aCLDQ7wNmIdEuXJ/QNL72k5q4NejAldPfe3UVVqzkys8YZ/jYOGOp6c+YzRCrCuq0M11y7TiN6qk7YXRMn/gukxrEimbMQjr3jwRM6dKVZ4RUfWQr8noPXLJq6yh5R3EH1IVOHESst/LItbG2D2vRsZRkAObzvQAAD3mb3/G4NzopI0FAiHfbpq0X72adg6SRj+8OHMShtFxxLZlf/nLgRLbClwl5WmaYSs+yEjkq48tY7Z2bE0N91mJwt+ua0NlRJIDh0HikF4UvSVorFj2YVu9YeS5tfvlVjPSoNu/Zu6dEUfBOT555hahBdN3Sa5Xuj2Rvau1lQNIaC944y0RWj9UiNDskAK1WoL+EfXcC6IbBXFRyVfX/WKXxPAwUyIAGW8ggZ08hcijKTt1YKnUO6QPvcrmDVAb0FCLIXn5id4fD/Jx4tw/gbXs7WF9b2RgXtPhLBG9vF5FEkdHAKrQHZAJC/HWvk7nvzzDzIXZlfFTJoC3JpGgLPBY7SQTjGlUvG577yNutZ1hTfs9/1nkSXK9zzKLRZ3VODeKUovJe0WCq1zVMYxCJMenmNzPIU2S8TA4E7wWmbNkxq9rI2dd6v0VpcAPVMxnDsvWTWFayyqvKZO7Z08a62i/oH2/jxf8rpmfO64in3FLiL1GX8IGtVE9M23yGsIqJbxDTy+LtaMWDaPqkymb5VrQdzOvqldeU0SUi6IirG8UZ3jcpRbwHa1C0Dww9G/SFX3gPvTJQE+kyz+g1BeMILKKO+olcHzctOWgzxYHnOD7dpCRtuZEXACjgqesZMasoPgnuDC4nUviAAxDc5pngjoAITIkvhKwg5d608pdrZcA+qn5TMT6Uo/QzBaOxBCLTJX3Mgk85rMfsnWx86oLxf7p2PX5ONqieTa/qM3tPw4ZXvlAp83NSD8F7+ZgctK1TpoYwtiU2h02HCGioH5tkVCqNVTMH5p00sRy2JU1qyDBP2CII/Dg4WDsIl+zgeX7589srx6YORRQMBfKbodbB743Tl4WLKOEnwWUVBsm94SOlCracU72MSyj068wdpYjyz1FwC2bjQnxnB6Mp/pZ+yyZXtguEaYB+kqhjQ6UUmwSFazOb+rhYjLaoiM+aN9/8KKn0zaCTFpN9eKwWy7/u4EHzO46TdFSNjMfn2iPSJwDPCFHc0I1+vjdAZw5ZjqR/uzi9Zn20oAa5JnLEk/EA3VRWE7J/XrupfFJPtCUuqHPpnlL7ISJtRpSVcB8qsZCm2QEkWoROtCKKxUh3yEcMbWYJwk6DlEBG0bZP6eg06FL3v6RPb7odGuwm7FN8fG4woqtB8e7M5klPpo97GoObNwt+ludTAmxyC5hmcFx+dIvEZKI6igFKHqLH01iY1o7903VzG9QGetyVx5RNmBYUU+zIuSva/yIcECUi4pRmE3VkF2avqulQEUY4yZ/wmNboBzPmAPey3+dSYtBZUjeWWT0pPwCz4Vozxp9xeClIU60qvEFMQCaPvPaA70WlOP9f/ey39macvpGCVa+zfa8gO44wbxpJUlC8GN/pRMTQtzY8Z8/hiNrU+Zq64ZfFGIkdj7m7abcK1EBtws1X4J/hnqvasPvvDSDYWN+QcQVGMqXalkDtTad5rYY0TIR1Eqox3czwPMjKPvF5sFv17Thujr1IZ1Ytl4VX1J0vjXKmLY4lmXipRAro0qVGEcXxEVMMEl54jQMd4J7RjgomU0j1ptjyxY+cLiSyXPfiEcIS2lWDK3ISAy6UZ3Hb5vnPncA94411jcy75ay6B6DSTzK6UTCZR9uDANtPBrvIDgjsfarMiwoax2OlLxaSoYn4iRgkpEGqEkwox5tyI8aKkLlfZ12lO11TxsqRMY89j5JaO55XfPJPDL1LGSnC88Re9Ai+Nu5bZjtwRrvFITUFHPR4ZmxGslQMecgbZO7nHk32qHxYkdvWpup07ojcMCaVrpFAyFZJJbNvBpZfdf39Hdo2kPtT7v0/f8R/B5Nz4f1t9/3zNM/7n6SUHfcWk5dfQFJvcJMgPolGCpOFb/WC0FGWU2asuQyT+rm88ZKZ78Cei/CAh939CH0JYbpZIPtxc2ufXqjS3pHH9lnWK4iJ7OjR/EESpCo2R3MYKyE7rHfhTvWho4cL1QdN4jFTyR6syMwFm124TVDDRXMNveI1Dp/ntwdz8k8kxw7iFSx6+Yx6O+1LzMVrN0BBzziZi9kneZSzgollBnVwBh6oSOPHXrglrOj+QmR/AESrhDpKrWT+8/AiMDxS/5wwRNuGQPLlJ9ovomhJWn8sMLVItQ8N/7IXvtD8kdOoHaw+vBSbFImQsv/OCAIui99E+YSIOMlMvBXkAt+NAZK8wB9Jf8CPtB+TOUOR+z71d/AFXpPBT6+A5FLjxMjLIEoJzrQfquvxEIi+WoUzGR1IzQFNvbYOnxb2PyQ0kGdyXKzW2axQL8lNAXPk6NEjqrRD1oZtKLlFoofrXw0dCNWASHzy+7PSzOUJ3XtaPZsxLDjr+o41fKuKWNmjiZtfkOzItvlV2MDGSheGF0ma04qE3TUEfqJMrXFm7DpK+27DSvCUVf7rbNoljPhha5W7KBqVq0ShUSTbRmuqPtQreVWH4JET5yMhuqMoSd4r/N8sDmeQiQQvi1tcZv7Moc7dT5X5AtCD6kNEGZOzVcNYlpX4AbTsLgSYYliiPyVoniuYYySxsBy5cgb3pD+EK0Gpb0wJg031dPgaL8JZt6sIvzNPEHfVPOjXmaXj4bd4voXzpZ5GApMhILgMbCEWZ2zwgdeQgjNHLbPIt+KqxRwWPLTN6HwZ0Ouijj4UF+Sg0Au8XuIKW0WxlexdrFrDcZJ8Shauat3X0XmHygqgL1nAu2hrJFb4wZXkcS+i36KMyU1yFvYv23bQUJi/3yQpqr/naUOoiEWOxckyq/gq43dFou1DVDaYMZK9tho7+IXXokBCs5GRfOcBK7g3A+jXQ39K4YA8PBRW4m5+yR0ZAxWJncjRVbITvIAPHYRt1EJ3YLiUbqIvoKHtzHKtUy1ddRUQ0AUO41vonZDUOW+mrszw+SW/6Q/IUgNpcXFjkM7F4CSSQ2ExZg85otsMs7kqsQD4OxYeBNDcSpifjMoLb7GEbGWTwasVObmB/bfPcUlq0wYhXCYEDWRW02TP5bBrYsKTGWjnWDDJ1F7zWai0zW/2XsCuvBQjPFcTYaQX3tSXRSm8hsAoDdjArK/OFp6vcWYOE7lizP0Yc+8p16i7/NiXIiiQTp7c7Xus925VEtlKAjUdFhyaiLT7VxDagprMFwix4wZ05u0qj7cDWFd0W9OYHIu3JbJKMXRJ1aYNovugg+QqRN7fNHSi26VSgBpn+JfMuPo3aeqPWik/wI5Rz3BWarPQX4i5+dM0npwVOsX+KsOhC7vDg+OJsz4Q5zlnIeflUWL6QYMbf9WDfLmosLF4Qev3mJiOuHjoor/dMeBpA9iKDkMjYBNbRo414HCxjsHrB4EXNbHzNMDHCLuNBG6Sf+J4MZ/ElVsDSLxjIiGsTPhw8BPjxbfQtskj+dyNMKOOcUYIRBEIqbazz3lmjlRQhplxq673VklMMY6597vu+d89ec/zq7Mi4gQvh87ehYbpOuZEXj5g/Q7S7BFDAAB9DzG35SC853xtWVcnZQoH54jeOqYLR9NDuwxsVthTV7V99n/B7HSbAytbEyVTz/5NhJ8gGIjG0E5j3griULUd5Rg7tQR+90hJgNQKQH2btbSfPcaTOfIexc1db1BxUOhM1vWCpLaYuKr3FdNTt/T3PWCpEUWDKEtzYrjpzlL/wri3MITKsFvtF8QVV/NhVo97aKIBgdliNc10dWdXVDpVtsNn+2UIolrgqdWA4EY8so0YvB4a+aLzMXiMAuOHQrXY0tr+CL10JbvZzgjJJuB1cRkdT7DUqTvnswVUp5kkUSFVtIIFYK05+tQxT6992HHNWVhWxUsD1PkceIrlXuUVRogwmfdhyrf6zzaL8+c0L7GXMZOteAhAVQVwdJh+7nrX7x4LaIIfz2F2v7Dg/uDfz2Fa+4gFm2zHAor8UqimJG3VTJtZEoFXhnDYXvxMJFc6ku2bhbCxzij2z5UNuK0jmp1mnvkVNUfR+SEmj1Lr94Lym75PO7Fs0MIr3GdsWXRXSfgLTVY0FLqba97u1In8NAcY7IC6TjWLigwKEIm43NxTdaVTv9mcKkzuzBkKd8x/xt1p/9BbP7Wyb4bpo1K1gnOpbLvKz58pWl3B55RJ/Z5mRDLPtNQg14jdOEs9+h/V5UVpwrAI8kGbX8KPVPDIMfIqKDjJD9UyDOPhjZ3vFAyecwyq4akUE9mDOtJEK1hpDyi6Ae87sWAClXGTiwPwN7PXWwjxaR79ArHRIPeYKTunVW24sPr/3HPz2IwH8oKH4OlWEmt4BLM6W5g4kMcYbLwj2usodD1088stZA7VOsUSpEVl4w7NMb1EUHMRxAxLF0CIV+0L3iZb+ekB1vSDSFjAZ3hfLJf7gFaXrOKn+mhR+rWw/eTXIcAgl4HvFuBg1LOmOAwJH3eoVEjjwheKA4icbrQCmvAtpQ0mXG0agYp5mj4Rb6mdQ+RV4QBPbxMqh9C7o8nP0Wko2ocnCHeRGhN1XVyT2b9ACsL+6ylUy+yC3QEnaKRIJK91YtaoSrcWZMMwxuM0E9J68Z+YyjA0g8p1PfHAAIROy6Sa04VXOuT6A351FOWhKfTGsFJ3RTJGWYPoLk5FVK4OaYR9hkJvezwF9vQN1126r6isMGXWTqFW+3HL3I/jurlIdDWIVvYY+s6yq7lrFSPAGRdnU7PVwY/SvWbZGpXzy3BQ2LmAJlrONUsZs4oGkly0V267xbD5KMY8woNNsmWG1VVgLCra8aQBBcI4DP2BlNwxhiCtHlaz6OWFoCW0vMR3ErrG7JyMjTSCnvRcsEHgmPnwA6iNpJ2DrFb4gLlhKJyZGaWkA97H6FFdwEcLT6DRQQL++fOkVC4cYGW1TG/3iK5dShRSuiBulmihqgjR45Vi03o2RbQbP3sxt90VxQ6vzdlGfkXmmKmjOi080JSHkLntjvsBJnv7gKscOaTOkEaRQqAnCA4HWtB4XnMtOhpRmH2FH8tTXrIjAGNWEmudQLCkcVlGTQ965Kh0H6ixXbgImQP6b42B49sO5C8pc7iRlgyvSYvcnH9FgQ3azLbQG2cUW96SDojTQStxkOJyOuDGTHAnnWkz29aEwN9FT8EJ4yhXOg+jLTrCPKeEoJ9a7lDXOjEr8AgX4BmnMQ668oW0zYPyQiVMPxKRHtpfnEEyaKhdzNVThlxxDQNdrHeZiUFb6NoY2KwvSb7BnRcpJy+/g/zAYx3fYSN5QEaVD2Y1VsNWxB0BSO12MRsRY8JLfAezRMz5lURuLUnG1ToKk6Q30FughqWN6gBNcFxP/nY/iv+iaUQOa+2Nuym46wtI/DvSfzSp1jEi4SdYBE7YhTiVV5cX9gwboVDMVgZp5YBQlHOQvaDNfcCoCJuYhf5kz5kwiIKPjzgpcRJHPbOhJajeoeRL53cuMahhV8Z7IRr6M4hW0JzT7mzaMUzQpm866zwM7Cs07fJYXuWvjAMkbe5O6V4bu71sOG6JQ4oL8zIeXHheFVavzxmlIyBkgc9IZlEDplMPr8xlcyss4pVUdwK1e7CK2kTsSdq7g5SHRAl3pYUB9Ko4fsh4qleOyJv1z3KFSTSvwEcRO/Ew8ozEDYZSqpfoVW9uhJfYrNAXR0Z3VmeoAD+rVWtwP/13sE/3ICX3HhDG3CMc476dEEC0K3umSAD4j+ZQLVdFOsWL2C1TH5+4KiSWH+lMibo+B55hR3Gq40G1n25sGcN0mEcoU2wN9FCVyQLBhYOu9aHVLWjEKx2JIUZi5ySoHUAI9b8hGzaLMxCZDMLhv8MkcpTqEwz9KFDpCpqQhVmsGQN8m24wyB82FAKNmjgfKRsXRmsSESovAwXjBIoMKSG51p6Um8b3i7GISs7kjTq/PZoioCfJzfKdJTN0Q45kQEQuh9H88M3yEs3DbtRTKALraM0YC8laiMiOOe6ADmTcCiREeAWZelBaEXRaSuj2lx0xHaRYqF65O0Lo5OCFU18A8cMDE4MLYm9w2QSr9NgQAIcRxZsNpA7UJR0e71JL+VU+ISWFk5I97lra8uGg7GlQYhGd4Gc6rxsLFRiIeGO4abP4S4ekQ1fiqDCy87GZHd52fn5aaDGuvOmIofrzpVwMvtbreZ/855OaXTRcNiNE0wzGZSxbjg26v8ko8L537v/XCCWP2MFaArJpvnkep0pA+O86MWjRAZPQRfznZiSIaTppy6m3p6HrNSsY7fDtz7Cl4V/DJAjQDoyiL2uwf1UHVd2AIrzBUSlJaTj4k6NL97a/GqhWKU9RUmjnYKpm2r+JYUcrkCuZKvcYvrg8pDoUKQywY9GDWg03DUFSirlUXBS5SWn/KAntnf0IdHGL/7mwXqDG+LZYjbEdQmqUqq4y54TNmWUP7IgcAw5816YBzwiNIJiE9M4lPCzeI/FGBeYy3p6IAmH4AjXXmvQ4Iy0Y82NTobcAggT2Cdqz6Mx4TdGoq9fn2etrWKUNFyatAHydQTVUQ2S5OWVUlugcNvoUrlA8cJJz9MqOa/W3iVno4zDHfE7zhoY5f5lRTVZDhrQbR8LS4eRLz8iPMyBL6o4PiLlp89FjdokQLaSBmKHUwWp0na5fE3v9zny2YcDXG/jfI9sctulHRbdkI5a4GOPJx4oAJQzVZ/yYAado8KNZUdEFs9ZPiBsausotXMNebEgr0dyopuqfScFJ3ODNPHgclACPdccwv0YJGQdsN2lhoV4HVGBxcEUeUX/alr4nqpcc1CCR3vR7g40zteQg/JvWmFlUE4mAiTpHlYGrB7w+U2KdSwQz2QJKBe/5eiixWipmfP15AFWrK8Sh1GBBYLgzki1wTMhGQmagXqJ2+FuqJ8f0XzXCVJFHQdMAw8xco11HhM347alrAu+wmX3pDFABOvkC+WPX0Uhg1Z5MVHKNROxaR84YV3s12UcM+70cJ460SzEaKLyh472vOMD3XnaK7zxZcXlWqenEvcjmgGNR2OKbI1s8U+iwiW+HotHalp3e1MGDy6BMVIvajnAzkFHbeVsgjmJUkrP9OAwnEHYXVBqYx3q7LvXjoVR0mY8h+ZaOnh053pdsGkmbqhyryN01eVHySr+CkDYkSMeZ1xjPNVM+gVLTDKu2VGsMUJqWO4TwPDP0VOg2/8ITbAUaMGb4LjL7L+Pi11lEVMXTYIlAZ/QHmTENjyx3kDkBdfcvvQt6tKk6jYFM4EG5UXDTaF5+1ZjRz6W7MdJPC+wTkbDUim4p5QQH3b9kGk2Bkilyeur8Bc20wm5uJSBO95GfYDI1EZipoRaH7uVveneqz43tlTZGRQ4a7CNmMHgXyOQQOL6WQkgMUTQDT8vh21aSdz7ERiZT1jK9F+v6wgFvuEmGngSvIUR2CJkc5tx1QygfZnAruONobB1idCLB1FCfO7N1ZdRocT8/Wye+EnDiO9pzqIpnLDl4bkaRKW+ekBVwHn46Shw1X0tclt/0ROijuUB4kIInrVJU4buWf4YITJtjOJ6iKdr1u+flgQeFH70GxKjhdgt/MrwfB4K/sXczQ+9zYcrD4dhY6qZhZ010rrxggWA8JaZyg2pYij8ieYEg1aZJkZK9O1Re7sB0iouf60rK0Gd+AYlp7soqCBCDGwfKeUQhCBn0E0o0GS6PdmjLi0TtCYZeqazqwN+yNINIA8Lk3iPDnWUiIPLGNcHmZDxfeK0iAdxm/T7LnN+gemRL61hHIc0NCAZaiYJR+OHnLWSe8sLrK905B5eEJHNlWq4RmEXIaFTmo49f8w61+NwfEUyuJAwVqZCLFcyHBKAcIVj3sNzfEOXzVKIndxHw+AR93owhbCxUZf6Gs8cz6/1VdrFEPrv330+9s6BtMVPJ3zl/Uf9rUi0Z/opexfdL3ykF76e999GPfVv8fJv/Y/+/5hEMon1tqNFyVRevV9y9/uIvsG3dbB8GRRrgaEXfhx+2xeOFt+cEn3RZanNxdEe2+B6MHpNbrRE53PlDifPvFcp4kO78ILR0T4xyW/WGPyBsqGdoA7zJJCu1TKbGfhnqgnRbxbB2B3UZoeQ2bz2sTVnUwokTcTU21RxN1PYPS3Sar7T0eRIsyCNowr9amwoMU/od9s2APtiKNL6ENOlyKADstAEWKA+sdKDhrJ6BOhRJmZ+QJbAaZ3/5Fq0/lumCgEzGEbu3yi0Y4I4EgVAjqxh4HbuQn0GrRhOWyAfsglQJAVL1y/6yezS2k8RE2MstJLh92NOB3GCYgFXznF4d25qiP4ZCyI4RYGesut6FXK6GwPpKK8WHEkhYui0AyEmr5Ml3uBFtPFdnioI8RiCooa7Z1G1WuyIi3nSNglutc+xY8BkeW3JJXPK6jd2VIMpaSxpVtFq+R+ySK9J6WG5Qvt+C+QH1hyYUOVK7857nFmyDBYgZ/o+AnibzNVqyYCJQvyDXDTK+iXdkA71bY7TL3bvuLxLBQ8kbTvTEY9aqkQ3+MiLWbEgjLzOH+lXgco1ERgzd80rDCymlpaRQbOYnKG/ODoFl46lzT0cjM5FYVvv0qLUbD5lyJtMUaC1pFlTkNONx6lliaX9o0i/1vws5bNKn5OuENQEKmLlcP4o2ZmJjD4zzd3Fk32uQ4uRWkPSUqb4LBe3EXHdORNB2BWsws5daRnMfNVX7isPSb1hMQdAJi1/qmDMfRUlCU74pmnzjbXfL8PVG8NsW6IQM2Ne23iCPIpryJjYbVnm5hCvKpMa7HLViNiNc+xTfDIaKm3jctViD8A1M9YPJNk003VVr4Zo2MuGW8vil8SLaGpPXqG7I4DLdtl8a4Rbx1Lt4w5Huqaa1XzZBtj208EJVGcmKYEuaeN27zT9EE6a09JerXdEbpaNgNqYJdhP1NdqiPKsbDRUi86XvvNC7rME5mrSQtrzAZVndtSjCMqd8BmaeGR4l4YFULGRBeXIV9Y4yxLFdyoUNpiy2IhePSWzBofYPP0eIa2q5JP4j9G8at/AqoSsLAUuRXtvgsqX/zYwsE+of6oSDbUOo4RMJw+DOUTJq+hnqwKim9Yy/napyZNTc2rCq6V9jHtJbxGPDwlzWj/Sk3zF/BHOlT/fSjSq7FqlPI1q6J+ru8Aku008SFINXZfOfnZNOvGPMtEmn2gLPt+H4QLA+/SYe4j398auzhKIp2Pok3mPC5q1IN1HgR+mnEfc4NeeHYwd2/kpszR3cBn7ni9NbIqhtSWFW8xbUJuUPVOeeXu3j0IGZmFNiwaNZ6rH4/zQ2ODz6tFxRLsUYZu1bfd1uIvfQDt4YD/efKYv8VF8bHGDgK22w2Wqwpi43vNCOXFJZCGMqWiPbL8mil6tsmOTXAWCyMCw73e2rADZj2IK6rqksM3EXF2cbLb4vjB14wa/yXK5vwU+05MzERJ5nXsXsW21o7M+gO0js2OyKciP5uF2iXyb2DiptwQeHeqygkrNsqVCSlldxBMpwHi1vfc8RKpP/4L3Lmpq6DZcvhDDfxTCE3splacTcOtXdK2g303dIWBVe2wD/Gvja1cClFQ67gw0t1ZUttsUgQ1Veky8oOpS6ksYEc4bqseCbZy766SvL3FodmnahlWJRgVCNjPxhL/fk2wyvlKhITH/VQCipOI0dNcRa5B1M5HmOBjTLeZQJy237e2mobwmDyJNHePhdDmiknvLKaDbShL+Is1XTCJuLQd2wmdJL7+mKvs294whXQD+vtd88KKk0DXP8B1Xu9J+xo69VOuFgexgTrcvI6SyltuLix9OPuE6/iRJYoBMEXxU4shQMf4Fjqwf1PtnJ/wWSZd29rhZjRmTGgiGTAUQqRz+nCdjeMfYhsBD5Lv60KILWEvNEHfmsDs2L0A252351eUoYxAysVaCJVLdH9QFWAmqJDCODUcdoo12+gd6bW2boY0pBVHWL6LQDK5bYWh1V8vFvi0cRpfwv7cJiMX3AZNJuTddHehTIdU0YQ/sQ1dLoF2xQPcCuHKiuCWOY30DHe1OwcClLAhqAKyqlnIbH/8u9ScJpcS4kgp6HKDUdiOgRaRGSiUCRBjzI5gSksMZKqy7Sd51aeg0tgJ+x0TH9YH2Mgsap9N7ENZdEB0bey2DMTrBA1hn56SErNHf3tKtqyL9b6yXEP97/rc+jgD2N1LNUH6RM9AzP3kSipr06RkKOolR7HO768jjWiH1X92jA7dkg7gcNcjqsZCgfqWw0tPXdLg20cF6vnQypg7gLtkazrHAodyYfENPQZsdfnjMZiNu4nJO97D1/sQE+3vNFzrSDOKw+keLECYf7RJwVHeP/j79833oZ0egonYB2FlFE5qj02B/LVOMJQlsB8uNg3Leg4qtZwntsOSNidR0abbZmAK4sCzvt8Yiuz2yrNCJoH5O8XvX/vLeR/BBYTWj0sOPYM/jyxRd5+/JziKAABaPcw/34UA3aj/gLZxZgRCWN6m4m3demanNgsx0P237/Q+Ew5VYnJPkyCY0cIVHoFn2Ay/e7U4P19APbPFXEHX94N6KhEMPG7iwB3+I+O1jd5n6VSgHegxgaSawO6iQCYFgDsPSMsNOcUj4q3sF6KzGaH/0u5PQoAj/8zq6Uc9MoNrGqhYeb2jQo0WlGlXjxtanZLS24/OIN5Gx/2g684BPDQpwlqnkFcxpmP/osnOXrFuu4PqifouQH0eF5qCkvITQbJw/Zvy5mAHWC9oU+cTiYhJmSfKsCyt1cGVxisKu+NymEQIAyaCgud/V09qT3nk/9s/SWsYtha7yNpzBIMM40rCSGaJ9u6lEkl00vXBiEt7p9P5IBCiavynEOv7FgLqPdeqxRiCwuFVMolSIUBcoyfUC2e2FJSAUgYdVGFf0b0Kn2EZlK97yyxrT2MVgvtRikfdaAW8RwEEfN+B7/eK8bBdp7URpbqn1xcrC6d2UjdsKbzCjBFqkKkoZt7Mrhg6YagE7spkqj0jOrWM+UGQ0MUlG2evP1uE1p2xSv4dMK0dna6ENcNUF+xkaJ7B764NdxLCpuvhblltVRAf7vK5qPttJ/9RYFUUSGcLdibnz6mf7WkPO3MkUUhR2mAOuGv8IWw5XG1ZvoVMnjSAZe6T7WYA99GENxoHkMiKxHlCuK5Gd0INrISImHQrQmv6F4mqU/TTQ8nHMDzCRivKySQ8dqkpQgnUMnwIkaAuc6/FGq1hw3b2Sba398BhUwUZSAIO8XZvnuLdY2n6hOXws+gq9BHUKcKFA6kz6FDnpxLPICa3qGhnc97bo1FT/XJk48LrkHJ2CAtBv0RtN97N21plfpXHvZ8gMJb7Zc4cfI6MbPwsW7AilCSXMFIEUEmir8XLEklA0ztYbGpTTGqttp5hpFTTIqUyaAIqvMT9A/x+Ji5ejA4Bhxb/cl1pUdOD6epd3yilIdO6j297xInoiBPuEDW2/UfslDyhGkQs7Wy253bVnlT+SWg89zYIK/9KXFl5fe+jow2rd5FXv8zDPrmfMXiUPt9QBO/iK4QGbX5j/7Rx1c1vzsY8ONbP3lVIaPrhL4+1QrECTN3nyKavGG0gBBtHvTKhGoBHgMXHStFowN+HKrPriYu+OZ05Frn8okQrPaaxoKP1ULCS/cmKFN3gcH7HQlVjraCeQmtjg1pSQxeuqXiSKgLpxc/1OiZsU4+n4lz4hpahGyWBURLi4642n1gn9qz9bIsaCeEPJ0uJmenMWp2tJmIwLQ6VSgDYErOeBCfSj9P4G/vI7oIF+l/n5fp956QgxGvur77ynawAu3G9MdFbJbu49NZnWnnFcQHjxRuhUYvg1U/e84N4JTecciDAKb/KYIFXzloyuE1eYXf54MmhjTq7B/yBToDzzpx3tJCTo3HCmVPYfmtBRe3mPYEE/6RlTIxbf4fSOcaKFGk4gbaUWe44hVk9SZzhW80yfW5QWBHxmtUzvMhfVQli4gZTktIOZd9mjJ5hsbmzttaHQB29Am3dZkmx3g/qvYocyhZ2PXAWsNQiIaf+Q8W/MWPIK7/TjvCx5q2XRp4lVWydMc2wIQkhadDB0xsnw/kSEyGjLKjI4coVIwtubTF3E7MJ6LS6UOsJKj82XVAVPJJcepfewbzE91ivXZvOvYfsmMevwtPpfMzGmC7WJlyW2j0jh7AF1JLmwEJSKYwIvu6DHc3YnyLH9ZdIBnQ+nOVDRiP+REpqv++typYHIvoJyICGA40d8bR7HR2k7do6UQTHF4oriYeIQbxKe4Th6+/l1BjUtS9hqORh3MbgvYrStXTfSwaBOmAVQZzpYNqsAmQyjY56MUqty3c/xH6GuhNvNaG9vGbG6cPtBM8UA3e8r51D0AR9kozKuGGSMgLz3nAHxDNnc7GTwpLj7/6HeWp1iksDeTjwCLpxejuMtpMnGJgsiku1sOACwQ9ukzESiDRN77YNESxR5LphOlcASXA5uIts1LnBIcn1J7BLWs49DMALSnuz95gdOrTZr0u1SeYHinno/pE58xYoXbVO/S+FEMMs5qyWkMnp8Q3ClyTlZP52Y9nq7b8fITPuVXUk9ohG5EFHw4gAEcjFxfKb3xuAsEjx2z1wxNbSZMcgS9GKyW3R6KwJONgtA64LTyxWm8Bvudp0M1FdJPEGopM4Fvg7G/hsptkhCfHFegv4ENwxPeXmYhxwZy7js+BeM27t9ODBMynVCLJ7RWcBMteZJtvjOYHb5lOnCLYWNEMKC59BA7covu1cANa2PXL05iGdufOzkgFqqHBOrgQVUmLEc+Mkz4Rq8O6WkNr7atNkH4M8d+SD1t/tSzt3oFql+neVs+AwEI5JaBJaxARtY2Z4mKoUqxds4UpZ0sv3zIbNoo0J4fihldQTX3XNcuNcZmcrB5LTWMdzeRuAtBk3cZHYQF6gTi3PNuDJ0nmR+4LPLoHvxQIxRgJ9iNNXqf2SYJhcvCtJiVWo85TsyFOuq7EyBPJrAdhEgE0cTq16FQXhYPJFqSfiVn0IQnPOy0LbU4BeG94QjdYNB0CiQ3QaxQqD2ebSMiNjaVaw8WaM4Z5WnzcVDsr4eGweSLa2DE3BWViaxhZFIcSTjgxNCAfelg+hznVOYoe5VqTYs1g7WtfTm3e4/WduC6p+qqAM8H4ZyrJCGpewThTDPe6H7CzX/zQ8Tm+r65HeZn+MsmxUciEWPlAVaK/VBaQBWfoG/aRL/jSZIQfep/89GjasWmbaWzeEZ2R1FOjvyJT37O9B8046SRSKVEnXWlBqbkb5XCS3qFeuE9xb9+frEknxWB5h1D/hruz2iVDEAS7+qkEz5Ot5agHJc7WCdY94Ws61sURcX5nG8UELGBAHZ3i+3VulAyT0nKNNz4K2LBHBWJcTBX1wzf+//u/j/9+//v87+9/l9Lbh/L/uyNYiTsWV2LwsjaA6MxTuzFMqmxW8Jw/+IppdX8t/Clgi1rI1SN0UC/r6tX/4lUc2VV1OQReSeCsjUpKZchw4XUcjHfw6ryCV3R8s6VXm67vp4n+lcPV9gJwmbKQEsmrJi9c2vkwrm8HFbVYNTaRGq8D91t9n5+U+aD/hNtN3HjC/nC/vUoGFSCkXP+NlRcmLUqLbiUBl4LYf1U/CCvwtd3ryCH8gUmGITAxiH1O5rnGTz7y1LuFjmnFGQ1UWuM7HwfXtWl2fPFKklYwNUpF2IL/TmaRETjQiM5SJacI+3Gv5MBU8lP5Io6gWkawpyzNEVGqOdx4YlO1dCvjbWFZWbCmeiFKPSlMKtKcMFLs/KQxtgAHi7NZNCQ32bBAW2mbHflVZ8wXKi1JKVHkW20bnYnl3dKWJeWJOiX3oKPBD6Zbi0ZvSIuWktUHB8qDR8DMMh1ZfkBL9FS9x5r0hBGLJ8pUCJv3NYH+Ae8p40mZWd5m5fhobFjQeQvqTT4VKWIYfRL0tfaXKiVl75hHReuTJEcqVlug+eOIIc4bdIydtn2K0iNZPsYWQvQio2qbO3OqAlPHDDOB7DfjGEfVF51FqqNacd6QmgFKJpMfLp5DHTv4wXlONKVXF9zTJpDV4m1sYZqJPhotcsliZM8yksKkCkzpiXt+EcRQvSQqmBS9WdWkxMTJXPSw94jqI3varCjQxTazjlMH8jTS8ilaW8014/vwA/LNa+YiFoyyx3s/KswP3O8QW1jtq45yTM/DX9a8M4voTVaO2ebvw1EooDw/yg6Y1faY+WwrdVs5Yt0hQ5EwRfYXSFxray1YvSM+kYmlpLG2/9mm1MfmbKHXr44Ih8nVKb1M537ZANUkCtdsPZ80JVKVKabVHCadaLXg+IV8i5GSwpZti0h6diTaKs9sdpUKEpd7jDUpYmHtiX33SKiO3tuydkaxA7pEc9XIQEOfWJlszj5YpL5bKeQyT7aZSBOamvSHl8xsWvgo26IP/bqk+0EJUz+gkkcvlUlyPp2kdKFtt7y5aCdks9ZJJcFp5ZWeaWKgtnXMN3ORwGLBE0PtkEIek5FY2aVssUZHtsWIvnljMVJtuVIjpZup/5VL1yPOHWWHkOMc6YySWMckczD5jUj2mlLVquFaMU8leGVaqeXis+aRRL8zm4WuBk6cyWfGMxgtr8useQEx7k/PvRoZyd9nde1GUCV84gMX8Ogu/BWezYPSR27llzQnA97oo0pYyxobYUJfsj+ysTm9zJ+S4pk0TGo9VTG0KjqYhTmALfoDZVKla2b5yhv241PxFaLJs3i05K0AAIdcGxCJZmT3ZdT7CliR7q+kur7WdQjygYtOWRL9B8E4s4LI8KpAj7bE0dg7DLOaX+MGeAi0hMMSSWZEz+RudXbZCsGYS0QqiXjH9XQbd8sCB+nIVTq7/T/FDS+zWY9q7Z2fdq1tdLb6v3hKKVDAw5gjj6o9r1wHFROdHc18MJp4SJ2Ucvu+iQ9EgkekW8VCM+psM6y+/2SBy8tNN4a3L1MzP+OLsyvESo5gS7IQOnIqMmviJBVc6zbVG1n8eXiA3j46kmvvtJlewwNDrxk4SbJOtP/TV/lIVK9ueShNbbMHfwnLTLLhbZuO79ec5XvfgRwLFK+w1r5ZWW15rVFZrE+wKqNRv5KqsLNfpGgnoUU6Y71NxEmN7MyqwqAQqoIULOw/LbuUB2+uE75gJt+kq1qY4LoxV+qR/zalupea3D5+WMeaRIn0sAI6DDWDh158fqUb4YhAxhREbUN0qyyJYkBU4V2KARXDT65gW3gRsiv7xSPYEKLwzgriWcWgPr0sbZnv7m1XHNFW6xPdGNZUdxFiUYlmXNjDVWuu7LCkX/nVkrXaJhiYktBISC2xgBXQnNEP+cptWl1eG62a7CPXrnrkTQ5BQASbEqUZWMDiZUisKyHDeLFOaJILUo5f6iDt4ZO8MlqaKLto0AmTHVVbkGuyPa1R/ywZsWRoRDoRdNMMHwYTsklMVnlAd2S0282bgMI8fiJpDh69OSL6K3qbo20KfpNMurnYGQSr/stFqZ7hYsxKlLnKAKhsmB8AIpEQ4bd/NrTLTXefsE6ChRmKWjXKVgpGoPs8GAicgKVw4K0qgDgy1A6hFq1WRat3fHF+FkU+b6H4NWpOU3KXTxrIb2qSHAb+qhm8hiSROi/9ofapjxhyKxxntPpge6KL5Z4+WBMYkAcE6+0Hd3Yh2zBsK2MV3iW0Y6cvOCroXlRb2MMJtdWx+3dkFzGh2Pe3DZ9QpSqpaR/rE1ImOrHqYYyccpiLC22amJIjRWVAherTfpQLmo6/K2pna85GrDuQPlH1Tsar8isAJbXLafSwOof4gg9RkAGm/oYpBQQiPUoyDk2BCQ1k+KILq48ErFo4WSRhHLq/y7mgw3+L85PpP6xWr6cgp9sOjYjKagOrxF148uhuaWtjet953fh1IQiEzgC+d2IgBCcUZqgTAICm2bR8oCjDLBsmg+ThyhfD+zBalsKBY1Ce54Y/t9cwfbLu9SFwEgphfopNA3yNxgyDafUM3mYTovZNgPGdd4ZFFOj1vtfFW3u7N+iHEN1HkeesDMXKPyoCDCGVMo4GCCD6PBhQ3dRZIHy0Y/3MaE5zU9mTCrwwnZojtE+qNpMSkJSpmGe0EzLyFelMJqhfFQ7a50uXxZ8pCc2wxtAKWgHoeamR2O7R+bq7IbPYItO0esdRgoTaY38hZLJ5y02oIVwoPokGIzxAMDuanQ1vn2WDQ00Rh6o5QOaCRu99fwDbQcN0XAuqkFpxT/cfz3slGRVokrNU0iqiMAJFEbKScZdmSkTUznC0U+MfwFOGdLgsewRyPKwBZYSmy6U325iUhBQNxbAC3FLKDV9VSOuQpOOukJ/GAmu/tyEbX9DgEp6dv1zoU0IqzpG6gssSjIYRVPGgU1QAQYRgIT8gEV0EXr1sqeh2I6rXjtmoCYyEDCe/PkFEi/Q48FuT29p557iN+LCwk5CK/CZ2WdAdfQZh2Z9QGrzPLSNRj5igUWzl9Vi0rCqH8G1Kp4QMLkuwMCAypdviDXyOIk0AHTM8HBYKh3b0/F+DxoNj4ZdoZfCpQVdnZarqoMaHWnMLNVcyevytGsrXQEoIbubqWYNo7NRHzdc0zvT21fWVirj7g36iy6pxogfvgHp1xH1Turbz8QyyHnXeBJicpYUctbzApwzZ1HT+FPEXMAgUZetgeGMwt4G+DHiDT2Lu+PT21fjJCAfV16a/Wu1PqOkUHSTKYhWW6PhhHUlNtWzFnA7MbY+r64vkwdpfNB2JfWgWXAvkzd42K4lN9x7Wrg4kIKgXCb4mcW595MCPJ/cTfPAMQMFWwnqwde4w8HZYJFpQwcSMhjVz4B8p6ncSCN1X4klxoIH4BN2J6taBMj6lHkAOs8JJAmXq5xsQtrPIPIIp/HG6i21xMGcFgqDXSRF0xQg14d2uy6HgKE13LSvQe52oShF5Jx1R6avyL4thhXQZHfC94oZzuPUBKFYf1VvDaxIrtV6dNGSx7DO0i1p6CzBkuAmEqyWceQY7F9+U0ObYDzoa1iKao/cOD/v6Q9gHrrr1uCeOk8fST9MG23Ul0KmM3r+Wn6Hi6WAcL7gEeaykicvgjzkjSwFsAXIR81Zx4QJ6oosVyJkCcT+4xAldCcihqvTf94HHUPXYp3REIaR4dhpQF6+FK1H0i9i7Pvh8owu3lO4PT1iuqu+DkL2Bj9+kdfGAg2TXw03iNHyobxofLE2ibjsYDPgeEQlRMR7afXbSGQcnPjI2D+sdtmuQ771dbASUsDndU7t58jrrNGRzISvwioAlHs5FA+cBE5Ccznkd8NMV6BR6ksnKLPZnMUawRDU1MZ/ib3xCdkTblHKu4blNiylH5n213yM0zubEie0o4JhzcfAy3H5qh2l17uLooBNLaO+gzonTH2uF8PQu9EyH+pjGsACTMy4cHzsPdymUSXYJOMP3yTkXqvO/lpvt0cX5ekDEu9PUfBeZODkFuAjXCaGdi6ew4qxJ8PmFfwmPpkgQjQlWqomFY6UkjmcnAtJG75EVR+NpzGpP1Ef5qUUbfowrC3zcSLX3BxgWEgEx/v9cP8H8u1Mvt9/rMDYf6sjwU1xSOPBgzFEeJLMRVFtKo5QHsUYT8ZRLCah27599EuqoC9PYjYO6aoAMHB8X1OHwEAYouHfHB3nyb2B+SnZxM/vw/bCtORjLMSy5aZoEpvgdGvlJfNPFUu/p7Z4VVK1hiI0/UTuB3ZPq4ohEbm7Mntgc1evEtknaosgZSwnDC2BdMmibpeg48X8Ixl+/8+xXdbshQXUPPvx8jT3fkELivHSmqbhblfNFShWAyQnJ3WBU6SMYSIpTDmHjdLVAdlADdz9gCplZw6mTiHqDwIsxbm9ErGusiVpg2w8Q3khKV/R9Oj8PFeF43hmW/nSd99nZzhyjCX3QOZkkB6BsH4H866WGyv9E0hVAzPYah2tkRfQZMmP2rinfOeQalge0ovhduBjJs9a1GBwReerceify49ctOh5/65ATYuMsAkVltmvTLBk4oHpdl6i+p8DoNj4Fb2vhdFYer2JSEilEwPd5n5zNoGBXEjreg/wh2NFnNRaIUHSOXa4eJRwygZoX6vnWnqVdCRT1ARxeFrNBJ+tsdooMwqnYhE7zIxnD8pZH+P0Nu1wWxCPTADfNWmqx626IBJJq6NeapcGeOmbtXvl0TeWG0Y7OGGV4+EHTtNBIT5Wd0Bujl7inXgZgfXTM5efD3qDTJ54O9v3Bkv+tdIRlq1kXcVD0BEMirmFxglNPt5pedb1AnxuCYMChUykwsTIWqT23XDpvTiKEru1cTcEMeniB+HQDehxPXNmkotFdwUPnilB/u4Nx5Xc6l8J9jH1EgKZUUt8t8cyoZleDBEt8oibDmJRAoMKJ5Oe9CSWS5ZMEJvacsGVdXDWjp/Ype5x0p9PXB2PAwt2LRD3d+ftNgpuyvxlP8pB84oB1i73vAVpwyrmXW72hfW6Dzn9Jkj4++0VQ4d0KSx1AsDA4OtXXDo63/w+GD+zC7w5SJaxsmnlYRQ4dgdjA7tTl2KNLnpJ+mvkoDxtt1a4oPaX3EVqj96o9sRKBQqU7ZOiupeAIyLMD+Y3YwHx30XWHB5CQiw7q3mj1EDlP2eBsZbz79ayUMbyHQ7s8gu4Lgip1LiGJj7NQj905/+rgUYKAA5qdrlHKIknWmqfuR+PB8RdBkDg/NgnlT89G72h2NvySnj7UyBwD+mi/IWs1xWbxuVwUIVXun5cMqBtFbrccI+DILjsVQg6eeq0itiRfedn89CvyFtpkxaauEvSANuZmB1p8FGPbU94J9medwsZ9HkUYjmI7OH5HuxendLbxTaYrPuIfE2ffXFKhoNBUp33HsFAXmCV/Vxpq5AYgFoRr5Ay93ZLRlgaIPjhZjXZZChT+aE5iWAXMX0oSFQEtwjiuhQQItTQX5IYrKfKB+queTNplR1Hoflo5/I6aPPmACwQCE2jTOYo5Dz1cs7Sod0KTG/3kEDGk3kUaUCON19xSJCab3kNpWZhSWkO8l+SpW70Wn3g0ciOIJO5JXma6dbos6jyisuxXwUUhj2+1uGhcvuliKtWwsUTw4gi1c/diEEpZHoKoxTBeMDmhPhKTx7TXWRakV8imJR355DcIHkR9IREHxohP4TbyR5LtFU24umRPRmEYHbpe1LghyxPx7YgUHjNbbQFRQhh4KeU1EabXx8FS3JAxp2rwRDoeWkJgWRUSKw6gGP5U2PuO9V4ZuiKXGGzFQuRuf+tkSSsbBtRJKhCi3ENuLlXhPbjTKD4djXVnfXFds6Zb+1XiUrRfyayGxJq1+SYBEfbKlgjiSmk0orgTqzSS+DZ5rTqsJbttiNtp+KMqGE2AHGFw6jQqM5vD6vMptmXV9OAjq49Uf/Lx9Opam+Hn5O9p8qoBBAQixzQZ4eNVkO9sPzJAMyR1y4/RCQQ1s0pV5KAU5sKLw3tkcFbI/JqrjCsK4Mw+W8aod4lioYuawUiCyVWBE/qPaFi5bnkgpfu/ae47174rI1fqQoTbW0HrU6FAejq7ByM0V4zkZTg02/YJK2N7hUQRCeZ4BIgSEqgD8XsjzG6LIsSbuHoIdz/LhFzbNn1clci1NHWJ0/6/O8HJMdIpEZbqi1RrrFfoo/rI/7ufm2MPG5lUI0IYJ4MAiHRTSOFJ2oTverFHYXThkYFIoyFx6rMYFgaOKM4xNWdlOnIcKb/suptptgTOTdVIf4YgdaAjJnIAm4qNNHNQqqAzvi53GkyRCEoseUBrHohZsjUbkR8gfKtc/+Oa72lwxJ8Mq6HDfDATbfbJhzeIuFQJSiw1uZprHlzUf90WgqG76zO0eCB1WdPv1IT6sNxxh91GEL2YpgC97ikFHyoaH92ndwduqZ6IYjkg20DX33MWdoZk7QkcKUCgisIYslOaaLyvIIqRKWQj16jE1DlQWJJaPopWTJjXfixEjRJJo8g4++wuQjbq+WVYjsqCuNIQW3YjnxKe2M5ZKEqq+cX7ZVgnkbsU3RWIyXA1rxv4kGersYJjD//auldXGmcEbcfTeF16Y1708FB1HIfmWv6dSFi6oD4E+RIjCsEZ+kY7dKnwReJJw3xCjKvi3kGN42rvyhUlIz0Bp+fNSV5xwFiuBzG296e5s/oHoFtUyUplmPulIPl+e1CQIQVtjlzLzzzbV+D/OVQtYzo5ixtMi5BmHuG4N/uKfJk5UIREp7+12oZlKtPBomXSzAY0KgtbPzzZoHQxujnREUgBU+O/jKKhgxVhRPtbqyHiUaRwRpHv7pgRPyUrnE7fYkVblGmfTY28tFCvlILC04Tz3ivkNWVazA+OsYrxvRM/hiNn8Fc4bQBeUZABGx5S/xFf9Lbbmk298X7iFg2yeimvsQqqJ+hYbt6uq+Zf9jC+Jcwiccd61NKQtFvGWrgJiHB5lwi6fR8KzYS7EaEHf/ka9EC7H8D+WEa3TEACHBkNSj/cXxFeq4RllC+fUFm2xtstYLL2nos1DfzsC9vqDDdRVcPA3Ho95aEQHvExVThXPqym65llkKlfRXbPTRiDepdylHjmV9YTWAEjlD9DdQnCem7Aj/ml58On366392214B5zrmQz/9ySG2mFqEwjq5sFl5tYJPw5hNz8lyZPUTsr5E0F2C9VMPnZckWP7+mbwp/BiN7f4kf7vtGnZF2JGvjK/sDX1RtcFY5oPQnE4lIAYV49U3C9SP0LCY/9i/WIFK9ORjzM9kG/KGrAuwFmgdEpdLaiqQNpCTGZVuAO65afkY1h33hrqyLjZy92JK3/twdj9pafFcwfXONmPQWldPlMe7jlP24Js0v9m8bIJ9TgS2IuRvE9ZVRaCwSJYOtAfL5H/YS4FfzKWKbek+GFulheyKtDNlBtrdmr+KU+ibHTdalzFUmMfxw3f36x+3cQbJLItSilW9cuvZEMjKw987jykZRlsH/UI+HlKfo2tLwemBEeBFtmxF2xmItA/dAIfQ+rXnm88dqvXa+GapOYVt/2waFimXFx3TC2MUiOi5/Ml+3rj/YU6Ihx2hXgiDXFsUeQkRAD6wF3SCPi2flk7XwKAA4zboqynuELD312EJ88lmDEVOMa1W/K/a8tGylZRMrMoILyoMQzzbDJHNZrhH77L9qSC42HVmKiZ5S0016UTp83gOhCwz9XItK9fgXfK3F5d7nZCBUekoLxrutQaPHa16Rjsa0gTrzyjqTnmcIcrxg6X6dkKiucudc0DD5W4pJPf0vuDW8r5/uw24YfMuxFRpD2ovT2mFX79xH6Jf+MVdv2TYqR6/955QgVPe3JCD/WjAYcLA9tpXgFiEjge2J5ljeI/iUzg91KQuHkII4mmHZxC3XQORLAC6G7uFn5LOmlnXkjFdoO976moNTxElS8HdxWoPAkjjocDR136m2l+f5t6xaaNgdodOvTu0rievnhNAB79WNrVs6EsPgkgfahF9gSFzzAd+rJSraw5Mllit7vUP5YxA843lUpu6/5jAR0RvH4rRXkSg3nE+O5GFyfe+L0s5r3k05FyghSFnKo4TTgs07qj4nTLqOYj6qaW9knJTDkF5OFMYbmCP+8H16Ty482OjvERV6OFyw043L9w3hoJi408sR+SGo1WviXUu8d7qS+ehKjpKwxeCthsm2LBFSFeetx0x4AaKPxtp3CxdWqCsLrB1s/j5TAhc1jNZsXWl6tjo/WDoewxzg8T8NnhZ1niUwL/nhfygLanCnRwaFGDyLw+sfZhyZ1UtYTp8TYB6dE7R3VsKKH95CUxJ8u8N+9u2/9HUNKHW3x3w5GQrfOPafk2w5qZq8MaHT0ebeY3wIsp3rN9lrpIsW9c1ws3VNV+JwNz0Lo9+V7zZr6GD56We6gWVIvtmam5GPPkVAbr74r6SwhuL+TRXtW/0pgyX16VNl4/EAD50TnUPuwrW6OcUO2VlWXS0inq872kk7GUlW6o/ozFKq+Sip6LcTtSDfDrPTcCHhx75H8BeRon+KG2wRwzfDgWhALmiWOMO6h3pm1UCZEPEjScyk7tdLx6WrdA2N1QTPENvNnhCQjW6kl057/qv7IwRryHrZBCwVSbLLnFRiHdTwk8mlYixFt1slEcPD7FVht13HyqVeyD55HOXrh2ElAxJyinGeoFzwKA91zfrdLvDxJSjzmImfvTisreI25EDcVfGsmxLVbfU8PGe/7NmWWKjXcdTJ11jAlVIY/Bv/mcxg/Q10vCHwKG1GW/XbJq5nxDhyLqiorn7Wd7VEVL8UgVzpHMjQ+Z8DUgSukiVwWAKkeTlVVeZ7t1DGnCgJVIdBPZAEK5f8CDyDNo7tK4/5DBjdD5MPV86TaEhGsLVFPQSI68KlBYy84FievdU9gWh6XZrugvtCZmi9vfd6db6V7FmoEcRHnG36VZH8N4aZaldq9zZawt1uBFgxYYx+Gs/qW1jwANeFy+LCoymyM6zgG7j8bGzUyLhvrbJkTYAEdICEb4kMKusKT9V3eIwMLsjdUdgijMc+7iKrr+TxrVWG0U+W95SGrxnxGrE4eaJFfgvAjUM4SAy8UaRwE9j6ZQH5qYAWGtXByvDiLSDfOD0yFA3UCMKSyQ30fyy1mIRg4ZcgZHLNHWl+c9SeijOvbOJxoQy7lTN2r3Y8p6ovxvUY74aOYbuVezryqXA6U+fcp6wSV9X5/OZKP18tB56Ua0gMyxJI7XyNT7IrqN8GsB9rL/kP5KMrjXxgqKLDa+V5OCH6a5hmOWemMUsea9vQl9t5Oce76PrTyTv50ExOqngE3PHPfSL//AItPdB7kGnyTRhVUUFNdJJ2z7RtktZwgmQzhBG/G7QsjZmJfCE7k75EmdIKH7xlnmDrNM/XbTT6FzldcH/rcRGxlPrv4qDScqE7JSmQABJWqRT/TUcJSwoQM+1jvDigvrjjH8oeK2in1S+/yO1j8xAws/T5u0VnIvAPqaE1atNuN0cuRliLcH2j0nTL4JpcR7w9Qya0JoaHgsOiALLCCzRkl1UUESz+ze/gIXHGtDwgYrK6pCFKJ1webSDog4zTlPkgXZqxlQDiYMjhDpwTtBW2WxthWbov9dt2X9XFLFmcF+eEc1UaQ74gqZiZsdj63pH1qcv3Vy8JYciogIVKsJ8Yy3J9w/GhjWVSQAmrS0BPOWK+RKV+0lWqXgYMnIFwpcZVD7zPSp547i9HlflB8gVnSTGmmq1ClO081OW/UH11pEQMfkEdDFzjLC1Cdo/BdL3s7cXb8J++Hzz1rhOUVZFIPehRiZ8VYu6+7Er7j5PSZu9g/GBdmNzJmyCD9wiswj9BZw+T3iBrg81re36ihMLjoVLoWc+62a1U/7qVX5CpvTVF7rocSAKwv4cBVqZm7lLDS/qoXs4fMs/VQi6BtVbNA3uSzKpQfjH1o3x4LrvkOn40zhm6hjduDglzJUwA0POabgdXIndp9fzhOo23Pe+Rk9GSLX0d71Poqry8NQDTzNlsa+JTNG9+UrEf+ngxCjGEsDCc0bz+udVRyHQI1jmEO3S+IOQycEq7XwB6z3wfMfa73m8PVRp+iOgtZfeSBl01xn03vMaQJkyj7vnhGCklsCWVRUl4y+5oNUzQ63B2dbjDF3vikd/3RUMifPYnX5Glfuk2FsV/7RqjI9yKTbE8wJY+74p7qXO8+dIYgjtLD/N8TJtRh04N9tXJA4H59IkMmLElgvr0Q5OCeVfdAt+5hkh4pQgfRMHpL74XatLQpPiOyHRs/OdmHtBf8nOZcxVKzdGclIN16lE7kJ+pVMjspOI+5+TqLRO6m0ZpNXJoZRv9MPDRcAfJUtNZHyig/s2wwReakFgPPJwCQmu1I30/tcBbji+Na53i1W1N+BqoY7Zxo+U/M9XyJ4Ok2SSkBtoOrwuhAY3a03Eu6l8wFdIG1cN+e8hopTkiKF093KuH/BcB39rMiGDLn6XVhGKEaaT/vqb/lufuAdpGExevF1+J9itkFhCfymWr9vGb3BTK4j598zRH7+e+MU9maruZqb0pkGxRDRE1CD4Z8LV4vhgPidk5w2Bq816g3nHw1//j3JStz7NR9HIWELO8TMn3QrP/zZp//+Dv9p429/ogv+GATR+n/UdF+ns9xNkXZQJXY4t9jMkJNUFygAtzndXwjss+yWH9HAnLQQfhAskdZS2l01HLWv7L7us5uTH409pqitvfSOQg/c+Zt7k879P3K9+WV68n7+3cZfuRd/dDPP/03rn+d+/nBvWfgDlt8+LzjqJ/vx3CnNOwiXhho778C96iD+1TBvRZYeP+EH81LE0vVwOOrmCLB3iKzI1x+vJEsrPH4uF0UB4TJ4X3uDfOCo3PYpYe0MF4bouh0DQ/l43fxUF7Y+dpWuvTSffB0yO2UQUETI/LwCZE3BvnevJ7c9zUlY3H58xzke6DNFDQG8n0WtDN4LAYN4nogKav1ezOfK/z+t6tsCTp+dhx4ymjWuCJk1dEUifDP+HyS4iP/Vg9B2jTo9L4NbiBuDS4nuuHW6H+JDQn2JtqRKGkEQPEYE7uzazXIkcxIAqUq1esasZBETlEZY7y7Jo+RoV/IsjY9eIMkUvr42Hc0xqtsavZvhz1OLwSxMOTuqzlhb0WbdOwBH9EYiyBjatz40bUxTHbiWxqJ0uma19qhPruvcWJlbiSSH48OLDDpaHPszvyct41ZfTu10+vjox6kOqK6v0K/gEPphEvMl/vwSv+A4Hhm36JSP9IXTyCZDm4kKsqD5ay8b1Sad/vaiyO5N/sDfEV6Z4q95E+yfjxpqBoBETW2C7xl4pIO2bDODDFurUPwE7EWC2Uplq+AHmBHvir2PSgkR12/Ry65O0aZtQPeXi9mTlF/Wj5GQ+vFkYyhXsLTjrBSP9hwk4GPqDP5rBn5/l8b0mLRAvRSzXHc293bs3s8EsdE3m2exxidWVB4joHR+S+dz5/W+v00K3TqN14CDBth8eWcsTbiwXPsygHdGid0PEdy6HHm2v/IUuV5RVapYmzGsX90mpnIdNGcOOq64Dbc5GUbYpD9M7S+6cLY//QmjxFLP5cuTFRm3vA5rkFZroFnO3bjHF35uU3s8mvL7Tp9nyTc4mymTJ5sLIp7umSnGkO23faehtz3mmTS7fbVx5rP7x3HXIjRNeq/A3xCs9JNB08c9S9BF2O3bOur0ItslFxXgRPdaapBIi4dRpKGxVz7ir69t/bc9qTxjvtOyGOfiLGDhR4fYywHv1WdOplxIV87TpLBy3Wc0QP0P9s4G7FBNOdITS/tep3o3h1TEa5XDDii7fWtqRzUEReP2fbxz7bHWWJdbIOxOUJZtItNZpTFRfj6vm9sYjRxQVO+WTdiOhdPeTJ+8YirPvoeL88l5iLYOHd3b/Imkq+1ZN1El3UikhftuteEYxf1Wujof8Pr4ICTu5ezZyZ4tHQMxlzUHLYO2VMOoNMGL/20S5i2o2obfk+8qqdR7xzbRDbgU0lnuIgz4LelQ5XS7xbLuSQtNS95v3ZUOdaUx/Qd8qxCt6xf2E62yb/HukLO6RyorV8KgYl5YNc75y+KvefrxY+lc/64y9kvWP0a0bDz/rojq+RWjO06WeruWqNFU7r3HPIcLWRql8ICZsz2Ls/qOm/CLn6++X+Qf7mGspYCrZod/lpl6Rw4xN/yuq8gqV4B6aHk1hVE1SfILxWu5gvXqbfARYQpspcxKp1F/c8XOPzkZvmoSw+vEqBLdrq1fr3wAPv5NnM9i8F+jdAuxkP5Z71c6uhK3enlnGymr7UsWZKC12qgUiG8XXGQ9mxnqz4GSIlybF9eXmbqj2sHX+a1jf0gRoONHRdRSrIq03Ty89eQ1GbV/Bk+du4+V15zls+vvERvZ4E7ZbnxWTVjDjb4o/k8jlw44pTIrUGxxuJvBeO+heuhOjpFsO6lVJ/aXnJDa/bM0Ql1cLbXE/Pbv3EZ3vj3iVrB5irjupZTzlnv677NrI9UNYNqbPgp/HZXS+lJmk87wec+7YOxTDo2aw2l3NfDr34VNlvqWJBknuK7oSlZ6/T10zuOoPZOeoIk81N+sL843WJ2Q4Z0fZ3scsqC/JV2fuhWi1jGURSKZV637lf53Xnnx16/vKEXY89aVJ0fv91jGdfG+G4+sniwHes4hS+udOr4RfhFhG/F5gUG35QaU+McuLmclb5ZWmR+sG5V6nf+PxYzlrnFGxpZaK8eqqVo0NfmAWoGfXDiT/FnUbWvzGDOTr8aktOZWg4BYvz5YH12ZbfCcGtNk+dDAZNGWvHov+PIOnY9Prjg8h/wLRrT69suaMVZ5bNuK00lSVpnqSX1NON/81FoP92rYndionwgOiA8WMf4vc8l15KqEEG4yAm2+WAN5Brfu1sq9suWYqgoajgOYt/JCk1gC8wPkK+XKCtRX6TAtgvrnuBgNRmn6I8lVDipOVB9kX6Oxkp4ZKyd1M6Gj8/v2U7k+YQBL95Kb9PQENucJb0JlW3b5tObN7m/Z1j1ev388d7o15zgXsI9CikAGAViR6lkJv7nb4Ak40M2G8TJ447kN+pvfHiOFjSUSP6PM+QfbAywKJCBaxSVxpizHseZUyUBhq59vFwrkyGoRiHbo0apweEZeSLuNiQ+HAekOnarFg00dZNXaPeoHPTRR0FmEyqYExOVaaaO8c0uFUh7U4e/UxdBmthlBDgg257Q33j1hA7HTxSeTTSuVnPZbgW1nodwmG16aKBDKxEetv7D9OjO0JhrbJTnoe+kcGoDJazFSO8/fUN9Jy/g4XK5PUkw2dgPDGpJqBfhe7GA+cjzfE/EGsMM+FV9nj9IAhrSfT/J3QE5TEIYyk5UjsI6ZZcCPr6A8FZUF4g9nnpVmjX90MLSQysIPD0nFzqwCcSJmIb5mYv2Cmk+C1MDFkZQyCBq4c/Yai9LJ6xYkGS/x2s5/frIW2vmG2Wrv0APpCdgCA9snFvfpe8uc0OwdRs4G9973PGEBnQB5qKrCQ6m6X/H7NInZ7y/1674/ZXOVp7OeuCRk8JFS516VHrnH1HkIUIlTIljjHaQtEtkJtosYul77cVwjk3gW1Ajaa6zWeyHGLlpk3VHE2VFzT2yI/EvlGUSz2H9zYE1s4nsKMtMqNyKNtL/59CpFJki5Fou6VXGm8vWATEPwrUVOLvoA8jLuwOzVBCgHB2Cr5V6OwEWtJEKokJkfc87h+sNHTvMb0KVTp5284QTPupoWvQVUwUeogZR3kBMESYo0mfukewRVPKh5+rzLQb7HKjFFIgWhj1w3yN/qCNoPI8XFiUgBNT1hCHBsAz8L7Oyt8wQWUFj92ONn/APyJFg8hzueqoJdNj57ROrFbffuS/XxrSXLTRgj5uxZjpgQYceeMc2wJrahReSKpm3QjHfqExTLAB2ipVumE8pqcZv8LYXQiPHHsgb5BMW8zM5pvQit+mQx8XGaVDcfVbLyMTlY8xcfmm/RSAT/H09UQol5gIz7rESDmnrQ4bURIB4iRXMDQwxgex1GgtDxKp2HayIkR+E/aDmCttNm2C6lytWdfOVzD6X2SpDWjQDlMRvAp1symWv4my1bPCD+E1EmGnMGWhNwmycJnDV2WrQNxO45ukEb08AAffizYKVULp15I4vbNK5DzWwCSUADfmKhfGSUqii1L2UsE8rB7mLuHuUJZOx4+WiizHBJ/hwboaBzhpNOVvgFTf5cJsHef7L1HCI9dOUUbb+YxUJWn6dYOLz+THi91kzY5dtO5c+grX7v0jEbsuoOGnoIreDIg/sFMyG+TyCLIcAWd1IZ1UNFxE8Uie13ucm40U2fcxC0u3WLvLOxwu+F7MWUsHsdtFQZ7W+nlfCASiAKyh8rnP3EyDByvtJb6Kax6/HkLzT9SyEyTMVM1zPtM0MJY14DmsWh4MgD15Ea9Hd00AdkTZ0EiG5NAGuIBzQJJ0JR0na+OB7lQA6UKxMfihIQ7GCCnVz694QvykWXTxpS2soDu+smru1UdIxSvAszBFD1c8c6ZOobA8bJiJIvuycgIXBQIXWwhyTgZDQxJTRXgEwRNAawGSXO0a1DKjdihLVNp/taE/xYhsgwe+VpKEEB4LlraQyE84gEihxCnbfoyOuJIEXy2FIYw+JjRusybKlU2g/vhTSGTydvCvXhYBdtAXtS2v7LkHtmXh/8fly1do8FI/D0f8UbzVb5h+KRhMGSAmR2mhi0YG/uj7wgxcfzCrMvdjitUIpXDX8ae2JcF/36qUWIMwN6JsjaRGNj+jEteGDcFyTUb8X/NHSucKMJp7pduxtD6KuxVlyxxwaeiC1FbGBESO84lbyrAugYxdl+2N8/6AgWpo/IeoAOcsG35IA/b3AuSyoa55L7llBLlaWlEWvuCFd8f8NfcTUgzJv6CbB+6ohWwodlk9nGWFpBAOaz5uEW5xBvmjnHFeDsb0mXwayj3mdYq5gxxNf3H3/tnCgHwjSrpSgVxLmiTtuszdRUFIsn6LiMPjL808vL1uQhDbM7aA43mISXReqjSskynIRcHCJ9qeFopJfx9tqyUoGbSwJex/0aDE3plBPGtNBYgWbdLom3+Q/bjdizR2/AS/c/dH/d3G7pyl1qDXgtOFtEqidwLqxPYtrNEveasWq3vPUUtqTeu8gpov4bdOQRI2kneFvRNMrShyVeEupK1PoLDPMSfWMIJcs267mGB8X9CehQCF0gIyhpP10mbyM7lwW1e6TGvHBV1sg/UyTghHPGRqMyaebC6pbB1WKNCQtlai1GGvmq9zUKaUzLaXsXEBYtHxmFbEZ2kJhR164LhWW2Tlp1dhsGE7ZgIWRBOx3Zcu2DxgH+G83WTPceKG0TgQKKiiNNOlWgvqNEbnrk6fVD+AqRam2OguZb0YWSTX88N+i/ELSxbaUUpPx4vJUzYg/WonSeA8xUK6u7DPHgpqWpEe6D4cXg5uK9FIYVba47V/nb+wyOtk+zG8RrS4EA0ouwa04iByRLSvoJA2FzaobbZtXnq8GdbfqEp5I2dpfpj59TCVif6+E75p665faiX8gS213RqBxTZqfHP46nF6NSenOneuT+vgbLUbdTH2/t0REFXZJOEB6DHvx6N6g9956CYrY/AYcm9gELJXYkrSi+0F0geKDZgOCIYkLU/+GOW5aGj8mvLFgtFH5+XC8hvAE3CvHRfl4ofM/Qwk4x2A+R+nyc9gNu/9Tem7XW4XRnyRymf52z09cTOdr+PG6+P/Vb4QiXlwauc5WB1z3o+IJjlbxI8MyWtSzT+k4sKVbhF3xa+vDts3NxXa87iiu+xRH9cAprnOL2h6vV54iQRXuOAj1s8nLFK8gZ70ThIQcWdF19/2xaJmT0efrkNDkWbpAQPdo92Z8+Hn/aLjbOzB9AI/k12fPs9HhUNDJ1u6ax2VxD3R6PywN7BrLJ26z6s3QoMp76qzzwetrDABKSGkfW5PwS1GvYNUbK6uRqxfyVGNyFB0E+OugMM8kKwmJmupuRWO8XkXXXQECyRVw9UyIrtCtcc4oNqXqr7AURBmKn6Khz3eBN96LwIJrAGP9mr/59uTOSx631suyT+QujDd4beUFpZ0kJEEnjlP+X/Kr2kCKhnENTg4BsMTOmMqlj2WMFLRUlVG0fzdCBgUta9odrJfpVdFomTi6ak0tFjXTcdqqvWBAzjY6hVrH9sbt3Z9gn+AVDpTcQImefbB4edirjzrsNievve4ZT4EUZWV3TxEsIW+9MT/RJoKfZZYSRGfC1CwPG/9rdMOM8qR/LUYvw5f/emUSoD7YSFuOoqchdUg2UePd1eCtFSKgxLSZ764oy4lvRCIH6bowPxZWwxNFctksLeil47pfevcBipkkBIc4ngZG+kxGZ71a72KQ7VaZ6MZOZkQJZXM6kb/Ac0/XkJx8dvyfJcWbI3zONEaEPIW8GbkYjsZcwy+eMoKrYjDmvEEixHzkCSCRPRzhOfJZuLdcbx19EL23MA8rnjTZZ787FGMnkqnpuzB5/90w1gtUSRaWcb0eta8198VEeZMUSfIhyuc4/nywFQ9uqn7jdqXh+5wwv+RK9XouNPbYdoEelNGo34KyySwigsrfCe0v/PlWPvQvQg8R0KgHO18mTVThhQrlbEQ0Kp/JxPdjHyR7E1QPw/ut0r+HDDG7BwZFm9IqEUZRpv2WpzlMkOemeLcAt5CsrzskLGaVOAxyySzZV/D2EY7ydNZMf8e8VhHcKGHAWNszf1EOq8fNstijMY4JXyATwTdncFFqcNDfDo+mWFvxJJpc4sEZtjXyBdoFcxbUmniCoKq5jydUHNjYJxMqN1KzYV62MugcELVhS3Bnd+TLLOh7dws/zSXWzxEb4Nj4aFun5x4kDWLK5TUF/yCXB/cZYvI9kPgVsG2jShtXkxfgT+xzjJofXqPEnIXIQ1lnIdmVzBOM90EXvJUW6a0nZ/7XjJGl8ToO3H/fdxnxmTNKBZxnkpXLVgLXCZywGT3YyS75w/PAH5I/jMuRspej8xZObU9kREbRA+kqjmKRFaKGWAmFQspC+QLbKPf0RaK3OXvBSWqo46p70ws/eZpu6jCtZUgQy6r4tHMPUdAgWGGUYNbuv/1a6K+MVFsd3T183+T8capSo6m0+Sh57fEeG/95dykGJBQMj09DSW2bY0mUonDy9a8trLnnL5B5LW3Nl8rJZNysO8Zb+80zXxqUGFpud3Qzwb7bf+8mq6x0TAnJU9pDQR9YQmZhlna2xuxJt0aCO/f1SU8gblOrbIyMsxTlVUW69VJPzYU2HlRXcqE2lLLxnObZuz2tT9CivfTAUYfmzJlt/lOPgsR6VN64/xQd4Jlk/RV7UKVv2Gx/AWsmTAuCWKhdwC+4HmKEKYZh2Xis4KsUR1BeObs1c13wqFRnocdmuheaTV30gvVXZcouzHKK5zwrN52jXJEuX6dGx3BCpV/++4f3hyaW/cQJLFKqasjsMuO3B3WlMq2gyYfdK1e7L2pO/tRye2mwzwZPfdUMrl5wdLqdd2Kv/wVtnpyWYhd49L6rsOV+8HXPrWH2Kup89l2tz6bf80iYSd+V4LROSOHeamvexR524q4r43rTmtFzQvArpvWfLYFZrbFspBsXNUqqenjxNNsFXatZvlIhk7teUPfK+YL32F8McTnjv0BZNppb+vshoCrtLXjIWq3EJXpVXIlG6ZNL0dh6qEm2WMwDjD3LfOfkGh1/czYc/0qhiD2ozNnH4882MVVt3JbVFkbwowNCO3KL5IoYW5wlVeGCViOuv1svZx7FbzxKzA4zGqBlRRaRWCobXaVq4yYCWbZf8eiJwt3OY+MFiSJengcFP2t0JMfzOiJ7cECvpx7neg1Rc5x+7myPJOXt2FohVRyXtD+/rDoTOyGYInJelZMjolecVHUhUNqvdZWg2J2t0jPmiLFeRD/8fOT4o+NGILb+TufCo9ceBBm3JLVn+MO2675n7qiEX/6W+188cYg3Zn5NSTjgOKfWFSAANa6raCxSoVU851oJLY11WIoYK0du0ec5E4tCnAPoKh71riTsjVIp3gKvBbEYQiNYrmH22oLQWA2AdwMnID6PX9b58dR2QKo4qag1D1Z+L/FwEKTR7osOZPWECPJIHQqPUsM5i/CH5YupVPfFA5pHUBcsesh8eO5YhyWnaVRPZn/BmdXVumZWPxMP5e28zm2uqHgFoT9CymHYNNrzrrjlXZM06HnzDxYNlI5b/QosxLmmrqDFqmogQdqk0WLkUceoAvQxHgkIyvWU69BPFr24VB6+lx75Rna6dGtrmOxDnvBojvi1/4dHjVeg8owofPe1cOnxU1ioh016s/Vudv9mhV9f35At+Sh28h1bpp8xhr09+vf47Elx3Ms6hyp6QvB3t0vnLbOhwo660cp7K0vvepabK7YJfxEWWfrC2YzJfYOjygPwfwd/1amTqa0hZ5ueebhWYVMubRTwIjj+0Oq0ohU3zfRfuL8gt59XsHdwKtxTQQ4Y2qz6gisxnm2UdlmpEkgOsZz7iEk6QOt8BuPwr+NR01LTqXmJo1C76o1N274twJvl+I069TiLpenK/miRxhyY8jvYV6W1WuSwhH9q7kuwnJMtm7IWcqs7HsnyHSqWXLSpYtZGaR1V3t0gauninFPZGtWskF65rtti48UV9uV9KM8kfDYs0pgB00S+TlzTXV6P8mxq15b9En8sz3jWSszcifZa/NuufPNnNTb031pptt0+sRSH/7UG8pzbsgtt3OG3ut7B9JzDMt2mTZuyRNIV8D54TuTrpNcHtgmMlYJeiY9XS83NYJicjRjtJSf9BZLsQv629QdDsKQhTK5CnXhpk7vMNkHzPhm0ExW/VCGApHfPyBagtZQTQmPHx7g5IXXsrQDPzIVhv2LB6Ih138iSDww1JNHrDvzUxvp73MsQBVhW8EbrReaVUcLB1R3PUXyaYG4HpJUcLVxMgDxcPkVRQpL7VTAGabDzbKcvg12t5P8TSGQkrj/gOrpnbiDHwluA73xbXts/L7u468cRWSWRtgTwlQnA47EKg0OiZDgFxAKQQUcsbGomITgeXUAAyKe03eA7Mp4gnyKQmm0LXJtEk6ddksMJCuxDmmHzmVhO+XaN2A54MIh3niw5CF7PwiXFZrnA8wOdeHLvvhdoqIDG9PDI7UnWWHq526T8y6ixJPhkuVKZnoUruOpUgOOp3iIKBjk+yi1vHo5cItHXb1PIKzGaZlRS0g5d3MV2pD8FQdGYLZ73aae/eEIUePMc4NFz8pIUfLCrrF4jVWH5gQneN3S8vANBmUXrEcKGn6hIUN95y1vpsvLwbGpzV9L0ZKTan6TDXM05236uLJcIEMKVAxKNT0K8WljuwNny3BNQRfzovA85beI9zr1AGNYnYCVkR1aGngWURUrgqR+gRrQhxW81l3CHevjvGEPzPMTxdsIfB9dfGRbZU0cg/1mcubtECX4tvaedmNAvTxCJtc2QaoUalGfENCGK7IS/O8CRpdOVca8EWCRwv2sSWE8CJPW5PCugjCXPd3h6U60cPD+bdhtXZuYB6stcoveE7Sm5MM2yvfUHXFSW7KzLmi7/EeEWL0wqcOH9MOSKjhCHHmw+JGLcYE/7SBZQCRggox0ZZTAxrlzNNXYXL5fNIjkdT4YMqVUz6p8YDt049v4OXGdg3qTrtLBUXOZf7ahPlZAY/O+7Sp0bvGSHdyQ8B1LOsplqMb9Se8VAE7gIdSZvxbRSrfl+Lk5Qaqi5QJceqjitdErcHXg/3MryljPSIAMaaloFm1cVwBJ8DNmkDqoGROSHFetrgjQ5CahuKkdH5pRPigMrgTtlFI8ufJPJSUlGgTjbBSvpRc0zypiUn6U5KZqcRoyrtzhmJ7/caeZkmVRwJQeLOG8LY6vP5ChpKhc8Js0El+n6FXqbx9ItdtLtYP92kKfaTLtCi8StLZdENJa9Ex1nOoz1kQ7qxoiZFKRyLf4O4CHRT0T/0W9F8epNKVoeyxUXhy3sQMMsJjQJEyMOjmOhMFgOmmlscV4eFi1CldU92yjwleirEKPW3bPAuEhRZV7JsKV3Lr5cETAiFuX5Nw5UlF7d2HZ96Bh0sgFIL5KGaKSoVYVlvdKpZJVP5+NZ7xDEkQhmDgsDKciazJCXJ6ZN2B3FY2f6VZyGl/t4aunGIAk/BHaS+i+SpdRfnB/OktOvyjinWNfM9Ksr6WwtCa1hCmeRI6icpFM4o8quCLsikU0tMoZI/9EqXRMpKGaWzofl4nQuVQm17d5fU5qXCQeCDqVaL9XJ9qJ08n3G3EFZS28SHEb3cdRBdtO0YcTzil3QknNKEe/smQ1fTb0XbpyNB5xAeuIlf+5KWlEY0DqJbsnzJlQxJPOVyHiKMx5Xu9FcEv1Fbg6Fhm4t+Jyy5JC1W3YO8dYLsO0PXPbxodBgttTbH3rt9Cp1lJIk2r3O1Zqu94eRbnIz2f50lWolYzuKsj4PMok4abHLO8NAC884hiXx5Fy5pWKO0bWL7uEGXaJCtznhP67SlQ4xjWIfgq6EpZ28QMtuZK7JC0RGbl9nA4XtFLug/NLMoH1pGt9IonAJqcEDLyH6TDROcbsmGPaGIxMo41IUAnQVPMPGByp4mOmh9ZQMkBAcksUK55LsZj7E5z5XuZoyWCKu6nHmDq22xI/9Z8YdxJy4kWpD16jLVrpwGLWfyOD0Wd+cBzFBxVaGv7S5k9qwh/5t/LQEXsRqI3Q9Rm3QIoaZW9GlsDaKOUyykyWuhNOprSEi0s1G4rgoiX1V743EELti+pJu5og6X0g6oTynUqlhH9k6ezyRi05NGZHz0nvp3HOJr7ebrAUFrDjbkFBObEvdQWkkUbL0pEvMU46X58vF9j9F3j6kpyetNUBItrEubW9ZvMPM4qNqLlsSBJqOH3XbNwv/cXDXNxN8iFLzUhteisYY+RlHYOuP29/Cb+L+xv+35Rv7xudnZ6ohK4cMPfCG8KI7dNmjNk/H4e84pOxn/sZHK9psfvj8ncA8qJz7O8xqbxESDivGJOZzF7o5PJLQ7g34qAWoyuA+x3btU98LT6ZyGyceIXjrqob2CAVql4VOTQPUQYvHV/g4zAuCZGvYQBtf0wmd5lilrvuEn1BXLny01B4h4SMDlYsnNpm9d7m9h578ufpef9Z4WplqWQvqo52fyUA7J24eZD5av6SyGIV9kpmHNqyvdfzcpEMw97BvknV2fq+MFHun9BT3Lsf8pbzvisWiIQvYkng+8Vxk1V+dli1u56kY50LRjaPdotvT5BwqtwyF+emo/z9J3yVUVGfKrxQtJMOAQWoQii/4dp9wgybSa5mkucmRLtEQZ/pz0tL/NVcgWAd95nEQ3Tg6tNbuyn3Iepz65L3huMUUBntllWuu4DbtOFSMSbpILV4fy6wlM0SOvi6CpLh81c1LreIvKd61uEWBcDw1lUBUW1I0Z+m/PaRlX+PQ/oxg0Ye6KUiIiTF4ADNk59Ydpt5/rkxmq9tV5Kcp/eQLUVVmBzQNVuytQCP6Ezd0G8eLxWyHpmZWJ3bAzkWTtg4lZlw42SQezEmiUPaJUuR/qklVA/87S4ArFCpALdY3QRdUw3G3XbWUp6aq9z0zUizcPa7351p9JXOZyfdZBFnqt90VzQndXB/mwf8LC9STj5kenVpNuqOQQP3mIRJj7eV21FxG8VAxKrEn3c+XfmZ800EPb9/5lIlijscUbB6da0RQaMook0zug1G0tKi/JBC4rw7/D3m4ARzAkzMcVrDcT2SyFtUdWAsFlsPDFqV3N+EjyXaoEePwroaZCiLqEzb8MW+PNE9TmTC01EzWli51PzZvUqkmyuROU+V6ik+Le/9qT6nwzUzf9tP68tYei0YaDGx6kAd7jn1cKqOCuYbiELH9zYqcc4MnRJjkeGiqaGwLImhyeKs+xKJMBlOJ05ow9gGCKZ1VpnMKoSCTbMS+X+23y042zOb5MtcY/6oBeAo1Vy89OTyhpavFP78jXCcFH0t7Gx24hMEOm2gsEfGabVpQgvFqbQKMsknFRRmuPHcZu0Su/WMFphZvB2r/EGbG72rpGGho3h+Msz0uGzJ7hNK2uqQiE1qmn0zgacKYYZBCqsxV+sjbpoVdSilW/b94n2xNb648VmNIoizqEWhBnsen+d0kbCPmRItfWqSBeOd9Wne3c6bcd6uvXOJ6WdiSsuXq0ndhqrQ4QoWUjCjYtZ0EAhnSOP1m44xkf0O7jXghrzSJWxP4a/t72jU29Vu2rvu4n7HfHkkmQOMGSS+NPeLGO5I73mC2B7+lMiBQQZRM9/9liLIfowupUFAbPBbR+lxDM6M8Ptgh1paJq5Rvs7yEuLQv/7d1oU2woFSb3FMPWQOKMuCuJ7pDDjpIclus5TeEoMBy2YdVB4fxmesaCeMNsEgTHKS5WDSGyNUOoEpcC2OFWtIRf0w27ck34/DjxRTVIcc9+kqZE6iMSiVDsiKdP/Xz5XfEhm/sBhO50p1rvJDlkyyxuJ9SPgs7YeUJBjXdeAkE+P9OQJm6SZnn1svcduI78dYmbkE2mtziPrcjVisXG78spLvbZaSFx/Rks9zP4LKn0Cdz/3JsetkT06A8f/yCgMO6Mb1Hme0JJ7b2wZz1qleqTuKBGokhPVUZ0dVu+tnQYNEY1fmkZSz6+EGZ5EzL7657mreZGR3jUfaEk458PDniBzsSmBKhDRzfXameryJv9/D5m6HIqZ0R+ouCE54Dzp4IJuuD1e4Dc5i+PpSORJfG23uVgqixAMDvchMR0nZdH5brclYwRoJRWv/rlxGRI5ffD5NPGmIDt7vDE1434pYdVZIFh89Bs94HGGJbTwrN8T6lh1HZFTOB4lWzWj6EVqxSMvC0/ljWBQ3F2kc/mO2b6tWonT2JEqEwFts8rz2h+oWNds9ceR2cb7zZvJTDppHaEhK5avWqsseWa2Dt5BBhabdWSktS80oMQrL4TvAM9b5HMmyDnO+OkkbMXfUJG7eXqTIG6lqSOEbqVR+qYdP7uWb57WEJqzyh411GAVsDinPs7KvUeXItlcMdOUWzXBH6zscymV1LLVCtc8IePojzXHF9m5b5zGwBRdzcyUJkiu938ApmAayRdJrX1PmVguWUvt2ThQ62czItTyWJMW2An/hdDfMK7SiFQlGIdAbltHz3ycoh7j9V7GxNWBpbtcSdqm4XxRwTawc3cbZ+xfSv9qQfEkDKfZTwCkqWGI/ur250ItXlMlh6vUNWEYIg9A3GzbgmbqvTN8js2YMo87CU5y6nZ4dbJLDQJj9fc7yM7tZzJDZFtqOcU8+mZjYlq4VmifI23iHb1ZoT9E+kT2dolnP1AfiOkt7PQCSykBiXy5mv637IegWSKj9IKrYZf4Lu9+I7ub+mkRdlvYzehh/jaJ9n7HUH5b2IbgeNdkY7wx1yVzxS7pbvky6+nmVUtRllEFfweUQ0/nG017WoUYSxs+j2B4FV/F62EtHlMWZXYrjGHpthnNb1x66LKZ0Qe92INWHdfR/vqp02wMS8r1G4dJqHok8KmQ7947G13a4YXbsGgHcBvRuVu1eAi4/A5+ZixmdSXM73LupB/LH7O9yxLTVXJTyBbI1S49TIROrfVCOb/czZ9pM4JsZx8kUz8dQGv7gUWKxXvTH7QM/3J2OuXXgciUhqY+cgtaOliQQVOYthBLV3xpESZT3rmfEYNZxmpBbb24CRao86prn+i9TNOh8VxRJGXJfXHATJHs1T5txgc/opYrY8XjlGQQbRcoxIBcnVsMjmU1ymmIUL4dviJXndMAJ0Yet+c7O52/p98ytlmAsGBaTAmMhimAnvp1TWNGM9BpuitGj+t810CU2UhorrjPKGtThVC8WaXw04WFnT5fTjqmPyrQ0tN3CkLsctVy2xr0ZWgiWVZ1OrlFjjxJYsOiZv2cAoOvE+7sY0I/TwWcZqMoyIKNOftwP7w++Rfg67ljfovKYa50if3fzE/8aPYVey/Nq35+nH2sLPh/fP5TsylSKGOZ4k69d2PnH43+kq++sRXHQqGArWdwhx+hpwQC6JgT2uxehYU4Zbw7oNb6/HLikPyJROGK2ouyr+vzseESp9G50T4AyFrSqOQ0rroCYP4sMDFBrHn342EyZTMlSyk47rHSq89Y9/nI3zG5lX16Z5lxphguLOcZUndL8wNcrkyjH82jqg8Bo8OYkynrxZvbFno5lUS3OPr8Ko3mX9NoRPdYOKKjD07bvgFgpZ/RF+YzkWvJ/Hs/tUbfeGzGWLxNAjfDzHHMVSDwB5SabQLsIZHiBp43FjGkaienYoDd18hu2BGwOK7U3o70K/WY/kuuKdmdrykIBUdG2mvE91L1JtTbh20mOLbk1vCAamu7utlXeGU2ooVikbU/actcgmsC1FKk2qmj3GWeIWbj4tGIxE7BLcBWUvvcnd/lYxsMV4F917fWeFB/XbINN3qGvIyTpCalz1lVewdIGqeAS/gB8Mi+sA+BqDiX3VGD2eUunTRbSY+AuDy4E3Qx3hAhwnSXX+B0zuj3eQ1miS8Vux2z/l6/BkWtjKGU72aJkOCWhGcSf3+kFkkB15vGOsQrSdFr6qTj0gBYiOlnBO41170gOWHSUoBVRU2JjwppYdhIFDfu7tIRHccSNM5KZOFDPz0TGMAjzzEpeLwTWp+kn201kU6NjbiMQJx83+LX1e1tZ10kuChJZ/XBUQ1dwaBHjTDJDqOympEk8X2M3VtVw21JksChA8w1tTefO3RJ1FMbqZ01bHHkudDB/OhLfe7P5GOHaI28ZXKTMuqo0hLWQ4HabBsGG7NbP1RiXtETz074er6w/OerJWEqjmkq2y51q1BVI+JUudnVa3ogBpzdhFE7fC7kybrAt2Z6RqDjATAUEYeYK45WMupBKQRtQlU+uNsjnzj6ZmGrezA+ASrWxQ6LMkHRXqXwNq7ftv28dUx/ZSJciDXP2SWJsWaN0FjPX9Yko6LobZ7aYW/IdUktI9apTLyHS8DyWPyuoZyxN1TK/vtfxk3HwWh6JczZC8Ftn0bIJay2g+n5wd7lm9rEsKO+svqVmi+c1j88hSCxbzrg4+HEP0Nt1/B6YW1XVm09T1CpAKjc9n18hjqsaFGdfyva1ZG0Xu3ip6N6JGpyTSqY5h4BOlpLPaOnyw45PdXTN+DtAKg7DLrLFTnWusoSBHk3s0d7YouJHq85/R09Tfc37ENXZF48eAYLnq9GLioNcwDZrC6FW6godB8JnqYUPvn0pWLfQz0lM0Yy8Mybgn84Ds3Q9bDP10bLyOV+qzxa4Rd9Dhu7cju8mMaONXK3UqmBQ9qIg7etIwEqM/kECk/Dzja4Bs1xR+Q/tCbc8IKrSGsTdJJ0vge7IG20W687uVmK6icWQ6cD3lwFzgNMGtFvO5qyJeKflGLAAcQZOrkxVwy3cWvqlGpvjmf9Qe6Ap20MPbV92DPV0OhFM4kz8Yr0ffC2zLWSQ1kqY6QdQrttR3kh1YLtQd1kCEv5hVoPIRWl5ERcUTttBIrWp6Xs5Ehh5OUUwI5aEBvuiDmUoENmnVw1FohCrbRp1A1E+XSlWVOTi7ADW+5Ohb9z1vK4qx5R5lPdGCPBJZ00mC+Ssp8VUbgpGAvXWMuWQQRbCqI6Rr2jtxZxtfP7W/8onz+yz0Gs76LaT5HX9ecyiZCB/ZR/gFtMxPsDwohoeCRtiuLxE1GM1vUEUgBv86+eehL58/P56QFGQ/MqOe/vC76L63jzmeax4exd/OKTUvkXg+fOJUHych9xt/9goJMrapSgvXrj8+8vk/N80f22Sewj6cyGqt1B6mztoeklVHHraouhvHJaG/OuBz6DHKMpFmQULU1bRWlyYE0RPXYYkUycIemN7TLtgNCJX6BqdyxDKkegO7nJK5xQ7OVYDZTMf9bVHidtk6DQX9Et+V9M7esgbsYBdEeUpsB0Xvw2kd9+rI7V+m47u+O/tq7mw7262HU1WlS9uFzsV6JxIHNmUCy0QS9e077JGRFbG65z3/dOKB/Zk+yDdKpUmdXjn/aS3N5nv4fK7bMHHmPlHd4E2+iTbV5rpzScRnxk6KARuDTJ8Q1LpK2mP8gj1EbuJ9RIyY+EWK4hCiIDBAS1Tm2IEXAFfgKPgdL9O6mAa06wjCcUAL6EsxPQWO9VNegBPm/0GgkZbDxCynxujX/92vmGcjZRMAY45puak2sFLCLSwXpEsyy5fnF0jGJBhm+fNSHKKUUfy+276A7/feLOFxxUuHRNJI2Osenxyvf8DAGObT60pfTTlhEg9u/KKkhJqm5U1/+BEcSkpFDA5XeCqxwXmPac1jcuZ3JWQ+p0NdWzb/5v1ZvF8GtMTFFEdQjpLO0bwPb0BHNWnip3liDXI2fXf05jjvfJ0NpjLCUgfTh9CMFYVFKEd4Z/OG/2C+N435mnK+9t1gvCiVcaaH7rK4+PjCvpVNiz+t2QyqH1O8x3JKZVl6Q+Lp/XK8wMjVMslOq9FdSw5FtUs/CptXH9PW+wbWHgrV17R5jTVOtGtKFu3nb80T+E0tv9QkzW3J2dbaw/8ddAKZ0pxIaEqLjlPrji3VgJ3GvdFvlqD8075woxh4fVt0JZE0KVFsAvqhe0dqN9b35jtSpnYMXkU+vZq+IAHad3IHc2s/LYrnD1anfG46IFiMIr9oNbZDWvwthqYNqOigaKd/XlLU4XHfk/PXIjPsLy/9/kAtQ+/wKH+hI/IROWj5FPvTZAT9f7j4ZXQyG4M0TujMAFXYkKvEHv1xhySekgXGGqNxWeWKlf8dDAlLuB1cb/qOD+rk7cmwt+1yKpk9cudqBanTi6zTbXRtV8qylNtjyOVKy1HTz0GW9rjt6sSjAZcT5R+KdtyYb0zyqG9pSLuCw5WBwAn7fjBjKLLoxLXMI+52L9cLwIR2B6OllJZLHJ8vDxmWdtF+QJnmt1rsHPIWY20lftk8fYePkAIg6Hgn532QoIpegMxiWgAOfe5/U44APR8Ac0NeZrVh3gEhs12W+tVSiWiUQekf/YBECUy5fdYbA08dd7VzPAP9aiVcIB9k6tY7WdJ1wNV+bHeydNtmC6G5ICtFC1ZwmJU/j8hf0I8TRVKSiz5oYIa93EpUI78X8GYIAZabx47/n8LDAAJ0nNtP1rpROprqKMBRecShca6qXuTSI3jZBLOB3Vp381B5rCGhjSvh/NSVkYp2qIdP/Bg=", j2 = function(e) {
  var r = R2.toByteArray(z2);
  return e(r);
}, V2 = {
  init: j2
}, We = be(function(t, e) {
  e.init = function(r) {
    e.dictionary = V2.init(r);
  }, e.offsetsByLength = new Uint32Array([0, 0, 0, 0, 0, 4096, 9216, 21504, 35840, 44032, 53248, 63488, 74752, 87040, 93696, 100864, 104704, 106752, 108928, 113536, 115968, 118528, 119872, 121280, 122016]), e.sizeBitsByLength = new Uint8Array([0, 0, 0, 0, 10, 10, 11, 11, 10, 10, 10, 10, 10, 9, 9, 8, 7, 7, 8, 7, 7, 6, 6, 5, 5]), e.minDictionaryWordLength = 4, e.maxDictionaryWordLength = 24;
});
We.init;
We.dictionary;
We.offsetsByLength;
We.sizeBitsByLength;
We.minDictionaryWordLength;
We.maxDictionaryWordLength;
function Dr(t, e) {
  this.bits = t, this.value = e;
}
var G2 = Dr, Ir = 15;
function Iu(t, e) {
  for (var r = 1 << e - 1; t & r; )
    r >>= 1;
  return (t & r - 1) + r;
}
function Ou(t, e, r, n, a) {
  do
    n -= r, t[e + n] = new Dr(a.bits, a.value);
  while (n > 0);
}
function q2(t, e, r) {
  for (var n = 1 << e - r; e < Ir && (n -= t[e], !(n <= 0)); )
    ++e, n <<= 1;
  return e - r;
}
var H2 = function(e, r, n, a, o) {
  var s = r, u, f, l, c, p, y, v, m, w, F, S, I = new Int32Array(Ir + 1), A = new Int32Array(Ir + 1);
  for (S = new Int32Array(o), l = 0; l < o; l++)
    I[a[l]]++;
  for (A[1] = 0, f = 1; f < Ir; f++)
    A[f + 1] = A[f] + I[f];
  for (l = 0; l < o; l++)
    a[l] !== 0 && (S[A[a[l]]++] = l);
  if (m = n, w = 1 << m, F = w, A[Ir] === 1) {
    for (c = 0; c < F; ++c)
      e[r + c] = new Dr(0, S[0] & 65535);
    return F;
  }
  for (c = 0, l = 0, f = 1, p = 2; f <= n; ++f, p <<= 1)
    for (; I[f] > 0; --I[f])
      u = new Dr(f & 255, S[l++] & 65535), Ou(e, r + c, p, w, u), c = Iu(c, f);
  for (v = F - 1, y = -1, f = n + 1, p = 2; f <= Ir; ++f, p <<= 1)
    for (; I[f] > 0; --I[f])
      (c & v) !== y && (r += w, m = q2(I, f, n), w = 1 << m, F += w, y = c & v, e[s + y] = new Dr(m + n & 255, r - s - y & 65535)), u = new Dr(f - n & 255, S[l++] & 65535), Ou(e, r + (c >> n), p, w, u), c = Iu(c, f);
  return F;
}, Ul = {
  HuffmanCode: G2,
  BrotliBuildHuffmanTable: H2
}, W2 = new Uint8Array([
  /* CONTEXT_UTF8, last byte. */
  /* ASCII range. */
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  4,
  4,
  0,
  0,
  4,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  8,
  12,
  16,
  12,
  12,
  20,
  12,
  16,
  24,
  28,
  12,
  12,
  32,
  12,
  36,
  12,
  44,
  44,
  44,
  44,
  44,
  44,
  44,
  44,
  44,
  44,
  32,
  32,
  24,
  40,
  28,
  12,
  12,
  48,
  52,
  52,
  52,
  48,
  52,
  52,
  52,
  48,
  52,
  52,
  52,
  52,
  52,
  48,
  52,
  52,
  52,
  52,
  52,
  48,
  52,
  52,
  52,
  52,
  52,
  24,
  12,
  28,
  12,
  12,
  12,
  56,
  60,
  60,
  60,
  56,
  60,
  60,
  60,
  56,
  60,
  60,
  60,
  60,
  60,
  56,
  60,
  60,
  60,
  60,
  60,
  56,
  60,
  60,
  60,
  60,
  60,
  24,
  12,
  28,
  12,
  0,
  /* UTF8 continuation byte range. */
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  0,
  1,
  /* UTF8 lead byte range. */
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  2,
  3,
  /* CONTEXT_UTF8 second last byte. */
  /* ASCII range. */
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  1,
  1,
  1,
  1,
  1,
  1,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  1,
  1,
  1,
  1,
  0,
  /* UTF8 continuation byte range. */
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  /* UTF8 lead byte range. */
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  /* CONTEXT_SIGNED, second last byte. */
  0,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  1,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  2,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  3,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  4,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  5,
  6,
  6,
  6,
  6,
  6,
  6,
  6,
  6,
  6,
  6,
  6,
  6,
  6,
  6,
  6,
  7,
  /* CONTEXT_SIGNED, last byte, same as the above values shifted by 3 bits. */
  0,
  8,
  8,
  8,
  8,
  8,
  8,
  8,
  8,
  8,
  8,
  8,
  8,
  8,
  8,
  8,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  24,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  32,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  40,
  48,
  48,
  48,
  48,
  48,
  48,
  48,
  48,
  48,
  48,
  48,
  48,
  48,
  48,
  48,
  56,
  /* CONTEXT_LSB6, last byte. */
  0,
  1,
  2,
  3,
  4,
  5,
  6,
  7,
  8,
  9,
  10,
  11,
  12,
  13,
  14,
  15,
  16,
  17,
  18,
  19,
  20,
  21,
  22,
  23,
  24,
  25,
  26,
  27,
  28,
  29,
  30,
  31,
  32,
  33,
  34,
  35,
  36,
  37,
  38,
  39,
  40,
  41,
  42,
  43,
  44,
  45,
  46,
  47,
  48,
  49,
  50,
  51,
  52,
  53,
  54,
  55,
  56,
  57,
  58,
  59,
  60,
  61,
  62,
  63,
  0,
  1,
  2,
  3,
  4,
  5,
  6,
  7,
  8,
  9,
  10,
  11,
  12,
  13,
  14,
  15,
  16,
  17,
  18,
  19,
  20,
  21,
  22,
  23,
  24,
  25,
  26,
  27,
  28,
  29,
  30,
  31,
  32,
  33,
  34,
  35,
  36,
  37,
  38,
  39,
  40,
  41,
  42,
  43,
  44,
  45,
  46,
  47,
  48,
  49,
  50,
  51,
  52,
  53,
  54,
  55,
  56,
  57,
  58,
  59,
  60,
  61,
  62,
  63,
  0,
  1,
  2,
  3,
  4,
  5,
  6,
  7,
  8,
  9,
  10,
  11,
  12,
  13,
  14,
  15,
  16,
  17,
  18,
  19,
  20,
  21,
  22,
  23,
  24,
  25,
  26,
  27,
  28,
  29,
  30,
  31,
  32,
  33,
  34,
  35,
  36,
  37,
  38,
  39,
  40,
  41,
  42,
  43,
  44,
  45,
  46,
  47,
  48,
  49,
  50,
  51,
  52,
  53,
  54,
  55,
  56,
  57,
  58,
  59,
  60,
  61,
  62,
  63,
  0,
  1,
  2,
  3,
  4,
  5,
  6,
  7,
  8,
  9,
  10,
  11,
  12,
  13,
  14,
  15,
  16,
  17,
  18,
  19,
  20,
  21,
  22,
  23,
  24,
  25,
  26,
  27,
  28,
  29,
  30,
  31,
  32,
  33,
  34,
  35,
  36,
  37,
  38,
  39,
  40,
  41,
  42,
  43,
  44,
  45,
  46,
  47,
  48,
  49,
  50,
  51,
  52,
  53,
  54,
  55,
  56,
  57,
  58,
  59,
  60,
  61,
  62,
  63,
  /* CONTEXT_MSB6, last byte. */
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  2,
  2,
  2,
  2,
  3,
  3,
  3,
  3,
  4,
  4,
  4,
  4,
  5,
  5,
  5,
  5,
  6,
  6,
  6,
  6,
  7,
  7,
  7,
  7,
  8,
  8,
  8,
  8,
  9,
  9,
  9,
  9,
  10,
  10,
  10,
  10,
  11,
  11,
  11,
  11,
  12,
  12,
  12,
  12,
  13,
  13,
  13,
  13,
  14,
  14,
  14,
  14,
  15,
  15,
  15,
  15,
  16,
  16,
  16,
  16,
  17,
  17,
  17,
  17,
  18,
  18,
  18,
  18,
  19,
  19,
  19,
  19,
  20,
  20,
  20,
  20,
  21,
  21,
  21,
  21,
  22,
  22,
  22,
  22,
  23,
  23,
  23,
  23,
  24,
  24,
  24,
  24,
  25,
  25,
  25,
  25,
  26,
  26,
  26,
  26,
  27,
  27,
  27,
  27,
  28,
  28,
  28,
  28,
  29,
  29,
  29,
  29,
  30,
  30,
  30,
  30,
  31,
  31,
  31,
  31,
  32,
  32,
  32,
  32,
  33,
  33,
  33,
  33,
  34,
  34,
  34,
  34,
  35,
  35,
  35,
  35,
  36,
  36,
  36,
  36,
  37,
  37,
  37,
  37,
  38,
  38,
  38,
  38,
  39,
  39,
  39,
  39,
  40,
  40,
  40,
  40,
  41,
  41,
  41,
  41,
  42,
  42,
  42,
  42,
  43,
  43,
  43,
  43,
  44,
  44,
  44,
  44,
  45,
  45,
  45,
  45,
  46,
  46,
  46,
  46,
  47,
  47,
  47,
  47,
  48,
  48,
  48,
  48,
  49,
  49,
  49,
  49,
  50,
  50,
  50,
  50,
  51,
  51,
  51,
  51,
  52,
  52,
  52,
  52,
  53,
  53,
  53,
  53,
  54,
  54,
  54,
  54,
  55,
  55,
  55,
  55,
  56,
  56,
  56,
  56,
  57,
  57,
  57,
  57,
  58,
  58,
  58,
  58,
  59,
  59,
  59,
  59,
  60,
  60,
  60,
  60,
  61,
  61,
  61,
  61,
  62,
  62,
  62,
  62,
  63,
  63,
  63,
  63,
  /* CONTEXT_{M,L}SB6, second last byte, */
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0
]), X2 = new Uint16Array([
  /* CONTEXT_LSB6 */
  1024,
  1536,
  /* CONTEXT_MSB6 */
  1280,
  1536,
  /* CONTEXT_UTF8 */
  0,
  256,
  /* CONTEXT_SIGNED */
  768,
  512
]), Ar = {
  lookup: W2,
  lookupOffsets: X2
};
function T(t, e) {
  this.offset = t, this.nbits = e;
}
var Y2 = [new T(1, 2), new T(5, 2), new T(9, 2), new T(13, 2), new T(17, 3), new T(25, 3), new T(33, 3), new T(41, 3), new T(49, 4), new T(65, 4), new T(81, 4), new T(97, 4), new T(113, 5), new T(145, 5), new T(177, 5), new T(209, 5), new T(241, 6), new T(305, 6), new T(369, 7), new T(497, 8), new T(753, 9), new T(1265, 10), new T(2289, 11), new T(4337, 12), new T(8433, 13), new T(16625, 24)], K2 = [new T(0, 0), new T(1, 0), new T(2, 0), new T(3, 0), new T(4, 0), new T(5, 0), new T(6, 1), new T(8, 1), new T(10, 2), new T(14, 2), new T(18, 3), new T(26, 3), new T(34, 4), new T(50, 4), new T(66, 5), new T(98, 5), new T(130, 6), new T(194, 7), new T(322, 8), new T(578, 9), new T(1090, 10), new T(2114, 12), new T(6210, 14), new T(22594, 24)], Z2 = [new T(2, 0), new T(3, 0), new T(4, 0), new T(5, 0), new T(6, 0), new T(7, 0), new T(8, 0), new T(9, 0), new T(10, 1), new T(12, 1), new T(14, 2), new T(18, 2), new T(22, 3), new T(30, 3), new T(38, 4), new T(54, 4), new T(70, 5), new T(102, 5), new T(134, 6), new T(198, 7), new T(326, 8), new T(582, 9), new T(1094, 10), new T(2118, 24)], J2 = [0, 0, 8, 8, 0, 16, 8, 16, 16], Q2 = [0, 8, 0, 8, 16, 0, 16, 8, 16], Mt = {
  kBlockLengthPrefixCode: Y2,
  kInsertLengthPrefixCode: K2,
  kCopyLengthPrefixCode: Z2,
  kInsertRangeLut: J2,
  kCopyRangeLut: Q2
}, B = 0, Du = 1, _2 = 2, $2 = 3, ew = 4, tw = 5, rw = 6, nw = 7, iw = 8, Nl = 9, Ie = 10, Pe = 11, Ia = 12, aw = 13, ow = 14, sw = 15, uw = 16, fw = 17, lw = 18, cw = 20;
function E(t, e, r) {
  this.prefix = new Uint8Array(t.length), this.transform = e, this.suffix = new Uint8Array(r.length);
  for (var n = 0; n < t.length; n++)
    this.prefix[n] = t.charCodeAt(n);
  for (var n = 0; n < r.length; n++)
    this.suffix[n] = r.charCodeAt(n);
}
var rn = [new E("", B, ""), new E("", B, " "), new E(" ", B, " "), new E("", Ia, ""), new E("", Ie, " "), new E("", B, " the "), new E(" ", B, ""), new E("s ", B, " "), new E("", B, " of "), new E("", Ie, ""), new E("", B, " and "), new E("", aw, ""), new E("", Du, ""), new E(", ", B, " "), new E("", B, ", "), new E(" ", Ie, " "), new E("", B, " in "), new E("", B, " to "), new E("e ", B, " "), new E("", B, '"'), new E("", B, "."), new E("", B, '">'), new E("", B, `
`), new E("", $2, ""), new E("", B, "]"), new E("", B, " for "), new E("", ow, ""), new E("", _2, ""), new E("", B, " a "), new E("", B, " that "), new E(" ", Ie, ""), new E("", B, ". "), new E(".", B, ""), new E(" ", B, ", "), new E("", sw, ""), new E("", B, " with "), new E("", B, "'"), new E("", B, " from "), new E("", B, " by "), new E("", uw, ""), new E("", fw, ""), new E(" the ", B, ""), new E("", ew, ""), new E("", B, ". The "), new E("", Pe, ""), new E("", B, " on "), new E("", B, " as "), new E("", B, " is "), new E("", nw, ""), new E("", Du, "ing "), new E("", B, `
	`), new E("", B, ":"), new E(" ", B, ". "), new E("", B, "ed "), new E("", cw, ""), new E("", lw, ""), new E("", rw, ""), new E("", B, "("), new E("", Ie, ", "), new E("", iw, ""), new E("", B, " at "), new E("", B, "ly "), new E(" the ", B, " of "), new E("", tw, ""), new E("", Nl, ""), new E(" ", Ie, ", "), new E("", Ie, '"'), new E(".", B, "("), new E("", Pe, " "), new E("", Ie, '">'), new E("", B, '="'), new E(" ", B, "."), new E(".com/", B, ""), new E(" the ", B, " of the "), new E("", Ie, "'"), new E("", B, ". This "), new E("", B, ","), new E(".", B, " "), new E("", Ie, "("), new E("", Ie, "."), new E("", B, " not "), new E(" ", B, '="'), new E("", B, "er "), new E(" ", Pe, " "), new E("", B, "al "), new E(" ", Pe, ""), new E("", B, "='"), new E("", Pe, '"'), new E("", Ie, ". "), new E(" ", B, "("), new E("", B, "ful "), new E(" ", Ie, ". "), new E("", B, "ive "), new E("", B, "less "), new E("", Pe, "'"), new E("", B, "est "), new E(" ", Ie, "."), new E("", Pe, '">'), new E(" ", B, "='"), new E("", Ie, ","), new E("", B, "ize "), new E("", Pe, "."), new E("Â ", B, ""), new E(" ", B, ","), new E("", Ie, '="'), new E("", Pe, '="'), new E("", B, "ous "), new E("", Pe, ", "), new E("", Ie, "='"), new E(" ", Ie, ","), new E(" ", Pe, '="'), new E(" ", Pe, ", "), new E("", Pe, ","), new E("", Pe, "("), new E("", Pe, ". "), new E(" ", Pe, "."), new E("", Pe, "='"), new E(" ", Pe, ". "), new E(" ", Ie, '="'), new E(" ", Pe, "='"), new E(" ", Ie, "='")], hw = rn, pw = rn.length;
function Tu(t, e) {
  return t[e] < 192 ? (t[e] >= 97 && t[e] <= 122 && (t[e] ^= 32), 1) : t[e] < 224 ? (t[e + 1] ^= 32, 2) : (t[e + 2] ^= 5, 3);
}
var dw = function(e, r, n, a, o) {
  var s = rn[o].prefix, u = rn[o].suffix, f = rn[o].transform, l = f < Ia ? 0 : f - (Ia - 1), c = 0, p = r, y;
  l > a && (l = a);
  for (var v = 0; v < s.length; )
    e[r++] = s[v++];
  for (n += l, a -= l, f <= Nl && (a -= f), c = 0; c < a; c++)
    e[r++] = We.dictionary[n + c];
  if (y = r - a, f === Ie)
    Tu(e, y);
  else if (f === Pe)
    for (; a > 0; ) {
      var m = Tu(e, y);
      y += m, a -= m;
    }
  for (var w = 0; w < u.length; )
    e[r++] = u[w++];
  return r - p;
}, Pu = {
  kTransforms: hw,
  kNumTransforms: pw,
  transformDictionaryWord: dw
}, Rl = kl.BrotliInput, vw = kl.BrotliOutput, Be = Ul.HuffmanCode, zl = Ul.BrotliBuildHuffmanTable, yw = 8, Bu = 16, gw = 256, mw = 704, bw = 26, ku = 6, Lu = 2, Oa = 8, ww = 255, Ut = 1080, Da = 18, Fw = new Uint8Array([1, 2, 3, 4, 0, 5, 17, 6, 16, 7, 8, 9, 10, 11, 12, 13, 14, 15]), Ta = 16, xw = new Uint8Array([3, 2, 1, 0, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2]), Sw = new Int8Array([0, 0, 0, 0, -1, 1, -2, 2, -3, 3, -1, 1, -2, 2, -3, 3]), Aw = new Uint16Array([256, 402, 436, 468, 500, 534, 566, 598, 630, 662, 694, 726, 758, 790, 822, 854, 886, 920, 952, 984, 1016, 1048, 1080]);
function jl(t) {
  var e;
  return t.readBits(1) === 0 ? 16 : (e = t.readBits(3), e > 0 ? 17 + e : (e = t.readBits(3), e > 0 ? 8 + e : 17));
}
function Vl(t) {
  if (t.readBits(1)) {
    var e = t.readBits(3);
    return e === 0 ? 1 : t.readBits(e) + (1 << e);
  }
  return 0;
}
function Ew() {
  this.meta_block_length = 0, this.input_end = 0, this.is_uncompressed = 0, this.is_metadata = !1;
}
function Gl(t) {
  var e = new Ew(), r, n, a;
  if (e.input_end = t.readBits(1), e.input_end && t.readBits(1))
    return e;
  if (r = t.readBits(2) + 4, r === 7) {
    if (e.is_metadata = !0, t.readBits(1) !== 0) throw new Error("Invalid reserved bit");
    if (n = t.readBits(2), n === 0) return e;
    for (a = 0; a < n; a++) {
      var o = t.readBits(8);
      if (a + 1 === n && n > 1 && o === 0) throw new Error("Invalid size byte");
      e.meta_block_length |= o << a * 8;
    }
  } else
    for (a = 0; a < r; ++a) {
      var s = t.readBits(4);
      if (a + 1 === r && r > 4 && s === 0) throw new Error("Invalid size nibble");
      e.meta_block_length |= s << a * 4;
    }
  return ++e.meta_block_length, !e.input_end && !e.is_metadata && (e.is_uncompressed = t.readBits(1)), e;
}
function Mr(t, e, r) {
  var n;
  return r.fillBitWindow(), e += r.val_ >>> r.bit_pos_ & ww, n = t[e].bits - Oa, n > 0 && (r.bit_pos_ += Oa, e += t[e].value, e += r.val_ >>> r.bit_pos_ & (1 << n) - 1), r.bit_pos_ += t[e].bits, t[e].value;
}
function Cw(t, e, r, n) {
  for (var a = 0, o = yw, s = 0, u = 0, f = 32768, l = [], c = 0; c < 32; c++)
    l.push(new Be(0, 0));
  for (zl(l, 0, 5, t, Da); a < e && f > 0; ) {
    var p = 0, y;
    if (n.readMoreInput(), n.fillBitWindow(), p += n.val_ >>> n.bit_pos_ & 31, n.bit_pos_ += l[p].bits, y = l[p].value & 255, y < Bu)
      s = 0, r[a++] = y, y !== 0 && (o = y, f -= 32768 >> y);
    else {
      var v = y - 14, m, w, F = 0;
      if (y === Bu && (F = o), u !== F && (s = 0, u = F), m = s, s > 0 && (s -= 2, s <<= v), s += n.readBits(v) + 3, w = s - m, a + w > e)
        throw new Error("[ReadHuffmanCodeLengths] symbol + repeat_delta > num_symbols");
      for (var S = 0; S < w; S++)
        r[a + S] = u;
      a += w, u !== 0 && (f -= w << 15 - u);
    }
  }
  if (f !== 0)
    throw new Error("[ReadHuffmanCodeLengths] space = " + f);
  for (; a < e; a++)
    r[a] = 0;
}
function _n(t, e, r, n) {
  var a = 0, o, s = new Uint8Array(t);
  if (n.readMoreInput(), o = n.readBits(2), o === 1) {
    for (var u, f = t - 1, l = 0, c = new Int32Array(4), p = n.readBits(2) + 1; f; )
      f >>= 1, ++l;
    for (u = 0; u < p; ++u)
      c[u] = n.readBits(l) % t, s[c[u]] = 2;
    switch (s[c[0]] = 1, p) {
      case 1:
        break;
      case 3:
        if (c[0] === c[1] || c[0] === c[2] || c[1] === c[2])
          throw new Error("[ReadHuffmanCode] invalid symbols");
        break;
      case 2:
        if (c[0] === c[1])
          throw new Error("[ReadHuffmanCode] invalid symbols");
        s[c[1]] = 1;
        break;
      case 4:
        if (c[0] === c[1] || c[0] === c[2] || c[0] === c[3] || c[1] === c[2] || c[1] === c[3] || c[2] === c[3])
          throw new Error("[ReadHuffmanCode] invalid symbols");
        n.readBits(1) ? (s[c[2]] = 3, s[c[3]] = 3) : s[c[0]] = 2;
        break;
    }
  } else {
    var u, y = new Uint8Array(Da), v = 32, m = 0, w = [new Be(2, 0), new Be(2, 4), new Be(2, 3), new Be(3, 2), new Be(2, 0), new Be(2, 4), new Be(2, 3), new Be(4, 1), new Be(2, 0), new Be(2, 4), new Be(2, 3), new Be(3, 2), new Be(2, 0), new Be(2, 4), new Be(2, 3), new Be(4, 5)];
    for (u = o; u < Da && v > 0; ++u) {
      var F = Fw[u], S = 0, I;
      n.fillBitWindow(), S += n.val_ >>> n.bit_pos_ & 15, n.bit_pos_ += w[S].bits, I = w[S].value, y[F] = I, I !== 0 && (v -= 32 >> I, ++m);
    }
    if (!(m === 1 || v === 0)) throw new Error("[ReadHuffmanCode] invalid num_codes or space");
    Cw(y, t, s, n);
  }
  if (a = zl(e, r, Oa, s, t), a === 0)
    throw new Error("[ReadHuffmanCode] BuildHuffmanTable failed: ");
  return a;
}
function Pn(t, e, r) {
  var n, a;
  return n = Mr(t, e, r), a = Mt.kBlockLengthPrefixCode[n].nbits, Mt.kBlockLengthPrefixCode[n].offset + r.readBits(a);
}
function Iw(t, e, r) {
  var n;
  return t < Ta ? (r += xw[t], r &= 3, n = e[r] + Sw[t]) : n = t - Ta + 1, n;
}
function Ow(t, e) {
  for (var r = t[e], n = e; n; --n)
    t[n] = t[n - 1];
  t[0] = r;
}
function Dw(t, e) {
  var r = new Uint8Array(256), n;
  for (n = 0; n < 256; ++n)
    r[n] = n;
  for (n = 0; n < e; ++n) {
    var a = t[n];
    t[n] = r[a], a && Ow(r, a);
  }
}
function ir(t, e) {
  this.alphabet_size = t, this.num_htrees = e, this.codes = new Array(e + e * Aw[t + 31 >>> 5]), this.htrees = new Uint32Array(e);
}
ir.prototype.decode = function(t) {
  var e, r, n = 0;
  for (e = 0; e < this.num_htrees; ++e)
    this.htrees[e] = n, r = _n(this.alphabet_size, this.codes, n, t), n += r;
};
function Mu(t, e) {
  var r = {
    num_htrees: null,
    context_map: null
  }, n, a = 0, o, s;
  e.readMoreInput();
  var u = r.num_htrees = Vl(e) + 1, f = r.context_map = new Uint8Array(t);
  if (u <= 1)
    return r;
  for (n = e.readBits(1), n && (a = e.readBits(4) + 1), o = [], s = 0; s < Ut; s++)
    o[s] = new Be(0, 0);
  for (_n(u + a, o, 0, e), s = 0; s < t; ) {
    var l;
    if (e.readMoreInput(), l = Mr(o, 0, e), l === 0)
      f[s] = 0, ++s;
    else if (l <= a)
      for (var c = 1 + (1 << l) + e.readBits(l); --c; ) {
        if (s >= t)
          throw new Error("[DecodeContextMap] i >= context_map_size");
        f[s] = 0, ++s;
      }
    else
      f[s] = l - a, ++s;
  }
  return e.readBits(1) && Dw(f, t), r;
}
function sa(t, e, r, n, a, o, s) {
  var u = r * 2, f = r, l = Mr(e, r * Ut, s), c;
  l === 0 ? c = a[u + (o[f] & 1)] : l === 1 ? c = a[u + (o[f] - 1 & 1)] + 1 : c = l - 2, c >= t && (c -= t), n[r] = c, a[u + (o[f] & 1)] = c, ++o[f];
}
function Tw(t, e, r, n, a, o) {
  var s = a + 1, u = r & a, f = o.pos_ & Lr.IBUF_MASK, l;
  if (e < 8 || o.bit_pos_ + (e << 3) < o.bit_end_pos_) {
    for (; e-- > 0; )
      o.readMoreInput(), n[u++] = o.readBits(8), u === s && (t.write(n, s), u = 0);
    return;
  }
  if (o.bit_end_pos_ < 32)
    throw new Error("[CopyUncompressedBlockToOutput] br.bit_end_pos_ < 32");
  for (; o.bit_pos_ < 32; )
    n[u] = o.val_ >>> o.bit_pos_, o.bit_pos_ += 8, ++u, --e;
  if (l = o.bit_end_pos_ - o.bit_pos_ >> 3, f + l > Lr.IBUF_MASK) {
    for (var c = Lr.IBUF_MASK + 1 - f, p = 0; p < c; p++)
      n[u + p] = o.buf_[f + p];
    l -= c, u += c, e -= c, f = 0;
  }
  for (var p = 0; p < l; p++)
    n[u + p] = o.buf_[f + p];
  if (u += l, e -= l, u >= s) {
    t.write(n, s), u -= s;
    for (var p = 0; p < u; p++)
      n[p] = n[s + p];
  }
  for (; u + e >= s; ) {
    if (l = s - u, o.input_.read(n, u, l) < l)
      throw new Error("[CopyUncompressedBlockToOutput] not enough bytes");
    t.write(n, s), e -= l, u = 0;
  }
  if (o.input_.read(n, u, e) < e)
    throw new Error("[CopyUncompressedBlockToOutput] not enough bytes");
  o.reset();
}
function Pw(t) {
  var e = t.bit_pos_ + 7 & -8, r = t.readBits(e - t.bit_pos_);
  return r == 0;
}
function Bw(t) {
  var e = new Rl(t), r = new Lr(e);
  jl(r);
  var n = Gl(r);
  return n.meta_block_length;
}
function ql(t, e) {
  var r = new Rl(t);
  e == null && (e = Bw(t));
  var n = new Uint8Array(e), a = new vw(n);
  return Lw(r, a), a.pos < a.buffer.length && (a.buffer = a.buffer.subarray(0, a.pos)), a.buffer;
}
var kw = ql;
function Lw(t, e) {
  var r, n = 0, a = 0, o = 0, s, u = 0, f, l, c, p, y = [16, 15, 11, 4], v = 0, m = 0, w = 0, F = [new ir(0, 0), new ir(0, 0), new ir(0, 0)], S, I, A, M = 128 + Lr.READ_SIZE;
  A = new Lr(t), o = jl(A), s = (1 << o) - 16, f = 1 << o, l = f - 1, c = new Uint8Array(f + M + We.maxDictionaryWordLength), p = f, S = [], I = [];
  for (var L = 0; L < 3 * Ut; L++)
    S[L] = new Be(0, 0), I[L] = new Be(0, 0);
  for (; !a; ) {
    var P = 0, G, W = [1 << 28, 1 << 28, 1 << 28], ne = [0], q = [1, 1, 1], N = [0, 1, 0, 1, 0, 1], Q = [0], te, ce, j, le, K = null, re = null, de, X = null, ae, we = 0, Ee = null, Le = 0, ke = 0, ye = null, Oe = 0, Ce = 0, _ = 0, V, ie;
    for (r = 0; r < 3; ++r)
      F[r].codes = null, F[r].htrees = null;
    A.readMoreInput();
    var H = Gl(A);
    if (P = H.meta_block_length, n + P > e.buffer.length) {
      var J = new Uint8Array(n + P);
      J.set(e.buffer), e.buffer = J;
    }
    if (a = H.input_end, G = H.is_uncompressed, H.is_metadata) {
      for (Pw(A); P > 0; --P)
        A.readMoreInput(), A.readBits(8);
      continue;
    }
    if (P !== 0) {
      if (G) {
        A.bit_pos_ = A.bit_pos_ + 7 & -8, Tw(e, P, n, c, l, A), n += P;
        continue;
      }
      for (r = 0; r < 3; ++r)
        q[r] = Vl(A) + 1, q[r] >= 2 && (_n(q[r] + 2, S, r * Ut, A), _n(bw, I, r * Ut, A), W[r] = Pn(I, r * Ut, A), Q[r] = 1);
      for (A.readMoreInput(), te = A.readBits(2), ce = Ta + (A.readBits(4) << te), j = (1 << te) - 1, le = ce + (48 << te), re = new Uint8Array(q[0]), r = 0; r < q[0]; ++r)
        A.readMoreInput(), re[r] = A.readBits(2) << 1;
      var xe = Mu(q[0] << ku, A);
      de = xe.num_htrees, K = xe.context_map;
      var g = Mu(q[2] << Lu, A);
      for (ae = g.num_htrees, X = g.context_map, F[0] = new ir(gw, de), F[1] = new ir(mw, q[1]), F[2] = new ir(le, ae), r = 0; r < 3; ++r)
        F[r].decode(A);
      for (Ee = 0, ye = 0, V = re[ne[0]], Ce = Ar.lookupOffsets[V], _ = Ar.lookupOffsets[V + 1], ie = F[1].htrees[0]; P > 0; ) {
        var h, d, b, x, O, C, U, Y, oe, ge, ue;
        for (A.readMoreInput(), W[1] === 0 && (sa(q[1], S, 1, ne, N, Q, A), W[1] = Pn(I, Ut, A), ie = F[1].htrees[ne[1]]), --W[1], h = Mr(F[1].codes, ie, A), d = h >> 6, d >= 2 ? (d -= 2, U = -1) : U = 0, b = Mt.kInsertRangeLut[d] + (h >> 3 & 7), x = Mt.kCopyRangeLut[d] + (h & 7), O = Mt.kInsertLengthPrefixCode[b].offset + A.readBits(Mt.kInsertLengthPrefixCode[b].nbits), C = Mt.kCopyLengthPrefixCode[x].offset + A.readBits(Mt.kCopyLengthPrefixCode[x].nbits), m = c[n - 1 & l], w = c[n - 2 & l], ge = 0; ge < O; ++ge)
          A.readMoreInput(), W[0] === 0 && (sa(q[0], S, 0, ne, N, Q, A), W[0] = Pn(I, 0, A), we = ne[0] << ku, Ee = we, V = re[ne[0]], Ce = Ar.lookupOffsets[V], _ = Ar.lookupOffsets[V + 1]), oe = Ar.lookup[Ce + m] | Ar.lookup[_ + w], Le = K[Ee + oe], --W[0], w = m, m = Mr(F[0].codes, F[0].htrees[Le], A), c[n & l] = m, (n & l) === l && e.write(c, f), ++n;
        if (P -= O, P <= 0) break;
        if (U < 0) {
          var oe;
          if (A.readMoreInput(), W[2] === 0 && (sa(q[2], S, 2, ne, N, Q, A), W[2] = Pn(I, 2 * Ut, A), ke = ne[2] << Lu, ye = ke), --W[2], oe = (C > 4 ? 3 : C - 2) & 255, Oe = X[ye + oe], U = Mr(F[2].codes, F[2].htrees[Oe], A), U >= ce) {
            var je, et, Ve;
            U -= ce, et = U & j, U >>= te, je = (U >> 1) + 1, Ve = (2 + (U & 1) << je) - 4, U = ce + (Ve + A.readBits(je) << te) + et;
          }
        }
        if (Y = Iw(U, y, v), Y < 0)
          throw new Error("[BrotliDecompress] invalid distance");
        if (n < s && u !== s ? u = n : u = s, ue = n & l, Y > u)
          if (C >= We.minDictionaryWordLength && C <= We.maxDictionaryWordLength) {
            var Ve = We.offsetsByLength[C], It = Y - u - 1, Ot = We.sizeBitsByLength[C], Zt = (1 << Ot) - 1, Jt = It & Zt, tt = It >> Ot;
            if (Ve += Jt * C, tt < Pu.kNumTransforms) {
              var gr = Pu.transformDictionaryWord(c, ue, Ve, C, tt);
              if (ue += gr, n += gr, P -= gr, ue >= p) {
                e.write(c, f);
                for (var Qt = 0; Qt < ue - p; Qt++)
                  c[Qt] = c[p + Qt];
              }
            } else
              throw new Error("Invalid backward reference. pos: " + n + " distance: " + Y + " len: " + C + " bytes left: " + P);
          } else
            throw new Error("Invalid backward reference. pos: " + n + " distance: " + Y + " len: " + C + " bytes left: " + P);
        else {
          if (U > 0 && (y[v & 3] = Y, ++v), C > P)
            throw new Error("Invalid backward reference. pos: " + n + " distance: " + Y + " len: " + C + " bytes left: " + P);
          for (ge = 0; ge < C; ++ge)
            c[n & l] = c[n - Y & l], (n & l) === l && e.write(c, f), ++n, --P;
        }
        m = c[n - 1 & l], w = c[n - 2 & l];
      }
      n &= 1073741823;
    }
  }
  e.write(c, n & l);
}
We.init(ql);
var Mw = {
  BrotliDecompressBuffer: kw
}, Uw = Mw.BrotliDecompressBuffer;
function Nw(t, e) {
  t.prototype = Object.create(e.prototype), t.prototype.constructor = t, t.__proto__ = e;
}
var Rw = /* @__PURE__ */ (function(t) {
  Nw(e, t);
  function e() {
    return t.apply(this, arguments) || this;
  }
  var r = e.prototype;
  return r._decode = function() {
    return this._font._transformedGlyphs[this.id];
  }, r._getCBox = function() {
    return this.path.bbox;
  }, e;
})(bi), Uu = {
  decode: function(e) {
    for (var r = 0, n = [0, 1, 2, 3, 4], a = 0; a < n.length; a++) {
      var o = e.readUInt8();
      if (r & 3758096384)
        throw new Error("Overflow");
      if (r = r << 7 | o & 127, (o & 128) === 0)
        return r;
    }
    throw new Error("Bad base 128 number");
  }
}, zw = ["cmap", "head", "hhea", "hmtx", "maxp", "name", "OS/2", "post", "cvt ", "fpgm", "glyf", "loca", "prep", "CFF ", "VORG", "EBDT", "EBLC", "gasp", "hdmx", "kern", "LTSH", "PCLT", "VDMX", "vhea", "vmtx", "BASE", "GDEF", "GPOS", "GSUB", "EBSC", "JSTF", "MATH", "CBDT", "CBLC", "COLR", "CPAL", "SVG ", "sbix", "acnt", "avar", "bdat", "bloc", "bsln", "cvar", "fdsc", "feat", "fmtx", "fvar", "gvar", "hsty", "just", "lcar", "mort", "morx", "opbd", "prop", "trak", "Zapf", "Silf", "Glat", "Gloc", "Feat", "Sill"], jw = new i.Struct({
  flags: i.uint8,
  customTag: new i.Optional(new i.String(4), function(t) {
    return (t.flags & 63) === 63;
  }),
  tag: function(e) {
    return e.customTag || zw[e.flags & 63];
  },
  // || (() => { throw new Error(`Bad tag: ${flags & 0x3f}`); })(); },
  length: Uu,
  transformVersion: function(e) {
    return e.flags >>> 6 & 3;
  },
  transformed: function(e) {
    return e.tag === "glyf" || e.tag === "loca" ? e.transformVersion === 0 : e.transformVersion !== 0;
  },
  transformLength: new i.Optional(Uu, function(t) {
    return t.transformed;
  })
}), Hl = new i.Struct({
  tag: new i.String(4),
  // should be 'wOF2'
  flavor: i.uint32,
  length: i.uint32,
  numTables: i.uint16,
  reserved: new i.Reserved(i.uint16),
  totalSfntSize: i.uint32,
  totalCompressedSize: i.uint32,
  majorVersion: i.uint16,
  minorVersion: i.uint16,
  metaOffset: i.uint32,
  metaLength: i.uint32,
  metaOrigLength: i.uint32,
  privOffset: i.uint32,
  privLength: i.uint32,
  tables: new i.Array(jw, "numTables")
});
Hl.process = function() {
  for (var t = {}, e = 0; e < this.tables.length; e++) {
    var r = this.tables[e];
    t[r.tag] = r;
  }
  return this.tables = t;
};
function Vw(t, e) {
  t.prototype = Object.create(e.prototype), t.prototype.constructor = t, t.__proto__ = e;
}
var Gw = /* @__PURE__ */ (function(t) {
  Vw(e, t);
  function e() {
    return t.apply(this, arguments) || this;
  }
  e.probe = function(a) {
    return a.toString("ascii", 0, 4) === "wOF2";
  };
  var r = e.prototype;
  return r._decodeDirectory = function() {
    this.directory = Hl.decode(this.stream), this._dataPos = this.stream.pos;
  }, r._decompress = function() {
    if (!this._decompressed) {
      this.stream.pos = this._dataPos;
      var a = this.stream.readBuffer(this.directory.totalCompressedSize), o = 0;
      for (var s in this.directory.tables) {
        var u = this.directory.tables[s];
        u.offset = o, o += u.transformLength != null ? u.transformLength : u.length;
      }
      var f = Uw(a, o);
      if (!f)
        throw new Error("Error decoding compressed data in WOFF2");
      this.stream = new i.DecodeStream(new pe(f)), this._decompressed = !0;
    }
  }, r._decodeTable = function(a) {
    return this._decompress(), t.prototype._decodeTable.call(this, a);
  }, r._getBaseGlyph = function(a, o) {
    if (o === void 0 && (o = []), !this._glyphs[a])
      return this.directory.tables.glyf && this.directory.tables.glyf.transformed ? (this._transformedGlyphs || this._transformGlyfTable(), this._glyphs[a] = new Rw(a, o, this)) : t.prototype._getBaseGlyph.call(this, a, o);
  }, r._transformGlyfTable = function() {
    this._decompress(), this.stream.pos = this.directory.tables.glyf.offset;
    for (var a = qw.decode(this.stream), o = [], s = 0; s < a.numGlyphs; s++) {
      var u = {}, f = a.nContours.readInt16BE();
      if (u.numberOfContours = f, f > 0) {
        for (var l = [], c = 0, p = 0; p < f; p++) {
          var y = ua(a.nPoints);
          c += y, l.push(c);
        }
        u.points = Yw(a.flags, a.glyphs, c);
        for (var v = 0; v < f; v++)
          u.points[l[v] - 1].endContour = !0;
        ua(a.glyphs);
      } else if (f < 0) {
        var m = bi.prototype._decodeComposite.call({
          _font: this
        }, u, a.composites);
        m && ua(a.glyphs);
      }
      o.push(u);
    }
    this._transformedGlyphs = o;
  }, e;
})(pr), tr = /* @__PURE__ */ (function() {
  function t(r) {
    this.length = r, this._buf = new i.Buffer(r);
  }
  var e = t.prototype;
  return e.decode = function(n, a) {
    return new i.DecodeStream(this._buf.decode(n, a));
  }, t;
})(), qw = new i.Struct({
  version: i.uint32,
  numGlyphs: i.uint16,
  indexFormat: i.uint16,
  nContourStreamSize: i.uint32,
  nPointsStreamSize: i.uint32,
  flagStreamSize: i.uint32,
  glyphStreamSize: i.uint32,
  compositeStreamSize: i.uint32,
  bboxStreamSize: i.uint32,
  instructionStreamSize: i.uint32,
  nContours: new tr("nContourStreamSize"),
  nPoints: new tr("nPointsStreamSize"),
  flags: new tr("flagStreamSize"),
  glyphs: new tr("glyphStreamSize"),
  composites: new tr("compositeStreamSize"),
  bboxes: new tr("bboxStreamSize"),
  instructions: new tr("instructionStreamSize")
}), Hw = 253, Ww = 254, Xw = 255, Nu = 253;
function ua(t) {
  var e = t.readUInt8();
  return e === Hw ? t.readUInt16BE() : e === Xw ? t.readUInt8() + Nu : e === Ww ? t.readUInt8() + Nu * 2 : e;
}
function at(t, e) {
  return t & 1 ? e : -e;
}
function Yw(t, e, r) {
  for (var n, a = n = 0, o = [], s = 0; s < r; s++) {
    var u = 0, f = 0, l = t.readUInt8(), c = !(l >> 7);
    if (l &= 127, l < 10)
      u = 0, f = at(l, ((l & 14) << 7) + e.readUInt8());
    else if (l < 20)
      u = at(l, ((l - 10 & 14) << 7) + e.readUInt8()), f = 0;
    else if (l < 84) {
      var p = l - 20, y = e.readUInt8();
      u = at(l, 1 + (p & 48) + (y >> 4)), f = at(l >> 1, 1 + ((p & 12) << 2) + (y & 15));
    } else if (l < 120) {
      var p = l - 84;
      u = at(l, 1 + (p / 12 << 8) + e.readUInt8()), f = at(l >> 1, 1 + (p % 12 >> 2 << 8) + e.readUInt8());
    } else if (l < 124) {
      var y = e.readUInt8(), v = e.readUInt8();
      u = at(l, (y << 4) + (v >> 4)), f = at(l >> 1, ((v & 15) << 8) + e.readUInt8());
    } else
      u = at(l, e.readUInt16BE()), f = at(l >> 1, e.readUInt16BE());
    a += u, n += f, o.push(new bt(c, !1, a, n));
  }
  return o;
}
function Ru(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = Kw(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function Kw(t, e) {
  if (t) {
    if (typeof t == "string") return zu(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return zu(t, e);
  }
}
function zu(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
function Zw(t, e) {
  for (var r = 0; r < e.length; r++) {
    var n = e[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(t, n.key, n);
  }
}
function Jw(t, e, r) {
  return e && Zw(t.prototype, e), t;
}
var Qw = new i.VersionedStruct(i.uint32, {
  65536: {
    numFonts: i.uint32,
    offsets: new i.Array(i.uint32, "numFonts")
  },
  131072: {
    numFonts: i.uint32,
    offsets: new i.Array(i.uint32, "numFonts"),
    dsigTag: i.uint32,
    dsigLength: i.uint32,
    dsigOffset: i.uint32
  }
}), _w = /* @__PURE__ */ (function() {
  t.probe = function(n) {
    return n.toString("ascii", 0, 4) === "ttcf";
  };
  function t(r) {
    if (this.stream = r, r.readString(4) !== "ttcf")
      throw new Error("Not a TrueType collection");
    this.header = Qw.decode(r);
  }
  var e = t.prototype;
  return e.getFont = function(n) {
    for (var a = Ru(this.header.offsets), o; !(o = a()).done; ) {
      var s = o.value, u = new i.DecodeStream(this.stream.buffer);
      u.pos = s;
      var f = new pr(u);
      if (f.postscriptName === n)
        return f;
    }
    return null;
  }, Jw(t, [{
    key: "fonts",
    get: function() {
      for (var n = [], a = Ru(this.header.offsets), o; !(o = a()).done; ) {
        var s = o.value, u = new i.DecodeStream(this.stream.buffer);
        u.pos = s, n.push(new pr(u));
      }
      return n;
    }
  }]), t;
})();
function Qr(t) {
  var e = 0;
  if (typeof Symbol > "u" || t[Symbol.iterator] == null) {
    if (Array.isArray(t) || (t = $w(t))) return function() {
      return e >= t.length ? { done: !0 } : { done: !1, value: t[e++] };
    };
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  return e = t[Symbol.iterator](), e.next.bind(e);
}
function $w(t, e) {
  if (t) {
    if (typeof t == "string") return ju(t, e);
    var r = Object.prototype.toString.call(t).slice(8, -1);
    if (r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set") return Array.from(t);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return ju(t, e);
  }
}
function ju(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var r = 0, n = new Array(e); r < e; r++)
    n[r] = t[r];
  return n;
}
function e6(t, e) {
  for (var r = 0; r < e.length; r++) {
    var n = e[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(t, n.key, n);
  }
}
function t6(t, e, r) {
  return e && e6(t.prototype, e), t;
}
var r6 = new i.String(i.uint8);
new i.Struct({
  len: i.uint32,
  buf: new i.Buffer("len")
});
var n6 = new i.Struct({
  id: i.uint16,
  nameOffset: i.int16,
  attr: i.uint8,
  dataOffset: i.uint24,
  handle: i.uint32
}), i6 = new i.Struct({
  name: new i.String(4),
  maxTypeIndex: i.uint16,
  refList: new i.Pointer(i.uint16, new i.Array(n6, function(t) {
    return t.maxTypeIndex + 1;
  }), {
    type: "parent"
  })
}), a6 = new i.Struct({
  length: i.uint16,
  types: new i.Array(i6, function(t) {
    return t.length + 1;
  })
}), o6 = new i.Struct({
  reserved: new i.Reserved(i.uint8, 24),
  typeList: new i.Pointer(i.uint16, a6),
  nameListOffset: new i.Pointer(i.uint16, "void")
}), Vu = new i.Struct({
  dataOffset: i.uint32,
  map: new i.Pointer(i.uint32, o6),
  dataLength: i.uint32,
  mapLength: i.uint32
}), s6 = /* @__PURE__ */ (function() {
  t.probe = function(n) {
    var a = new i.DecodeStream(n);
    try {
      var o = Vu.decode(a);
    } catch {
      return !1;
    }
    for (var s = Qr(o.map.typeList.types), u; !(u = s()).done; ) {
      var f = u.value;
      if (f.name === "sfnt")
        return !0;
    }
    return !1;
  };
  function t(r) {
    this.stream = r, this.header = Vu.decode(this.stream);
    for (var n = Qr(this.header.map.typeList.types), a; !(a = n()).done; ) {
      for (var o = a.value, s = Qr(o.refList), u; !(u = s()).done; ) {
        var f = u.value;
        f.nameOffset >= 0 ? (this.stream.pos = f.nameOffset + this.header.map.nameListOffset, f.name = r6.decode(this.stream)) : f.name = null;
      }
      o.name === "sfnt" && (this.sfnt = o);
    }
  }
  var e = t.prototype;
  return e.getFont = function(n) {
    if (!this.sfnt)
      return null;
    for (var a = Qr(this.sfnt.refList), o; !(o = a()).done; ) {
      var s = o.value, u = this.header.dataOffset + s.dataOffset + 4, f = new i.DecodeStream(this.stream.buffer.slice(u)), l = new pr(f);
      if (l.postscriptName === n)
        return l;
    }
    return null;
  }, t6(t, [{
    key: "fonts",
    get: function() {
      for (var n = [], a = Qr(this.sfnt.refList), o; !(o = a()).done; ) {
        var s = o.value, u = this.header.dataOffset + s.dataOffset + 4, f = new i.DecodeStream(this.stream.buffer.slice(u));
        n.push(new pr(f));
      }
      return n;
    }
  }]), t;
})();
Hr.registerFormat(pr);
Hr.registerFormat(x2);
Hr.registerFormat(Gw);
Hr.registerFormat(_w);
Hr.registerFormat(s6);
export {
  Hr as default
};
