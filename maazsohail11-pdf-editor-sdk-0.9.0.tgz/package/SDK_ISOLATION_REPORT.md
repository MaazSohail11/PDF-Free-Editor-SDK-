# SDK isolation verification

Date: 2026-09-20. Starting commit: `dddede7`.

## Baseline

`npm run build:sdk` passed (1,932 modules). The static harness serves the actual
`dist-sdk` files and installed React peers locally: `node scripts/serve-sdk-isolation.mjs`,
then `http://127.0.0.1:5188/`. It uses a synthetic two-page PDF with a text form field.
No customer documents or credentials are involved.

Baseline mount, PDF load, text entry, drawing, highlighting, stamp selection,
export (384,652 bytes), reopen and unmount passed. Export waited on external fonts;
Dancing Script and Satisfy URLs returned 404.

### Browser-observed external URLs

The harness uses the browser's Resource Timing observer plus a fetch initiation
log. Host `gtag` and `clarity` spies detect emissions without sending analytics
to a real account. These are live runtime observations, not just source searches.
The earlier automated harness did not expose the DevTools Network panel or HAR
capture. Resource Timing did not give exhaustive cross-frame/worker traffic or
DNS preconnect coverage, so a manual Network-panel confirmation was retained as
a release check.

Observed in the baseline mount/edit/export cycle (query strings included):

```text
https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap
https://fonts.googleapis.com/css2?family=Dancing+Script:wght@400;700&family=Great+Vibes&family=Sacramento&display=swap
https://fonts.googleapis.com/css2?family=Pacifico&family=Dancing+Script:wght@400;600&family=Great+Vibes&family=Satisfy&display=swap
https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2161679270376605
https://pagead2.googlesyndication.com/pagead/managed/js/adsense/m202609160101/show_ads_impl_fy2021.js?bust=122881097
https://ep1.adtrafficquality.google/getconfig/sodar?sv=200&tid=gda&tv=r20260917&st=env&sjk=1054661267675051
https://ep2.adtrafficquality.google/sodar/sodar2.js
https://raw.githubusercontent.com/google/fonts/main/ofl/pacifico/Pacifico-Regular.ttf
https://raw.githubusercontent.com/google/fonts/main/ofl/dancingscript/DancingScript-Regular.ttf
https://raw.githubusercontent.com/google/fonts/main/ofl/greatvibes/GreatVibes-Regular.ttf
https://raw.githubusercontent.com/google/fonts/main/ofl/satisfy/Satisfy-Regular.ttf
https://pdf-export-worker.maazsohail731.workers.dev/export/increment
```

Also confirmed from source: PDF.js uses
`https://cdn.jsdelivr.net/npm/pdfjs-dist@5.4.296/legacy/build/pdf.worker.min.mjs`
inside a blob worker; this nested worker fetch is not represented in the main
document Resource Timing list. The worker is required functionality; its CDN
location is not required. Fonts support preview/export but need not be remote.
Advertising, analytics and usage counters are incidental.

No Google Analytics/Clarity library is installed by the harness. Nevertheless,
baseline SDK calls to the supplied host spies included load/edit/tool/export
Clarity events and gtag stamp/export events, including the export filename.
This shows why merely excluding website tracker script tags is insufficient.

The existing `isSDKMode` prop distinguishes the editor from the website. Before
this pass it hid navigation/ad slots but did not gate the AdSense script,
analytics helpers, counter, Google Fonts or GitHub font fetches.

## Progress

### Advertising and analytics

Gated all three editor AdSense script insertions and all editor Clarity/gtag
emission helpers with the per-instance `isSDKMode` flag. Website instances keep
their original behavior; the host's global tracking functions are not overwritten
by SDK production code.

SDK rebuild passed. Browser mount/load/text edit/export (375,841 bytes)/reopen/
unmount passed. The runtime log contained zero ad-domain requests and zero gtag
or Clarity spy calls. Fonts and export telemetry remained at this stage, as
expected; they are addressed in separate changes below.

### Hardcoded endpoints: Option A

SDK mode no longer calls either usage-counter helper. The export helper sends a
bodyless POST to `https://pdf-export-worker.maazsohail731.workers.dev/export/increment`.
The staged-upload helper sends JSON `{"delta":1}` to
`https://summer-waterfall-a2fa.maazsohail731.workers.dev/increment`. Neither helper
sends PDF bytes, but ordinary request metadata (such as client IP/origin) still
reaches the operator. No SDK telemetry opt-in/licensing system exists here; both
calls are disabled entirely for SDK instances. Website behavior is retained.
All three Adobe proxy preconnect hints are now website-only. The editor's unused
Adobe endpoint constant was removed; SDK PDF export is local.

SDK rebuild passed. Browser mount/load/local-image insertion/scaling/movement/
export (413,807 bytes)/reopen/unmount passed. The observed external list contained
only Google Fonts and GitHub fonts. No Cloudflare requests, ad requests, tracker
emissions or preconnect elements remained. The harness attaches the editor's
otherwise detached file input temporarily to support automated file selection;
this does not change SDK production code.

### Localized functional assets

The SDK build now resolves `pdf.worker.min.mjs` relative to the generated SDK
chunk and copies the exact installed `pdfjs-dist` 5.4.296 worker into `dist-sdk`.
Its SHA-256 matches the installed source worker. Pacifico, Dancing Script, Great
Vibes and Satisfy load from `dist-sdk/fonts/`; SDK CSS no longer imports Google
Fonts. Website source behavior remains unchanged. The SDK playground no longer
prefills third-party `placehold.co` branding URLs.

During testing, the former 81,140-byte Dancing Script file reproduced a
`fontkit` “Trying to access beyond buffer length” export failure. It was replaced
with the official Google Fonts `DancingScript[wght].ttf` (133,636 bytes). A direct
`pdf-lib` embed/draw/save test passed before the SDK was rebuilt.

The final generated SDK contains no occurrences of the known AdSense, ad quality,
Google Fonts, GitHub font, jsDelivr worker, Cloudflare counter, Adobe proxy,
`window.gtag`, or `window.clarity` signatures.

## Local browser storage disclosure

The SDK uses browser-origin storage for local recovery, saved stamps/signatures,
theme preference, and same-origin file handoff. Exact database/key names,
contents, lifecycle and a host clearing snippet are documented in
`SDK_DOCUMENTATION.md`. Document bytes stay in the browser origin. HTTP(S)
branding URLs supplied by a host are an explicit host-requested fetch; data URIs
keep branding offline.

## Final verification

`npm run build:sdk` passed with 1,933 transformed modules. The output contains
42 files totaling 34,436,780 bytes (32.84 MiB), 48,282 bytes (0.14%) above the
34,388,498-byte security baseline because the repaired Dancing Script font is larger.

The final built-bundle smoke test passed PDF mount/load, text insertion, drawing,
highlighting, stamp placement, local image insertion/scaling/movement, typed
Dancing Script signature insertion with metadata, page-number configuration,
blank-page add/delete, export (599,766 bytes), reopening the exported PDF, and
unmount. Page reordering was then verified separately by dragging the blank second
page ahead of the content page, exporting the reordered document (471,580 bytes),
and reopening it; the reopened file displayed “Page two” as page 1 and the original
content as page 2. The synthetic source includes an Acrobat-compatible PDF text
field. The field was manually tested in the SDK harness and accepted input as
expected during the final verification.

The harness's final runtime external-request evidence was an empty array: `[]`.
No new console warning/error was emitted by the successful final cycle. The two
console errors retained in the tab were from the earlier corrupt-font failure and
preceded the repaired build.

### Independent Network-tab confirmation

On 2026-09-26 the user manually ran the complete harness flow in DevTools:
mount → load → edit, including the Acrobat form field → export → reopen →
unmount. The Network panel showed zero uploads to the user's server and no
third-party requests; only local harness resources were present. This confirms
the SDK's zero-server-upload/offline claim for the tested flow.

The Acrobat-compatible form field was also manually edited and confirmed
functional. Page reordering had already passed the automated drag → export →
reopen check described above.

### Packaging-pass automated network confirmation (2026-09-25)

The final packaged-surface test launches installed Chrome against the generated
`dist-sdk` output and subscribes to every Playwright page request. It exercises
mount, local PDF load, page mutation, export, unmount, and two simultaneous
editor instances. The test failed on any origin other than its localhost harness;
the observed external-request array was empty. Run the same check with:

```text
npm run test:sdk-package
```

This browser-protocol check closes the earlier Resource Timing coverage gap. It
is repeatable and enforced as a failing assertion; the subsequent manual
DevTools run independently confirmed zero server uploads and zero third-party
requests.
