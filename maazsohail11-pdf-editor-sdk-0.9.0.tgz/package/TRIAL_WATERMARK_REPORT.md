# Trial SDK Watermark Verification

Branch: `watermark-trial-sdk-version`
Verification date: 2026-09-26

## Fixed wording

Every exported page contains both of these exact strings:

1. Large diagonal mark: `PDF Free Editor | pdffreeeditor.com | TRIAL`
2. Bottom mark: `PDF Free Editor Trial | https://pdffreeeditor.com/pricing`

The footer uses the explicit `https://` scheme so PDF viewers recognize the
pricing address as a live web URL instead of resolving it as a local relative
file path.

## Implementation

The marks are drawn directly onto each `pdf-lib` output page inside the core
per-page export composition in `src/components/PDFEditor.jsx`. The calls occur
for imported source pages, rotated pages, blank inserted pages, and raster
fallback pages. They are written as page content, not PDF annotations, optional
content groups, Fabric objects, or a post-export overlay.

The trial behavior is unconditional. There is no `watermark` option, branding
override, environment variable, constructor parameter, SDK callback, or hidden
test switch that suppresses either mark. Existing `brandingConfig` only controls
the separately documented host letterhead/footer feature and cannot remove the
trial marks.

The branch exposes `build:sdk:trial` as an explicit alias for the branch's
watermarked SDK build. The clean/licensed candidate remains on
`security/dependency-remediation`; no watermark source or generated output was
added there.

## Verification

Commands:

```text
npm run build:sdk:trial
npm run test:sdk-package
```

The automated browser test passed mount, local PDF load, edit, export, unmount,
two simultaneous editor instances, and zero external requests. It extracts text
from the generated PDF with PDF.js and asserts that every exported page contains
both watermark strings. The sample export had three pages after the test added a
page; all three contained both strings.

The generated export sizes increased from approximately 471 KB to approximately
473 KB, consistent with the two embedded page-content text marks.

## Build separation evidence

This branch is the trial/showcase branch and therefore its `build:sdk` output
contains the watermark strings. The parent clean branch remains unchanged. A
direct source comparison confirms the watermark constants and draw calls exist
only in this branch's working tree; the clean branch's source does not contain
them. No licensed build was modified on this branch.

## Remaining manual check

The PDF.js content assertion proves the marks are page content rather than
annotations or optional layers. A final manual attempt to select/delete them in a
full PDF editor should be recorded separately if a customer-facing trial QA
sign-off requires that exact interaction; ordinary annotation selection cannot
target these marks.
