# Dependency Security Remediation Report

## Scope

- Remediation is being performed against the current shared `frontend/package.json` dependency tree.
- The SDK was not split into a standalone package.
- Branch: `security/dependency-remediation` (already present and checked out when work began).

## Baseline

Commands:

```text
npm audit
npm audit --omit=dev
npm run build:sdk
npm run build
npm run dev
```

Results:

- Full audit: 50 vulnerabilities (3 low, 13 moderate, 29 high, 5 critical).
- Production audit: 27 vulnerabilities (11 moderate, 14 high, 2 critical).
- SDK build: pass with Vite 7.1.1.
- Web build: pass; 88 HTML documents pre-rendered.
- Baseline SDK output: 17,078.79 kB across the six emitted JavaScript files reported by Vite.

Installed direct packages called out by the brief:

| Package | Baseline installed version |
| --- | ---: |
| `@adobe/pdfservices-node-sdk` | 4.1.0 |
| `express` | 4.21.2 |
| `fabric` | 4.6.0 |
| `postcss` | 8.5.6 |
| `react-router-dom` | 7.9.1 |
| `vite` | 7.1.1 |
| `electron` | 31.7.7 |
| `electron-builder` | 24.13.3 |

### Baseline browser smoke test

| Check | Result | Evidence / note |
| --- | --- | --- |
| Mount editor | Pass | `/editor/workspace` rendered the full toolbar and canvas. |
| Load PDF | Pass | Repository `sample-ocr-test.pdf` rendered as page 1 with visible `Hello OCR` content. |
| Add text | Pass | Added and edited `Security baseline`. |
| Draw | Pass | A freehand black stroke rendered on the page. |
| Highlight | Pass | A translucent highlight rendered over `Hello OCR`. |
| Stamp | Pass | A `PAID` stamp rendered on the page. |
| Insert/upload image | Partial pass | The direct Insert Image tool creates a detached native file input that the browser driver cannot populate. The same repository `icon.png` was uploaded through the persistent image-stamp input, placed on the Fabric canvas, and moved successfully. |
| Export | Pass | Export completed and opened `/editor/export`; the in-app browser does not expose its intercepted download as a local file path, preventing an independent reopen in this run. |
| Console | Existing warnings | Two pre-existing custom-font HTTP 404 warnings for Dancing Script and Satisfy appeared during export; no errors were observed. |

## Phase 1: non-force audit fix

`npm audit fix` initially stopped without changes because the installed `vite-plugin-css-injected-by-js@5.0.2` declares a Vite 8+ peer while the baseline uses Vite 7.1.1. The already-working dependency pair was preserved and the non-force fix was rerun as:

```text
npm audit fix --legacy-peer-deps
```

No `--force` operation was used.

Direct installed-version changes made through the lockfile:

| Package | Before | After |
| --- | ---: | ---: |
| `concurrently` | 9.2.1 | 9.2.4 |
| `express` | 4.21.2 | 4.22.2 |
| `postcss` | 8.5.6 | 8.5.28 |
| `react-router-dom` | 7.9.1 | 7.18.3 |
| `vite` | 7.1.1 | 7.3.6 |

Verification:

- SDK build: pass.
- Web build: pass; 88 HTML documents pre-rendered.
- Browser smoke: PDF load, text insertion, drawing, highlighting, saved image overlay placement, and export-page generation all pass.
- Export page identified `sample-ocr-test_edited.pdf` at 0.42 MB.
- Phase 1 SDK output: 17,075.26 kB, a decrease of 3.53 kB (about 0.02%); no material size change.
- Full audit after Phase 1: 22 vulnerabilities (9 moderate, 10 high, 3 critical).
- Production audit after Phase 1: 14 vulnerabilities (9 moderate, 2 high, 3 critical).

Remaining critical/high roots after Phase 1:

- Production: `fabric` 4.6.0 and its legacy Node-only dependency chain (`jsdom` / `request` / `form-data` / `tar`).
- Development/full tree: `electron` 31.7.7 and `electron-builder` 24.13.3.

## Final SDK bundle verification

Verification date: 2026-09-06.

The distributed SDK was rebuilt from the current lockfile with the exact package script:

```text
npm run build:sdk
```

The Vite 7.3.6 build completed successfully after transforming 1,932 modules. The resulting `dist-sdk` directory contains 42 files totaling 34,388,498 bytes (32.795 MiB). Seven JavaScript files total 18,165,064 bytes (17.324 MiB), including the copied PDF.js worker. The six application chunks emitted and measured directly by Vite total 17,075.25 kB.

No source maps or bundle-analyzer dependency are configured. Verification therefore used the generated JavaScript itself: emitted import statements, exact package/module specifiers, and distinctive runtime symbols taken from the installed vulnerable packages. Generic word matches were reviewed separately so that PDF terminology, minified identifiers such as `qs`, and UUID fields were not mistaken for npm package code.

| Package/module | Found in `dist-sdk`? | Direct bundle evidence | Conclusion |
| --- | --- | --- | --- |
| `fabric` browser code | Yes | `PDFEditor-BIYXUkKB.js` contains Fabric version `4.6.0`, `Gradient`, `loadFromJSON`, and SVG serialization methods. | Expected; this is the assessed and deferred Fabric risk. |
| `tar` | No | No module specifier and none of `TAR_BAD_ARCHIVE`, `TAR_ENTRY_ERROR`, `SAW_VALID_ENTRY`, or `maxMetaEntrySize`. | Audited tar implementation is absent. |
| `node-pre-gyp` / `@mapbox/node-pre-gyp` | No | No package name, module specifier, or runtime signature. | Fabric's optional native canvas installation tooling is absent. |
| `jsdom` | No implementation | Fabric's dormant Node fallback retains `JSDOM` and `cleanUpJsdomNode` identifiers, but Vite maps Fabric's `jsdom` imports to an empty browser module. No `VirtualConsole`, `NoOpResourceLoader`, `normalizeHTML`, or other jsdom implementation symbols are present. | The vulnerable jsdom package is not bundled. |
| Fabric optional `canvas` package | No implementation | Fabric's package declares `canvas: false` in its browser map. The bundle contains no `require("canvas")`, `node-pre-gyp`, or native canvas package code. | The audited `canvas -> node-pre-gyp -> tar` chain is absent. |
| `request` | No | No module specifier and none of `requestToJSON`, `filterOutReservedFunctions`, `forever-agent`, or `har-validator`. | Package implementation is absent. |
| `form-data` | No | No module specifier and none of `_multiPartHeader`, `_multiPartFooter`, or `_overheadLength`. | Package implementation is absent. |
| `tough-cookie` | No | No module specifier and none of `COOKIE_OCTETS`, `MemoryCookieStore`, or the package name. | Package implementation is absent. |
| `qs` | No | No module specifier and none of `parseQueryStringValues`, `strictNullHandling`, `allowPrototypes`, `parameterLimit`, or `arrayLimit`. Short `qs`/`Qs` tokens are unrelated minified identifiers. | Package implementation is absent. |
| `uuid` | No | No module specifier and none of `bytesToUuid` or `clock_seq_hi_and_reserved`. UUID fields in PDF.js are unrelated. | Vulnerable npm uuid implementations are absent. |
| `express` | No | No module specifier and none of `express:application`, `expressInit`, `x-powered-by`, or `trust_proxy_default`. | Server package is absent. |
| Adobe PDF Services Node SDK | No | No `@adobe/pdfservices-node-sdk`, `ServicePrincipalCredentials`, or `PDFServicesJobStatus`. Generic Adobe PDF/font metadata and the application's proxy URL are unrelated. | Adobe Node SDK implementation is absent. |
| `electron` / `electron-builder` | No | No Electron module specifier, `BrowserWindow`, `electron-builder`, or `extract-zip`. | Desktop runtime and packaging code are absent. |
| `app-builder-lib` / `builder-util` | No | No package names or distinctive runtime references. | Desktop build-chain implementation is absent. |

One unrelated guarded Node fallback string, `@napi-rs/canvas`, is retained by PDF.js. It is guarded by PDF.js's Node-environment detection, is not the Fabric optional `canvas` package, and does not include or resolve the audited `canvas`, `node-pre-gyp`, or `tar` dependency chain in the browser SDK bundle.

### SDK security disposition

Fabric 4.6.0 ships in the SDK bundle and contains two known advisories: CVE-2026-27013 and CVE-2026-44311. Both require Fabric's SVG serialization path (`toSVG()` and, for CVE-2026-44311, attacker-controlled `fabric.Gradient` color stops) followed by browser rendering of the generated SVG. Source tracing confirms that the SDK never calls these vulnerable methods, and the public SDK API does not expose Fabric or a Fabric canvas instance.

Direct inspection of the built SDK confirms that the unrelated vulnerable transitive implementations are absent. The small amount of Fabric Node-fallback scaffolding retained in the browser chunk points only to empty browser stubs and cannot load jsdom or the native canvas toolchain. Reassess this disposition immediately if SVG import/export, shared Fabric JSON, or DOM rendering of Fabric-generated SVG is introduced.

All other outstanding npm audit findings—including Express, Adobe PDF Services, Electron, electron-builder, and the shared installed-tree tar chain—belong to server, website/desktop, build-time, or Node-only optional dependency paths. They are confirmed absent from the distributed SDK implementation and remain tracked separately as non-SDK backlog items.

**Bundle verification confirms the prior assessment that only Fabric's two known advisory implementations are present in the shipped SDK bundle.**
