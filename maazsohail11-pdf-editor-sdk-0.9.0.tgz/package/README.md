# PDF Editor SDK

`@maazsohail11/pdf-editor-sdk` embeds the PDF Free Editor experience in a host
web application. Document editing and export run in the browser. This branch is
the non-removable trial/showcase build: every exported page carries the trial
watermarks documented below. The clean/licensed candidate remains on the
`security/dependency-remediation` branch.

The packaged
SDK includes its PDF.js worker and required signature fonts, and it does not
emit advertising, analytics, or product telemetry.

The current release is a proprietary prerelease (`0.9.0`). A commercial license
agreement is required; the repository's `UNLICENSED` metadata does not grant
permission to copy, redistribute, or sell the software.

## Install

```bash
npm install @maazsohail11/pdf-editor-sdk react react-dom
```

## One-command self-host trial

For a local trial on a machine with Node.js 20.19 or newer, run this readable
PowerShell launcher:

```powershell
irm https://raw.githubusercontent.com/MaazSohail11/PDF-Editor-sdk/watermark-trial-sdk-version/scripts/start-trial.ps1 | iex
```

The launcher asks whether you have a license. Answering `Y` only prints the
access contact message and exits. Answering `N` downloads the
`watermark-trial-sdk-version` branch, installs dependencies, builds the
watermarked SDK, and starts the local editor at `http://127.0.0.1:5188/`.
Read the launcher source before running it:
[start-trial.ps1](https://github.com/MaazSohail11/PDF-Editor-sdk/blob/watermark-trial-sdk-version/scripts/start-trial.ps1).

React and React DOM versions `>=18.2 <20` are peer dependencies.

## Minimal use

```js
import { VanillaPDFEditor } from "@maazsohail11/pdf-editor-sdk";

const container = document.getElementById("pdf-editor");
const response = await fetch("/documents/example.pdf");
const file = new File([await response.blob()], "example.pdf", {
  type: "application/pdf",
});

const editor = new VanillaPDFEditor(container, {
  file,
  theme: "system",
  onReady: () => console.log("Editor ready"),
  onError: ({ phase, error }) => console.error(phase, error),
  onExport: exportedFile => {
    const url = URL.createObjectURL(exportedFile);
    const link = document.createElement("a");
    link.href = url;
    link.download = exportedFile.name;
    link.click();
    URL.revokeObjectURL(url);
  },
});

// Later:
editor.updateOptions({ theme: "dark" });
editor.unmount();
```

The host element must have a useful height. The SDK renders into an open Shadow
DOM so its styles do not leak into the host page and aggressive host resets do
not restyle the editor.

See [SDK_SPEC.md](./SDK_SPEC.md) for the verified API, integration requirements,
bundle contents, offline behavior, security disposition, and current limitations.
