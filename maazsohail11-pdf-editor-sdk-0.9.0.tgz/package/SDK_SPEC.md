# PDF Editor SDK Technical Specification

Verified against trial branch `watermark-trial-sdk-version`, package version
`0.9.0`, on 2026-09-26.

## Package identity and status

| Field | Value |
| --- | --- |
| Package | `@maazsohail11/pdf-editor-sdk` |
| Version | `0.9.0` (prerelease) |
| License | Proprietary/commercial; package metadata is `UNLICENSED` |
| Repository | `https://github.com/MaazSohail11/PDF-Editor-sdk` |
| Runtime | Browser |
| Peer dependencies | `react` and `react-dom`, versions `>=18.2 <20` |

This branch is the trial/showcase build. It is technically distributable for
evaluation but is not ready for unrestricted
public sale: license-key enforcement, entitlement checks, and a kill switch have
not been implemented. Commercial license terms must also be supplied outside the
package before delivery to a customer.

Every export from this branch permanently includes these two page-content marks:

- Large diagonal: `PDF Free Editor | pdffreeeditor.com | TRIAL`
- Bottom branding: `PDF Free Editor Trial | https://pdffreeeditor.com/pricing`

They are drawn into each page's content stream during the same per-page PDF
composition that draws copied content and editor changes. They are not options,
annotations, layers, branding configuration, or removable SDK objects.

## Installation

Registry installation, once the package is published:

```bash
npm install @maazsohail11/pdf-editor-sdk react react-dom
```

### Self-hosted trial launcher

Evaluators with Node.js 20.19 or newer can run the watermarked trial locally:

```powershell
irm https://raw.githubusercontent.com/MaazSohail11/PDF-Editor-sdk/watermark-trial-sdk-version/scripts/start-trial.ps1 | iex
```

The transparent launcher source is available at
`scripts/start-trial.ps1`. It downloads only the trial branch, and the `Y`
license response exits with a contact message; it does not perform license
verification.

A private tarball can be installed without publishing it:

```bash
npm install ./maazsohail11-pdf-editor-sdk-0.9.0.tgz react react-dom
```

The package exports both an ES module entry and a CommonJS compatibility entry.
ESM is recommended for browser bundlers:

```js
import VanillaPDFEditor, {
  VanillaPDFEditor as NamedVanillaPDFEditor,
} from "@maazsohail11/pdf-editor-sdk";
```

CommonJS resolution is supported through a small asynchronous bridge:

```js
const { VanillaPDFEditor } = require("@maazsohail11/pdf-editor-sdk");
```

The CommonJS constructor begins an internal dynamic import; use `onReady` rather
than assuming the UI is mounted synchronously. Both entry points were installed
from a generated tarball and resolved from a separate clean consumer project.

A classic `<script src>`/UMD global is not currently supplied. For manual
distribution, serve the complete package with an ESM-capable bundler or host the
contents of `dist-sdk` without changing their relative layout. Do not copy only
the entry file: its lazy chunks, worker, fonts, and WebAssembly dependencies are
required.

## Minimal working example

The following example was exercised against the built SDK in Chrome using a
synthetic local PDF:

```html
<div id="pdf-editor" style="height: 850px"></div>
<script type="module">
  import { VanillaPDFEditor } from "@maazsohail11/pdf-editor-sdk";

  const response = await fetch("/example.pdf");
  const file = new File([await response.blob()], "example.pdf", {
    type: "application/pdf",
  });

  const editor = new VanillaPDFEditor(
    document.getElementById("pdf-editor"),
    {
      file,
      theme: "system",
      onReady() {
        console.log("PDF editor mounted");
      },
      onChange({ reason, pageIndex, pageCount }) {
        console.log("PDF changed", { reason, pageIndex, pageCount });
      },
      onError({ phase, error }) {
        console.error(`PDF editor ${phase} failure`, error);
      },
      onExport(exportedFile) {
        const url = URL.createObjectURL(exportedFile);
        const link = document.createElement("a");
        link.href = url;
        link.download = exportedFile.name || "edited.pdf";
        link.click();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
      },
    },
  );

  // Call this when the host view is destroyed:
  // editor.unmount();
</script>
```

`file` accepts a `Blob` or `File`, not a URL string. Fetch remote files in the
host application, apply the host's authentication/CORS policy, and pass the
resulting blob to the SDK.

## Public API

### `new VanillaPDFEditor(container, options?)`

Mounts one editor into an `HTMLElement`. The SDK attaches an open Shadow DOM to
the supplied element and creates its own React root inside it.

An alternate constructor form is supported:

```js
new VanillaPDFEditor({ containerId: "pdf-editor", file, onExport });
```

Construction throws when no valid container can be resolved. Supply `onError`
to receive the same mount error as a structured callback.

### `updateOptions(options)`

Merges a partial options object and rerenders the mounted editor. `theme`,
`brandingConfig`, callbacks, and `file` can be updated. This method returns
`void` in the ESM implementation.

### `unmount()`

Unmounts React, removes the SDK mount point, and removes the stylesheet injected
into the shadow root. Call it before the host removes or reuses the container.

### Options

| Option | Type | Behavior |
| --- | --- | --- |
| `file` | `Blob` | PDF input. A `File` is accepted because it extends `Blob`. URL strings are rejected by TypeScript and are not fetched internally. |
| `theme` | `"light" \| "dark" \| "system"` | Selects the initial theme and responds to `updateOptions`. When omitted, the editor's locally stored preference is used. |
| `brandingConfig` | `PDFEditorBrandingConfig` | Initializes graphical letterhead/footer export settings. Users can adjust the same settings in Header & Footer. |
| `onReady` | `() => void` | Fires once after the lazy editor component mounts. |
| `onChange` | `(event) => void` | Fires after a meaningful document mutation. It is not a keystroke-level audit log. |
| `onError` | `(event) => void` | Reports mount, load, export, and callback/runtime failures. |
| `onExport` | `(file: File) => void` | Receives the locally generated edited PDF when the user completes Export. |

`isSDKMode` is internal and cannot be overridden by a host.

### Change event

```ts
interface PDFEditorChangeEvent {
  reason: string;
  file: Blob;
  pageIndex: number;
  pageCount: number;
}
```

### Error event

```ts
interface PDFEditorErrorEvent {
  phase: "mount" | "load" | "export" | "runtime";
  error: Error;
}
```

### Branding configuration

```ts
interface PDFEditorBrandingConfig {
  headerAsset?: string;
  footerAsset?: string;
  topMargin?: number;       // PDF points; default 100
  bottomMargin?: number;    // PDF points; default 50
  usePrebuiltMargins?: boolean;
  onWarning?: (message: string) => void;
}
```

`headerAsset` and `footerAsset` accept PNG/JPEG data URIs or HTTP(S) URLs. Data
URIs keep the export path offline. A URL is an explicit host-requested external
fetch and must satisfy CORS. `usePrebuiltMargins: false` enlarges each page for
the selected header/footer margins; `true` stamps onto existing page margins.

## Feature surface

The packaged editor provides PDF loading, text and image placement, freehand
drawing, highlights, sticky notes, stamps, visual signatures, form interaction,
page add/delete/reorder/rotation, header/footer/page numbers, graphical
letterhead/footer branding, merge, and browser-local export.

Visual signatures are flattened marks with descriptive metadata. They are not
cryptographic signatures and do not provide tamper evidence, identity
verification, legal non-repudiation, an audit trail, or AATL compliance.

## Bundle and loading characteristics

The current clean `dist-sdk` build contains 12 files totaling 19,238,101 bytes
(18.35 MiB) before npm compression. The ESM entry is about 227 kB raw/36 kB gzip.
The largest component is MuPDF at 13,175,603 bytes raw (about 5.51 MB gzip); it is
emitted as a separate dynamic chunk and is not part of the initial entry payload.
The PDF editor implementation, font engine, PDF.js worker, and signature fonts
are likewise separate files loaded only when their code paths need them.

The published allowlist contains only `dist-sdk`, declarations, the license, and
SDK documentation/reports. Website images, SEO files, Electron files, redirects,
sitemaps, and unrelated site fonts are excluded.

## Browser compatibility

The complete packaged flow was tested on Windows with Google Chrome
`153.0.8010.53`: mount, PDF load, page edit, export, unmount, two simultaneous
instances, Shadow DOM style isolation, and zero external requests all passed.
The user also confirmed the same result manually in the browser Network panel:
the complete flow made zero uploads to the user's server and no third-party
requests. Acrobat-compatible form-field editing was manually tested and passed.

The implementation requires ES modules, dynamic import, WebAssembly, Web Workers,
Shadow DOM, IndexedDB, `Blob`/`File`, and modern Canvas APIs. Other Chromium,
Firefox, and Safari versions have not been certified in this pass; no unsupported
browser-version claim is made. A cross-browser matrix remains release validation
work before promising named browser/version support contractually.

## Dependencies included in the browser SDK

Current direct runtime implementations verified in the generated chunks include:

| Component | Version | Purpose |
| --- | ---: | --- |
| Fabric.js | 4.6.0 | Canvas editing and visual object model |
| PDF.js (`pdfjs-dist`) | 5.4.296 | PDF parsing/rendering and the bundled worker |
| MuPDF | 1.26.4 | Advanced PDF processing; lazy chunk |
| `pdf-lib` | 1.17.1 | PDF generation/post-processing |
| `@pdf-lib/fontkit` | 1.1.1 | Custom font embedding |
| React / React DOM | `>=18.2 <20` peer | Host-installed rendering runtime |

The SDK package does not ship Express, Adobe PDF Services Node SDK, Electron,
electron-builder, tar, node-pre-gyp, jsdom, request, form-data, tough-cookie, qs,
or uuid implementations. Those packages may exist in the shared development
tree but are absent from the published browser bundle.

The clean/licensed candidate is maintained on the `security/dependency-remediation`
branch. This trial branch intentionally contains the watermark code and output.

## Security disposition

Fabric 4.6.0 contains CVE-2026-27013 and CVE-2026-44311. Both concern Fabric SVG
serialization/rendering paths. Source tracing found no SDK calls to the vulnerable
`toSVG()`/gradient path, and the public API exposes neither Fabric nor its canvas.
The finding remains documented and deferred to a dedicated Fabric upgrade.

Direct bundle inspection confirmed that unrelated vulnerable Node/server/desktop
packages are absent. See [SECURITY_REMEDIATION_REPORT.md](./SECURITY_REMEDIATION_REPORT.md)
for advisory evidence and the conditions that require reassessment.

## Offline and storage disposition

The default SDK path makes no external network request. Its PDF.js worker and
required fonts are local package assets; ads, analytics, Clarity, usage counters,
and SDK-owned CDN URLs are disabled or removed from SDK mode. The packaged
Chrome test captured every page request during mount, load, edit, export,
multi-instance use, and unmount and observed an empty external-request list.

Offline behavior is conditional on host input: an HTTP(S) branding asset is
fetched because the host explicitly requested it. Use data URIs for completely
offline branding. See [SDK_ISOLATION_REPORT.md](./SDK_ISOLATION_REPORT.md) for the
full audit and browser-local storage disclosure.

## Current limitations and release prerequisites

- No license-key enforcement, entitlement service, usage enforcement, or kill
  switch exists. This is the primary open prerequisite before public sale.
- No cryptographic/AATL digital-signature module is included.
- Visual signatures carry no legal-validity or non-repudiation guarantee.
- No classic UMD/script-global build is provided.
- This branch is not the clean/licensed SDK build; every export is watermarked.
- Firefox, Safari, Edge, and mobile browser versions were not certified in this
  packaging pass.
- The Fabric advisories remain open in the installed tree under the documented,
  currently unreachable SVG conditions.
