export type PDFEditorTheme = "light" | "dark" | "system";

export interface PDFEditorChangeEvent {
  reason: string;
  file: Blob;
  pageIndex: number;
  pageCount: number;
}

export interface PDFEditorErrorEvent {
  phase: "mount" | "load" | "export" | "runtime";
  error: Error;
}

export interface PDFEditorBrandingConfig {
  /** PNG/JPEG data URI or an intentionally networked HTTP(S) URL. */
  headerAsset?: string;
  /** PNG/JPEG data URI or an intentionally networked HTTP(S) URL. */
  footerAsset?: string;
  /** Header area height in PDF points. Defaults to 100. */
  topMargin?: number;
  /** Footer area height in PDF points. Defaults to 50. */
  bottomMargin?: number;
  /** Stamp over existing margins instead of elongating the PDF page. */
  usePrebuiltMargins?: boolean;
  onWarning?: (message: string) => void;
}

export interface PDFEditorOptions {
  /** PDF data to load. URL strings are not accepted; fetch them as a Blob first. */
  file?: Blob;
  theme?: PDFEditorTheme;
  brandingConfig?: PDFEditorBrandingConfig;
  onReady?: () => void;
  onChange?: (event: PDFEditorChangeEvent) => void;
  onError?: (event: PDFEditorErrorEvent) => void;
  onExport?: (file: File) => void;
}

export interface PDFEditorOptionsWithContainer extends PDFEditorOptions {
  containerId: string;
}

export declare class VanillaPDFEditor {
  constructor(container: HTMLElement, options?: PDFEditorOptions);
  constructor(options: PDFEditorOptionsWithContainer);
  updateOptions(options: Partial<PDFEditorOptions>): void;
  unmount(): void;
}

export default VanillaPDFEditor;
